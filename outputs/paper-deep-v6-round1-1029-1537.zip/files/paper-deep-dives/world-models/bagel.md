---
paper_date: 2025-05
paper_title: "Emerging Properties in Unified Multimodal Pretraining"
paper_topic: 世界模型
---

# BAGEL：交错多模态预训练中的世界建模涌现

!!! info "论文信息"
    **论文题名：** Emerging Properties in Unified Multimodal Pretraining。<br>
    **作者：** Chaorui Deng、Deyao Zhu、Kunchang Li、Chenhui Gou、Feng Li、Zeyu Wang、Shu Zhong、Weihao Yu、Xiaonan Nie、Ziang Song 等（共 12 人）。<br>
    **机构：** ByteDance Seed,、Shenzhen Institutes of Advanced Technology,、Monash University、Hong Kong University of Science and Technology,。<br>
    **时间 / 主题：** 2025-05；世界模型。<br>
    **arXiv / 官方报告：** arXiv：[2505.14683](https://arxiv.org/abs/2505.14683)；官方材料：[bagel-ai.org/](https://bagel-ai.org/)。<br>
    **GitHub / 项目：** GitHub：[github.com/ByteDance-Seed/Bagel](https://github.com/ByteDance-Seed/Bagel)；项目页：[bagel-ai.org/](https://bagel-ai.org/)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2505.14683)；[GitHub API / repo](https://github.com/ByteDance-Seed/Bagel)；[官方 / 项目材料](https://bagel-ai.org/)；Checked Date：2026-06-04；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

| Checked Date | Repro Status | 本页证据口径 |
| --- | --- | --- |
| 2026-06-02 | Author code / checkpoints reported | 以 arXiv HTML、项目页与论文图表为主；future frame prediction、3D manipulation、world navigation 按论文 qualitative/demo evidence 解读。 |

## 理解与生成怎样在同一个上下文中协作

BAGEL 试图让图文理解、图像生成和复杂编辑共享长期交错上下文。相比 LLM 先把语义压缩成少数条件 token 再交给外部 diffusion generator，它让两类任务在每层 attention 交换信息，同时为理解和生成保留专用参数。最终模型为 14B 总参数、每 token 激活约 7B；统一上下文并不要求所有参数与视觉表示完全相同。[↗](https://arxiv.org/pdf/2505.14683#page=3)

## 两种视觉表示怎样进入 MoT

![BAGEL architecture 原图](../../assets/images/paper-deep-dives/world-models/bagel/figure-2-architecture.png)

*原论文 Figure 2。先追踪语义 encoder 与 VAE 两条输入，再看 shared attention 如何连接专用专家。*

理解路径采用 SigLIP2 ViT，提供与语言相关的语义；生成路径采用冻结 FLUX VAE，保留空间细节。VAE 下采样 8 倍、16 channels，再经过 $2\times2$ patch embedding。Qwen2.5 初始化的理解专家处理 text/ViT tokens，复制得到的生成专家处理 VAE tokens。两边有各自 QKV 和 FFN，却在同一 token 序列上执行 multimodal attention。[↗](https://arxiv.org/pdf/2505.14683#page=5)

文本使用 next-token cross-entropy，图像使用 rectified-flow velocity prediction。MoT 消融只在 Qwen2.5-1.5B 基础规模进行，generation:understanding sampling 为 4:1；dense、仅复制 FFN 的 MoE、复制完整 Transformer 的 MoT 保持 active FLOPs 相同，MoT 总参数更多。

![BAGEL loss designs 原图](../../assets/images/paper-deep-dives/world-models/bagel/figure-3-loss-designs.png)

*原论文 Figure 3。分别看 CE 与 generation MSE，MoT 的生成优化优势更明显；这支持专用容量减轻目标竞争，但不是大模型尺度上的单独因果证明。*

## causal mask 必须区分 clean context 与 noisy target

每张图可对应 ViT tokens、clean VAE tokens 和 noisy VAE tokens。标准交错生成时，后续文本或图像看前面图像的 clean VAE/ViT，不能把训练中的 noisy target 当作已经生成的事实。一个视觉 split 内部双向 attention，文本内部 causal，不同 split 按顺序依赖。

![BAGEL causal mask 原图](../../assets/images/paper-deep-dives/world-models/bagel/figure-15-causal-mask.png)

*原论文 Figure 15。阅读入口是 clean/noisy token 类型，再检查哪些跨块连接被允许。*

推理缓存 clean VAE 与 ViT 的 KV；图像去噪结束后以 clean 表示进入后续上下文。多图 generation 还采用独立 noise levels 的 diffusion forcing，并随机将相邻图分组、在组内 full attention。这些规则处理的是交错生成的信息可见性，不是外部物理世界的因果保证。[↗](https://arxiv.org/pdf/2505.14683#page=5)

## 交错数据比独立图文对多提供什么

视频天然给出对象身份、视角与状态变化的连续关系。web documents 则提供概念相关、但未必逐像素连续的图文序列；二者对应不同学习信号。

![BAGEL video interleaved data pipeline 原图](../../assets/images/paper-deep-dives/world-models/bagel/figure-4-video-data-pipeline.png)

*原论文 Figure 4a。先看视频过滤，再看 temporally grounded caption 怎样描述帧间变化。*

![BAGEL web interleaved data pipeline 原图](../../assets/images/paper-deep-dives/world-models/bagel/figure-4-web-data-pipeline.png)

*原论文 Figure 4b。web pipeline 在 topic selection 后做质量过滤与 caption，处理松散文本和图片的对齐。*

数据池含 45M video interleaved samples、20M web interleaved documents，并构造约 500k reasoning-augmented examples。数据池大小不等于实际 seen tokens，因为训练随机采样。alignment 先只训练连接器；PT 训练 2.5T tokens，CT 增加分辨率及交错数据比例、训练 2.6T，SFT 为 72.7B；CE:MSE loss weight 在后三阶段为 0.25:1。[↗](https://arxiv.org/pdf/2505.14683#page=10)

## “涌现”在这里用什么观察定义

历史 checkpoints 展示理解和一般生成先成熟，编辑及 intelligent editing 更晚。原文以达到最终峰值 85% 所需 tokens 比较：understanding 约 0.18T，generation 0.68T，classical editing 2.64T，intelligent editing 3.61T。它反映同一训练轨迹中能力增长的时点；CT 同时改变分辨率和数据混合，因此不能把转折全部归于 token 数这一单变量。[↗](https://arxiv.org/pdf/2505.14683#page=13)

IntelligentBench 有 350 examples，输入 question image/text，参考 answer image，由 GPT-4o-2024-11-20 对生成结果按 0–2 评分，再归一化至百分制。它检查 request fulfillment、visual consistency 和 knowledge-grounded creativity。与 GenEval 相比，任务更依赖跨模态知识与转换；它仍是作者构造的自动评测，分数含 evaluator 的判断。

![BAGEL navigation and rotation 原图](../../assets/images/paper-deep-dives/world-models/bagel/figure-14-navigation-rotation.png)

*原论文 Figure 14。沿连续指令追踪对象身份、视角与布局变化，这些定性结果展示 visual manipulation 与 navigation 的可能性。*

世界建模演示说明交错预训练可学到部分可控视觉变化，不能直接等同于经过真实环境回报验证的闭环策略。对实际系统，BAGEL 最值得借鉴的是让语义表示和细节表示都能进入生成上下文，并从数据构造、mask 和缓存三处共同保证多轮信息能够传递。
