---
paper_date: 2019-12
paper_title: "Dream to Control: Learning Behaviors by Latent Imagination"
paper_topic: 世界模型
---

# Dreamer：在 latent imagination 里训练 actor-critic

!!! info "论文信息"
    **论文题名：** Dream to Control: Learning Behaviors by Latent Imagination。<br>
    **作者：** Danijar Hafner、Timothy Lillicrap、Jimmy Ba、Mohammad Norouzi。<br>
    **机构：** 未在公开元数据中稳定解析；以 arXiv/PDF 或官方页 affiliation block 为准。<br>
    **时间 / 主题：** 2019-12；世界模型。<br>
    **arXiv / 官方报告：** arXiv：[1912.01603](https://arxiv.org/abs/1912.01603)；官方材料：[danijar.com/project/dreamer/](https://danijar.com/project/dreamer/)。<br>
    **GitHub / 项目：** GitHub：[github.com/danijar/dreamer](https://github.com/danijar/dreamer)；项目页：[danijar.com/project/dreamer/](https://danijar.com/project/dreamer/)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/1912.01603)；[GitHub API / repo](https://github.com/danijar/dreamer)；[官方 / 项目材料](https://danijar.com/project/dreamer/)；Checked Date：2026-06-15；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 从每步搜索转向学习会行动的模型

Dreamer 接续 PlaNet 的 latent dynamics，但改变了利用模型的方式。PlaNet 在每个真实时间步搜索动作序列，有限规划窗外的奖励难以进入评价；Dreamer 在模型里训练 actor 和 critic，让 critic 为窗口外的未来提供价值，让 actor 将反复搜索摊销成一次网络预测。核心贡献发生在行为学习，不是重新发明 RSSM。[↗](https://arxiv.org/pdf/1912.01603#page=1)

![Dreamer overview 原论文图](../../assets/images/paper-deep-dives/world-models/dreamer/figure-1-overview.png)

*原论文 Figure 1。沿 experience → dynamics → imagined behavior 阅读，注意策略训练的轨迹来自模型。*

## 三个阶段使用不同的信息

原图中的三个面板有明确分工。先从 replay 的真实图像、动作与奖励训练模型；然后从真实轨迹推断的 latent 出发，在模型里生成未来，训练 actor-critic；最后在环境中执行 actor，收集新的训练资料。

![Dreamer components 原论文图](../../assets/images/paper-deep-dives/world-models/dreamer/figure-3-components.png)

*原论文 Figure 3。只有模型学习和真实交互阶段接收对应时刻的真实图像。*

原文使用 $p_\theta(s_t\mid s_{t-1},a_{t-1},o_t)$ 表示 representation，使用 $q_\theta(s_t\mid s_{t-1},a_{t-1})$ 表示不接收当前观测的 transition，并从 $s_t$ 预测 reward。这里的 $p/q$ 命名应按本文理解，不应直接套用其他 VAE 论文的惯例。实现使用 RSSM，让 deterministic recurrent state 与 stochastic state 一起承担记忆和预测。[↗](https://arxiv.org/pdf/1912.01603#page=2)

模型可以通过 reward prediction、image reconstruction 或 contrastive estimation 学习。Dreamer 的主要结果采用图像重建信号。在有限数据、尤其稀疏奖励下，单独奖励监督很难告诉表示应保留哪些尚未产生奖励的环境信息。重建不必参与未来策略 rollout，却能在学习阶段提供密集约束。

## 价值如何穿过想象轨迹到达动作

actor 以可重参数化的方式输出连续动作

$$
a_\tau=\tanh\bigl(\mu_\phi(s_\tau)+\sigma_\phi(s_\tau)\epsilon\bigr),\qquad \epsilon\sim\mathcal N(0,I).
$$

这样动作采样可以看成噪声固定时的可微函数。后续状态、奖励与价值都是神经网络输出，梯度能够沿“动作 → transition → future reward/value”返回 actor。[↗](https://arxiv.org/pdf/1912.01603#page=4)

仅把窗口内奖励相加会使策略短视。论文式 5–6 使用带 bootstrap 的多步回报

$$
V_N^k(s_\tau)=\mathbb E\left[\sum_{n=\tau}^{h-1}\gamma^{n-\tau}r_n+\gamma^{h-\tau}v_\psi(s_h)\right],\qquad h=\min(\tau+k,t+H),
$$

$$
V_\lambda(s_\tau)=(1-\lambda)\sum_{n=1}^{H-1}\lambda^{n-1}V_N^n(s_\tau)+\lambda^{H-1}V_N^H(s_\tau).
$$

$H$ 是 imagination horizon，$v_\psi$ 估计延伸到窗口之外的价值，$\lambda$ 混合不同长度的回报。短回报更多依赖 critic，长回报更多依赖多步模型预测；混合缓和两者的偏差和方差取舍。actor 最大化这些价值估计，critic 则回归停止梯度的 $V_\lambda$。训练行为时世界模型参数固定，避免 actor 通过修改世界模型把想象回报抬高。[↗](https://arxiv.org/pdf/1912.01603#page=5)

![Dreamer value learning 原论文图](../../assets/images/paper-deep-dives/world-models/dreamer/figure-7-value-small.png)

*原论文关于 value learning 的比较图。阅读时区分仅预测窗口内奖励与包含 learned value 的行为学习。*

算法图将这些步骤放进同一个循环。部署时只编码当前历史并调用 actor，没有在每个动作前再次训练策略，也不必 CEM 搜索。

![Dreamer algorithm 原论文图](../../assets/images/paper-deep-dives/world-models/dreamer/algorithm-1-dreamer.png)

*原论文 Algorithm 1。model、actor、value 使用不同参数与目标。*

## 远期收益由什么实验支撑

Horizon 消融回答 critic 是否真的减少短视。比较同一 imagination horizon 下 Dreamer、去除 value 的 actor 与 PlaNet，而不只比较某条曲线的最高点。

![Dreamer horizon ablation](../../assets/images/paper-deep-dives/world-models/dreamer/figure-4-horizon.png)

*原论文 Figure 4。控制 action repeat 为 $R=2$，都用 pixel reconstruction 学表示。*

有 value 的 Dreamer 对 horizon 长度更稳健。它不需要把整个任务都展开在有限模型预测窗里，因而短窗口也可学习长时域行为；这项消融比单看最终高回报更直接地支持 actor-critic 设计。[↗](https://arxiv.org/pdf/1912.01603#page=4)

20 个视觉控制任务的总体结果采用以下预算。

| Agent | Environment steps | Average episode return |
| --- | ---: | ---: |
| Dreamer | $5\times10^6$ | 823 |
| PlaNet | $5\times10^6$ | 332 |
| D4PG | $10^8$ | 786 |

*原论文 Figure 6，5 seeds 平均；D4PG 使用的环境交互预算是前两者的 20 倍。*

![Dreamer benchmark bars](../../assets/images/paper-deep-dives/world-models/dreamer/figure-6-bars.png)

均值显示 Dreamer 在该任务集兼顾样本效率与最终表现；逐任务柱形保留了任务难度差异，不能由均值推出每个任务均获胜。图中 A3C 还使用 proprioceptive 输入，读取时需保留这个条件。[↗](https://arxiv.org/pdf/1912.01603#page=6)

预测图先给 5 帧 context，再依靠动作开环预测 45 步。看 context 之后的轨迹是否持续跟随物体运动，就能理解 actor 所依赖的 imagination 是否有合理基础。

![Dreamer video prediction](../../assets/images/paper-deep-dives/world-models/dreamer/figure-5-video.png)

*原论文 Figure 5。它检查表示的动态结构，任务回报与 horizon 消融则检验这些预测能否用于学习行为。*

可复用的关键是将真实经验用于校准世界模型，将大量廉价 latent rollout 用于改善策略，并用 value 接住有限展开之外的未来。这里节省的是反复真实交互及在线搜索；策略仍会受模型误差影响，因此从真实 replay 状态开始想象和持续回收环境反馈都是训练循环的一部分。
