---
paper_date: 2026-04
paper_title: "World Model for Robot Learning: A Comprehensive Survey"
paper_topic: 世界模型
---

# World Model for Robot Learning：机器人学习世界模型综述

!!! info "论文信息"
    **论文题名：** World Model for Robot Learning: A Comprehensive Survey。<br>
    **作者：** Bohan Hou、Gen Li、Jindou Jia、Tuo An、Xinying Guo、Sicong Leng、Haoran Geng、Yanjie Ze、Tatsuya Harada、Philip Torr、Oier Mees、Marc Pollefeys、Zhuang Liu、Jiajun Wu、Pieter Abbeel、Jitendra Malik、Yilun Du、Jianfei Yang。<br>
    **机构：** Nanyang Technological University、University of California, Berkeley、Stanford University、The University of Tokyo、University of Oxford、Microsoft、ETH Zurich、Princeton University、Harvard University。<br>
    **时间 / 主题：** 2026-04；世界模型、机器人学习、VLA、视频世界模型、learned simulator。<br>
    **arXiv / 官方报告：** arXiv：[2605.00080](https://arxiv.org/abs/2605.00080)；PDF：[arxiv.org/pdf/2605.00080](https://arxiv.org/pdf/2605.00080)。<br>
    **GitHub / 项目：** GitHub：[NTUMARS/Awesome-World-Model-for-Robotics-Policy](https://github.com/NTUMARS/Awesome-World-Model-for-Robotics-Policy)；项目页：[ntumars.github.io/wm-robot-survey](https://ntumars.github.io/wm-robot-survey/)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2605.00080)、论文 PDF、官方 GitHub / 项目页；Checked Date：2026-06-15；Repro Status：Survey / official resource list reviewed, independent reproduction not claimed。

## 先确定世界模型在机器人系统中做哪件事

这篇综述用机器人学习的需求重新整理世界模型。它关注的共同问题是，预测未来怎样改变机器人的动作，而不是视频本身是否逼真。预测可以直接参与动作生成，可以在训练阶段替代真实环境，也可以在执行前筛选候选动作；同一个视频骨干放在这三个位置，面对的误差、速度与评测要求都不同。[↗](https://arxiv.org/pdf/2605.00080#page=2)

总览图中的三条轴不能压成一串互相替代的模型名称。第三节按**策略与预测的架构耦合方式**分类，第四节按**模拟器的用途**分类，第五节按**视频世界模型的能力接口**分类。一个 MoT 策略也可以使用动作可控视频模型，一个视频模型也可以同时用于合成数据和策略评估。

![World Model for Robot Learning survey organization 原论文图](../../assets/images/paper-deep-dives/world-models/world-model-robot-learning-survey/figure-1-survey-organization.png){ width="920" }

这套组织尤其适合回答三类工程问题。已有可用策略但想提高成功率，应考虑候选评估或模型内后训练；有较少机器人数据但可用视频先验，应考虑预测表示怎样接到动作头；想建立多任务仿真平台，则需要动作响应、多视角一致性、奖励和长期 rollout 都能工作。它们需要的世界模型并不相同。

时间图进一步把策略侧与模拟器侧并列。上半部从分离接口扩展到共享骨干、专家与 latent 预测，下半部从候选验证扩展到模型内 RL 和共同更新。这些是并行扩展的设计选择，较新的路线并不自动替代较早的模块化方法。

![Temporal evolution of representative works 原论文图](../../assets/images/paper-deep-dives/world-models/world-model-robot-learning-survey/figure-2-temporal-evolution.png){ width="920" }

## 从反应式策略到预测控制，增加的变量是什么

普通策略学习 $p(a_{t+1:t+k}\mid o_t,\ell)$，根据当前观测 $o_t$ 和任务指令 $\ell$ 生成动作块。Diffusion Policy 用连续生成模型表示多模态动作，VLA 则把视觉语言预训练与动作预测结合。下图分别说明这两种已有起点：动作去噪可以提高轨迹表达能力，语义预训练可以扩大指令理解，但它们本身都不要求显式输出行动后的世界状态。[↗](https://arxiv.org/pdf/2605.00080#page=6)

![Diffusion Policy input-output 原论文/项目图](../../assets/images/paper-figures/vla/diffusion-policy-input-output-padded.jpg){ width="880" }

![RT-2 VLA overview 原论文图](../../assets/images/paper-figures/vla/rt2-overall-wide.png){ width="920" }

综述用一个理想的联合分布连接不同路线

$$
p(o_{t+1:t+k},a_{t+1:t+k}\mid o_t,\ell).
$$

对未来观测积分得到策略，对动作积分得到被动未来预测；给定动作再预测观测，是可控世界模型；给定当前与目标观测反推动作，是逆动力学。这个视角解释了几种接口为什么可以组合，但不意味着现有模型已同时学好这整个联合分布，也不意味着任意生成视频都能恢复为可执行动作。[↗](https://arxiv.org/pdf/2605.00080#page=7)

控制相关的收益来自引入了一个中间问题：动作应导致什么变化。仅凭当前图像，向左和向右都可能是合理动作；加入目标状态或预测后果后，动作分布可以被更具体地约束。但如果预测主要跟随语言意图，忽略候选动作，得到的“未来”就无法用于比较两种动作的真实优劣。

## 五类策略耦合方式，应按信息流区分

| Architectural route | Future information enters action generation through | What remains at inference |
|---|---|---|
| IDM-style | 独立世界模型先给视觉计划，再由动作模块恢复控制 | 完整视频、部分去噪 latent 或结构化计划，依方法而异 |
| Single backbone | 视觉与动作在一个生成骨干中联合建模 | 可能联合采样，也可能跳过视觉输出 |
| MoE / MoT | 专门的视频流与动作流反复交换特征 | 专家交互，未必解码视频像素 |
| Unified VLA | 同一多模态策略同时学习动作与未来目标 | 未来头可仅用于训练，也可参与规划 |
| Latent-space world modeling | 用未来 embedding 对齐或预测塑造策略表示 | 紧凑预测表示或已吸收到参数中的能力 |

表中最有部署价值的一列是推理时还保留什么。训练时预测未来与在线生成一段视频是两种成本承诺。[↗](https://arxiv.org/pdf/2605.00080#page=8)

### 分离的预测与逆动力学，接口可以逐渐变轻

UniPi 的基本路径是从当前观测和任务生成未来视频，再用相邻帧之间的变化恢复动作。优点是视频模型和动作模型可以分别训练、复用；问题是视觉上合理的轨迹未必能由机器人实现，两个阶段的误差会串联。

这个家族后续工作的关键变化，是交给动作模块的未来究竟长什么样。Gen2Act 使用人类视频作条件，扩大可用示范来源；VPP、Video2Act 从视频扩散内部抽取紧凑预测特征，减少完整渲染；MimicVideo 使用部分去噪的视觉计划；TC-IDM、LVP 则把预测转换成工具轨迹或更便于重定向的执行计划。它们都保留模块分工，但把中间接口从“给人看的视频”转向“给控制器用的状态变化”。[↗](https://arxiv.org/pdf/2605.00080#page=9)

VPP 图中应关注视频特征流向策略的位置。它说明利用视频先验不必先等到视频完全生成，动作头可以直接读取内部时空特征。

![VPP overview 原论文图](../../assets/images/paper-deep-dives/embodied-ai/vpp/figure-1-overview.png){ width="920" }

结构化中间变量是这条路线的另一个分支。AVDC 使用稠密对应，VidBot 提取三维手轨迹，NovaFlow 使用物体的三维流。这类接口把“未来怎样看”转成“哪里发生怎样的位移”，更接近动作恢复需要，但也增加几何估计和跨 embodiment 对应的要求。

### 共享骨干把一致性约束放到生成过程内部

单骨干方法把未来视觉表示 $z_v$ 与动作表示 $z_a$ 组成 $x=[z_v;z_a]$，在共同去噪或 flow-matching 过程中建模。视觉与动作不再通过一次外部调用传递，而是在网络内部相互约束。UVA 学习联合 latent，UWA 使用模态特定时间步，VideoVLA 将视频 DiT 扩展成联合视频动作 DiT。[↗](https://arxiv.org/pdf/2605.00080#page=11)

Cosmos Policy 的接口更直接，把动作、未来状态和价值编码成附加 latent “帧”。直接策略模式只需要动作输出；规划模式才用未来状态与价值排序。DreamZero 则采用分块的联合视频动作生成，每一块执行后重新接入真实反馈，降低长期自由 rollout 的误差。GigaWorld-Policy 通过因果结构让视觉分支在推理时可选。

因此，共享骨干的核心是联合训练和内部信息交换，并不要求所有方法在线完整生成视频。判断其是否适合实时控制，需要查看动作采样依赖哪些视觉计算、能否跳过解码，以及一个块完成后怎样重新接收观测。

### 专家分工保留不同模态的时间尺度

视频状态维度高、变化冗余多，动作维度较低、执行频率却可能更高。全部参数共享未必是唯一选择。MoT 让两条流保留各自 FFN、归一化或条件模块，再通过 shared attention、cross-attention 等方式交互。[↗](https://arxiv.org/pdf/2605.00080#page=12)

Motus 使用理解、视频、动作专家；LingBot-VA 把视频与动作交织到因果序列；BagelVLA 把语言计划、视觉预见和动作放进一个循环，并用少步视觉预测降低在线成本。Fast-WAM 则进一步检验收益是否主要来自视频共训练，允许推理跳过视频分支。LDA-1B 和 FRAPPE 把预测转向 DINO 等 latent 或表示对齐，说明“有多个专家”与“必须生成像素”是独立选择。

下图把分离、共享与专家耦合并列，最值得沿箭头比较动作在何时读取未来信息，而不是按模块数量判断先进程度。

![Policy paradigms 原论文图](../../assets/images/paper-deep-dives/world-models/world-model-robot-learning-survey/figure-3-policy-paradigms.png){ width="920" }

### 统一 VLA 与 latent 预测，允许未来能力留在参数中

GR-1、UP-VLA 以未来图像预测辅助动作学习；WorldVLA 统一动作与图像理解、生成；DreamVLA 使用动态、空间和语义知识；F1、InternVLA-A1 等则在统一训练框架内保留功能专家。这些方法从多模态策略出发，视频先验的进入方式与直接复用视频生成骨干有所不同。[↗](https://arxiv.org/pdf/2605.00080#page=13)

另一组方法完全在表示空间预测。FLARE 将动作去噪隐藏特征对齐未来观测 embedding；VLA-JEPA 强调未来帧只作监督目标，防止未来信息泄漏到当前输入；JEPA-VLA 复用已有视频 JEPA 的预测表示；WoG 直接学习对动作最有用的未来条件。这里最大的收益是避开像素重建，代价则是必须确认被压缩掉的信息不会影响接触、定位和失败识别。[↗](https://arxiv.org/pdf/2605.00080#page=14)

![UMM and latent-space VLA 原论文图](../../assets/images/paper-deep-dives/world-models/world-model-robot-learning-survey/figure-4-umm-latent-vla.png){ width="860" }

这两个面板的差别是未来输出的形式与位置。左侧可以显式生成图像或文字推理，右侧主要通过紧凑预测状态影响动作。符号世界模型还可进一步把状态表达成对象关系、谓词和操作规则，交给高层规划器；它们在长任务中更可组合，但需要感知与符号之间可靠的落地。

## 模拟器用于训练与用于评估，错误后果不同

作为训练环境时，世界模型提供

$$
(\hat o_{t+1},\hat r_t,\hat d_t)\sim p_\phi(\cdot\mid o_{\le t},a_{\le t},\ell),
\qquad
J(\theta)=\mathbb E_{\hat\tau\sim(\pi_\theta,p_\phi)}\left[\sum_t\gamma^t\hat r_t\right].
$$

$\hat d_t$ 是终止信息，奖励可以来自单独模型或任务验证器。这里优化的是模型环境中的回报，只有预测保留真实动作后果，收益才可能迁移。一个总把抓取生成得成功的模型，会让错误动作得到奖励，训练越充分反而越可能放大这种偏差。[↗](https://arxiv.org/pdf/2605.00080#page=16)

UniSim、World-Env、VLA-RFT 建立基本的“动作条件模拟+反馈+策略更新”接口。DiWA 探索用冻结模型支持离线适配，WMPO 将像素想象接到 on-policy 优化，RISE 把动力学与任务进度价值组合。不同方法的区别在 rollout 表示、奖励来源及怎样适配 flow/diffusion 动作头，不能统一视作某一种 RL 算法。

下一层问题是策略更新后会访问世界模型没见过的状态。World-VLA-Loop 用失败 rollout 修复模拟器，VLAW 交替使用真实数据改善模型、合成数据改善策略，WoVR 强调初始化和可靠性约束。共同机制是交替更新

$$
\phi_{k+1}\leftarrow\operatorname{UpdateWM}(\phi_k,D_{\mathrm{real}}\cup D_{\mathrm{policy}}(\pi_{\theta_k})),
\qquad
\theta_{k+1}\leftarrow\operatorname{UpdatePolicy}(\theta_k,\hat D(\phi_{k+1})).
$$

模型与策略共同演化有助于覆盖新状态，但真实验证仍是防止两者共同强化错误的参照。[↗](https://arxiv.org/pdf/2605.00080#page=17)

![World model for RL and validation 原论文图](../../assets/images/paper-deep-dives/world-models/world-model-robot-learning-survey/figure-5-rl-vs-validation.png){ width="860" }

右侧评估流程不一定更新策略。GPC 给冻结策略的多个动作候选打分，World-in-World 在执行前反复修订计划，DreamPlan 把候选比较转换为偏好训练数据；WorldEval 更直接研究能否在想象中保持不同策略与 checkpoint 的真实排序。它们需要的是**候选之间的相对后果正确**，并不总要求每个像素都准确。

连续优化动作序列的 MPC 又比一次候选排序更昂贵。它会多次调用动力学模型，在内部搜索低成本轨迹，再执行首段并重规划。综述提到 TD-MPC2 与 latent 预测路线时，应把它们理解为紧凑空间中的规划机制，不能把某个方法的具体优化器推广为整个 MPC 家族的统一实现。[↗](https://arxiv.org/pdf/2605.00080#page=18)

## 视频世界模型的能力阶梯，实质是增加约束

视频生成的四组路线分别增加了不同接口，并非严格历史替代关系。

| Capability emphasis | Added constraint | Representative mechanism |
|---|---|---|
| Imagination for supervision | 未来符合任务语义，并能转成训练材料 | UniPi 视觉计划、DreamGen 合成经验、RoboDreamer 组合任务条件 |
| Action-controllable rollout | 不同候选动作产生对应后果 | IRASim 逐帧动作注入、Ctrl-World 多视角与记忆、EVA 执行性对齐 |
| Structure-aware generation | 接触、几何、视角和对象身份保持一致 | Mask2IV 交互轨迹、TesserAct RGB/depth/normal、RoboVIP 身份提示 |
| Foundation world model | 可在多个任务与 embodiment 之间适配复用 | Vid2World 因果适配、Genie Envisioner 视频动作平台、DreamDojo 人类视频先验 |

图中语言、动作和结构是三种不同条件。语言说明想完成什么，动作说明实际怎样干预，结构限制干预后不能随意变化的几何和对象关系。[↗](https://arxiv.org/pdf/2605.00080#page=19)

![Robotic video world models 原论文图](../../assets/images/paper-deep-dives/world-models/world-model-robot-learning-survey/figure-6-video-world-models.png){ width="920" }

纯想象路线中，DreamGen 先适配目标 embodiment，再生成视频，并通过 latent action 或 IDM 恢复动作；DreMa 则把 Gaussian Splatting 与物理模拟结合，得到可操纵的数字场景来合成示范。前者依赖学到的视觉动态，后者引入显式物理约束，数据生产链的误差来源不同。[↗](https://arxiv.org/pdf/2605.00080#page=20)

动作可控路线要求模型对输入变化敏感。只观察同任务视频可能让模型忽略动作，按最常见成功轨迹续写。逐帧注入、多视角联合、历史记忆和逆动力学可执行性监督，分别约束时间对应、视角对应、长期事实与控制恢复。结构路线则用 depth、normal、mask、身份等信号降低模型“画对但做错”的自由度。[↗](https://arxiv.org/pdf/2605.00080#page=21)

基础模型路线把训练成本前置。以下 LingBot-World 原图展示一个相关工程例子：先获得视频先验与长时一致性，再加入动作控制，最后因果化和蒸馏以适应流式接口。该图帮助理解阶段分工；其游览环境能力不能直接作为机器人操作成功率证据。

![LingBot-World 训练 pipeline 原论文图](../../assets/images/paper-deep-dives/world-models/lingbot-world/figure-4-training-pipeline.png){ width="920" }

## 导航和驾驶改变了应预测的状态

导航的主要困难是部分可观测。Pathdreamer 想象未到达位置的 RGB、深度和语义，VISTAv2 将想象结果投到在线价值图，NWM 用动作条件视频支持轨迹预测，SparseVideoNav 用稀疏未来降低部署成本。其价值在于揭示可通行性、未来可见目标与目标进展，完整渲染每个中间帧未必必要。[↗](https://arxiv.org/pdf/2605.00080#page=23)

驾驶同时面对多智能体与几何约束。MILE 使用紧凑动态状态，OccWorld 使用三维 occupancy，让自车和环境变化进入可规划空间；GAIA-1、DriveDreamer 更强调生成式场景模拟；Drive-WM 用多视角未来与图像奖励筛选轨迹。latent 路线降低 rollout 成本，occupancy 路线直接暴露空间占用，视频路线则便于生成传感器可见的训练数据。三者对应不同下游任务，不应只按视觉分数排序。[↗](https://arxiv.org/pdf/2605.00080#page=24)

## 评测应从预测、决策、执行性三个层面闭合

综述将评测分为三层，这比单一 FVD 更贴近机器人需求。[↗](https://arxiv.org/pdf/2605.00080#page=25)

| Evaluation layer | Question | Representative resources |
|---|---|---|
| Open-loop prediction | 固定输入动作后，未来是否一致、语义是否正确 | RBench、EWMBench、DreamGen Bench、EVA-Bench |
| Closed-loop utility | 预测进入控制循环后，能否改善任务或保持策略排序 | WorldArena、WorldEval、WorldGym、World-in-World |
| Diagnostic executability | 哪些物理、动作或运动约束导致结果可用或不可用 | WorldSimBench、WoW-World-Eval、WM-ABench |

开环测试便于批量比较，但模型不必面对自己的预测被策略再利用后的分布变化。闭环测试暴露误差累积，却受策略、搜索预算和奖励器影响。诊断测试则定位问题，例如生成轨迹能否恢复成合法动作、物体运动是否响应控制、失败是否被正确识别。三层需要结合，才能判断提升来自更好的动力学还是更强的下游策略。

### 同一个 benchmark 也要保留子任务和预算

下面是综述表 5 中具有四个完整 LIBERO suite 数值的代表行，单位为成功率百分比。它们由原方法报告汇总，并非综述重新训练的统一实验。[↗](https://arxiv.org/pdf/2605.00080#page=28)

| Method | Spatial | Object | Goal | Long | Avg. |
|---|---:|---:|---:|---:|---:|
| MimicVideo | 94.2 | 96.8 | 90.6 | 94.0 | 93.9 |
| Say-Dream-ACT | 99.4 | 99.2 | 98.6 | 95.4 | 98.1 |
| Cosmos Policy | 98.1 | 100.0 | 98.2 | 97.6 | 98.5 |
| Motus | 96.8 | 99.8 | 96.6 | 97.6 | 97.7 |
| LingBot-VA | 98.5 | 99.6 | 97.2 | 98.5 | 98.5 |
| VLA-JEPA | 96.2 | 99.6 | 97.2 | 95.8 | 97.2 |

这些行能支持“多种耦合方式都可得到较强控制结果”，不能隔离证明某种架构最优。平均相同也不意味着能力相同，例如 Cosmos Policy 与 LingBot-VA 平均均为 98.5，但 Long 分别为 97.6 和 98.5。训练数据、骨干、在线生成开销仍需回到各方法设置比较。

跨 benchmark 更不能混排。综述表 6 的 RoboTwin 简单/随机设置中，Vidar 为 65.8/17.5，Motus 为 88.7/87.0，LingBot-VA 为 92.9/91.6；它们提示环境随机化可能比平均熟悉场景成绩更能区分鲁棒性。CALVIN 的 4.33、4.41 等是连续任务完成指标，并非 4.33% 成功率；SIMPLER 的 Google Robot、WidowX 还对应不同 embodiment 和协议。[↗](https://arxiv.org/pdf/2605.00080#page=29)

## 数据选型需要同时看动作、时长、接触和 embodiment

数据量大不保证包含模型缺少的经验。OXE、DROID、BridgeData 等提供真实轨迹；人类视频拓展动作语义和场景范围；UMI 类接口降低采集成本；触觉、力和接触丰富的数据补足视觉无法辨别的摩擦、刚度与接触稳定性；RoboTwin 等合成资源则便于有控制地改变环境。[↗](https://arxiv.org/pdf/2605.00080#page=26)

![Open X-Embodiment dataset overview 原论文图](../../assets/images/paper-figures/vla/openx-data-vis.jpg){ width="920" }

OXE 图强调跨机器人的共同数据格式，但统一存储并不会消除动作频率、坐标系、夹爪语义和机械约束的差异。世界模型训练还需要把这些差异转成一致的状态转移接口。

综述用两张表分别描述资源本身和它能支持的能力，这个区别很实用。某数据有语言标签，不代表覆盖长期恢复；有很多视频，不代表有动作干预；有人手轨迹，也不自动得到机器人可执行控制。实际数据规划可以围绕以下缺口展开：动作条件是否对齐，失败及恢复是否出现，同一状态是否有不同动作结果，长期任务是否连续记录，接触信号是否可用。尤其是失败恢复和决策敏感的变化，当前资源仍比成功示范稀少。[↗](https://arxiv.org/pdf/2605.00080#page=27)

## 怎样把这份综述转成研究或系统选择

若目标是改善现有策略的表示，又不能增加在线延迟，优先比较 latent 对齐、未来辅助预测或训练后可移除的视频分支。若需要动作选择可解释，独立视觉计划、结构化中间状态和候选 rollout 更容易直接观察，但应预算生成和排序成本。若希望进行模型内 RL，先验证动作响应与奖励排序，再扩展 rollout 长度。若要高接触精度，数据与表示都应保留力、触觉或几何约束，而不只追求视频清晰。

长时任务还要求把低层预测与抽象规划分开。像素保存细节，latent 提供紧凑动态，符号或对象关系提供组合结构；混合设计的价值取决于这些接口是否保留了任务真正需要的变化。综述留下的核心问题是，未来预测在哪个环节、以何种表示、支付多少计算，才能稳定地改善真实动作。可以据此阅读新论文，而不必把所有“世界模型+机器人”都归为同一种方法。[↗](https://arxiv.org/pdf/2605.00080#page=30)
