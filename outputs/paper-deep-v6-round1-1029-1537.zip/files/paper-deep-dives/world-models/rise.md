---
paper_date: 2026-02
paper_title: "RISE: Self-Improving Robot Policy with Compositional World Model"
paper_topic: 世界模型 / 机器人想象强化学习
---

# RISE：用组合式世界模型做机器人想象强化学习

!!! info "论文信息"
    **论文题名：** RISE: Self-Improving Robot Policy with Compositional World Model。<br>
    **作者：** Jiazhi Yang、Kunyang Lin、Jinwei Li、Wencong Zhang、Tianwei Lin、Longyan Wu、Zhizhong Su、Hao Zhao、Ya-Qin Zhang、Li Chen、Ping Luo、Xiangyu Yue、Hongyang Li。<br>
    **机构：** The Chinese University of Hong Kong、Kinetix AI、The University of Hong Kong、Shanghai Innovation Institute、Horizon Robotics、Tsinghua University。<br>
    **时间 / 主题：** arXiv v1 2026-02-11，v2 2026-04-28；RSS 2026；世界模型、机器人强化学习、视频动力学模型、VLA 自我改进。<br>
    **arXiv / 官方报告：** arXiv：[2602.11075](https://arxiv.org/abs/2602.11075)；PDF：[arxiv.org/pdf/2602.11075](https://arxiv.org/pdf/2602.11075)；项目页：[opendrivelab.com/RISE](https://opendrivelab.com/RISE/)。<br>
    **GitHub / 项目：** GitHub：[OpenDriveLab/RISE](https://github.com/OpenDriveLab/RISE)。<br>
    **元数据来源与核验口径：** 来源：arXiv metadata、论文 PDF、官方项目页、官方 GitHub README；Checked Date：2026-08-08；Repro Status：Paper / official project / official code reviewed, independent reproduction not claimed。

## 把昂贵的试错搬进可评价的视觉未来

RISE 针对的是 VLA 在长任务上的一个具体瓶颈。示范可以教机器人完成熟悉动作，但一旦拉链卡住、积木位置变化或双臂配合失败，继续增加同分布示范未必能教会它恢复。真实机器人上的在线强化学习又必须支付执行、复位和失败的成本。论文把后续试错放进一个 **Compositional World Model**：动力学模型生成执行候选动作后的多视角观测，价值模型判断这些观测是否推进任务，策略再用成功与失败的想象经验更新。[↗](https://arxiv.org/pdf/2602.11075#page=2)

先沿图中的闭环看信息流。策略产生动作，世界模型产生后果，价值函数把后果变成优势标签，标签反过来训练策略。世界模型只参与训练，部署后的策略仍直接根据观测和指令输出动作，因此论文的收益没有附加在线视频预测开销。

![RISE overview](../../assets/images/paper-deep-dives/world-models/rise/figure-1-overview.png){ width="920" }

## 一个模块预测后果，另一个模块判断进展

令 $o_t$ 表示当前多相机观测，$O_t$ 表示一段观测历史，$a_t$ 表示未来 $H$ 步组成的动作块。动力学模型执行

$$
\hat o_{t+1},\ldots,\hat o_{t+H}=D(O_t,a_t).
$$

这里必须保留动作条件。同一幅图像中，“把夹爪移向积木”和“把夹爪移开”可能都产生自然的视频，但只有能区分这两个后果的生成器，才有资格给策略提供训练环境。[↗](https://arxiv.org/pdf/2602.11075#page=3)

$D$ 从 Genie Envisioner 的 GE-base 初始化，加入动作编码器，并用 Agibot、Galaxea 机器人数据预训练。论文改变了 batch 的组织方式：**task-centric batching** 让同场景、同任务、不同动作的样本集中出现，降低模型仅凭背景就完成预测的机会，迫使其学习动作差异。对历史观测加入更强噪声，则用于降低自回归过程中历史图像不完美带来的敏感性。[↗](https://arxiv.org/pdf/2602.11075#page=4)

价值模型 $V(o_t,\ell)$ 从 π0.5 的多视角 VLA 初始化，输出观测在语言目标 $\ell$ 下的进展。只用终点成功奖励会使长序列中的大部分帧缺乏学习信号，因此先回归归一化进度

$$
\mathcal L_{\mathrm{prog}}=\mathbb E\left[\left(V(o_t,\ell)-\frac{t}{T}\right)^2\right].
$$

但“视频已经播放到后半段”不能保证任务快成功了。论文再加入 TD 学习

$$
\mathcal L_{\mathrm{TD}}=\mathbb E[(V(o_t,\ell)-y_t)^2],\qquad
 y_t=r_t+\gamma V(o_{t+1},\ell),
$$

其中中间奖励为零，终止成功与失败分别给 $+1$ 和 $-1$。进度回归提供稠密的时间结构，TD 项把这套结构连接到实际成败。训练前 10k 步只用进度项，随后 40k 步联合两者。[↗](https://arxiv.org/pdf/2602.11075#page=5)

下图应同时看视频预测分支和价值分支。两者分开训练，使视觉生成不必直接学会稀疏奖励；组合后又能对候选动作给出任务相关的判断。

![RISE compositional world model](../../assets/images/paper-deep-dives/world-models/rise/figure-4-cwm-workflow.png){ width="760" }

## 优势条件策略如何从想象中改进

RISE 用预测轨迹的平均价值相对当前价值的提升定义动作块优势

$$
A(o_t,a_t,\ell)=\frac{1}{H}\sum_{k=1}^{H}V(\hat o_{t+k},\ell)-V(o_t,\ell).
$$

平均未来价值让评价覆盖整个动作块，减轻仅盯住最后一帧的波动。这是论文给策略的训练标签，不等同于带完整累计奖励的通用优势估计器。[↗](https://arxiv.org/pdf/2602.11075#page=3)

策略先用专家示范、已有策略的成功及失败轨迹，以及人工纠错数据 warm-up。真实 rollout 的优势由模型估计，专家和纠错样本赋予最优标签 1。自改进时，使用参数的 EMA 版本执行 rollout，始终请求优势为 1 的动作，再由世界模型评价实际后果，把得到的优势离散成不同档位，作为 flow-matching 动作训练的条件。这样，高质量和低质量经验都能保留；部署时请求高优势条件，让模型偏向训练中对应好后果的动作。[↗](https://arxiv.org/pdf/2602.11075#page=5)

![RISE self-improving loop](../../assets/images/paper-deep-dives/world-models/rise/figure-5-self-improving-loop.png){ width="760" }

图中的在线状态有实质意义。如果每次只从原始数据的观测出发换动作，策略仍受固定状态分布限制；把生成的下一状态继续作为输入，才能学习自己偏离示范之后的应对。论文同时限制每个离线初始状态最多连续想象两个动作块，并混入离线样本，避免模型误差随长 rollout 无限放大。

## 三个真实任务的增益，来自怎样的比较

实验采用双 7-DoF AgileX 机器人、绝对关节控制，任务分别涉及传送带上的动态积木分拣、可变形背包装填和需要双臂协同的关盒。每项评测基于 20 次自主试验，并提供满分 10 分的分阶段评分。主表中的 RECAP 是在同一个 π0.5 骨干上重建的版本，因为原方法的 π0.6 不可用；因此此处比较的是方法在共同骨干与数据条件下的效果。[↗](https://arxiv.org/pdf/2602.11075#page=6) [↗](https://arxiv.org/pdf/2602.11075#page=15)

| Method | Brick Sorting Success (%) | Backpack Packing Success (%) | Box Closing Success (%) |
|---|---:|---:|---:|
| π0.5 | 35 | 30 | 35 |
| π0.5 + DAgger | 15 | 50 | 40 |
| π0.5 + PPO | 10 | 35 | 10 |
| π0.5 + DSRL | 10 | 10 | 10 |
| RECAP on π0.5 | 50 | 40 | 60 |
| RISE | **85** | **85** | **95** |

相对 RECAP，三个任务分别提高 **35、45、35 个百分点**，按表 I 的原始值相减得到。背包任务的正文概述与表格差值不完全一致，应以表中 40%→85% 的数值为准。RISE 的分阶段分数分别为 9.78、9.50、9.88，说明成功率提高也伴随接近完整流程的执行，而不只是某个早期动作更稳。

## 消融把“视频更好”与“策略更好”拆开

消融统一在动态积木分拣上进行。表 III 中，无在线动作和状态时完整成功率为 35%；只加入在线动作提高到 40%；动作与生成状态同时加入达到 70%。这支持“状态分布扩展”是重要贡献，不能把全部增益归于对原始示范重新打分。该消融的完整系统基准为 70%，不能与主表的 85% 混作同一行来计算贡献。[↗](https://arxiv.org/pdf/2602.11075#page=7)

| Ablation in Table IV | Complete Success (%) | Stage Score |
|---|---:|---:|
| Without dynamics pre-training | 15 | 7.43 |
| Without task-centric design | 40 | 8.78 |
| Without progress loss | 50 | 8.78 |
| Without TD learning | 35 | 8.38 |
| Full design | **70** | **9.43** |

去掉预训练最严重，说明一般视频与机器人动力学先验不能靠少量目标任务数据轻易补足。去掉 TD 后，抓放成功率仍有 98.75%，但分拣准确率降为 72.15%、完整成功率降为 35%；“手能抓住”与“按任务正确完成”正是在这里分开。离线数据比例实验也呈现中间最优：表 II 中比例 0.1、0.3、0.6、0.9 的完整成功率为 5%、25%、50%、30%，过少会丢失已学行为，过多又限制新经验的作用。

视觉比较应先看手与物体运动是否对齐，再看清晰度。原图展示 RISE 相对 Cosmos、GE 的动作一致性改善。

![RISE dynamics comparison](../../assets/images/paper-deep-dives/world-models/rise/figure-6-dynamics-comparison.png){ width="760" }

表 V 的目标任务测试中，RISE 的 EPE 为 0.54，GE 为 1.05、Cosmos 为 1.21，支持运动预测更准确；PSNR 为 23.90，也高于两者约 21.16–21.17。但去掉 task-centric 的模型 FVD 为 61.22，反而低于完整模型 66.84，尽管其 EPE 更差、策略成功率更低。因此不能把 FVD 当成可用于控制的充分条件。Bridge 上完整模型 FVD 为 45.21、EPE 为 0.64，则同时优于该消融的 49.07、0.72。[↗](https://arxiv.org/pdf/2602.11075#page=7)

## 可复用的是训练闭环，而不是免费的仿真器

动力学预训练使用 16 张 H100、batch 512、约 7 天；任务微调使用 8 张 H100、batch 64、约 3 天。价值模型还需约一天，策略自改进约 10k 步。这让 RISE 更适合已有视频模型、机器人数据与训练预算的团队。其实际价值是把这些离线投入转化为无需在线视频推演的最终策略，并给出了可以分别检验的三个接口：动作到未来观测、观测到任务价值、优势到动作分布。[↗](https://arxiv.org/pdf/2602.11075#page=6)

这套结果支持世界模型作为真实机器人策略的训练环境，但可靠性的关键仍在任务附近的动作响应和价值排序。短想象、离线混合、成功失败数据与任务进度监督共同构成了闭环能够工作的条件。
