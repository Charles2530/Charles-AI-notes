---
paper_date: 2024-02
paper_title: World Model on Million-Length Video And Language With Blockwise RingAttention
paper_topic: 世界模型
---

# LWM：百万 token 视频语言世界模型

!!! info "论文信息"
    **论文题名：** World Model on Million-Length Video And Language With Blockwise RingAttention。<br>
    **作者：** Hao Liu、Wilson Yan、Matei Zaharia、Pieter Abbeel。<br>
    **机构：** UC Berkeley、Code and models of Large World Model (LWM) are available at largeworldmodel.github.io/lwm/ .。<br>
    **时间 / 主题：** 2024-02；世界模型。<br>
    **arXiv / 官方报告：** arXiv：[2402.08268](https://arxiv.org/abs/2402.08268)；官方材料：[largeworldmodel.github.io/lwm/](https://largeworldmodel.github.io/lwm/)。<br>
    **GitHub / 项目：** GitHub：[github.com/LargeWorldModel/LWM](https://github.com/LargeWorldModel/LWM)；项目页：[largeworldmodel.github.io/lwm/](https://largeworldmodel.github.io/lwm/)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2402.08268)；[GitHub API / repo](https://github.com/LargeWorldModel/LWM)；[官方 / 项目材料](https://largeworldmodel.github.io/lwm/)；Checked Date：2026-06-04；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 一百万 token 怎样变成可用的多模态上下文

LWM 从 Llama-2 7B 出发，先扩展文本上下文，再加入图像与视频 token。论文解决的主要问题是长序列建模与训练组织：如何保留短文本能力，如何让模型学会从远处取信息，以及如何避免长短样本混装后损失比例失真。它同时训练理解与生成，但没有把动作闭环控制作为核心评测。[↗](https://arxiv.org/pdf/2402.08268#page=2)

## 统一 token 序列的输入和输出

![LWM model 原图](../../assets/images/localized-remote/paper-deep-dives/world-models/lwm/lwm-model-原图.png)

*原论文 Figure 3。先看视觉 token 与文本 token 如何交错，再看右侧 next-token prediction。*

文本使用 BPE，视觉采用 aMUSEd 的预训练 VQGAN，将 $256\times256$ 图像变成 $16\times16=256$ 个离散 token。视频逐帧编码再串接；`<vision>`、`</vision>`、`<eof>`、`<eov>` 标记模态、帧和视频边界。训练一个标准 causal Transformer 预测下一 token，使 image-to-text、text-to-image、video-to-text 等任务共享序列接口。[↗](https://arxiv.org/pdf/2402.08268#page=7)

这种接口让上下文长度直接约束可看帧数。更多 token 可以减少长视频的极端抽帧，但每帧 256 tokens 仍消耗大量注意力计算，视频时长还依赖采样帧率和文本占比，不能将“1M token”换成唯一固定的视频时长。

## 先扩文本，再扩视觉

![LWM data and stages 原图](../../assets/images/localized-remote/paper-deep-dives/world-models/lwm/lwm-data-and-stages-原图.png)

*原论文 Figure 4。按阶段看 context length 与数据组成，别把最终 chat 混合与早期预训练混合视为同一个比例。*

第一阶段按 32K、128K、256K、512K、1M 逐渐延长文本序列，后一阶段继承前一阶段权重，使用按长度筛选的 Books3，并随窗口扩大调整 RoPE 的 $\theta$。Ring Attention 配合 blockwise computation 解决设备内存，progressive training 则避免一开始就为全部训练支付最长序列的成本。[↗](https://arxiv.org/pdf/2402.08268#page=3)

长上下文 next-token training 不自动带来检索式对话。作者把文档切成 1000-token chunks，用短上下文模型生成问答，再拼接相邻 chunks、将问答放在后面，迫使回答定位到远处证据。chat fine-tuning 将 UltraChat 与这类长问答约按 7:3 混合。长问答大部分 token 属于不计 loss 的文档输入，loss tokens 可少于 1%；如果与密集短对话无区别地打包，优化会被短样本主导。

视觉阶段先训练 1K 的 text-image packing，再到 8K 的 image/video 混合。前两阶段另混 16% pure text 保存语言能力；后续 chat 阶段把 text-image generation、image understanding、text-video generation、video understanding 各分配 25% batch。短样本 packed 后用 attention mask 隔离彼此，重新加权 loss，使结果等价于未 packing 的训练。这个“隔离”避免模型通过不相关样本获得无意义上下文，不是禁止同一视频内帧间交互。[↗](https://arxiv.org/pdf/2402.08268#page=7)

## 检索成功与跨片段综合有多远

| Context Length | Model | N=2, R=2 | N=4, R=1 | N=4, R=2 |
| --- | --- | ---: | ---: | ---: |
| 128K | GPT-4-1106 | 0.92 | 0.80 | 0.82 |
| 128K | LWM-Text-1M | 0.83 | 0.98 | 0.83 |
| 1M | LWM-Text-1M | 0.67 | 0.84 | 0.69 |

*原论文 Table 2，$N$ 为埋入事实数，$R$ 为要求取回的事实数。*

从多条事实中取一条比同时取回多条更容易，且 1M 条件下降明显。这支持长程检索可行，也揭示窗口利用仍有改进空间。单 needle 的近乎完美成绩不能替代多信息整合测试。[↗](https://arxiv.org/pdf/2402.08268#page=6)

短上下文也不能只读作者的概括。Table 1 的 HellaSwag accuracy 在 base 与 1M 都为 0.57，但 MMLU 从 0.39 到 0.35，OpenBookQA accuracy 从 0.32 到 0.30。整体保留了相当多能力，并不意味着每项完全无损。[↗](https://arxiv.org/pdf/2402.08268#page=5)

## 长视频收益来自多看了什么

![LWM long video chat 原图](../../assets/images/localized-remote/paper-deep-dives/world-models/lwm/lwm-long-video-chat-原图.png)

*原论文 Figure 6。一小时、超过 500 个 clips 的视频问答示例，应关注问题对应的短暂事件是否落在可见帧中。*

示例说明密集覆盖有机会保留稀疏抽帧漏掉的信息，定量结果则来自 Long Video-MME。

| Method | Parameters | Frames | Medium (4min–15min) | Long (30min–60min) |
| --- | --- | ---: | ---: | ---: |
| Video-LLaVA | 7B | 8 | 38.1 | 36.2 |
| Long-LLaVA | 7B | 64 | 51.4 | 45.4 |
| LWM-1M | 7B | ≤1800 | 63.7 | 60.8 |
| Gemini 1.5 Pro | Unknown | ≤1800 | 74.3 | 67.4 |

*原论文 Table 4；部分比较模型发表于本文完成之后。帧数与数据条件不同，成绩不能全部归因于网络本身。*

LWM 给出了从长文本到长视频的一条可复用训练路径。采用时应同时检查上下文内存、loss token 比例、sample packing mask 与视频采样密度。它最直接支持的是长资料读取和生成式多模态序列建模；真实动作导致什么未来、生成未来能否可靠支撑规划，需要另外的动作条件和闭环实验来回答。
