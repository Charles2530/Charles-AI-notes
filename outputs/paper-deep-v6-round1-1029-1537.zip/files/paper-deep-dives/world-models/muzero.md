---
paper_date: 2019-11
paper_title: "Mastering Atari, Go, Chess and Shogi by Planning with a Learned Model"
paper_topic: 世界模型 / Planning / Model-Based RL
---

# MuZero：只预测对规划有用的世界模型

!!! info "论文信息"
    **论文题名：** Mastering Atari, Go, Chess and Shogi by Planning with a Learned Model。<br>
    **作者：** Julian Schrittwieser、Ioannis Antonoglou、Thomas Hubert、Karen Simonyan、Laurent Sifre、Simon Schmitt、Arthur Guez、Edward Lockhart、Demis Hassabis、Thore Graepel、Timothy Lillicrap、David Silver。<br>
    **机构：** DeepMind；University College London。<br>
    **时间 / 主题：** arXiv v1：2019-11-19；v2：2020-02-21；世界模型 / planning / model-based RL。<br>
    **arXiv / 官方报告：** arXiv：[1911.08265](https://arxiv.org/abs/1911.08265)；DOI：[10.48550/arXiv.1911.08265](https://doi.org/10.48550/arXiv.1911.08265)。<br>
    **GitHub / 项目：** 论文未在 arXiv 元数据中给出官方 GitHub；arXiv ancillary files 包含 pseudocode 和评测 JSON。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/1911.08265)、官方 PDF、arXiv ancillary `pseudocode.py`；Checked Date：2026-07-06；Repro Status：Paper / pseudocode / ancillary data reviewed, independent reproduction not claimed。

## 学习一个足以搜索的世界

MuZero 继承 AlphaZero 的搜索改进策略循环，将精确的游戏转移规则换成 learned dynamics。它不要求 latent 重建棋盘或视频，也不约束 latent 等于真实环境状态，而是训练模型预测搜索需要的 reward、policy 和 value。这使模型容量集中于决策有关的量。[↗](https://arxiv.org/pdf/1911.08265#page=2)

## 三个网络构成一个搜索接口

先从原图 A 的左端进入，再跟随候选动作展开。representation 将观测历史编码为根节点，dynamics 推进抽象状态，prediction 为每个节点提供策略先验与价值。

![MuZero planning acting training](../../assets/images/paper-deep-dives/world-models/muzero/figure-1-planning-acting-training.png)

*原论文 Figure 1。A 是规划，B 是真实行动，C 是 replay 上的训练；三个面板使用的动作与监督来源不同。*

$$
s^0=h_\theta(o_1,\ldots,o_t),\qquad (r^k,s^k)=g_\theta(s^{k-1},a^k),\qquad (p^k,v^k)=f_\theta(s^k).
$$

$s^k$ 是根节点之后第 $k$ 个想象状态，$r^k$ 是相应转移奖励，$p^k$ 是下一动作的先验分布，$v^k$ 是长期价值。MCTS 根据先验、访问次数与已回传价值选择分支；扩展新节点时调用 $g,f$，再将 reward 和 leaf value 向上 backup。根节点访问次数得到改进后的搜索策略 $\pi_t$，实际动作从它采样。[↗](https://arxiv.org/pdf/1911.08265#page=4)

模型内部使用确定性转移。没有像素重建损失意味着 latent 可以采用任何有利于预测决策量的表示，同时也意味着它不能直接作为通用视频模拟器输出画面。

## 搜索的结果如何反过来训练模型

replay 保存真实观测、动作、reward 与搜索得到的 policy/value。训练从真实历史得到 $s^0$，随后按 replay 中真实执行过的动作展开 $K$ 步，并在每步监督三种输出。

$$
\ell_t(\theta)=\sum_{k=0}^{K}\left[\ell^r(u_{t+k},r_t^k)+\ell^v(z_{t+k},v_t^k)+\ell^p(\pi_{t+k},p_t^k)\right]+c\|\theta\|^2.
$$

$u$ 是实际 reward，$\pi$ 是搜索策略。棋类的 $z$ 使用最终胜负；Atari 使用真实 reward 加未来搜索 value 的 $n$-step target

$$
z_t=u_{t+1}+\gamma u_{t+2}+\cdots+\gamma^{n-1}u_{t+n}+\gamma^n\nu_{t+n}.
$$

因此模型并非模仿自己未改进的动作分布，搜索产生了更强的 policy target。recurrent unroll 则要求表示经过多个动作后仍能预测后续 reward/value/policy。论文使用 $K=5$，却能在搜索时展开更深路径，这也是模型应接受检验的泛化维度。[↗](https://arxiv.org/pdf/1911.08265#page=4)

![MuZero equations](../../assets/images/paper-deep-dives/world-models/muzero/figure-s2-equations.png)

*原论文 Figure S2。将 acting 中的搜索输出与 learning 中的监督对应起来，能看出 policy improvement 的闭环。*

## 强成绩来自什么预算

棋类每步 800 simulations，Atari 每步 50 simulations。棋类用与 AlphaZero 相同的搜索次数比较；Atari 将大数据与低数据两组分开。

| Agent | Median | Mean | Env. Frames |
| --- | ---: | ---: | ---: |
| R2D2 | 1920.6% | 4024.9% | 37.5B |
| MuZero | 2041.1% | 4999.2% | 20.0B |
| LASER | 431% | — | 200M |
| MuZero Reanalyze | 731.1% | 2168.9% | 200M |

*原论文 Table 1；Atari 57 games，human-normalized scores。大数据 MuZero 与 200M Reanalyze 是不同配置。*

![MuZero training evaluation](../../assets/images/paper-deep-dives/world-models/muzero/figure-2-training-evaluation.png)

*原论文 Figure 2。棋类纵轴为 Elo，Atari 为归一化分数；不可跨面板比较数值大小。*

Reanalyze 用最新网络重新搜索旧轨迹，刷新训练目标，降低所需新交互。原文每个棋类实验用 16 个第三代 TPU 训练、1000 个 TPU self-play；每个 Atari 游戏用 8 个训练 TPU、32 个 self-play TPU。表中的 12 小时不能与单 GPU 算法的天数直接当作计算效率比。[↗](https://arxiv.org/pdf/1911.08265#page=6)

## 测试时搜索与训练时搜索并非同一个问题

![MuZero evaluations](../../assets/images/paper-deep-dives/world-models/muzero/figure-3-evaluations.png)

*原论文 Figure 3。先分清 A/B 改变训练完成后的搜索预算，C/D 改变训练算法或训练时搜索次数。*

Go 中增加思考时间继续改善成绩，learned model 能支撑超过训练搜索量的规划。Atari 的测试时收益较小，约 100 simulations 后趋于平台；单次 simulation 的策略也较强，说明训练后的 policy 已吸收部分搜索收益。Ms. Pacman 的训练对照显示 search-based learning 优于替换后的 Q-learning，但同时改变目标与输出头，不能归因成某个单独 loss 的功劳。即使每步只有 6 simulations，模型仍能学习有效策略，增加训练搜索则进一步提高表现。[↗](https://arxiv.org/pdf/1911.08265#page=6)

![MuZero policy improvement details](../../assets/images/paper-deep-dives/world-models/muzero/figure-s3-details.png)

*原论文 Figure S3。补充的搜索与策略改进结果帮助区分“搜索此刻更强”与“搜索教出更好的网络”。*

MuZero 最值得复用的思想是按下游决策定义模型输出：若目标是搜索动作，reward、value、policy 可以成为状态学习的监督接口。代价是训练与推理都要为搜索付费，且所得 latent 的有效性依赖任务与价值目标；它不保证恢复可解释物理状态。
