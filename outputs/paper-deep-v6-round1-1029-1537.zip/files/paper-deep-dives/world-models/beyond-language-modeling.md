---
paper_date: 2026-03
paper_title: "Beyond Language Modeling: An Exploration of Multimodal Pretraining"
paper_topic: 世界模型
---

# Beyond Language Modeling：多模态预训练怎样长出世界模型能力

!!! info "论文信息"
    **论文题名：** Beyond Language Modeling: An Exploration of Multimodal Pretraining。<br>
    **作者：** Shengbang Tong、David Fan、John Nguyen、Ellis Brown、Gaoyue Zhou、Shengyi Qian、Boyang Zheng、Théophane Vallaeys、Junlin Han、Rob Fergus 等（共 21 人）。<br>
    **机构：** 未在公开元数据中稳定解析；以 arXiv/PDF 或官方页 affiliation block 为准。<br>
    **时间 / 主题：** 2026-03；世界模型。<br>
    **arXiv / 官方报告：** arXiv：[2603.03276](https://arxiv.org/abs/2603.03276)；官方材料：[beyond-llms.github.io/](https://beyond-llms.github.io/)。<br>
    **GitHub / 项目：** GitHub：未找到官方链接；项目页：[beyond-llms.github.io/](https://beyond-llms.github.io/)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2603.03276)；[官方 / 项目材料](https://beyond-llms.github.io/)；Checked Date：2026-06-15；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 从头预训练，拆开多模态收益的来源

这篇研究围绕表示、数据、动作接口、MoE 与 scaling 分别做受控实验。作者从头训练 unified model，避免把预训练 LLM 已有能力误算为本轮多模态学习的收益。主干同时做语言 next-token prediction 与视觉 flow matching，默认 2.3B 总参数、1.5B activated；不同实验族控制自身预算，不能把各图结果看成同一个最终模型的所有成绩。[↗](https://arxiv.org/pdf/2603.03276#page=3)

![Beyond Language Modeling overview 原图](../../assets/images/paper-deep-dives/world-models/beyond-language-modeling/figure-1-study-overview.png)

*原论文 Figure 1。五条研究轴共同回答如何训练，但各自有独立对照。*

## 表示与预测目标共同决定学习难度

视觉可来自 VAE、semantic encoder 或 pixels。默认使用冻结 SigLIP2 So400M，视频逐帧编码到 224×224 输入；RAE 用 representation encoder 加 decoder，使语义特征也能还原图像。主干视觉侧通过线性 projection 进入 token sequence，而不是用另一个 U-Net 生成器。

$$
z_t=(1-t)\epsilon+tz_0,\qquad
\mathcal L_{\mathrm{flow}}=\mathbb E\left[\|v_\theta(z_t,t,\mathrm{context})-(z_0-\epsilon)\|_2^2\right].
$$

$z_0$ 为 clean image/frame latent，$\epsilon$ 为高斯噪声；每帧独立采样一个 $t$，帧内 tokens 共用。文本 causal，视觉帧内双向、帧间 causal。默认 loss 权重 language:flow=1:3；视觉推理使用 25-step Euler、CFG=3。[↗](https://arxiv.org/pdf/2603.03276#page=4)

语义表示使理解与生成共享更直接的内容信息，但高维特征还影响 denoising parameterization。MoE 实验中 SigLIP2 RAE 更受益于 x-pred，FLUX VAE 更适合 v-pred；不能把一个 representation 的最佳预测目标无条件搬给另一个。

## 异质数据为什么可能优于继续堆同类数据

![Beyond Language Modeling training data 原图](../../assets/images/paper-deep-dives/world-models/beyond-language-modeling/figure-2-training-data.png)

*原论文 Figure 2。text、unlabeled video、paired image-text 和 action-conditioned video 提供的监督关系不同。*

在 VQA 实验中，20B VQA tokens 单独训练得 34.6，增加 80B video 为 36.1，增加 80B image-text 为 36.9，增加 80B text 为 37.9；直接扩到 100B VQA 为 35.7。总量同为 100B 的比较支持异质预训练的价值，收益不只是“多训练了 80B”。[↗](https://arxiv.org/pdf/2603.03276#page=9)

语言与视觉的相互作用也受数据分布影响。图像 synthetic recaption 相对语言训练语料的 cosine distance 为 0.286，普通 MetaCLIP 为 0.196，SSTK 为 0.215。作者据此讨论 caption 分布导致的语言 perplexity 变化，并分别用适合 image-to-text 与 text-to-image 的数据。这里相关性为解释提供线索，不是独立证明距离指标本身导致性能变化。

## 动作可以成为文本接口，但评价仍需真实轨迹

![Navigation actions as text 原图](../../assets/images/paper-deep-dives/world-models/beyond-language-modeling/figure-11-navigation-actions.png)

*原论文 Figure 11。4 个 context frames 加 `dx,dy,dyaw,rel_t` 数值字符串，预测下一视角。*

Navigation World Model 任务无需新增 action adapter，数值动作直接作为文本 tokens。评测用 CEM 每轮采样 120 条候选、8-step horizon，最小化预测终点图与目标图的 LPIPS，报告 ATE 与 RPE。这检验的是动作条件预测能否支持目标导航，而不只是图像像不像。[↗](https://arxiv.org/pdf/2603.03276#page=10)

| Training mixture | ATE ↓ | RPE ↓ |
| --- | ---: | ---: |
| NWM 50B | 1.974 | 0.516 |
| NWM 100B | 1.669 | 0.450 |
| NWM 50B + Video 50B | 1.410 | 0.414 |
| NWM 50B + Text Action 50B | 1.448 | 0.407 |
| NWM 50B + Text 50B | 1.657 | 0.448 |
| NWM 50B + ImageText 50B | 1.801 | 0.503 |

![Video data improves world modeling 原图](../../assets/images/paper-deep-dives/world-models/beyond-language-modeling/figure-12-world-modeling-video-data.png)

*原论文 Figure 12。应优先比较总量相同的 100B 配置；两个误差都越低越好。*

unlabeled video 在 ATE 最好，Text Action 在 RPE 略好。ImageText 比 50B baseline 有帮助，却不如 100B NWM；“异质数据总优于同域扩展”超出了这组结果。

![Minimal alignment transfer 原图](../../assets/images/paper-deep-dives/world-models/beyond-language-modeling/figure-13-minimal-alignment.png)

*原论文 Figure 13。固定 total budget 为 200B，改变 NWM 占比；约 1% 后边际收益很小。*

这说明在该导航设置中，一部分视觉动力学可从一般预训练获得，再用较少动作数据建立接口。它不等于任何新机器人都只需 1% 数据，且 1% 的分母是 200B training tokens，仍是实质训练量。

## MoE 用容量分配回应模态不对称

原文定义 expert granularity

$$
G=\frac{4d_{\mathrm{model}}}{d_{\mathrm{expert}}}.
$$

增大 $G$ 时缩小每个 expert 并增加激活数，维持 active compute。固定 13.5B total、1.5B active 的实验中，视觉较早在 $G=4$ 附近饱和，语言到 $G=16$ 更受益，后续采用 $G=16$。另一实验固定激活 16 experts，扩充总 expert 数，分离更多容量与每 token 运算量。[↗](https://arxiv.org/pdf/2603.03276#page=12)

![MoE sparsity scaling 原图](../../assets/images/paper-deep-dives/world-models/beyond-language-modeling/figure-16-sparsity-scales.png)

*原论文 Figure 16。active compute 固定，总参数和存储需求增加；应同时读语言与视觉指标。*

![Expert specialization 原图](../../assets/images/paper-deep-dives/world-models/beyond-language-modeling/figure-18-expert-specialization.png)

*原论文 Figure 18。早层更多 text-focused experts，后层 vision 与 multimodal 比例增加，分类依据 held-out routing preference。*

IsoFLOP 拟合进一步得到 language 的 $N_{opt}\propto C^{0.47},D_{opt}\propto C^{0.53}$，vision 的 $N_{opt}\propto C^{0.37},D_{opt}\propto C^{0.63}$。在该实验范围内，视觉相对更需要数据，语言相对更需要参数；这些经验指数不是普适物理定律。实际启发是将视觉表示、任务数据与容量路由联合考虑，而不是为两种模态机械分配相同资源。
