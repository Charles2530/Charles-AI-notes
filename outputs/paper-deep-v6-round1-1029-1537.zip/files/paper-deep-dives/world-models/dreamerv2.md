---
paper_date: 2020-10
paper_title: Mastering Atari with Discrete World Models
paper_topic: 世界模型
---

# DreamerV2：离散世界模型玩 Atari

!!! info "论文信息"
    **论文题名：** Mastering Atari with Discrete World Models。<br>
    **作者：** Danijar Hafner、Timothy Lillicrap、Mohammad Norouzi、Jimmy Ba。<br>
    **机构：** 未在公开元数据中稳定解析；以 arXiv/PDF 或官方页 affiliation block 为准。<br>
    **时间 / 主题：** 2020-10；世界模型。<br>
    **arXiv / 官方报告：** arXiv：[2010.02193](https://arxiv.org/abs/2010.02193)。<br>
    **GitHub / 项目：** GitHub：[github.com/danijar/dreamerv2](https://github.com/danijar/dreamerv2)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2010.02193)；[GitHub API / repo](https://github.com/danijar/dreamerv2)；Checked Date：2026-06-04；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## Atari 改变了世界模型要处理的信号

DreamerV2 将 latent imagination 推进到离散动作的 Atari。沿用的骨架仍是“学习 dynamics → 在模型里训练 actor-critic → 真实环境采样”；关键变化包括 categorical latent、KL balancing，以及适合离散动作的策略梯度。论文在 55 个 Atari 游戏、sticky actions、每游戏 200M environment steps 下评价，并对每个游戏单独训练一个 agent。[↗](https://arxiv.org/pdf/2010.02193#page=7)

![Human-level Atari performance](../../assets/images/paper-deep-dives/world-models/dreamerv2/figure-1-first.png)

*原论文 Figure 1。总体成绩描述训练后的控制能力，不是一个共同模型跨游戏零样本迁移。*

## 离散 RSSM 如何工作

先看 Figure 2 的两类状态。$h_t$ 通过 GRU 汇总历史，$z_t$ 将当前图像编码成离散随机变量；没有图像时，prior 从 $h_t$ 预测 $\hat z_t$。图像、奖励和 discount predictor 都读取拼接后的 $(h_t,z_t)$。

![World Model Learning](../../assets/images/paper-deep-dives/world-models/dreamerv2/figure-2-world-model.png)

*原论文 Figure 2。posterior 使用当前图像，prior 不使用；后者才是想象 rollout 的入口。*

$$
h_t=f_\phi(h_{t-1},z_{t-1},a_{t-1}),\qquad z_t\sim q_\phi(z_t\mid h_t,x_t),\qquad \hat z_t\sim p_\phi(\hat z_t\mid h_t).
$$

随机表示含 32 个 categorical variables，每个 32 classes，采样后是 1024 维、32 位激活的稀疏向量。前向使用 one-hot 样本，反向以 softmax 概率的梯度作 straight-through 估计。它允许离散状态参与反向传播，但梯度是有偏估计，不应把采样说成天然可微。[↗](https://arxiv.org/pdf/2010.02193#page=3)

world model 同时最小化图像、reward、discount 的负对数似然和 posterior/prior KL。Atari 的 KL 权重 $\beta=0.1$，连续控制为 $1.0$。discount head 预测终止可能性，之后用累积 discount 为 imagined trajectory 的损失加权，防止将已经结束的未来持续计入收益。

## KL balancing 改变的是梯度方向的权重

一个 KL 数值同时承担两件事：让 prior 接近有图像依据的 posterior，以及让 posterior 不携带太多 prior 不能预测的信息。早期 prior 很差时，过强地把表示拉向它会损害学习。论文使用

$$
\mathcal L_{\mathrm{KL}}=\alpha\,D_{\mathrm{KL}}\!\left(\operatorname{sg}(q_\phi)\Vert p_\phi\right)+(1-\alpha)D_{\mathrm{KL}}\!\left(q_\phi\Vert\operatorname{sg}(p_\phi)\right),\qquad \alpha=0.8.
$$

$\operatorname{sg}$ 是 stop-gradient。第一项主要训练 prior，第二项主要约束表示；forward 值看起来与普通 KL 一样，backward 却更强调让 dynamics 追上表示。这与整体乘 $\beta$ 是两个不同操作。[↗](https://arxiv.org/pdf/2010.02193#page=4)

## actor 并非必须穿过离散 dynamics 求导

行为学习从 replay 对应的 posterior state 开始，预测 $H=15$ 步。critic 用 $\lambda=0.95$ 的 bootstrapped return，连接预测奖励与后续 value。world model 在这一步固定，actor-critic 不修改其表示。

![Actor Critic Learning](../../assets/images/paper-deep-dives/world-models/dreamerv2/figure-3-actor-critic.png)

*原论文 Figure 3。沿 action → next state → reward/value 看信息流，区分前向 rollout 与反向估计器。*

论文将 REINFORCE 与 dynamics backprop 两种 actor 梯度写入统一目标。Atari 最终采用纯 REINFORCE，混合系数 $\rho=1$、entropy scale $10^{-3}$；连续控制采用 dynamics backprop，$\rho=0$、entropy scale $10^{-4}$。因此“DreamerV2 必须将价值梯度穿过所有离散动作”并不符合 Atari 的实际配置。[↗](https://arxiv.org/pdf/2010.02193#page=6)

## 主结果为什么同时报告四种聚合

| Agent | Gamer Median | Gamer Mean | Record Mean | Clipped Record Mean |
| --- | ---: | ---: | ---: | ---: |
| DreamerV2 | 2.15 | 11.33 | 0.44 | 0.28 |
| IQN | 1.29 | 8.85 | 0.21 | 0.21 |
| Rainbow | 1.47 | 9.12 | 0.17 | 0.17 |
| C51 | 1.09 | 7.70 | 0.15 | 0.15 |
| DQN | 0.65 | 2.84 | 0.12 | 0.12 |

*原论文 Table 1；55 games，200M environment steps，baselines 来自采用 sticky actions 的 Dopamine。*

![Atari performance](../../assets/images/paper-deep-dives/world-models/dreamerv2/figure-4-atari-performance.png)

*原论文 Figure 4。先比较最右侧 clipped record mean，再看其余聚合是否给出一致趋势。*

Median 会忽略接近一半游戏的低分；gamer-normalized mean 又可能被少数人类基线低的游戏主导。作者建议按人类 world record 归一化，再将每游戏分数截断到 1 后平均，减少超高分离群游戏的影响。DreamerV2 四项均高于这些基线，而 IQN 与 Rainbow 的相对位置随聚合方式改变，说明指标选择会改变排名。[↗](https://arxiv.org/pdf/2010.02193#page=8)

## 哪些设计获得了直接消融支持

![DreamerV2 ablations](../../assets/images/paper-deep-dives/world-models/dreamerv2/figure-5-ablations.png)

*原论文 Figure 5。这里使用较早的 DreamerV2 版本，需在同一组实验内比较。*

| Ablation | Clipped Record Mean |
| --- | ---: |
| DreamerV2 | 0.25 |
| No Discrete Latents | 0.19 |
| No KL Balancing | 0.16 |
| No Policy Reinforce | 0.15 |
| No Image Gradients | 0.01 |

*原论文 Table 2，200M frames。不能用这张表的 0.25 与 Table 1 的 0.28 混合计算消融降幅。*

离散 latent、KL balancing 和策略 REINFORCE 都有贡献；关闭图像重建对表示的梯度几乎摧毁性能，说明密集视觉学习信号不可由当前奖励替代。categorical 比 Gaussian 在 42 个任务更好、8 个更差、5 个持平；作者提出 aggregate posterior 更易匹配、稀疏性和非平滑动态等解释，但未把这些假设分离验证。[↗](https://arxiv.org/pdf/2010.02193#page=9)

计算规模同样是理解结果的一部分。单张 V100、单环境实例在不到 10 天达到 200M environment steps；action repeat 为 4，实际收到 50M 输入，策略训练使用约 468B imagined compact states。它把大量训练计算移到了 latent space。Video Pinball 表现较弱，作者猜测单像素球容易被重建目标忽略；这也说明“能重建大部分画面”与“保留所有控制关键细节”并不等价。
