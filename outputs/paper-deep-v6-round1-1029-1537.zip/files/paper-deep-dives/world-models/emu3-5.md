---
paper_date: 2025-10
paper_title: "Emu3.5: Native Multimodal Models are World Learners"
paper_topic: 世界模型
---

# Emu3.5：原生多模态模型如何变成世界学习器

!!! info "论文信息"
    **论文题名：** Emu3.5: Native Multimodal Models are World Learners。<br>
    **作者：** Yufeng Cui、Honghao Chen、Haoge Deng、Xu Huang、Xinghang Li、Jirong Liu、Yang Liu、Zhuoyan Luo、Jinsheng Wang、Wenxuan Wang 等（共 23 人）。<br>
    **机构：** 未在公开元数据中稳定解析；以 arXiv/PDF 或官方页 affiliation block 为准。<br>
    **时间 / 主题：** 2025-10；世界模型。<br>
    **arXiv / 官方报告：** arXiv：[2510.26583](https://arxiv.org/abs/2510.26583)；官方材料：[huggingface.co/BAAI/Emu3.5](https://huggingface.co/BAAI/Emu3.5)。<br>
    **GitHub / 项目：** GitHub：[github.com/baaivision/Emu3.5](https://github.com/baaivision/Emu3.5)；项目页：[huggingface.co/BAAI/Emu3.5](https://huggingface.co/BAAI/Emu3.5)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2510.26583)；[GitHub API / repo](https://github.com/baaivision/Emu3.5)；[官方 / 项目材料](https://huggingface.co/BAAI/Emu3.5)；Checked Date：2026-06-15；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

| Checked Date | Repro Status | 本页证据口径 |
| --- | --- | --- |
| 2026-06-02 | Author code / model release reported | 以 arXiv HTML、官方仓库与论文图表为主；world exploration、long-horizon generation、embodied manipulation 按生成式 next-state evidence 解读。 |

## 先学统一序列，再改变图像解码方式

Emu3.5 的训练主线是把图文交错内容统一为离散 token 的 next-token prediction，用大规模视频序列学习状态变化，再以 SFT 和 RL 增强多步输出。推理瓶颈则单独通过 DiDA 处理，将一张图内的视觉 tokens 从逐个生成改为并行迭代。统一预训练目标与高效推理方式由此可以分开设计。[↗](https://arxiv.org/pdf/2510.26583#page=5)

![Emu3.5 architecture 原图](../../assets/images/paper-deep-dives/world-models/emu3-5/figure-3-architecture.png)

*原论文 Figure 3。左侧是训练时序列自回归，右侧是适配后的图内并行生成。*

## token、状态与 decoder 是不同层次

主模型实际含约 34.1B parameters，其中 Transformer layers 31.2B、embedding 2.9B；64 layers、hidden size 5120，context 32768。总词表 282926，包含 151854 text tokens 与 131072 vision tokens。视觉 tokenizer 基于 IBQ，下采样 16 倍、code dimension 256，因此 $1024\times1024$ 图约需 4096 visual tokens。

这些 token 既承担感知输入，也承担预测输出；生成 token 后还需 decoder 回到像素。论文除了 vanilla decoder，还训练 diffusion image decoder 和 video decoder，以恢复高分辨率或 keyframes 之间的连续视频。主干是否自回归、tokenizer 是否离散、像素 decoder 是否 diffusion 是三个可以独立变化的设计层次。[↗](https://arxiv.org/pdf/2510.26583#page=18)

## 长序列数据怎样支持多步任务

![Emu3.5 training pipeline 原图](../../assets/images/paper-deep-dives/world-models/emu3-5/figure-4-training-pipeline.png)

*原论文 Figure 4。按 pretraining、SFT、RL、DiDA 的顺序看，每阶段解决不同问题。*

两阶段预训练约 13T tokens，主要来自互联网视频的连续帧与 transcripts；后阶段增加分辨率、质量与标注丰富度。SFT 将任务统一为交错输入输出，Table 3 列出的 token 量包括 General 29.7B、X2I 56.2B、Visual Narrative 10.1B、Visual Guidance 22.5B、World Exploration 17.5B、Embodied Manipulation 14.1B，合计约 150B。这里是 tokens，不能误写为 150B 独立训练样本。[↗](https://arxiv.org/pdf/2510.26583#page=12)

![Emu3.5 video data statistics 原图](../../assets/images/paper-deep-dives/world-models/emu3-5/figure-5-video-data-stats.png)

*论文 video data statistics。观察长视频来源与长度分布如何覆盖连续过程，而不只看总条数。*

World Exploration 支持用户逐步发指令与 free exploration 两种方式。Embodied Manipulation 则将任务分成语义子任务，每个子任务由语言指令与完成时的 keyframe 表示；训练输出是 subtask instruction/keyframe 交错序列。它建模的是语义步骤及目标视觉状态，没有直接输出可执行的关节动作。[↗](https://arxiv.org/pdf/2510.26583#page=12)

## DiDA 如何在图内获得双向信息

![Discrete Diffusion Adaptation 原图](../../assets/images/paper-deep-dives/world-models/emu3-5/figure-9-dida.png)

*原论文 Figure 9。比较 noisy image copy 的 attention 与 clean/text 路径，图内双向不允许读取未来 clean 图。*

adaptation 为图像构造 noisy copy。noisy tokens 可以读取此前 clean context，并在同张 noisy image 内双向 attention；clean image 与 text 仍保持原 causal pattern。训练用 self-distillation 的图文及交错数据。推理时文本逐 token 输出，遇到图像进入 discrete denoising，整组 visual tokens 同时逐步修正。[↗](https://arxiv.org/pdf/2510.26583#page=16)

| Emu3.5 Variant | Resolution | Tokens | Naive Time (s) | FlagScale Time (s) | GenEval | DPG-Bench | GEdit-EN G_O |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| AR | 1024×1024 | 4096 | 512 | 120 | 0.86 | 88.26 | 7.59 |
| DiDA | 1024×1024 | 4096 | 22 | 10 | 0.86 | 87.46 | 7.56 |

*原论文 Table 16；文本到图像 inference time，34B 模型。*

按同一实现比较，naive 的加速为 $512/22\approx23.3$ 倍，FlagScale 为 $120/10=12$ 倍；论文概括的约 20 倍不能直接套在 FlagScale 10 秒上。质量指标总体接近，但 DPG 与 editing 有小幅下降，因此这是一种有具体质量—速度权衡的适配。[↗](https://arxiv.org/pdf/2510.26583#page=26)

## 多步世界输出到底测量了什么

![Emu3.5 world exploration 原图](../../assets/images/paper-deep-dives/world-models/emu3-5/figure-18-world-exploration.png)

*原论文 Figure 18。沿指令顺序追踪场景布局和视角，检查变化是否响应当前命令。*

![Emu3.5 embodied manipulation 原图](../../assets/images/paper-deep-dives/world-models/emu3-5/figure-19-embodied-manipulation.png)

*原论文 Figure 19。观察子步骤与关键帧是否对应；这展示生成的操作过程，而不是实机控制轨迹。*

| Task | Win (%) | Tie (%) | Lose (%) |
| --- | ---: | ---: | ---: |
| Visual Narrative | 49.2 | 10.3 | 40.5 |
| Visual Guidance | 51.5 | 9.5 | 39.0 |
| World Exploration | 65.5 | 0.0 | 34.5 |
| Embodied Manipulation | 67.1 | 2.4 | 30.5 |

*原论文 Table 14，相对 Gemini 2.5 Flash Image 的自动 preference evaluation，由 ChatGPT 评价。*

这些 win rates 衡量生成内容在指定维度上的相对偏好，不是机器人 success rate。探索评测关注路径合理性、空间一致性和图文对齐等；操作评测针对步骤与状态的生成质量。因此 Emu3.5 最直接的使用方式是交互视觉叙事、过程说明和可控未来关键帧生成。要把关键帧用于机器人执行，还需 inverse dynamics 或策略接口，以及实际闭环反馈检验。
