---
paper_date: 2025-07
paper_title: "Towards Video World Models"
paper_topic: 世界模型
---

# Towards Video World Models：视频世界模型五个门槛

!!! info "论文信息"
    **论文题名：** Towards Video World Models。<br>
    **作者：** Xun Huang。<br>
    **机构：** 作者个人技术博客；原文未给出机构署名。<br>
    **时间 / 主题：** 2025-07；世界模型。<br>
    **arXiv / 官方报告：** arXiv：未找到专门条目；官方原文：[xunhuang.me/blogs/world_model.html](https://www.xunhuang.me/blogs/world_model.html)。<br>
    **GitHub / 项目：** GitHub：未找到官方链接。<br>
    **元数据来源与核验口径：** 来源：[官方原文](https://www.xunhuang.me/blogs/world_model.html)；Checked Date：2026-07-07；Repro Status：Blog / official materials reviewed, independent reproduction not claimed。

## 同一个“世界模型”，可能在追求两种不同结果

Xun Huang 这篇技术文章的价值，是给视频世界模型建立一组可以逐项检查的要求。文章先区分两种目标：内部世界理解模型在抽象空间预测后果，帮助智能体决策；外部世界模拟器则试图提供足够细致的环境，让机器人或人可以在其中行动。两者都预测世界变化，但不需要同样的状态精度，也不应只凭生成画面的漂亮程度比较。[↗](https://www.xunhuang.me/blogs/world_model.html#what-are-world-models)

第一张图应看预测细节的差别。人做决定时可以忽略树叶的纹理，却需要知道前方障碍是否会挡路；给视觉机器人提供训练环境时，模拟器还需要生成能被相机策略识别的观测。

![World model paradigms](../../assets/images/paper-deep-dives/world-models/towards-video-world-models/figure-1-world-model-paradigms.jpg){ width="860" }

第二张图把目标与实现分开。JEPA 等表示预测路线、长视频多模态理解路线，与视频生成、物理引擎、神经三维场景不在同一个分类层级。内部模型可以通过外部模拟器产生的经验训练，二者能够协作。

![World model taxonomy](../../assets/images/paper-deep-dives/world-models/towards-video-world-models/figure-2-world-model-taxonomy.jpg){ width="900" }

## 因果生成给交互留下入口

文章提出五项要求：因果性、交互性、持续性、实时性和物理准确性。最前面的因果性指时间方向，即后续生成不能回过头改变已经呈现的历史，不等于因果推断研究中的干预效应识别。[↗](https://www.xunhuang.me/blogs/world_model.html#causality)

常见双向视频 DiT 联合去噪一整段视频，其优势是整段帧可以相互协调。但如果用户在播放中途按下向左，系统必须有能接收新动作、只重算未来的接口。时间自回归与块内扩散的结合正好提供这种分工：历史保持固定，当前帧或短块并行去噪，完成后成为下一次生成的条件。

文章把 Diffusion Forcing、CausVid 和 MAGI-1 放在同一条机制线上。Diffusion Forcing 用逐帧独立噪声等级适应不同已知程度的历史；CausVid 将已有双向视频模型转成因果、少步模型；MAGI-1 探索直接预训练这种架构。它们改变的是时间依赖和采样接口，不能仅用“把模型变快”概括。

![CausVid](../../assets/images/paper-deep-dives/world-models/towards-video-world-models/figure-3-causvid.jpg){ width="920" }

图中从双向教师到因果学生的转换值得与少步蒸馏一起看。前者让新动作有机会影响未来，后者缩短生成这些未来所需的计算时间。

## 动作标签决定模型能响应什么

因果视频生成仍可能只是一个不断播放的观察模式模拟器。交互性进一步要求系统根据外部行动改变预测，行动可以是游戏按键、机器人电机指令、车辆转向与加速，不能仅以开始时给过一段文字提示代替。[↗](https://www.xunhuang.me/blogs/world_model.html#interactive)

这把数据要求从“很多视频”提高为“视频与动作对齐”。游戏引擎可以记录按键及对应画面，机器人可以记录控制与观测，但网络视频通常没有这些信号。Genie 的潜在动作学习因此是一条重要路线：从相邻视觉状态中压缩出变化因素，再让动力学模型使用这些因素预测。它降低了动作标注需求，但潜在动作与真实机器人可执行指令之间仍需建立对应关系。

选择路线时先问控制接口是什么，比先问模型参数量更有用。相机移动模型能生成探索视频，并不自然拥有接触、抓取或受力控制；后者需要相应的数据与条件设计。

## 持续性遇到的是记忆与延迟的共同约束

持续性包含两个问题。视频要足够长，才能覆盖任务；历史事实要继续成立，才能称为同一个环境。单纯增加上下文长度会使每次生成越来越贵，这与交互应用不能越玩越慢的要求冲突。[↗](https://www.xunhuang.me/blogs/world_model.html#persistence)

文章归纳了三类取舍。

| Route | How it stores history | Where the trade-off appears |
|---|---|---|
| Temporal compression, e.g. FAR / FramePack | 越远的历史压缩得越强，优先保留近期细节 | 远处历史中偶尔关键的细节可能丢失 |
| Persistent 3D conditions | 用三维结构保存场景，再作为视频生成条件 | 静态几何容易复用，动态物体和四维变化更难表示 |
| Recurrent / state-space memory | 把历史更新到固定形式的隐藏状态 | 每步成本稳定，但状态必须保留任务需要的信息 |

下图的 State-Space Video World Model 把 block-wise SSM scan、三维隐藏状态与局部注意力结合。SSM 提供长历史更新，局部注意力补充近邻视觉细节。值得关注的是状态如何承担压缩后的历史，而不只是把 Transformer 换成另一个网络名称。

![State-Space Video World Model](../../assets/images/paper-deep-dives/world-models/towards-video-world-models/figure-5-state-space-video-world-model.png){ width="920" }

## FPS 与动作响应延迟必须分别测量

吞吐量是每秒生成多少帧，延迟是动作发出后多久出现响应帧。批量生成可以获得很高 FPS，但如果下一整块内容已经排定，用户仍可能等待很久。要判断交互体验，需要同时看采样速度、生成块长度和控制更新时机。[↗](https://www.xunhuang.me/blogs/world_model.html#real-time)

文章引用 Self Forcing 的单 GPU 17 FPS 与亚秒延迟，说明“用自己的 rollout 训练，再以缓存流式生成”的路线具有可行性。这个数字属于文中所引用的方法和配置，不是所有因果视频模型共享的速度，也不是机器人闭环控制频率。随着动作粒度、分辨率和上下文变化，吞吐与延迟都需要重新测量。

原文对非因果整段生成的批评应放在“生成后继续逐帧接收新动作”的场景理解。关键在于已生成片段如何处理新控制；视频时长本身不等于所有实现中的纯计算耗时。把因果结构、块大小和少步采样分开测，才能定位等待来自哪里。

## 物理泛化不能由视觉真实感代替

文章用 PhyWorld 的二维物理实验区分组合泛化和外推泛化。模型可能把训练中见过的运动、外观重新组合，却在速度、质量等物理属性超出训练分布时失败。因而“生成过很多真实视频”与“掌握可外推的物理规律”之间仍有待实验检验的距离。[↗](https://www.xunhuang.me/blogs/world_model.html#physically-accurate)

改善方式也不只扩大模型。VideoJAM 加入光流去噪目标，让训练明确关注运动；Ctrl-Crash 用事故数据补充罕见接触事件；PISA 关注物体下落数据。这些代表了两类可执行干预：改变学习信号，以及补足对应用关键、却在普通视频中稀少的状态转移。

文章关于“数据覆盖整个世界就没有分布外”的表述是一种乐观设想，不是实验结论。真正决定机器人训练可用性的，是模型是否在策略将访问的动作和状态附近保持可信，尤其能否识别失败后果。

## 五项要求不是单一总分

金字塔将因果性与交互性置于底部，持续性位于中间，再把实时响应与物理准确性分成两个方向。这一结构表达的是应用优先级，而非一套已经统一验证的等级认证。[↗](https://www.xunhuang.me/blogs/world_model.html#summary)

![Levels of video world models](../../assets/images/paper-deep-dives/world-models/towards-video-world-models/figure-8-levels-pyramid.jpg){ width="760" }

面向人的娱乐环境对动作延迟极其敏感，部分物理近似只要不破坏体验就可能被接受。用于离线训练机器人的模拟器可以运行得慢一些，但错误的接触结果和奖励会把策略带向现实中无法成功的行为。由此应先决定应用最不能牺牲什么，再选择模型与评测。

## 视频路线应与几何、物理路线组合比较

物理引擎用显式动力学与渲染器产生观测，通常易于定义控制和约束，但场景、物体和任务配置需要投入。神经三维表示便于保持视角一致和快速渲染，但复杂动态仍难处理。视频生成具有广泛外观先验和灵活条件接口，却需要额外解决持续性、控制精度与运行时成本。[↗](https://www.xunhuang.me/blogs/world_model.html#other-approaches)

![Simulation approaches](../../assets/images/paper-deep-dives/world-models/towards-video-world-models/figure-9-simulation-approaches.jpg){ width="920" }

这张比较图适合按需求阅读，不能当作所有实现的定量排名。文章举 WonderPlay 说明混合路线可以让物理模拟负责动态、三维表示负责几何、视频模型负责视觉效果。对实际系统而言，最可复用的判断方法是明确每个模块负责保存哪种事实、接收什么动作、产生什么可检验的后果，然后分别测量一致性、动作误差、响应延迟和任务结果。
