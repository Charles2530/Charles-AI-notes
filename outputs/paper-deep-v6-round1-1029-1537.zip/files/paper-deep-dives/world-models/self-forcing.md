---
paper_date: 2025-06
paper_title: "Self Forcing: Bridging the Train-Test Gap in Autoregressive Video Diffusion"
paper_topic: 世界模型
---

# Self Forcing：对齐自回归视频训练与推理

!!! info "论文信息"
    **论文题名：** Self Forcing: Bridging the Train-Test Gap in Autoregressive Video Diffusion。<br>
    **作者：** Xun Huang、Zhengqi Li、Guande He、Mingyuan Zhou、Eli Shechtman。<br>
    **机构：** Adobe Research；The University of Texas at Austin。<br>
    **时间 / 主题：** 2025-06 首版，2025-11 v2；世界模型。<br>
    **arXiv / 官方报告：** arXiv：[2506.08009](https://arxiv.org/abs/2506.08009)；官方材料：[self-forcing.github.io/](https://self-forcing.github.io/)。<br>
    **GitHub / 项目：** GitHub：[github.com/guandeh17/Self-Forcing](https://github.com/guandeh17/Self-Forcing)；项目页：[self-forcing.github.io/](https://self-forcing.github.io/)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2506.08009)；[GitHub repo](https://github.com/guandeh17/Self-Forcing)；[官方项目页](https://self-forcing.github.io/)；Checked Date：2026-07-08；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 将模型自己的历史带回训练

自回归视频模型在推理时只能依赖已生成的历史。Teacher Forcing 训练时读取真实历史，Diffusion Forcing 训练时读取不同噪声水平的真实历史，二者都不等于模型实际生成的历史。Self Forcing 在后训练时按推理流程 rollout，再对整段生成视频施加 distribution-matching loss，让模型在自己的偏差上学习。[↗](https://arxiv.org/pdf/2506.08009#page=2)

![Self Forcing training paradigms 原图](../../assets/images/localized-remote/paper-deep-dives/world-models/self-forcing/self-forcing-training-paradigms-原图.png)

*原论文 Figure 1。先比较 context 的来源，再比较监督是逐帧还是完整生成序列。*

## 两层生成循环与梯度截断

视频概率按时间分解为

$$
p_\theta(x^{1:N})=\prod_{i=1}^{N}p_\theta(x^i\mid x^{<i}).
$$

每个 conditional 再由少步 diffusion 生成。外层逐 frame/chunk 前进，内层从高斯噪声逐步去噪；上一块 clean output 的 K/V 缓存给下一块。$x^i$ 在实现中也可以表示多个 latent frames，不能将公式中的“frame”一律理解为一张最终 RGB 帧。

![Self Forcing attention masks 原图](../../assets/images/localized-remote/paper-deep-dives/world-models/self-forcing/self-forcing-attention-masks-原图.png)

*原论文 Figure 2。TF/DF 通过 mask 并行模拟条件关系，Self Forcing 直接沿时间展开并复用 KV cache。*

完整穿过所有去噪步和所有历史块反传会消耗过多显存。作者每次为序列随机选择一个 denoising exit step，只在每块的该最后计算步骤保留梯度，较早去噪步骤不建梯度图；历史 KV 也 detach。因此训练匹配了自生成 context，但采用截断梯度，不是对无限 rollout 作完整反向传播。随机 exit 使不同去噪阶段都有机会获得监督。[↗](https://arxiv.org/pdf/2506.08009#page=5)

## 整段视频分布怎样对齐

论文比较三类目标。DMD 以真实数据 teacher 与生成模型的 score 差优化噪声分布上的 reverse KL；SiD 使用 Fisher divergence；GAN 则由判别器区分生成与真实序列。它们共享的是对实际 self-rollout 视频分布的训练，不只是把去噪步数减少。

DMD 的目标写为

$$
\mathbb E_t\left[D_{\mathrm{KL}}\bigl(p_{\theta,t}\Vert p_{\mathrm{data},t}\bigr)\right].
$$

$t$ 为加噪时间，$p_{\theta,t}$ 来自生成完整视频后再加噪；teacher 提供 data score。换成 TF/DF 的并行输出再做 DMD，会改变被对齐的 generator distribution，这正是与 CausVid 比较的机制重点。DMD/SiD 后训练可不使用视频训练样本，但依赖预训练 diffusion teacher；GAN 版本则使用生成的视频数据集。[↗](https://arxiv.org/pdf/2506.08009#page=6)

## rolling cache 不等于无限记忆

![Self Forcing rolling KV cache 原图](../../assets/images/localized-remote/paper-deep-dives/world-models/self-forcing/self-forcing-rolling-kv-cache-原图.png)

*原论文 Figure 3。比较窗口移动时是否重算旧 KV，而不是只看 attention 是否 causal。*

固定窗口保存最近 $L$ 帧的 KV，满后逐出最旧部分，避免滑窗时反复编码重叠历史。按文中窗口 attention 分析，重算 causal cache 为 $O(L^2+TL)$，rolling 为 $O(TL)$，$T$ 是去噪步数。可持续向后生成来自有限缓存循环，不代表永久记住所有历史。

3D VAE 首个 latent frame 只编码一张图，统计特性与后续时间压缩 latent 不同。训练总能看到第一帧、长生成却会将它逐出，因此作者在训练最后 chunk 时禁止读取第一 chunk，模拟这一变化。10 秒生成中重算 cache 为 4.6 FPS，经过上述训练适配的 rolling cache 为 16.1 FPS。[↗](https://arxiv.org/pdf/2506.08009#page=9)

## 速度、启动延迟与质量分别看

| Model | Resolution | Throughput (FPS) ↑ | Latency (s) ↓ | VBench Total ↑ |
| --- | --- | ---: | ---: | ---: |
| Wan2.1 1.3B | 832×480 | 0.78 | 103 | 84.26 |
| CausVid 1.3B | 832×480 | 17.0 | 0.69 | 81.20 |
| Self Forcing, chunk-wise | 832×480 | 17.0 | 0.69 | 84.31 |
| Self Forcing, frame-wise | 832×480 | 8.9 | 0.45 | 84.26 |

*原论文 Table 1；单张 H100，Self Forcing 使用 DMD，4-step diffusion。chunk-wise 每次生成 3 个 latent frames。*

chunk-wise 保持 17 FPS 吞吐并改善同架构 CausVid 的质量；frame-wise 将首输出延迟降到 0.45 秒，吞吐却低于 16 FPS 播放率。因而低 latency 和持续实时播放是两个指标，不应只选其中一个称为全面实时。[↗](https://arxiv.org/pdf/2506.08009#page=8)

![Self Forcing qualitative comparison 原图](../../assets/images/localized-remote/paper-deep-dives/world-models/self-forcing/self-forcing-qualitative-comparison-原图.png)

*原论文 Figure 5。沿时间对比饱和度和细节是否持续漂移，静态首帧无法检验累积误差。*

Table 2 在相同训练实现下进一步区分收益来源。chunk-wise 的 DF+DMD 为 82.76，TF+DMD 为 82.32，Self Forcing+DMD 为 84.31；frame-wise 对应为 80.56、78.12、84.26。更频繁的 AR rollout 对基线伤害更明显，Self Forcing 更稳定，支持处理 exposure bias 的解释。SiD、GAN 也达到相近水平，说明收益不完全绑定某一个 divergence。

![Self Forcing training efficiency 原图](../../assets/images/localized-remote/paper-deep-dives/world-models/self-forcing/self-forcing-training-efficiency-原图.png)

*原论文 Figure 6。先看相同 wall-clock 下的质量，再读单次迭代时间。*

每次 DMD 实验约在 64 张 H100 上训练 1.5 小时收敛，基础模型为 Wan2.1-T2V-1.3B，初始化使用 16k ODE solution pairs。后训练时序列内部仍有大量并行 token 计算，且无需复杂 TF/DF mask，解释了 sequential rollout 未必更慢。实践价值是用后训练预算换更接近真实部署分布的生成质量，尤其适用于必须边生成边接收新输入的系统。
