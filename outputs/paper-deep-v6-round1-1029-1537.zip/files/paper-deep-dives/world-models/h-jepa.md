---
paper_date: 2023-06
paper_title: "Introduction to Latent Variable Energy-Based Models: A Path Towards Autonomous Machine Intelligence"
paper_topic: 世界模型
---

# H-JEPA：层级 JEPA 与潜变量 EBM

!!! info "论文信息"
    **论文题名：** Introduction to Latent Variable Energy-Based Models: A Path Towards Autonomous Machine Intelligence。<br>
    **作者：** Anna Dawid、Yann LeCun。<br>
    **机构：** 未在公开元数据中稳定解析；以 arXiv/PDF 或官方页 affiliation block 为准。<br>
    **时间 / 主题：** 2023-06；世界模型。<br>
    **arXiv / 官方报告：** arXiv：[2306.02572](https://arxiv.org/abs/2306.02572)。<br>
    **GitHub / 项目：** GitHub：未找到官方链接。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2306.02572)；Checked Date：2026-06-15；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 用 energy 描述相容性，而不先生成每一个细节

这篇讲义从 Energy-Based Model 解释 JEPA 与层级预测的动机。它的主要成果是概念与机制的组织：如何表示多个相容答案，怎样防止能量塌缩，以及为何不同时间尺度需要不同抽象。H-JEPA 是这条论证的终点，不是一套附有统一 benchmark 的新训练系统。[↗](https://arxiv.org/pdf/2306.02572#page=2)

![Autonomous AI architecture](../../assets/images/paper-deep-dives/world-models/h-jepa/figure-1-autonomous-ai-architecture.png)

*原文 Figure 1。world model 与 actor、cost、perception 组成闭环，预测只是行为系统的一部分。*

## EBM 的 inference 与 learning 要分开

EBM 给输入 $x$ 和候选输出 $y$ 分配标量 $F_w(x,y)$。相容的组合应能量低，不相容的组合应能量高。已训练后，inference 对 $y$ 求低能解；training 则改变参数 $w$，塑造整个 energy landscape。

![Towards energy-based models](../../assets/images/paper-deep-dives/world-models/h-jepa/figure-3-energy-based-models.png)

*原文 Figure 3。比较网络直接输出单一 $y$ 与给多个候选打分的接口。*

如果需要概率，可用 Gibbs 形式

$$
p(y\mid x)=\frac{\exp[-\beta F_w(x,y)]}{\int\exp[-\beta F_w(x,y')]\,dy'}.
$$

$\beta$ 控制能量差对应的概率集中程度，分母是归一化所需的 partition function。在高维空间，计算或近似这个积分可能昂贵；EBM 可以仅通过能量排序与优化完成推断，而不总是显式归一化。不过“无需归一化”也不自动使寻找低能解变得容易。[↗](https://arxiv.org/pdf/2306.02572#page=10)

## 潜变量表示缺少的解释因素

![Latent variable examples](../../assets/images/paper-deep-dives/world-models/h-jepa/table-1-latent-variable-examples.png)

*原文 Table 1。看潜变量如何表达姿态、分割或结构，不要将它们一律理解为随机噪声。*

对于 $E_w(x,y,z)$，$z$ 可以表示目标中无法由输入确定的因素。原文以椭圆为例

$$
E_{r_1,r_2}(y,z)=(y_1-r_1\sin z)^2+(y_2-r_2\cos z)^2.
$$

$r_1,r_2$ 定义椭圆尺度，$z$ 是角度。固定点 $y$ 后优化 $z$，找的是椭圆上与它最相近的位置；若对 $z$ 积分，则综合多个位置的贡献。这分别对应最优解释与边缘化，而不应混淆最小能量值和实现该值的 argmin 参数。[↗](https://arxiv.org/pdf/2306.02572#page=11)

![Latent-variable EBM](../../assets/images/paper-deep-dives/world-models/h-jepa/figure-4-latent-variable-ebm.png)

*原文 Figure 4。绿色查询点和蓝色训练流形说明 latent variable 如何参数化多个可能解释。*

“存在潜变量”也不必然等于概率模型。可以从分布抽取 $z$，也可以从一个可行集合中选择它；两种方式都能产生多个未来，但只有前者明确赋予概率。

## 为什么只压低真实样本能量不够

![Energy collapse](../../assets/images/paper-deep-dives/world-models/h-jepa/figure-5-energy-collapse.png)

*原文 Figure 5。关键反例是所有输入都得到相同低能量，此时低训练误差没有区分能力。*

contrastive 方法降低数据点能量并抬高负样本能量，高维连续空间的问题是负样本空间巨大、采样代价高。regularized 方法通过架构瓶颈或正则限制低能量区域的容量，间接避免整个空间都变低。

![EBM training](../../assets/images/paper-deep-dives/world-models/h-jepa/figure-6-ebm-training.png)

*原文 Figure 6。两条路线共享“低能数据、高能非数据”的目标，但约束位置不同。*

讲义用 Hopfield、Boltzmann machine 与 denoising autoencoder 展示这些思想的不同实例。Hopfield 的 spurious minima 说明只强化已见模式可能产生意外低能状态；Boltzmann 的 positive/negative phase 更完整地塑造分布，却付出采样成本。它们为 JEPA 的正则化路线提供动机，不构成本文对现代视频模型的统一比较实验。

## JEPA 需要同时控制三条信息通道

![JEPA architecture](../../assets/images/paper-deep-dives/world-models/h-jepa/figure-9-jepa.png)

*原文 Figure 9。$x,y$ 先各自编码，predictor 从 $s_x$ 与 $z$ 预测目标表示 $s_y$。*

两侧 encoder 可有不同结构，以支持视频、音频等不同输入。encoder 能过滤与预测无关的细节，$z$ 则表达剩余不确定性。训练需同时降低表示预测误差、维持 $s_x,s_y$ 的信息量、限制 $z$ 的信息容量。否则 encoder 输出常数，或全部目标信息经 $z$ 传入，都会让模型绕开真正的预测关系。

![Regularized JEPA loss](../../assets/images/paper-deep-dives/world-models/h-jepa/figure-10-regularized-jepa-loss.png)

*原文 Figure 10。先看每条正则约束作用于哪个变量，再理解其防止的捷径。*

VICReg 是讲义给出的实现例子。跨 batch 的各维标准差下限，例如 $[1-\sqrt{\operatorname{Var}(v_i)}]_+$，避免常数输出；非对角 covariance 约束减少表示分量的线性冗余；prediction 项联系两侧信息。高维 expander 可增强独立信息的学习，但去相关本身不等于已经证明统计独立。[↗](https://arxiv.org/pdf/2306.02572#page=21)

## 层级的本质是改变预测粒度

![H-JEPA architecture](../../assets/images/paper-deep-dives/world-models/h-jepa/figure-11-h-jepa.png)

*原文 Figure 11。下层从 $x_0$ 预测短时 $x_1$ 的表示，上层以更抽象表示跨越到更远的 $x_2$。*

短期预测需要细节，长期预测却可能被同样的细节拖累。H-JEPA 在层间编码、pooling，令不同层保留不同尺度信息，从而将复杂任务分成逐步细化的子目标。其可采用的设计原则是先确定每层的状态语义、时间间隔和子目标接口，再讨论网络规模。单独增大模型或减少像素重建，都不能替代这些接口的明确设计。[↗](https://arxiv.org/pdf/2306.02572#page=22)
