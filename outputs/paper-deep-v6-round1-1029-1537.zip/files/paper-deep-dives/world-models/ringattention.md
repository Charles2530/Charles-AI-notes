---
paper_date: 2023-10
paper_title: Ring Attention with Blockwise Transformers for Near-Infinite Context
paper_topic: 世界模型
---

# RingAttention：近无限上下文训练

!!! info "论文信息"
    **论文题名：** Ring Attention with Blockwise Transformers for Near-Infinite Context。<br>
    **作者：** Hao Liu、Matei Zaharia、Pieter Abbeel。<br>
    **机构：** UC Berkeley。<br>
    **时间 / 主题：** 2023-10；世界模型。<br>
    **arXiv / 官方报告：** arXiv：[2310.01889](https://arxiv.org/abs/2310.01889)；官方材料：[largeworldmodel.github.io/lwm/](https://largeworldmodel.github.io/lwm/)。<br>
    **GitHub / 项目：** GitHub：[github.com/haoliuhl/ringattention](https://github.com/haoliuhl/ringattention)；项目页：[largeworldmodel.github.io/lwm/](https://largeworldmodel.github.io/lwm/)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2310.01889)；[GitHub API / repo](https://github.com/haoliuhl/ringattention)；[官方 / 项目材料](https://largeworldmodel.github.io/lwm/)；Checked Date：2026-06-04；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 长序列的障碍不只在 attention matrix

内存高效 attention 可以不物化完整 $s\times s$ 权重矩阵，但每层输出仍随序列长度 $s$ 增长。Blockwise Parallel Transformer 又把 FFN 分块，仍需要保存长序列的 layer output。Ring Attention 把序列本身分布到不同设备，每台设备保留自己的 query 和输出，让 key/value block 环形流动。它改变 exact attention 的执行顺序与存放位置，不改变全局可见性。[↗](https://arxiv.org/pdf/2310.01889#page=3)

## 一个 query block 怎样看到整个序列

$$
\operatorname{Attention}(Q,K,V)=\operatorname{softmax}\left(\frac{QK^\top}{\sqrt d}\right)V.
$$

$Q,K,V\in\mathbb R^{s\times d}$。块级 attention 的 softmax 统计量可以正确合并，因而一个 query block 不必同时持有全部 K/V，也不必按固定顺序遇到各块。先看原图中 query 固定在哪台设备，再追踪 K/V 如何传给下一个邻居。

![RingAttention method 原图](../../assets/images/localized-remote/paper-deep-dives/world-models/ringattention/ringattention-method-原图.png)

*原论文 Figure 2。每台设备完成自己 query 对所有 K/V 的 attention，随后对本地输出执行 FFN。*

计算当前块时，设备同时向后继发送 K/V，并从前驱接收下一块。这样既避免等待完整 all-gather，也避免长期存储全序列 K/V。反向传播同样使用块级运算和通信重叠。它仍然计算所有需要的 query-key 对，故总算术复杂度保持二次增长，分布式执行并没有把 dense attention 变成线性 attention。

## “隐藏通信”有一个明确条件

设每块长度为 $c$、hidden dimension 为 $d$，设备算力为 $F$ FLOP/s，链路带宽为 $B$ byte/s。论文按计算 $QK^\top$ 与乘 $V$ 共 $4dc^2$ FLOPs、传输 K/V 共 $4cd$ bytes 估算

$$
\frac{4dc^2}{F}\ge\frac{4cd}{B}\quad\Longrightarrow\quad c\ge\frac FB.
$$

左侧计算时间足够长，右侧传输才能藏在计算后面。忽略 projection 和 FFN 的纯计算使这个条件偏保守。小 block 或低带宽都会破坏“无额外通信开销”的理想情形。[↗](https://arxiv.org/pdf/2310.01889#page=5)

| Spec Per Host | Interconnect Bandwidth (GB/s) | Minimal Blocksize (×1e3) | Minimal Sequence Len (×1e3) |
| --- | ---: | ---: | ---: |
| A100 NVLink | 300 | 1.0 | 6.2 |
| A100 InfiniBand | 12.5 | 24.5 | 149.5 |
| TPU v4 | 268 | 1.0 | 6.2 |

*原论文 Table 2。对比同为 A100 的两行，就能看到网络拓扑怎样改变合适的分块尺度。*

缓存包括 query、当前 K/V、接收 K/V 和输出共六类 block。论文 Table 1 在其记账口径下给出最大 activation $6bch$，而 BPT 为 $2bsh$；关键差异是依赖本地 block 长度而非全局 $s$。参数、优化器和全模型训练内存仍需结合其他并行策略考虑，不能把该局部 activation 公式当作完整显存预算。

## 容量实验测的是可运行长度

![RingAttention max context 原图](../../assets/images/localized-remote/paper-deep-dives/world-models/ringattention/ringattention-max-context-原图.png)

*论文最大上下文结果。先固定模型与设备，再比较 baseline 和 Ring Attention。*

| Configuration | Model | Memory Efficient Attn and FFN (×1e3 tokens) | Ring Attention (×1e3 tokens) |
| --- | --- | ---: | ---: |
| 8× A100 NVLink | 7B | 32 | 256 |
| 32× A100 InfiniBand | 7B | 128 | 4096 |
| TPUv4-1024 | 7B | 16 | 8192 |

*原论文 Table 3，end-to-end training。实验保持 total batch tokens 可比，用 FSDP 配合 Ring sequence parallelism。*

这些倍率来自把更多设备内存用于同一序列，而不只用于更多独立样本。它说明系统容量能随设备数增长，不说明预训练模型自动学会使用那么远的依赖。line retrieval 是另一层证据，检查模型能否从长上下文中找回目标。

![RingAttention line retrieval 原图](../../assets/images/localized-remote/paper-deep-dives/world-models/ringattention/ringattention-line-retrieval-原图.png)

*论文检索实验。应分别看 context length 与目标所在位置，容量上限和有效检索能力是不同指标。*

对视频、轨迹与多模态训练，Ring Attention 提供长序列的基础设施。实践要先根据实际网络带宽和 kernel 吞吐选择 block，再与参数分片及 checkpointing 组合。后续 [LWM](lwm.md) 展示了下一步工作：长上下文数据、位置编码、任务混合和损失配平都必须跟上，硬件能装下序列只是起点。
