---
paper_date: 2026-05
paper_title: "Lance: Unified Multimodal Modeling by Multi-Task Synergy"
paper_topic: 世界模型
---

# Lance：统一多模态模型，为什么对世界模型有启发

!!! info "论文信息"
    **论文题名：** Lance: Unified Multimodal Modeling by Multi-Task Synergy。<br>
    **作者：** Fengyi Fu、Mengqi Huang、Shaojin Wu、Yunsheng Jiang、Yufei Huo、Hao Li、Yinghang Song、Fei Ding、Jianzhu Guo、Qian He 等（共 13 人）。<br>
    **机构：** 未在公开元数据中稳定解析；以 arXiv/PDF 或官方页 affiliation block 为准。<br>
    **时间 / 主题：** 2026-05；世界模型。<br>
    **arXiv / 官方报告：** arXiv：[2605.18678](https://arxiv.org/abs/2605.18678)；官方材料：[lance-project.github.io/](https://lance-project.github.io/)。<br>
    **GitHub / 项目：** GitHub：未找到官方链接；项目页：[lance-project.github.io/](https://lance-project.github.io/)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2605.18678)；[官方 / 项目材料](https://lance-project.github.io/)；Checked Date：2026-06-15；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 多任务统一需要共享上下文，也需要区分职责

Lance 将 image/video understanding、generation、editing 与 subject-driven generation 放进同一训练框架，检验不同任务能否互相改善。它采用 3B activated parameters 的双专家结构：理解侧偏重语义，生成侧偏重外观与时序，两侧通过共享交错序列交互。工作重点是统一多模态建模，世界模型相关价值在于可组合的视觉状态转换接口。[↗](https://arxiv.org/pdf/2605.18678#page=7)

![Lance framework 原图](../../assets/images/paper-deep-dives/world-models/lance/figure-6-framework.png)

*原论文 Figure 6。先区分 text、semantic ViT、clean VAE、noisy VAE，再追踪 LM head 与 flow head。*

理解路径由 Qwen2.5-VL 初始化，ViT 使用 14 倍空间、2 倍时间 patching，随后 $2\times2$ spatial merge。生成路径使用 Wan2.2 causal 3D VAE，视频空间下采样 16 倍、时间下采样 4 倍。不同表示进入同一 hidden space，但由对应 expert 处理。序列中后一个 segment 读取此前 clean segments；文本段内部 causal，视觉段内部 bidirectional。[↗](https://arxiv.org/pdf/2605.18678#page=10)

## 两种目标如何连接到实际输出

文本端最小化 next-token cross-entropy；视觉端从噪声 $x_0\sim\mathcal N(0,I)$ 与 clean latent $x_1$ 构造

$$
x_t=tx_1+(1-t)x_0,\qquad
\mathcal L_{\mathrm{GEN}}=\mathbb E\left[\|v_{\theta_{\mathrm{GEN}}}(x_t,S,t)-(x_1-x_0)\|_2^2\right].
$$

$S$ 是共享交错上下文，$t\sim U(0,1)$。flow head 学到从噪声朝 clean latent 移动的速度，推理时对视觉 tokens 迭代生成；语言仍逐 token 输出。总目标 $\mathcal L=\lambda_u\mathcal L_{\mathrm{UND}}+\lambda_g\mathcal L_{\mathrm{GEN}}$ 保留不同能力路径的优化职责。[↗](https://arxiv.org/pdf/2605.18678#page=11)

## MaPE 解决同一坐标下的 token 角色混淆

semantic token、clean condition 和 noisy target 可能来自同一位置，却承担不同功能。普通 3D-RoPE 只编码时空位置，不显式区分这三类角色。

![MaPE 原图](../../assets/images/paper-deep-dives/world-models/lance/figure-7-mape.png)

*原论文 Figure 7。比较三组 token 的时间偏移，空间位置保持不变。*

$$
p^{(m_i)}_{t,h,w}=\hat p^{(m_i)}_{t,h,w}+[i\Delta_t,0,0],\qquad i\in\{0,1,2\}.
$$

$\hat p$ 是原始 3D position，$i$ 为模态组，$\Delta_t$ 为固定偏移。组内全部 tokens 同幅平移，所以内部时间距离不变；改变的是不同组之间的位置关系。它让网络更容易区分视觉证据和待生成目标，而不重新安排原有空间网格。

## 数据日程如何逐步引入困难任务

PT 使用 1.5T tokens 建立基础理解与生成，CT 使用 300B 引入多任务交错，SFT 使用 72B，RL 阶段约 0.5B。最大窗口从 PT 的 40K 到后续 70K，论文报告 128-GPU 训练预算；设备数不是 GPU-hours，不能据此单独比较完整训练成本。

全局 video-generation:video-understanding:image-generation:image-understanding 保持 64:16:16:4，但 generation 内部任务比例逐步变化。CT 中 T2V:I2V:video-edit:subject-to-video 从 60:10:15:15 到 25:25:25:25，让模型先形成基础视觉生成，再增加条件复杂度。[↗](https://arxiv.org/pdf/2605.18678#page=12)

![Training token scaling 原图](../../assets/images/paper-deep-dives/world-models/lance/figure-13-token-scaling.png)

*原论文 Figure 13。先标出 PT、CT、SFT 边界；阶段切换也改变任务数据，曲线不是只有训练步数一个因素。*

## 协同是否超出了简单能力拼装

| Setting | GenEval ↑ | VBench ↑ | MVBench ↑ |
| --- | ---: | ---: | ---: |
| Gen. only | 80.88 | 81.25 | — |
| Gen.:Und.=8:2 | 81.65 | 82.91 | 58.06 |
| Gen.:Und.=9:1 | 80.93 | 81.47 | 57.99 |
| 9:1, Gen.:MT-Gen.=8:2 | 81.89 | 82.88 | 59.18 |
| 9:1, Gen.:MT-Gen.=6:4 | 82.06 | 83.05 | 58.95 |

*原论文 Table 9。MT-Gen. 包括 editing 与 subject-driven generation，数值保留论文百分制口径。*

加入 understanding data 改善 generation，加入 multi-task generation 又改善基本生成，支持跨任务互补。但更高 MT 比例的 MVBench 58.95 低于另一配置 59.18，数据配比不存在对所有指标同时最优的保证。[↗](https://arxiv.org/pdf/2605.18678#page=22)

MaPE 的直接消融则是另一层证据：w/ 与 w/o 的 GenEval 为 80.94/80.56，GEdit 为 6.86/6.30，VBench 为 81.81/80.95，MVBench 为 59.16/59.02。最大变化出现在 editing，比只引用总榜更清楚地说明 positional disambiguation 帮助了什么。[↗](https://arxiv.org/pdf/2605.18678#page=24)

![Lance benchmark overview 原图](../../assets/images/paper-deep-dives/world-models/lance/figure-1-radar.png)

*原论文 Figure 1。雷达图用于观察能力覆盖，不能把不同基准分数当成同一量纲。*

实际采用可从三点入手：按任务保留合适的视觉表示，显式区分 condition/target 的位置与可见性，按训练阶段调整任务难度。论文的生成、理解和编辑结果支持这套设计；“生成看似符合物理的片段”与实际机器人闭环成功率仍是不同评价对象。
