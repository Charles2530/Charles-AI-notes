---
paper_date: 2025-10
paper_title: "A Comprehensive Survey on World Models for Embodied AI"
paper_topic: 世界模型
---

# Embodied World Model Survey：具身世界模型综述

!!! info "论文信息"
    **论文题名：** A Comprehensive Survey on World Models for Embodied AI。<br>
    **作者：** Xinqing Li、Xin He、Le Zhang、Min Wu、Xiaoli Li、Yun Liu。<br>
    **机构：** This work was supported in part by the National Natural Science Foundation of China (No. 62576176) and in part by the Fundamental Research Funds for the Central Universities (Nankai University, No. 070-63253235).。<br>
    **时间 / 主题：** 2025-10；世界模型。<br>
    **arXiv / 官方报告：** arXiv：[2510.16732](https://arxiv.org/abs/2510.16732)。<br>
    **GitHub / 项目：** GitHub：[github.com/Li-Zn-H/AwesomeWorldModels](https://github.com/Li-Zn-H/AwesomeWorldModels)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2510.16732)；[GitHub API / repo](https://github.com/Li-Zn-H/AwesomeWorldModels)；Checked Date：2026-06-15；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 用三个独立问题定位一个世界模型

这篇综述用三个分类轴整理具身世界模型：它是否与具体决策任务耦合，未来按什么时间结构生成，以及世界状态保存在什么空间表示中。三个轴分别回答**预测为了什么、预测怎样展开、预测的对象是什么**。这比按 RNN、Transformer、diffusion 排队更有解释力，因为同一种网络可以支持完全不同的控制接口。[↗](https://arxiv.org/pdf/2510.16732#page=3)

总概念图可以从观测到内部状态、再从内部状态到想象与决策阅读。历史既提供当前判断，也约束未来。世界模型的价值最终取决于这些想象是否能被规划器、策略或评估器使用。

![Core concepts](../../assets/images/paper-deep-dives/world-models/world-models-embodied-ai-survey/Fig1_core_concepts.png){ width="760" }

本文的覆盖横跨机器人操作、导航、驾驶和通用视频。它的主要产出是设计空间和对比资料，而非提出一个统一模型。因此，量化表里的成绩应连同输入、监督、分辨率和任务预算解读，不宜合成“最佳世界模型”的总排名。

## 数学起点是部分可观测下的状态估计

机器人看到的是观测 $o_t$，真正状态 $s_t$ 通常不可直接获取。综述先用 latent $z_t$ 表达与预测有关的历史，区分三个分布

$$
\underbrace{p_\theta(z_t\mid z_{t-1},a_{t-1})}_{\text{dynamics prior}},\qquad
\underbrace{q_\phi(z_t\mid z_{t-1},a_{t-1},o_t)}_{\text{filtered posterior}},\qquad
\underbrace{p_\theta(o_t\mid z_t)}_{\text{reconstruction}}.
$$

prior 仅凭旧状态和动作向前预测；posterior 在真实观测到达时校正；decoder 把状态连接回可观察世界。训练中有观测可用，想象 rollout 时没有未来观测，因而模型必须让 prior 足够接近由 posterior 获得的状态。[↗](https://arxiv.org/pdf/2510.16732#page=2)

对应的变分目标由重建项和 KL 约束组成

$$
\mathcal L(\theta,\phi)=\sum_{t=1}^{T}\mathbb E_{q_\phi(z_t)}[\log p_\theta(o_t\mid z_t)]
-D_{\mathrm{KL}}\!\left(q_\phi(z_{0:T}\mid o_{1:T},a_{0:T-1})\,\|\,p_\theta(z_{0:T}\mid a_{0:T-1})\right).
$$

重建要求 latent 保存足够信息，KL 将看过真实未来的推断状态与可由动作预测的状态对齐。这是理解 RSSM 等概率状态模型的共同起点，不能把它当作所有被综述方法的实际损失。JEPA 预测教师 embedding，离散 token 模型优化序列目标，flow/diffusion 模型学习去噪或速度场，显式几何方法也可能依赖渲染及物理约束。

## 第一轴，决策耦合决定学习中哪些错误更重要

**Decision-Coupled** 模型围绕特定控制任务学习。奖励、价值、动作和动力学共同决定表示，模型可以舍弃对任务无用的视觉细节。Dreamer 类 latent imagination、驾驶中的 MILE、用于候选轨迹评估的预测系统，都体现这种用途。紧耦合有助于样本效率，但也可能把特定任务偏好写进状态表示，转移到新任务时需要重新适配。[↗](https://arxiv.org/pdf/2510.16732#page=3)

![Decision-coupled world model](../../assets/images/paper-deep-dives/world-models/world-models-embodied-ai-survey/Fig1_decision.png){ width="760" }

**General-Purpose** 模型先学习较广泛的视觉、几何或物理变化，再供多种下游任务调用。iVideoGPT、Genie、视频 JEPA 以及通用视频/三维生成路线在这一侧提供可迁移先验。但广度不保证控制敏感性：视频预训练可能很擅长续写最可能发生的事情，却未必精确区分两个很接近的电机指令。

这条轴应理解为目标耦合程度，不是永久标签。一个通用视频模型经动作适配后可以成为任务模拟器，再通过奖励或价值学习与某个策略强耦合。评估其迁移能力时，应区分预训练期间的通用能力和任务适配后的效果。

## 第二轴，逐步模拟与整体预测如何分配时间依赖

### 顺序生成天然适合闭环，但会继承自己的误差

Sequential Simulation and Inference 按时间展开，每个预测状态成为下一步的条件。RNN/RSSM 通过递归隐藏状态压缩历史，Transformer 通过历史 token 或 KV 缓存提供上下文，分块自回归 diffusion 则在块间因果、块内联合生成。[↗](https://arxiv.org/pdf/2510.16732#page=6)

![Sequential simulation](../../assets/images/paper-deep-dives/world-models/world-models-embodied-ai-survey/Fig1_Seq.png){ width="780" }

图中递归结构与分块自回归共享同一控制机会：下一步生成前可以接入新动作或新观测。相应代价是生成出的偏差会进入后续条件，开放 rollout 越长，分布偏移越明显。缓存能够减少重复计算，却不能自动修复已经错误的历史。

不同路线用不同方式维持历史。StateSpaceDiffuser 和 state-space video 模型把长历史压进可递归状态；VRAG 检索历史帧；持久 RGB-D/几何记忆保留曾经看过的空间；MiLA 等方法先预测稀疏锚点再补细节。它们分别控制记忆成本、信息检索和长期约束，不能仅以“上下文更长”概括。[↗](https://arxiv.org/pdf/2510.16732#page=9)

逆动力学在顺序建模中承担另一种角色。forward model 问动作导致什么，IDM 问两状态之间需要怎样的动作。IDM 可以把视频计划变成控制，也能帮助区分可控变化与环境自主变化，例如 Iso-Dream 的分解。反向恢复动作只是接口，仍需检查生成转移是否落在机器人可执行的范围内。

### 整体预测降低串行依赖，但在线交互粒度不同

综述称为 **Global Difference Prediction** 的另一组方法，一次预测多个未来状态或被掩码时空区域。它减少逐步调用的串行深度，并在同一生成过程里施加跨时间约束；但未来通常在一个整体中被确定，中途更新动作需要重新生成、分块或另设因果接口。[↗](https://arxiv.org/pdf/2510.16732#page=8)

JEPA 图强调的是预测空间的选择。context encoder 处理可见部分，EMA target encoder 给出监督目标，predictor 在 embedding 空间补足被遮挡区域；stop-gradient 防止目标随预测误差任意移动。该机制学习通用时空表示，不能仅凭 masked prediction 就宣称已经具备动作条件前向动力学。

![Masked JEPA](../../assets/images/paper-deep-dives/world-models/world-models-embodied-ai-survey/Fig1_mask.png){ width="680" }

V-JEPA 2 通过大规模视频预训练和少量机器人交互后训练连接规划，V-JEPA 2.1 进一步采用稠密及深层监督；DINO-Foresight 预测未来语义特征，再连接分割、深度等任务头。另一侧的视频 DiT 或 occupancy diffusion 则生成完整未来片段。它们都能并行预测，却有不同的输出与训练目标。[↗](https://arxiv.org/pdf/2510.16732#page=10)

时间轴与网络类型并非一一对应。扩散既可以一次生成完整片段，也可以做因果块生成；Transformer 既可以递归使用历史，也可以全局 masked prediction。选择时应查看实际注意力掩码、预测跨度与观测刷新时机。

## 第三轴，状态表示决定哪些结构容易保持

| Representation | Preserved structure | Typical benefit | Main cost |
|---|---|---|---|
| Global Latent Vector | 整体状态的紧凑摘要 | rollout 轻量，适合高频控制与小预算学习 | 局部几何、遮挡和多物体关系可能压缩不足 |
| Token Feature Sequence | patch、模态或对象间依赖 | 灵活融合视觉、语言、动作，可复用序列模型 | token 数量与注意力成本，是否保留空间结构取决于编码 |
| Spatial Latent Grid | BEV、voxel 或空间对齐特征 | 多视角融合、局部更新、占用与规划直连 | 分辨率、范围和显存相互制约 |
| Decomposed Rendering Representation | Gaussian、NeRF 等可渲染几何元素 | 视角一致、对象组合、连接数字孪生 | 重建成本，快速形变和拓扑变化难处理 |

这四类表达了主要组织方式，现实系统常混合使用。网格也会被 token 化，对象 token 也可能有连续特征；“token”不应一律理解成离散词表索引。[↗](https://arxiv.org/pdf/2510.16732#page=3)

### 全局 latent 的优势在控制预算

RSSM 把确定性历史与随机状态结合，在 latent 内预测奖励并训练策略，适合大量便宜的想象。DayDreamer 将这一思路用于物理机器人；ReDRAW 用少量现实数据修正仿真预训练的 latent 动态；AdaWM 根据模型与规划器不一致选择适配环节。LeWorldModel 则显示紧凑空间也可以采用 next-embedding prediction 与防塌缩正则，不必依赖图像重建。[↗](https://arxiv.org/pdf/2510.16732#page=5)

这一类的工程吸引力是预测成本可控，但如果任务需要区分细小物体位移或接触状态，就必须确认编码器没有把相关信息平均掉。高奖励不能自动说明 latent 保留了完整场景。

### Token 序列便于统一接口，对象结构需要额外设计

IRIS 将视觉离散 token 与想象训练结合，WorldVLA、DrivingGPT 等把视觉和动作放进序列，CarFormer、Dyn-O 等使用对象 slot 保留实体分工。对象中心表示可以把静态背景、运动主体与交互关系拆开；一般 patch token 则更灵活，但需要网络自己学习这种结构。[↗](https://arxiv.org/pdf/2510.16732#page=6)

LLM 推理与世界模型还可以通过不同层次连接。Statler 维护结构化世界状态，Inner Monologue 用执行反馈修正语言推理，MineDreamer 以想象图像指导动作。这里真正应比较的是语言模块负责计划、状态更新还是候选评价，而不是有没有出现 CoT 字样。

### 空间网格把几何直接交给规划器

BEV 与 occupancy 把世界展开到空间坐标，适合驾驶中的可占用区域、障碍及自车未来轨迹。OccWorld 预测 occupancy token，DriveWorld 在 BEV 上建模动态，WoTE 根据候选轨迹模拟并评分；机器人中的 RoboOccWorld、PointWorld 分别使用三维占用和点流，让动作后果直接表现为几何变化。[↗](https://arxiv.org/pdf/2510.16732#page=7)

![Spatial latent grid](../../assets/images/paper-deep-dives/world-models/world-models-embodied-ai-survey/Fig1_SLG.png){ width="760" }

图中的多源特征先对齐空间再预测，优势是保留局部邻接。代价也具体：扩大三维范围或提高体素分辨率会迅速增加内存，静态网格对新区域和不规则形变的表达也需要设计。DINO-WM 等 patch feature 路线则介于语义 token 与局部空间表征之间，说明选择并非只能落在四个极端。

### 可渲染表示把视角一致性变成结构约束

ManiGaussian 预测 Gaussian 场景变化，DreMa 把 Gaussian 场景与物理模拟连接，PIN-WM 从观测估计物理参数；驾驶中的 DriveDreamer4D、ReconDreamer 把视频先验与三维/四维重建结合。与逐帧生成相比，已有几何可以被反复渲染，回头观察时更容易保持结构。[↗](https://arxiv.org/pdf/2510.16732#page=8)

但一份漂亮重建还不是可交互动力学。必须定义 Gaussian、粒子或神经场在动作下怎样变化，如何处理新可见区域、接触、遮挡、物体破坏或形变。混合系统的意义就在于给不同模块分配职责，而不是假设显式三维表示已解决全部物理问题。

## 用三轴组合解释路线，而不是给路线排代际

决策耦合、顺序模拟、全局 latent 的组合，把算力集中到便宜的控制相关 rollout；通用、整体预测、token 表示的组合，适合学习广泛视频先验和语义结构；决策耦合的空间网格便于候选轨迹与占用直接对齐；可渲染表示则适合需要多视角复用和数字孪生的场景。

这几类组合没有统一最优。任务需要的未来跨度、动作更新频率、传感器和可用数据，决定结构收益是否抵得过计算成本。综述在机器人与驾驶方法表中同时记录数据平台和输入模态，正是为了避免把架构名称当作决定性能的唯一因素。[↗](https://arxiv.org/pdf/2510.16732#page=11)

## 数据资源要区分环境、任务协议和离线记录

MuJoCo、Isaac、CARLA、Habitat 是可以创建或运行环境的平台；DMC、Atari、Meta-World、RLBench、LIBERO 是带任务与评测协议的资源；OXE、RT-1、nuScenes、Waymo 等提供离线记录；真实机器人平台则决定实际动作、传感器和复位条件。四者不能互换。

离线视频能教观测规律，交互环境可以测试动作干预，真实轨迹提供执行约束，几何与触觉信号补充不可见状态。跨 embodiment 聚合扩大覆盖，却要求处理坐标、频率和动作语义差异。驾驶 occupancy 数据提供 free/occupied/unobserved 的空间监督，但带真值占用输入的模型与仅从相机推断状态的模型，起点已不同。[↗](https://arxiv.org/pdf/2510.16732#page=11)

实际选择数据时，应先匹配模型的查询形式。无动作视频适合表示和一般动态预训练；动作条件仿真需要同步观测动作；多步控制需要连续历史和失败后的恢复；对象或几何预测需要空间对应；罕见碰撞和多人交互则需要专门覆盖，不能仅靠成功示范数量增长期待自动出现。

## 指标分三层，不能用一个分数代替另外两层

像素生成质量关注 FID、FVD、PSNR、SSIM、LPIPS 或 VBench。FID/FVD 比较特征分布，PSNR/SSIM 比较配对观测，LPIPS 比较感知特征；它们各自测量不同性质。FVD 低可以表明视频分布更接近参考，但不能保证输入动作产生了正确物理后果。[↗](https://arxiv.org/pdf/2510.16732#page=13)

状态理解关注 mIoU、检测、轨迹偏差或 Chamfer distance。它们把问题转向空间占用、对象定位和几何变化，更接近规划需要；但一个预测准确的对象若与任务无关，对控制提升可能很小。

任务层则看成功率、回报、样本效率和碰撞等。它最接近最终目标，也受到策略、搜索预算和反馈机制影响。因而评估最好保持三层对应：世界状态哪里预测错，错误是否改变候选排序，以及是否真的导致闭环失败。[↗](https://arxiv.org/pdf/2510.16732#page=14)

## 原始对比表说明了什么，也暴露了什么条件差异

### 视频质量表需要保留分辨率

综述表 IV 汇总 nuScenes 视频生成结果，以下为代表行。

| Method | Resolution | FID ↓ | FVD ↓ |
|---|---|---:|---:|
| Drive-WM | 192 × 384 | 15.8 | 122.7 |
| Vista | 576 × 1024 | 6.9 | 89.4 |
| DrivePhysica | 256 × 448 | 4.0 | 38.1 |
| MiLA | 360 × 640 | 4.1 | 14.9 |
| GeoDrive | 480 × 720 | 4.1 | 61.6 |

表中 DrivePhysica 的 FID 更低，MiLA 的 FVD 更低，说明外观与视频特征分布的表现可以分离。但分辨率、数据处理和方法预算并不统一，不能据此计算一个纯架构提升比例，更不能推断驾驶安全性。[↗](https://arxiv.org/pdf/2510.16732#page=14)

### Occupancy 预测首先要看输入与自车轨迹

Occ3D-nuScenes 设置用过去 2 秒预测未来 3 秒。表 V 中 COME-O 使用真值 occupancy 输入，若自车轨迹也给 GT，平均 mIoU 为 34.23%；若使用预测自车轨迹，平均 mIoU 为 21.29%。二者相差 12.94 个百分点，直接表明未来自车运动这个条件会显著改变任务难度。[↗](https://arxiv.org/pdf/2510.16732#page=15)

| Method / condition | Input | Ego trajectory | Future mIoU Avg. (%) | Future IoU Avg. (%) |
|---|---|---|---:|---:|
| OccWorld-O | Ground-truth occupancy | Predicted | 17.14 | 26.63 |
| DTT-O | Ground-truth occupancy | Predicted | 30.85 | **74.58** |
| COME-O | Ground-truth occupancy | Predicted | 21.29 | 29.03 |
| COME-O | Ground-truth occupancy | Ground truth | **34.23** | 44.13 |
| COME-S | Camera, no auxiliary supervision | Predicted | 19.11 | 37.63 |

mIoU 与 IoU 排名也不同。正文将 COME 的优势概括得较广，但表中 DTT-O 的平均 IoU 74.58 高于 COME-O 的 44.13，不能写成 COME 在两种指标全面领先。该表更有价值的用途是逐列检查监督与输入，再分析语义占用和总体几何占用各自的变化。

### DMC 和 RLBench 的平均值覆盖不同任务

DMC 表中 PlaNet 与 Dreamer 同为 5M steps、20 个任务，均值分别为 333 和 823；HRSSM 的 938 来自 500k steps、3 个任务，DreamerPro 的 857 来自 1M steps、6 个任务。较高均值不自动意味着全套能力更强，任务集合不同已经改变分母。[↗](https://arxiv.org/pdf/2510.16732#page=15)

RLBench 同样如此。VidMan 为 67%/18 tasks，ManiGaussian 为 45%/10 tasks，DreMa 为 25%/9 tasks，TesserAct 为 63%/10 tasks；分辨率、训练 episode 数、depth 与 proprioception 也有差异。对架构选择更有用的是在共同任务、相同监督与预算下比较；综述均值适合导航文献，不能替代这个受控实验。

### 规划轨迹误差与碰撞率不是同一个目标

nuScenes 开环规划表按 UniAD 协议汇总，观察过去 2 秒、预测未来 3 秒。UniAD+DriveWorld 使用地图、框、运动、tracklet 和 occupancy 等辅助监督，平均 L2 为 0.69 m、碰撞率 0.19%；SSR 无额外辅助监督，平均 L2 为 0.75 m、碰撞率 0.15%。更贴近真值轨迹不一定对应最低碰撞率，监督资源也必须保留。[↗](https://arxiv.org/pdf/2510.16732#page=16)

这些是开环预测指标，尚未包含模型实际控制车辆后环境与其他交通参与者的反馈。将开环改善外推成真实自动驾驶安全提升，需要额外闭环证据。

## 从分类到设计，需要同时预算误差和计算

低延迟场景可以优先考虑紧凑 latent、SSM 或训练后可去掉的大生成分支；需要多视角与空间推理的系统，应考虑网格或显式几何；离线数据生产可以接受较大视频模型，但仍需验证动作与物理约束。长时系统则可能把局部快速递归、稀疏全局纠正、显式记忆与层次规划结合，而不让同一个表示同时承担所有细节。[↗](https://arxiv.org/pdf/2510.16732#page=17)

综述最可复用的分析方法，是给每个新模型写下完整三轴位置，再核对部署时的具体查询和评测条件。只有当表示保留了动作敏感的信息、时间结构允许所需反馈、训练目标与实际用途一致，较好的预测才有机会转化成可靠决策。
