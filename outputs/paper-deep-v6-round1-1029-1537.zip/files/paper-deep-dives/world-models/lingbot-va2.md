---
paper_date: 2026-07
paper_title: "Native Video-Action Pretraining for Generalizable Robot Control"
paper_topic: 世界模型 / 视频-动作机器人控制
---

# LingBot-VA 2.0：原生视频-动作预训练

!!! info "论文信息"
    **论文题名：** Native Video-Action Pretraining for Generalizable Robot Control。<br>
    **作者：** Qihang Zhang、Lin Li、Luyao Zhang、Shuai Yang、Yiming Luo、Shuaiting Li、Ruilin Wang、Junke Wang、Jiahao Shao、Gangwei Xu、Jiaming Zhou、Yishu Shen、Yudong Jin、Fangyi Xu、Shuailei Ma、Jiaqi Liao、Guanxing Lu、Zifan Shi、Yongkun Wen、Yujie Zhao、Weixuan Tang、Xinyang Wang、Chaojian Li、Jiapeng Zhu、Ka Leong Cheng、Nan Xue、Xing Zhu、Yujun Shen、Yinghao Xu。<br>
    **机构：** PDF title page 未列机构；GitHub 归属 Robbyant，README 标注 `[RSS 2026] Causal video-action world model for generalist robot control`。<br>
    **时间 / 主题：** 2026-07（GitHub PDF metadata 生成时间）；世界模型、视频-动作预训练、机器人控制。<br>
    **arXiv / 官方报告：** 用户提供 PDF：[GitHub PDF](https://github.com/Robbyant/lingbot-va/blob/main/LingBot_VA2_paper.pdf)；项目页：[technology.robbyant.com/lingbot-va-v2](https://technology.robbyant.com/lingbot-va-v2)；相关 arXiv：[2601.21998](https://arxiv.org/abs/2601.21998)，题名为 `Causal World Modeling for Robot Control`，与 GitHub VA2 PDF 标题不同。<br>
    **GitHub / 项目：** GitHub：[github.com/Robbyant/lingbot-va](https://github.com/Robbyant/lingbot-va)。<br>
    **元数据来源与核验口径：** 来源：GitHub PDF `LingBot_VA2_paper.pdf`、GitHub README、arXiv metadata；Checked Date：2026-07-31；Repro Status：Paper / official GitHub reviewed, independent reproduction not claimed。

## 让预训练的每一层都面向机器人控制

LingBot-VA 2.0 从第一代视频动作模型的三处错配出发：重建型 VAE 主要保留外观，双向视频生成的时间结构与在线控制不同，完整视频去噪又过于昂贵。它选择重新训练整套 tokenizer 与因果视频动作骨干，把语义对齐、无标签视频中的潜在动作、多步预测监督以及异步执行放进同一系统。[↗](https://github.com/Robbyant/lingbot-va/blob/main/LingBot_VA2_paper.pdf#page=2)

总图应分成快慢两层阅读。高层 VLM planner 给出当前子任务，低层模型根据视觉历史和机器人状态预测未来 latent，再解码动作；MCP 主要提供训练监督，部署时的异步闭环则由 Foresight Reasoning 组织。

![LingBot-VA 2.0 overview](../../assets/images/paper-deep-dives/world-models/lingbot-va2/figure-1-overview.png){ width="900" }

## 视觉压缩同时需要语义和可变化的因素

视觉 tokenizer 把第一帧分为 $16\times16$ patch，后续视频用 $4\times16\times16$ tubelet 编码，空间内全注意力、时间上因果注意力。它保留像素、感知及对抗重建损失，同时使用冻结的 Perception Encoder 作语义教师

$$
\mathcal L_{\mathrm{vis}}=\mathcal L_{\mathrm{rec}}+\lambda_{\mathrm{align}}\mathcal L_{\mathrm{align}},
\qquad
\mathcal L_{\mathrm{align}}=
\left\|\operatorname{avg}(W_{\mathrm{align}}z)-\operatorname{avg}(G(o))\right\|_2^2.
$$

$G(o)$ 是教师特征，$W_{\mathrm{align}}$ 对齐特征维度，$\operatorname{avg}$ 是时间平均。重建监督要求状态仍可还原成观测，语义项要求状态承载与指令和物体相关的信息。两者并用，避免把生成清晰纹理当成控制所需表示的全部目标。[↗](https://github.com/Robbyant/lingbot-va/blob/main/LingBot_VA2_paper.pdf#page=5)

![LingBot-VA 2.0 tokenizer](../../assets/images/paper-deep-dives/world-models/lingbot-va2/figure-2-tokenizer.png){ width="900" }

图的另一半从无动作标签的视频提取变化。冻结视觉 tokenizer 后，逆动力学模型从相邻状态推断低维潜在动作

$$
\ell_t=q_\phi(z_t,z_{t+1}),\qquad
\hat z_{t+1}=f_\psi(z_t,\ell_t)=K_tz_t+\delta_t.
$$

$K_t$ 搬移空间 token 中的信息，$\delta_t$ 表示不能只靠搬移解释的变化。训练同时要求正向预测下一状态、反向恢复上一状态；$\ell_t$ 的低维瓶颈阻止它直接复制整幅未来。这使网络视频也能提供状态转移监督，但这种潜在动作尚不等于机器人关节指令，真实控制仍需要机器人动作数据和对应输出头。

## 因果视频动作模型预测什么

动作 $a_t$ 在这里是一块低层指令，对应 $z_t\to z_{t+1}$ 的一个视觉转移。原文采用的分解是

$$
p_\theta(z_{1:N},a_{0:N-1}\mid z_0)=
\prod_{t=0}^{N-1}
 p_\theta(z_{t+1}\mid z_{\le t},a_{<t})
 p_\theta(a_t\mid z_{\le t},a_{<t},z_{t+1}).
$$

先从历史提出未来视觉状态，再通过逆动力学式路径恢复应当怎样行动。视频与动作分别使用 flow matching，在两个专家流中处理，通过共享因果注意力交换信息。注意第一项只看过去动作 $a_{<t}$；它表达期望未来，还不是“给定当前待执行动作的物理后果预测”。这一差别在异步执行时会再次出现。[↗](https://github.com/Robbyant/lingbot-va/blob/main/LingBot_VA2_paper.pdf#page=4)

视频流有 30 层，在 FFN 使用 128 个 routed experts、每 token 选 8 个，并有共享专家；动作流保持较窄的 dense FFN。视频骨干约 13.0B 总参数、1.9B 激活参数，动作专家约 0.6B，MCP 约 1.7B，合计约 15.3B 训练参数；推理每 token 激活约 2.5B。这里的 MoE 发生在视频流内部，MoT 则指视频与动作两条专家流，两个层级不应混用。[↗](https://github.com/Robbyant/lingbot-va/blob/main/LingBot_VA2_paper.pdf#page=17)

训练混合 T2I、T2V、TI2VA、视频 ICL 与人机共训练五类任务，只逐步改变比例，始终保留早期任务的小比例信号。视觉语言广度、时间动态与动作对齐因此持续共存，减少后期机器人数据使原有先验退化的机会。

## MCP 让相邻帧复制不再足够

高帧率视频相邻时刻非常相似，只监督下一块，模型可能通过保持外观获得较低损失。MCP 从骨干多层特征出发，以辅助模块预测更远的三个未来块，损失权重为 0.5、0.2、0.1。

![LingBot-VA 2.0 MCP](../../assets/images/paper-deep-dives/world-models/lingbot-va2/figure-5-mcp.png){ width="900" }

应看图中辅助头的输入：它们接收融合后的中间特征以及前一辅助模块的隐藏状态，没有把干净未来观测作为当前动作的输入。因此监督迫使历史表示提前包含轨迹变化，避免训练时泄漏未来答案。MCP 主要作用于视觉预测，却通过共享注意力改善动作解码。[↗](https://github.com/Robbyant/lingbot-va/blob/main/LingBot_VA2_paper.pdf#page=9)

标准推理移除这些辅助头，收益来自训练后的骨干；报告也讨论保留辅助头用于并行预测的可选模式。MCP 与异步 Foresight Reasoning 可以独立启用，不能把训练辅助头的存在当作异步控制的必要条件。

## 人类视频有两种不同用途

视频 ICL 把另一个人类示范完整编码成外部任务提示，所有机器人时间步都能关注它。它不是当前机器人轨迹的未来，因而不会违反机器人侧的因果约束。构造 ICL 数据时，报告用 VLM 分析机器人任务，再生成保持同一任务语义的人类视频并筛选，获得超过 5,000 个任务、50,000 个人机配对样本。[↗](https://github.com/Robbyant/lingbot-va/blob/main/LingBot_VA2_paper.pdf#page=16)

人机共训练则把真实第一视角人类操作数据用于更新参数。内部语料含 65.4k episodes、超过 600 名操作者、3.0k 以上场景任务组合。人手根部的 6-DoF 位姿保留，手指关节转换为功能性的夹爪开合量，并使用各 embodiment 的动作编码及解码头；世界模型与主要专家共享。推理只保留机器人分支。前者是“看一个例子再执行”的条件接口，后者是扩大预训练动作经验，两者的作用不同。[↗](https://github.com/Robbyant/lingbot-va/blob/main/LingBot_VA2_paper.pdf#page=11)

高层 planner 约 2 Hz 异步运行，向共享缓冲区写入子任务指令、期望运动描述和局部场景描述；完成标志只供调度器切换子任务。低层动作在块边界读取最新上下文。这要求训练标注与部署输出字段一致，否则高层看似合理的文本也可能成为低层从未学过的条件。

## Foresight Reasoning 的关键在每次重新锚定真实观测

机器人执行当前动作块时，预测流并行准备下一块。为知道当前动作结束后机器人会在哪里，视频专家增加真正的前向动力学条件

$$
\hat z_{t+1}=\operatorname{FDM}_\theta(C_t\cup\{a_t\})
             =v_\theta^{\mathrm{vid}}(z_{\le t},a_{\le t}).
$$

$C_t$ 是由最新真实观测校正后的历史缓存。与前面的生成分解相比，这里额外输入当前正在执行的 $a_t$，并通过专门的 FDM loss 学习其后果。这个在线 FDM 是策略自己的视频专家，不是 tokenizer 阶段冻结的 $f_\psi$。[↗](https://github.com/Robbyant/lingbot-va/blob/main/LingBot_VA2_paper.pdf#page=13)

![LingBot-VA 2.0 Foresight Reasoning](../../assets/images/paper-deep-dives/world-models/lingbot-va2/figure-6-foresight-reasoning.png){ width="900" }

图中执行与预测时间线有重叠，但每次真实观测到达，都会替换缓存中过期的想象状态。若只不断往前想象，模型会沿着平滑但错误的轨迹继续，异步系统就退化为开环。闭环性来自持续的真实反馈校正，而不是“生成未来”这个动作本身。

## 实验支持了哪些环节

RoboTwin 使用 50 个任务，训练数据为 2,500 条 clean 示范和 25,000 条随机场景示范，统一多任务训练。

| Method | Clean Success (%) | Randomized Success (%) | Avg. (%) |
|---|---:|---:|---:|
| π0.5 | 82.7 | 76.8 | 79.8 |
| Motus | 88.7 | 87.0 | 87.9 |
| LingBot-VA | 92.9 | 91.6 | 92.2 |
| LingBot-VA 2.0 | **93.8** | **93.4** | **93.6** |

按表 I 相减，2.0 相对 π0.5 的平均提升是 **13.8 个百分点**，相对第一代是 **1.4 个百分点**，clean 与 randomized 的差距是 **0.4 个百分点**。报告叙述中的 14.0 和 0.6 与表值不一致，此处保留表格计算口径。[↗](https://github.com/Robbyant/lingbot-va/blob/main/LingBot_VA2_paper.pdf#page=19)

真实评测是另一个实验：每项收集 20 条遥操作示范，训练一个共享多任务策略。图 8 中，2.0 在收笔、水果分类、抽屉整理、托盘移交上的成功率分别为 77%、67%、82%、64%；第一代分别为 75%、42%、64%、55%，π0.5 为 50%、42%、64%、45%。这显示收益随任务变化，收笔上的增益明显小于水果分类。单独的视频 ICL 演示则用四个已见任务、每任务 15 条示范微调，再通过人类参考视频执行四种新任务组合；它是无参数更新的组合迁移演示，不能扩大成任意新任务的零样本成功率。[↗](https://github.com/Robbyant/lingbot-va/blob/main/LingBot_VA2_paper.pdf#page=18)

tokenizer 消融用相同 1.3B 下游架构、相同 token 数和 RoboTwin 后训练，50 任务平均 Easy/Hard 从 Wan2.2 VAE 的 78.0%/76.0% 提高到 86.6%/83.1%。在更长的 horizon=3 子集上，提升为 67.2%/68.0%→92.0%/85.4%，支持语义与动作对齐的表示对长转移尤其有用。MCP 消融另用 5B 模型，在 50 FPS randomized 条件下，5k 步时领先 29.7 个百分点，20k 步达到基线 45k 步的效果；这里的约 2.3 倍是训练步数比，不是部署速度。[↗](https://github.com/Robbyant/lingbot-va/blob/main/LingBot_VA2_paper.pdf#page=20)

## 225 Hz 的准确含义

一致性蒸馏把视频和动作的采样步数由 5/10 降为各 2 步，再依次加入 FP8 TensorRT、paged/ragged KV 与 FlashInfer、运行时缓存及同步优化。

| Cumulative acceleration | Inference time (ms/chunk) | Async Hz |
|---|---:|---:|
| BF16 PyTorch async baseline | 927 | 35 |
| + Consistency distillation | 466 | 69 |
| + FP8 compiled execution | 369 | 87 |
| + Attention / KV optimization | 272 | 118 |
| + Runtime optimization | **142** | **225** |

频率按 $(1000/t_{\mathrm{chunk}})\times32$ 计算，每个生成块含 32 个低层控制步。因而 225 Hz 是异步动作供应能力，**每块仍需约 142 ms 推理**，不能理解为每秒 225 次完整视觉反馈重规划。927/142≈6.5 倍是整个累计优化链的提速，不能全部归于 MoE 或量化。[↗](https://github.com/Robbyant/lingbot-va/blob/main/LingBot_VA2_paper.pdf#page=21)

最值得采用的经验是把表示、监督和执行接口一起设计：动作相关 latent 减少无关视觉负担，多块监督迫使表示包含运动，异步预测利用执行时间，而真实观测校正负责保持闭环。少样本适配建立在大规模预训练、专门数据处理和完整推理系统之上，适配数据少并不意味着从零训练成本低。
