---
paper_date: 2024-02
paper_title: "Genie: Generative Interactive Environments"
paper_topic: 世界模型
---

# Genie：没有动作标签，怎样学出可交互环境

!!! info "论文信息"
    **论文题名：** Genie: Generative Interactive Environments。<br>
    **作者：** Jake Bruce、Michael Dennis、Ashley Edwards、Jack Parker-Holder、Yuge Shi、Edward Hughes、Matthew Lai、Aditi Mavalankar、Richie Steigerwald、Chris Apps 等（共 25 人）。<br>
    **机构：** Google DeepMind、University of British Columbia。<br>
    **时间 / 主题：** 2024-02；世界模型。<br>
    **arXiv / 官方报告：** arXiv：[2402.15391](https://arxiv.org/abs/2402.15391)；官方材料：[deepmind.google/research/publications/60474/](https://deepmind.google/research/publications/60474/)。<br>
    **GitHub / 项目：** GitHub：未找到官方链接；项目页：[deepmind.google/research/publications/60474/](https://deepmind.google/research/publications/60474/)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2402.15391)；[官方 / 项目材料](https://deepmind.google/research/publications/60474/)；Checked Date：2026-06-15；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 从没有动作标签的视频里找出控制接口

Genie 的问题是能否仅用视频学出逐帧可操控的生成环境。它不要求互联网录像提供键盘或手柄标签，而是让 latent action model 从前后帧推断少量变化代码，再训练 dynamics 使用这些代码预测下一帧。推理时用户选择代码，接管了原本从视频推断的 latent action。[↗](https://arxiv.org/pdf/2402.15391#page=3)

## 三个组件分别压缩什么

![Genie model training 原论文图](../../assets/images/localized-remote/paper-deep-dives/world-models/genie/genie-model-training-原论文图.png)

*原论文 Figure 3。video tokenizer 压缩画面，LAM 压缩帧间变化，dynamics 将二者联系起来。*

video tokenizer 先以 VQ-VAE 目标训练，将视频变成离散视觉 token。随后 LAM 与 dynamics 联合训练：LAM 直接读取原始像素，dynamics 读取视觉 token 与停止梯度的动作 embedding。

![Video tokenizer 原论文图](../../assets/images/localized-remote/paper-deep-dives/world-models/genie/video-tokenizer-原论文图.png)

*原论文 Figure 6。tokenizer 的 temporal attention 是 causal，所以当前表示只使用已见帧。*

LAM encoder 可看到历史和下一帧，生成连续动作表示并量化到只有 8 个 codes 的 codebook；其 decoder 只能读取历史与这个 code 重建下一帧。小容量迫使 code 集中描述重要变化，而不能直接传递整张未来图。LAM decoder 只提供训练信号，推理时除 codebook 外整套 LAM 都被移除。[↗](https://arxiv.org/pdf/2402.15391#page=4)

![Latent action model 原论文图](../../assets/images/localized-remote/paper-deep-dives/world-models/genie/latent-action-model-原论文图.png)

*原论文 Figure 5。看清训练时下一帧进入 encoder，却不能绕过动作瓶颈直接进入 decoder。*

这些 code 的语义是从数据学习的，并不预先定义成“向左”“跳跃”。用户需要像熟悉新手柄一样探索映射；跨输入出现相近行为是作者展示的涌现性质。

## 时间自回归，帧内迭代补全

![Dynamics model 原论文图](../../assets/images/localized-remote/paper-deep-dives/world-models/genie/dynamics-model-原论文图.png)

*原论文 Figure 7。dynamics 根据过去帧与动作生成目标帧 token，用 cross-entropy 训练。*

dynamics 使用 MaskGIT，在时间维度逐帧推进，在每帧内部迭代填充 masked tokens。训练 masking rate 在 0.5–1 之间采样，动作以 additive embedding 注入，作者发现比单独拼接动作 token 更有利于 controllability。推理每帧采用 25 个 MaskGIT steps，temperature 2。[↗](https://arxiv.org/pdf/2402.15391#page=6)

![ST-transformer architecture 原论文图](../../assets/images/localized-remote/paper-deep-dives/world-models/genie/st-transformer-architecture-原论文图.png)

*原论文 Figure 4。先在单帧空间内 attention，再沿相同空间位置做 temporal attention。*

所有组件采用 ST-transformer，将空间与时间 attention 分开，并在二者之后共用一个 FFN。论文强调主导的 spatial attention 成本随帧数线性增长；这不等于所有时间相关计算都没有二次项。分解结构让视频模型在可用计算预算内扩大规模。

![Genie inference 原论文图](../../assets/images/localized-remote/paper-deep-dives/world-models/genie/genie-inference-原论文图.png)

*原论文 Figure 8。图像 prompt → token → 用户 code → next-frame tokens → decoder，循环产生交互轨迹。*

## 如何区分画面质量与真正受动作影响

FVD 衡量生成视频分布，不能单独判断模型是否忽略控制。论文另定义

$$
\Delta_t\operatorname{PSNR}=\operatorname{PSNR}(x_t,\hat x_t)-\operatorname{PSNR}(x_t,\hat x'_t).
$$

$x_t$ 是真实帧，$\hat x_t$ 使用从真实视频推断的 actions，$\hat x'_t$ 使用随机 actions。差值越大，说明替换动作对重建目标产生更大影响。实验报告 $t=4$。它测的是 action-sensitive reconstruction，仍不同于准确完成指定任务的 success rate。[↗](https://arxiv.org/pdf/2402.15391#page=6)

| LAM input | Dataset | FVD ↓ | ΔtPSNR ↑ |
| --- | --- | ---: | ---: |
| Token-input | Platformers | 38.8 | 1.33 |
| Pixel-input | Platformers | 40.1 | 1.91 |
| Token-input | Robotics | 257.8 | 1.65 |
| Pixel-input | Robotics | 136.4 | 2.07 |

*原论文 Table 2。Platformers 的两模型为 2.3B/2.5B，Robotics 均为 1B。*

Pixel-input 并未在 Platformers FVD 上获胜，却提高了两个领域的 controllability。这说明可视重建最好的瓶颈未必保留最有用的动作变化信息。tokenizer 消融进一步比较 ViT、C-ViViT 与 ST-ViViT，FVD 分别为 114.5、272.7、81.4，显存为 0.3、1.6、0.9 GB；ST-ViViT 在该实验中取得更好的质量/成本折中。[↗](https://arxiv.org/pdf/2402.15391#page=9)

## 规模、泛化与可采用的部分

初始收集超过 200k 小时录像，最终过滤为约 30k 小时、6.8M 个 16-second clips，10 FPS、160×90。模型训练 sequence length 为 16 帧，这与源 clip 的 16 秒不是同一个长度。最终 dynamics 为 10.1B，全部组件约 10.7B，使用 batch 512、125k steps、256 TPUv5p，训练 942B tokens。论文还在 40M–2.7B dynamics 上观察扩大参数带来的 training loss 改善。[↗](https://arxiv.org/pdf/2402.15391#page=7)

![Robotics latent actions 原论文图](../../assets/images/localized-remote/paper-deep-dives/world-models/genie/robotics-latent-actions-原论文图.png)

*论文 Robotics 可视化。机器人结果来自另一个以无动作视频训练的模型，应与 Platformers 主模型区分。*

手绘图、生成图和真实照片 prompt 的演示显示控制可迁移到外观不同的场景；机器人视频展示另一数据域也可学习 latent actions。原文还探索用少量真实动作建立 latent-to-real 映射、从无动作视频学 policy。它们共同说明视频中包含可用于控制学习的信息，但长时间交互仍受上下文、生成误差与约 1 FPS 推理速度限制。最便于复用的部分是“用紧致变化代码构造动作接口”，再以独立 controllability 指标检验模型是否真的使用这个接口。
