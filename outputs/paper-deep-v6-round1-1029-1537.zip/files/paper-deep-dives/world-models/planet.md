---
paper_date: 2018-11
paper_title: Learning Latent Dynamics for Planning from Pixels
paper_topic: 世界模型
---

# PlaNet：像素规划的潜变量动力学

!!! info "论文信息"
    **论文题名：** Learning Latent Dynamics for Planning from Pixels。<br>
    **作者：** Danijar Hafner、Timothy Lillicrap、Ian Fischer、Ruben Villegas、David Ha、Honglak Lee、James Davidson。<br>
    **机构：** 未在公开元数据中稳定解析；以 arXiv/PDF 或官方页 affiliation block 为准。<br>
    **时间 / 主题：** 2018-11；世界模型。<br>
    **arXiv / 官方报告：** arXiv：[1811.04551](https://arxiv.org/abs/1811.04551)。<br>
    **GitHub / 项目：** GitHub：[github.com/danijar/planet](https://github.com/danijar/planet)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/1811.04551)；[GitHub API / repo](https://github.com/danijar/planet)；Checked Date：2026-06-04；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 让规划离开像素空间

PlaNet 解决的困难很具体。智能体只收到图像、动作和奖励，却要在未知动力学中比较许多未来动作。直接为每个候选生成未来视频太慢，单帧图像又不足以给出速度、遮挡物体的位置或接触状态。论文把视觉学习和动作搜索分开：训练时用图像塑造潜在状态，决策时只预测潜在状态与奖励。[↗](https://arxiv.org/pdf/1811.04551#page=3)

先看原图中的任务差异。Cartpole 会离开相机视野，Reacher 与 Cup 有稀疏奖励，Finger 与 Walker 涉及接触。它们使“记住过去”“预测多个可能未来”和“搜索有回报的动作”同时成为要求。

![Image-based control domains](../../assets/images/paper-deep-dives/world-models/planet/figure-1-domains.png)

*原论文 Figure 1。输入最终缩放为 $64\times64\times3$；这是视觉控制任务，不向 agent 提供模拟器的完整物理状态。*

## RSSM 如何同时保存历史和不确定性

纯 RNN 可以长久传递确定性记忆，却容易把不确定未来压成一个预测；纯 stochastic state-space model 每步都经过采样，长期记忆难以稳定保存。RSSM 将两条通路结合。先沿图中实线读生成过程，再看虚线如何利用当前观测修正状态。

![Latent dynamics model designs](../../assets/images/paper-deep-dives/world-models/planet/figure-2-latent-dynamics.png)

*原论文 Figure 2。方框是确定性状态，圆圈是随机变量。*

原文式 4 为

$$
h_t=f(h_{t-1},s_{t-1},a_{t-1}),\qquad s_t\sim p(s_t\mid h_t),
$$

$$
o_t\sim p(o_t\mid h_t,s_t),\qquad r_t\sim p(r_t\mid h_t,s_t).
$$

$h_t$ 是 recurrent memory，$s_t$ 是随机潜变量，$a_t,o_t,r_t$ 分别为动作、观测和奖励。训练及真实交互中，encoder 使用 $q(s_t\mid h_t,o_t)$，让观测纠正 prior；想象未来时没有 $o_t$，必须使用 $p(s_t\mid h_t)$。所有观测信息均经过 encoder 的采样步骤，避免图像直接绕过随机瓶颈进入重建器。[↗](https://arxiv.org/pdf/1811.04551#page=4)

目标函数将图像重建、奖励预测与 posterior/prior 的 KL 联系起来。重建要求状态携带视觉信息；奖励预测使其能够评价任务；KL 要求“看见图像才知道的状态”尽量能由历史和动作预测出来。因而 decoder 虽不参与规划，仍参与形成可规划的表示。

## 训练的一步与规划的多步

标准变分目标逐步重建真实观测，并将一步 prior 对齐 posterior。规划却反复使用自己的预测，训练误差与规划误差并不完全一致。Latent overshooting 将多步 prior 与相应时刻的 posterior 对齐，省去额外图像解码。

![Latent overshooting](../../assets/images/paper-deep-dives/world-models/planet/figure-3-latent-overshooting.png)

*原论文 Figure 3。比较 (b) 的多次图像 likelihood 与 (c) 的波浪形 KL 边，就能看到节省的计算发生在哪里。*

原文先定义

$$
p(s_t\mid s_{t-d})=\int\prod_{\tau=t-d+1}^{t}p(s_\tau\mid s_{\tau-1})\,ds_{t-d+1:t-1}.
$$

这里为简洁省略了动作条件。$d$ 是越过的步数，中间状态仍由 transition 生成。实际目标对 $1\le d\le D$ 的距离平均，并对 $d>1$ 的 posterior 停止梯度，让多步预测追赶有观测支撑的目标。它提供的是通用多步正则方法；论文明确指出最终采用 RSSM 的 agent 并不需要它。不能把 PlaNet 的全部控制收益归因于 overshooting。[↗](https://arxiv.org/pdf/1811.04551#page=5)

## 决策时如何搜索

每次接收新图像，PlaNet 先更新当前状态 belief，再通过 Cross-Entropy Method 搜索未来动作。CEM 从对角高斯中采样 $J$ 条动作序列，在 latent dynamics 中 rollout，累计预测奖励，保留最好的 $K$ 条并重估均值与方差。重复 $I$ 次后，只执行当前步的均值动作。下一次获得观测后重新规划，动作分布重新初始化，避免沿用旧分布困在局部最优。

每条候选动作只采样一条潜在轨迹，将算力优先用于比较更多不同动作。整个搜索无需重建图像，也没有单独的 policy 或 value network。这意味着部署成本仍包含在线搜索，而模型训练阶段通过不断收集新轨迹纠正已经访问区域的动力学。[↗](https://arxiv.org/pdf/1811.04551#page=3)

## 控制结果分别验证了什么

先看模型比较图中 RSSM 与纯 RNN、纯 SSM 的差别，再看 agent 设计图。前者检验表示与动力学，后者检验如何使用模型；两个问题不能合并成一个“世界模型有效”的判断。

![Model comparison](../../assets/images/paper-deep-dives/world-models/planet/figure-4-model-comparison.png)

![Agent designs](../../assets/images/paper-deep-dives/world-models/planet/figure-5-agent-designs.png)

*原论文 Figures 4–5。模型比较支持确定性记忆与随机状态共同使用；agent 比较考察规划和数据收集方式。*

六个任务上，论文报告相对强 model-free 基线平均约 $200\times$ 更少环境交互，最终表现接近、部分超过 D4PG。这个比值说的是训练交互量，不能读成在线决策快 200 倍。单张 NVIDIA V100 的训练耗时约 10–20 小时，随任务变化；因此样本节省没有消除模型拟合与搜索计算。[↗](https://arxiv.org/pdf/1811.04551#page=6)

开环预测展示另一个问题：一旦停止输入真实图像，模型是否还保持合理动态。应从 context 结束处向右看，再比较真实与预测行中的物体轨迹，而不只是背景是否清晰。

![Open-loop predictions](../../assets/images/paper-deep-dives/world-models/planet/figure-9-open-loop-predictions.png)

*原论文 Figure 9。视频重建帮助检查 dynamics，但控制回报才直接检验规划是否成功。*

PlaNet 留下的可复用接口是“观测更新 belief，动作推动 latent，奖励给搜索打分”。适合它的场景是交互数据昂贵、动作维度与规划时域尚可搜索的任务。后续 [Dreamer](dreamer.md) 沿用 latent imagination，把每步搜索改为在模型中训练 actor；这正好对应 PlaNet 仍需付出的在线规划成本。
