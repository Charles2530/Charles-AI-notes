---
paper_date: 2023-01
paper_title: Mastering Diverse Domains through World Models
paper_topic: 世界模型
---

# DreamerV3：世界模型怎样在 latent 里训练策略

!!! info "论文信息"
    **论文题名：** Mastering Diverse Domains through World Models。<br>
    **作者：** Danijar Hafner、Jurgis Pasukonis、Jimmy Ba、Timothy Lillicrap。<br>
    **机构：** 未在公开元数据中稳定解析；以 arXiv/PDF 或官方页 affiliation block 为准。<br>
    **时间 / 主题：** 2023-01；世界模型。<br>
    **arXiv / 官方报告：** arXiv：[2301.04104](https://arxiv.org/abs/2301.04104)；官方材料：[danijar.com/project/dreamerv3/](https://danijar.com/project/dreamerv3/)。<br>
    **GitHub / 项目：** GitHub：[github.com/danijar/dreamerv3](https://github.com/danijar/dreamerv3)；项目页：[danijar.com/project/dreamerv3/](https://danijar.com/project/dreamerv3/)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2301.04104)；[GitHub API / repo](https://github.com/danijar/dreamerv3)；[官方 / 项目材料](https://danijar.com/project/dreamerv3/)；Checked Date：2026-06-15；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 难点从学会任务变成少调参地学会许多任务

DreamerV3 的重点是训练稳定性。DreamerV2 已能通过离散 RSSM 和 imagined actor-critic 学习控制，但新领域会改变奖励尺度、视觉复杂度、动作类型和探索难度。V3 用变换、梯度平衡与归一化让同一套超参数适用于超过 150 个任务。这里的“同一配置”指算法配置复用，各任务仍训练各自的 agent。[↗](https://arxiv.org/pdf/2301.04104#page=2)

![DreamerV3 benchmark summary](../../assets/images/paper-deep-dives/world-models/dreamerv3/x1.png)

*论文 benchmark summary。先看各面板的任务与步数预算，再比较该面板内算法；不同任务的原始回报不共用一个量纲。*

## world model 的三种目标怎样分工

每个环境时间步先用历史状态和上一步动作更新 $h_t$，再结合观测编码离散 $z_t$。模型从 $(h_t,z_t)$ 重建输入、预测 reward 与 continue flag；rollout 时用 prior 代替有观测的 encoder。actor 和 critic 从真实 replay 的表示开始想象，部署时采样 actor 动作，不执行额外 lookahead search。

![World model learning](../../assets/images/paper-deep-dives/world-models/dreamerv3/x2.png)

*原论文 world model 图。关注编码路径和不接收未来图像的 dynamics 路径。*

原文将 world model 损失分为 prediction、dynamics 和 representation，权重分别为 $1,1,0.1$。

$$
\mathcal L_{\mathrm{dyn}}=\max\left(1,D_{\mathrm{KL}}[\operatorname{sg}(q_\phi(z_t\mid h_t,x_t))\Vert p_\phi(z_t\mid h_t)]\right),
$$

$$
\mathcal L_{\mathrm{rep}}=\max\left(1,D_{\mathrm{KL}}[q_\phi(z_t\mid h_t,x_t)\Vert\operatorname{sg}(p_\phi(z_t\mid h_t))]\right).
$$

两式的差异是梯度流向。dynamics 学着预测表示，representation 以较小权重变得容易预测；1 nat 的 free-bits 下限使 KL 已经足够小时停止继续压缩表示，让重建与任务预测保留信息。categorical distribution 还混入 1% uniform probability，避免概率接近零时 KL 尖峰。[↗](https://arxiv.org/pdf/2301.04104#page=5)

这些设计回应了一个实际冲突：复杂 3D 图像有许多无关细节，适合更强压缩；某些 Atari 游戏却可能由单个小物体决定成败。单纯统一加大 KL 权重会伤害后者，free bits 与较小 representation 权重为同一配置留下适应余地。

## 为什么 symlog 与 twohot 要同时理解

不同任务的 observation、reward 和 return 可以相差多个数量级。直接平方误差会使大目标主导梯度，而用运行均值方差归一化又会不断移动训练目标。论文使用

$$
\operatorname{symlog}(x)=\operatorname{sign}(x)\ln(1+|x|),\qquad
\operatorname{symexp}(x)=\operatorname{sign}(x)(e^{|x|}-1).
$$

symlog 保留符号、压缩大幅度，接近零时近似恒等。向量 observation 在 encoder 输入与 decoder 目标处使用它。对于具有随机性的 reward 和 return，论文采用 exponentially spaced bins 上的 twohot 分类损失

$$
\hat y=\operatorname{softmax}(f(x))^\top B,\qquad
\mathcal L=-\operatorname{twohot}(y)^\top\log\operatorname{softmax}(f(x)).
$$

$B$ 是对 $[-20,+20]$ 中的支撑点应用 symexp 后得到的 bin 位置。twohot 将连续目标分配给相邻两个 bin，权重总和为 1；网络学习概率，输出时再取 bin 位置的期望。因此连续预测并未被硬量化成一个类别，梯度尺度也不再随目标数值线性放大。[↗](https://arxiv.org/pdf/2301.04104#page=7)

## 稀疏奖励下为何不能一律放大 advantage

actor 通过 REINFORCE 学习，离散和连续动作均采用这一估计器。critic 提供 bootstrapped $\lambda$-returns，使有限 imagination horizon 之外的回报进入训练。探索使用固定 entropy coefficient $3\times10^{-4}$，但最大化回报的信号先除以 $\max(1,S)$，其中

$$
S=\operatorname{EMA}\bigl(\operatorname{Per}(R_t^\lambda,95)-\operatorname{Per}(R_t^\lambda,5),0.99\bigr).
$$

百分位区间避免极端 episode 主导尺度；分母至少为 1，确保稀疏奖励下不会将接近零的估计噪声大幅放大。这样只有大 return 被缩小，探索与奖励频率的关系得以保留。[↗](https://arxiv.org/pdf/2301.04104#page=6)

![Actor critic learning](../../assets/images/paper-deep-dives/world-models/dreamerv3/x3.png)

*原论文 actor-critic 图。想象状态由模型给出，value 将后续回报传回当前策略。*

## 跨任务、消融与扩规模各回答不同问题

| Domain | Tasks | Training budget |
| --- | ---: | --- |
| Atari | 57 | 200M frames |
| ProcGen | 16 | 50M frames |
| DMLab | 30 | 100M frames |
| Proprio Control | 18 | 500K environment steps |
| Visual Control | 20 | 1M environment steps |

*原论文 Results 的主要协议。Atari100k 另用 26 games、400K frames；不能将 frames 与 agent 决策次数互换。*

跨域实验检验固定配置的适用范围；DMLab 比较中 IMPALA、R2D2+ 使用 1B steps，不能把成绩差异单独归因于模型结构。ProcGen 上 Dreamer 与 tuned PPG 相当，论文并没有在所有比较中一律获胜。[↗](https://arxiv.org/pdf/2301.04104#page=8)

![Ablations and scaling](../../assets/images/paper-deep-dives/world-models/dreamerv3/x7.png)

*论文 ablations/scaling 图。先区分 robustness、learning signals、model size 与 replay ratio 面板。*

14-task 消融显示各稳定化组件平均有帮助，作用集中于不同任务。KL balancing 与 free bits 在该实验中共同移除，不能据此拆出两者各自的独立贡献。移除重建对表示的梯度严重伤害学习，表明视觉自监督提供了主要表示信号。12M–400M 的六个模型规模，以及更高 replay ratio，进一步检验能否用额外计算换更少环境交互；这些是算力与样本效率的交换，不是免费提升。[↗](https://arxiv.org/pdf/2301.04104#page=10)

Minecraft 实验将这种鲁棒性放到探索困难的任务。agent 从像素、稀疏奖励开始，需要获取一串 12 类物品；无 human data 或 adaptive curricula。报告的全部训练 agent 在 100M environment steps 内发现 diamond。应看“发现 diamond 的 agent 比例”随训练变化，而不是把发现一次理解成每个 episode 都稳定完成。

![Minecraft Diamond discovery](../../assets/images/paper-deep-dives/world-models/dreamerv3/x6.png)

*论文 Minecraft 图。任务沿用特定 block-breaking 与动作空间设置。*

开环预测则提供模型内部的诊断。对照 context 后的真实与预测行，可观察空间布局和动作引起的运动是否持续一致。

![Long-term video predictions 1](../../assets/images/paper-deep-dives/world-models/dreamerv3/x4.png)

![Long-term video predictions 2](../../assets/images/paper-deep-dives/world-models/dreamerv3/x5.png)

*论文长期预测可视化。重建质量与控制成绩承担不同证据作用。*

实际采用时，最有价值的是将数据尺度、KL 压缩和探索强度分开处理。原文每个 agent 使用单张 A100；增加模型与 replay 能进一步节约交互，但会增加训练计算。对于交互昂贵、又难以逐任务调参的环境，这套稳定化配方比单个 benchmark 的最高分更值得复用。
