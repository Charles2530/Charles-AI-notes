---
paper_date: 2022-06
paper_title: A Path Towards Autonomous Machine Intelligence
paper_topic: 世界模型
---

# JEPA：预测式表征学习路线

!!! info "论文信息"
    **论文题名：** A Path Towards Autonomous Machine Intelligence。<br>
    **作者：** Yann LeCun。<br>
    **机构：** Meta AI。<br>
    **时间 / 主题：** 2022-06；世界模型。<br>
    **arXiv / 官方报告：** arXiv：未找到专门条目；官方材料：[openreview.net/forum?id=BZ5a1r-kVsf](https://openreview.net/forum?id=BZ5a1r-kVsf)。<br>
    **GitHub / 项目：** GitHub：未找到官方链接；项目页：[openreview.net/forum?id=BZ5a1r-kVsf](https://openreview.net/forum?id=BZ5a1r-kVsf)。<br>
    **元数据来源与核验口径：** 来源：[官方 / 项目材料](https://openreview.net/forum?id=BZ5a1r-kVsf)；Checked Date：2026-06-04；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 从可预测表示到能规划的 agent

这份 position paper 提出的研究路线，是让机器先从观察学习世界的可预测结构，再用这个结构评价行动，并在多个抽象层次上规划。它讨论一组相互配合的模块与训练原则，没有给出一个已经完成所有能力的统一实验系统。JEPA 的意义需要放回这一整体架构中理解。[↗](https://openreview.net/pdf?id=BZ5a1r-kVsf#page=2)

## 世界模型在架构中负责什么

先看 perception 到 world model 再到 cost 的路径，随后看 actor 如何利用预测结果。configurator 负责依据情境和目标配置其他模块，short-term memory 保存近期状态与代价。

![Autonomous intelligence architecture](../../assets/images/paper-deep-dives/world-models/jepa/figure-2-autonomous-agent-architecture.png)

*原文 Figure 2。world model 提供“会发生什么”，cost 提供“希望发生什么”，两者不应混为一体。*

cost 分为 intrinsic cost 与 trainable critic。前者定义即时驱动，后者预测未来 intrinsic cost。actor 可以直接产生动作，也可以反复提出动作序列，通过 world model 预测后果，再优化累计 cost。后一种模式接近 MPC：只执行优化序列的第一个或前几个动作，得到新观测后重新规划。模型可微意味着可以将 cost 对动作的梯度传回；若动作—结果映射有不连续性，原文也讨论采用其他优化方式。[原文 §3.1](https://openreview.net/pdf?id=BZ5a1r-kVsf#page=8)

这一分工解释了为何单纯预测未来还不构成自主行为。模型必须与目标、记忆、动作接口相连，且执行后仍要接受新观测的校正。

## JEPA 为什么在表示空间预测

未来像素包含大量无法由当前输入精确决定的细节。若学习目标必须还原全部细节，模型就必须处理它们；JEPA 则让两侧 encoder 学习表示，使可预测因素进入表示，部分无关细节被不变性过滤。

![JEPA architecture](../../assets/images/paper-deep-dives/world-models/jepa/figure-12-jepa.png)

*原文 Figure 12。先区分输入 $x,y$、表示 $s_x,s_y$ 与 predictor 输出，再追踪潜变量 $z$ 的位置。*

基本过程是 $s_x=\operatorname{Enc}(x)$、$s_y=\operatorname{Enc}(y)$，predictor 从 $s_x$ 与 $z$ 预测 $s_y$，用表示间距离定义 energy。$x,y$ 可以是同一内容的不同视图、不同时间，也可以来自不同模态。$z$ 表达目标中无法从输入确定的变化因素，因而同一个输入允许多个相容未来。[原文 §4.4](https://openreview.net/pdf?id=BZ5a1r-kVsf)

这里“抽象”不等于天然保留任务所需的一切。什么容易预测，受 encoder、predictor、时间间隔与数据构造影响。原文建议加入与任务相关的 prediction heads，把表征偏向有用变量；这是可预测性与任务相关性之间的桥梁。

## 低预测误差为什么可能什么都没学到

如果两个 encoder 输出常数，表示间预测误差也可以很低。如果 $z$ 装入全部目标信息，predictor 又可以忽略 $x$。因此训练要同时解决两种捷径。

![Non-contrastive JEPA training](../../assets/images/paper-deep-dives/world-models/jepa/figure-13-non-contrastive-training.png)

*原文 Figure 13。除了压低预测误差，还要维持表示信息量，并限制潜变量信息容量。*

原文介绍 VICReg 风格约束：variance 项为每个表示分量的跨样本变化设下限，阻止常数塌缩；covariance 项抑制维度间线性冗余，使不同分量承载不同内容；prediction/invariance 项使相应表示能够匹配。expander 将表示映射到更高维空间，以增强这些约束的作用。若使用潜变量，还要通过低维、离散、噪声或正则限制其信息量。[原文 §4.5](https://openreview.net/pdf?id=BZ5a1r-kVsf)

不能把“非对比”理解为只剩一个 L2 误差。被省去的是显式负样本比较，维持表示多样性的机制仍必不可少。这里的方差、协方差约束也不是声称直接精确计算了高维 mutual information，而是可训练的替代约束。

## 时间尺度改变了什么应该被预测

![Hierarchical JEPA](../../assets/images/paper-deep-dives/world-models/jepa/figure-15-h-jepa.png)

*原文 Figure 15。低层处理短时间的丰富细节，高层对低层表示再编码，以更粗粒度跨越更长时间。*

开车几秒后的轨迹需要精细位置和速度，去上班的整体路线却可以忽略具体方向盘角度。H-JEPA 将这两类预测放在不同层级。较高层编码较低层表示，并可在时间上 pooling，使长期预测不必承担短时细节的全部不确定性。这是对信息保留尺度的改变，不只是将同一网络堆深。[↗](https://openreview.net/pdf?id=BZ5a1r-kVsf#page=30)

## 抽象动作怎样约束具体动作

![Hierarchical JEPA planning](../../assets/images/paper-deep-dives/world-models/jepa/figure-16-hierarchical-planning.png)

*原文 Figure 16。先从高层 terminal cost 反推抽象动作，再看抽象动作怎样成为低层子目标。*

高层动作并非直接施加到电机的控制量，而是下层预测状态需要满足的条件。上层选择“到达某处”一类抽象状态，下层 cost 检查实际轨迹能否满足；低层再优化动作。原文指出逐层贪心求解只是起点，跨层联合迭代可令抽象计划与执行可行性相互协调。[↗](https://openreview.net/pdf?id=BZ5a1r-kVsf#page=32)

![Uncertain hierarchical planning](../../assets/images/paper-deep-dives/world-models/jepa/figure-17-uncertain-planning.png)

*原文 Figure 17。红色 latent variables 表示不由 agent 直接控制的未来变化；它们与 action 有不同角色。*

面对不确定性，若任由规划器选择最有利的 $z$，就可能得到过分乐观的计划。原文讨论在多个可能未来上考虑 worst-case、average cost 或风险相关组合。真正需要检验的后续问题由此明确：表示是否同时保留可预测与控制关键因素，高层子目标是否可实现，以及不确定未来的权重是否让计划具有实际鲁棒性。这份路线图的价值，是把这些问题组织成可分工实现的接口。
