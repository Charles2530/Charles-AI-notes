---
paper_date: 2026-01
paper_title: Advancing Open-source World Models with Video Generation Models
paper_topic: 世界模型
---

# LingBot-World：视频基础模型到世界模拟器

!!! info "论文信息"
    **论文题名：** Advancing Open-source World Models。<br>
    **作者：** Robbyant Team、Zelin Gao、Qiuyu Wang、Yanhong Zeng、Jiapeng Zhu、Ka Leong Cheng、Yixuan Li、Hanlin Wang、Yinghao Xu、Shuailei Ma 等（共 24 人）。<br>
    **机构：** 未在公开元数据中稳定解析；以 arXiv/PDF 或官方页 affiliation block 为准。<br>
    **时间 / 主题：** 2026-01；世界模型。<br>
    **arXiv / 官方报告：** arXiv：[2601.20540](https://arxiv.org/abs/2601.20540)。<br>
    **GitHub / 项目：** GitHub：[github.com/robbyant/lingbot-world](https://github.com/robbyant/lingbot-world)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2601.20540)；[GitHub API / repo](https://github.com/robbyant/lingbot-world)；Checked Date：2026-06-04；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 让视频生成器持续响应动作

LingBot-World 把 Wan2.2 的视频生成先验改造成可交互的视觉环境。输入是一幅图或一段历史视频，控制包括键盘移动、连续相机旋转和文字事件，输出则是随着控制不断展开的视频。报告的主线是三项能力如何接起来：先用长视频训练空间和时间一致性，再把动作注入生成过程，最后用因果注意力与少步蒸馏降低交互延迟。[↗](https://arxiv.org/pdf/2601.20540#page=8)

其中 Base 与 Fast 承担不同角色。Base 保留双向视频扩散的生成能力；Fast 是后训练得到的自回归版本，面向流式交互。不能把 Base 的教师架构、Fast 的吞吐以及长视频演示合并成一个无条件性能承诺。

## 数据必须包含“同一个世界被怎样改变”

训练数据来自一般视频、带控制信号的游戏录像，以及 Unreal 渲染的合成场景。三类数据各有作用。网络视频提供外观与运动覆盖；游戏同时给出画面、键盘及相机动作；合成数据提供准确轨迹，并能专门生成后退、绕行、返回旧位置等序列，让模型在画面离开视野后还需要恢复其布局。[↗](https://arxiv.org/pdf/2601.20540#page=3)

没有现成动作标签的真实视频使用 MegaSAM 估计相机信息。文字标注也分工：静态描述尽量剔除动作和镜头信息，避免文本代替控制信号决定运动；全局叙述与时间局部描述补充场景和事件。这些设计都指向同一个训练问题：生成结果应随动作变化，而不是只按视频中最常见的续写方式推进。[↗](https://arxiv.org/pdf/2601.20540#page=6)

下面的训练路线应从左到右看。长时一致性和可控性先在较强但较慢的教师上学习，因果化与加速随后进行，因此后训练不必从头承担所有环境知识的学习。

![LingBot-World 训练路线原图](../../assets/images/paper-deep-dives/world-models/lingbot-world/figure-4-training-pipeline.png){ width="920" }

## 动作如何进入视频模型

报告将问题写成条件轨迹建模

$$
\max_\theta\ \mathbb E\left[\log p_\theta(x_{t:t+L}\mid x_{<t},a_{t:t+L})\right].
$$

$x_{<t}$ 是已有历史，$a$ 是接下来施加的动作，预测对象是未来视频片段。这是任务层面的条件概率描述；实际训练和采样使用扩散/flow 模型，不是按像素逐个做离散 next-token prediction。[↗](https://arxiv.org/pdf/2601.20540#page=7)

基础模型继承 Wan2.2 的高噪声与低噪声两个专家，每个约 14B 参数，总计约 28B；每个去噪时间步只激活一个专家。前者处理全局结构和粗运动，后者修饰细节。训练视频长度从 5 秒逐步延长至 60 秒，并随长度增加 flow shift，提高高噪声阶段的重要性，让模型先稳定全局布局。图生视频与视频续写联合训练，分别覆盖从单帧和从历史运动出发的情况。[↗](https://arxiv.org/pdf/2601.20540#page=10)

在控制接口上，连续相机旋转用 Plücker embedding 表示，离散按键用 multi-hot 向量表示，两者拼接后进入动作编码器，并以 adaptive normalization 的 scale、shift 调制 DiT 的视频特征。文字仍经 cross-attention 输入。这样，视觉历史负责世界现状，动作负责如何移动，文字负责语义场景和事件。

![LingBot-World 系统 pipeline 原图](../../assets/images/paper-deep-dives/world-models/lingbot-world/figure-5-system-pipeline.png){ width="920" }

图中视频 latent 先经过自注意力建立时空联系，动作再改变其计算，文字通过另一条条件通道进入。这里的“世界状态”主要保存在视频上下文和网络特征中，没有另建一份可直接查询的显式三维物体数据库。

## 因果化、蒸馏和自生成训练分别解决什么

双向教师一次处理完整片段，未来帧能参与当前帧的去噪，不能自然接受生成中途的新动作。Fast 从高噪声专家初始化，把注意力改为 **block causal**：块内双向，块间只看历史。历史块的 KV 可以缓存，新控制只影响后续块。它保留局部并行生成能力，同时获得流式接口。[↗](https://arxiv.org/pdf/2601.20540#page=11)

![因果化与长时训练原图](../../assets/images/paper-deep-dives/world-models/lingbot-world/figure-6-causal-adaptation.png){ width="790" }

因果适配阶段给不同块分配独立噪声时间，并额外采样干净帧，让原本专注高噪声的专家补上低噪声表示能力。学生在所选时间步上学习重建干净视频

$$
\mathcal L=\mathbb E_{x^i\sim p(x),\,t\in\{t_1,\ldots,t_m\}}
\left\|G_\theta(x_t^i,t,a)-x_0^i\right\|^2.
$$

少步蒸馏随后用 DMD 匹配教师和学生生成分布。真实 score 网络固定，fake score 网络跟踪当前学生，二者的差异为学生提供更新方向。为防止训练只见过干净历史、推理却不断看到自己的误差，训练时也让模型用自己的已生成片段继续 rollout；滚动 KV 缓存保存上下文，梯度仅穿过最近 $K$ 次生成，控制长序列训练成本。[↗](https://arxiv.org/pdf/2601.20540#page=12)

图右侧的判别头给蒸馏补充真实视频信号。教师本身可能有偏差，少步学生还会损失细节；判别真实与生成视频的目标用于改善视觉质量。判别头接在 fake score 网络特征上，但报告明确区分参数更新：判别损失更新判别头，fake score 网络本体沿 DMD 对应的训练目标更新。几项设计的职责不同，单独减少采样步数不能自动修复长 rollout 漂移。[↗](https://arxiv.org/pdf/2601.20540#page=13)

## 记忆演示与量化指标分别支持什么

记忆图最值得看的是视野移开之后的返回帧。前三行展示地标离开画面最长约 60 秒后仍能重现；另外两行展示桥梁距离变化和车辆在离开视野后的继续运动。它们支持模型从视频中学到了一定持续性，尤其比只检查相邻帧平滑更接近世界模拟需要。[↗](https://arxiv.org/pdf/2601.20540#page=19)

![长时记忆能力原图](../../assets/images/paper-deep-dives/world-models/lingbot-world/figure-12-memory.png){ width="920" }

这些是定性序列，不能直接等同于所有环境上的永久记忆成功率。报告也给出最长约 10 分钟的生成示例，同时在局限中承认上下文产生的隐式记忆并不稳定，长时间仍会漂移。

量化评测使用 100 个超过 30 秒的生成视频，以 VBench 比较 Yume-1.5、HY-World 1.5。

| Model | Imaging Quality | Aesthetic Quality | Dynamic Degree | Motion Smooth | Temporal Flickering | Overall Consistency |
|---|---:|---:|---:|---:|---:|---:|
| Yume-1.5 | 0.5838 | 0.5185 | 0.7612 | 0.9709 | 0.9545 | 0.1994 |
| HY-World 1.5 | 0.6512 | 0.5487 | 0.7217 | **0.9897** | **0.9773** | 0.2016 |
| LingBot-World | **0.6683** | **0.5660** | **0.8857** | 0.9895 | 0.9648 | **0.2178** |

结果支持更丰富的动态和较好的视觉、语义一致性，但并非每一项都领先。动态程度高也不能独自证明精确的动作响应或物理正确；表中没有机器人接触控制成功率、相机轨迹误差或对象永久性统计，因此这些能力需要与演示分开判断。[↗](https://arxiv.org/pdf/2601.20540#page=21)

## 可交互的生成环境已经可以做什么

Fast 在报告中以 **480p、一个 GPU 节点**达到 16 FPS，摘要报告延迟低于 1 秒。这里的 node 不能改写成单张消费级 GPU，报告也明确指出推理仍依赖企业级硬件。长序列训练则使用 FSDP2 分片参数、梯度及优化器状态，并以 Ulysses context parallel 分摊序列激活。[↗](https://arxiv.org/pdf/2601.20540#page=1) [↗](https://arxiv.org/pdf/2601.20540#page=11)

应用展示包括中途通过文字切换天气或添加事件、从生成视频重建点云，以及把 Qwen3-VL-2B 微调为动作代理。该代理根据图像预测接下来 10 秒的键盘和离散鼠标动作，再驱动世界模型；这是探索动作生成示例，报告没有据此给出真实机器人训练收益。[↗](https://arxiv.org/pdf/2601.20540#page=25)

这项工作可复用的核心是从视频先验到交互模拟器的工程路径，以及对控制数据、长时上下文、少步生成之间依赖关系的拆解。它对导航和基础移动最直接；精确抓取某个物体仍受动作空间与对象定位能力限制，不能把视觉上连贯的游览环境直接当成已经校准的机器人动力学仿真器。
