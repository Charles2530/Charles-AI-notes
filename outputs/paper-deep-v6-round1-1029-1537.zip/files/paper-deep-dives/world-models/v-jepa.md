---
paper_date: 2024-02
paper_title: "V-JEPA: Latent Video Prediction for Visual Representation Learning"
paper_topic: 世界模型
---

# V-JEPA：视频潜变量预测表征

!!! info "论文信息"
    **论文题名：** Revisiting Feature Prediction for Learning Visual Representations from Video。<br>
    **作者：** Adrien Bardes、Quentin Garrido、Jean Ponce、Xinlei Chen、Michael Rabbat、Yann LeCun、Mahmoud Assran、Nicolas Ballas。<br>
    **机构：** Meta AI。<br>
    **时间 / 主题：** 2024-02；世界模型。<br>
    **arXiv / 官方报告：** arXiv：[2404.08471](https://arxiv.org/abs/2404.08471)；官方材料：[ai.meta.com/research/publications/revisiting-feature-prediction-for-learning-visual-representations-from-video/](https://ai.meta.com/research/publications/revisiting-feature-prediction-for-learning-visual-representations-from-video/)。<br>
    **GitHub / 项目：** GitHub：[github.com/facebookresearch/jepa](https://github.com/facebookresearch/jepa)；项目页：[ai.meta.com/research/publications/revisiting-feature-prediction-for-learning-visual-representations-from-video/](https://ai.meta.com/research/publications/revisiting-feature-prediction-for-learning-visual-representations-from-video/)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2404.08471)；[GitHub API / repo](https://github.com/facebookresearch/jepa)；[官方 / 项目材料](https://ai.meta.com/research/publications/revisiting-feature-prediction-for-learning-visual-representations-from-video/)；Checked Date：2026-06-15；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 只预测视频特征，能学到多好的视觉表示

V-JEPA 将 JEPA 的预测式表示学习落到视频预训练。它从视频可见区域预测被遮挡区域的特征，不生成像素、不使用文本或动作标签。论文主要检验冻结 encoder 后的分类、定位和迁移表现，因此这里的“预测”首先是一种学习表示的任务，并不是可直接接受机器人动作的未来模拟器。[↗](https://arxiv.org/pdf/2404.08471#page=1)

![V-JEPA overview](../../assets/images/paper-deep-dives/world-models/v-jepa/figure-1-overview.png)

*论文总览。理解与 motion-sensitive 任务是主要评测入口。*

## target 也经过学习，如何避免常数解

![V-JEPA training procedure](../../assets/images/paper-deep-dives/world-models/v-jepa/figure-3-training-procedure.png)

*原论文训练图。先看 x-encoder 只收到可见 tokens，再看 y-encoder 处理完整视频后选择目标位置。*

$$
\min_{\theta,\phi}\left\|P_\phi\bigl(E_\theta(x),\Delta_y\bigr)-\operatorname{sg}\bigl(E_{\bar\theta}(y)\bigr)\right\|_1.
$$

$x$ 是可见区域，$y$ 是预测区域，$\Delta_y$ 指定其时空位置。$E_{\bar\theta}$ 用 online encoder 的指数滑动平均更新，目标侧停止梯度。predictor、EMA 与 stop-gradient 的非对称组合避免两边即时合作把目标变成常数；L1 比较在特征空间进行，允许表征不保留难预测的像素细节。[↗](https://arxiv.org/pdf/2404.08471#page=3)

原文提供一维理想化解释：L1 下最优 predictor 是条件中位数，encoder 改善上下文信息可以减少目标的条件 median absolute deviation。这是一种机制动机，依赖最优 predictor 等假设，不应扩大为任意网络训练都绝不塌缩的保证。

## masking 决定预测任务到底有多难

视频每个 token 覆盖 $16\times16$ pixels、连续 2 帧。encoder 将可见 tokens 输入 ViT，predictor 是 12-block、384-dimensional 的窄 Transformer，并使用含目标位置的 mask tokens。

![V-JEPA tokenization](../../assets/images/paper-deep-dives/world-models/v-jepa/figure-4-tokenization.png)

*论文 tokenization 图。空间和时间都被分块，不能将这里的 token 当成整帧。*

视频相邻帧高度冗余，随机遮掉几个 patch 常可从邻帧复制。multi-block mask 沿整个时间轴扩展空间块，减弱这条捷径。short-range 使用 8 个各覆盖约 15% frame 的块，long-range 使用 2 个约覆盖 70% 的块；取并集后平均约 90% 被遮挡，这些比例不能简单相加。

![3D Multi-Block Masking](../../assets/images/paper-deep-dives/world-models/v-jepa/figure-2-3d-multi-block-masking.png)

*论文 masking 图。先看遮挡是否贯穿时间，再看剩余区域能否提供足够结构。*

VideoMix2M 合并 HowTo100M、K710、SSv2 并排除相关验证集重叠，约 2M videos。每次输入 16 frames、frame-skip 4，平均约 3 秒；224 分辨率的 L/H 模型 batch 为 3072，384 分辨率 H 模型为 2400。[↗](https://arxiv.org/pdf/2404.08471#page=4)

![V-JEPA pretraining hyperparameters](../../assets/images/paper-deep-dives/world-models/v-jepa/table-5-pretraining-hyperparameters.png)

*论文训练配置表。分辨率与 batch 是比较模型成本时需要同时保留的条件。*

## 对照实验把特征目标与任务设计分开

| Target | Arch. | K400 Frozen | SSv2 Frozen | IN1K Frozen | K400 Fine-Tuning |
| --- | --- | ---: | ---: | ---: | ---: |
| Pixels | ViT-L/16 | 68.6 | 66.0 | 73.3 | 85.4 |
| Features | ViT-L/16 | 73.7 | 66.2 | 74.8 | 85.6 |

*原论文 Table 1；VideoMix2M、90K iterations、batch 3072、相同 multi-block 任务；frozen 使用 attentive probe，视频为 single center view。*

受控比较中，feature target 在 frozen K400 提高 5.1 points，SSv2 仅提高 0.2，full fine-tuning K400 也只有 0.2。它支持表示可直接使用的改善，不支持声称所有任务都有同样幅度收益。[↗](https://arxiv.org/pdf/2404.08471#page=5)

![Frozen evaluation on video datasets](../../assets/images/paper-deep-dives/world-models/v-jepa/table-1-video-frozen-eval.png)

*论文 frozen evaluation 原表。必须保留 backbone 是否冻结、spatial/temporal views 与输入分辨率。*

mask 消融进一步检验结构。相同 K710+SSv2 下，random-tube[0.9] 的 K400/SSv2 为 51.5/46.4；causal multi-block[12] 为 71.9/63.6；完整 multi-block 为 72.9/67.4。可见最好的表征任务允许从整个 clip 的上下文填补区域，不是严格只看过去预测未来。[↗](https://arxiv.org/pdf/2404.08471#page=6)

![Ablating pretraining distribution](../../assets/images/paper-deep-dives/world-models/v-jepa/table-4-pretraining-distribution.png)

*论文数据分布消融。查看各单项而非只读 Avg.，不同数据源带来不同任务偏好。*

ViT-L 从 K710 到 VideoMix2M，平均 70.9→71.5，但 K400 75.8→73.7，SSv2 63.2→66.2。更多数据改变分布，motion 理解收益伴随 appearance 基准上的取舍。下游 attentive pooling 也非常关键，原文相对 average pooling 报告 K400 +17、SSv2 +16.1 points；“冻结 backbone”并不意味着完全无训练读出。[↗](https://arxiv.org/pdf/2404.08471#page=6)

V-JEPA 提供了一种值得复用的视频表征方案：将难预测细节从监督目标中移走，用连续时空 mask 构造有难度的任务，再让小读出适配下游用途。若需要 action-conditioned planning，还需添加动作接口、时序 rollout 和闭环控制验证；本文的 frozen probe 成绩回答的是表示质量。
