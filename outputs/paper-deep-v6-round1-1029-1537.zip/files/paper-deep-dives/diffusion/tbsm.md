---
paper_date: 2026-07
paper_title: "Three-Body Scattering for Generative Modeling"
paper_topic: 扩散模型
---

# TBSM：用三体散射把分布距离变成一步监督

!!! info "论文信息"
    **论文题名：** Three-Body Scattering for Generative Modeling。<br>
    **作者：** Peng Sun、Zhenglin Cheng、Deyuan Liu、Jun Xie、Xinyi Shang、Tao Lin。<br>
    **机构：** Westlake University、Zhejiang University、University College London。<br>
    **时间 / 主题：** 2026-07；生成模型与一步视觉生成。<br>
    **arXiv / 代码：** [2607.18198](https://arxiv.org/abs/2607.18198)；[github.com/sp12138/TBSM](https://github.com/sp12138/TBSM)。<br>
    **元数据与核验口径：** 来源为 arXiv HTML v1；Checked Date：2026-09-07；Repro Status：Paper / official code link reviewed, independent reproduction not claimed。

## 一个分布目标怎样变成三个样本之间的运动

TBSM从一个具体计算问题出发。分布距离通常涉及许多真实与生成样本的两两关系，能否把它变成每个生成样本都能接受的常数规模监督，同时保留清楚的总体目标？作者选择 energy distance，将一次交互限定为三个对象：一个正在接受梯度的生成样本 projectile、一个真实 source，以及另一个独立生成 source。

真实 source负责吸引，生成 source负责排斥。每个事件只给一个局部方向，很多独立事件的平均才恢复分布级运动。随后加入一个在线训练的向量场 tracker，对有噪声的局部方向做回归，再让生成器混合使用即时方向与学习到的场。由此得到可直接一次生成图像的训练接口。[原论文，第3—4页](https://arxiv.org/pdf/2607.18198#page=3)

这里的“three-body scattering”是对这种三样本有符号交互的命名，没有使用牛顿引力或真实物理散射方程。更重要的是，论文区分了一个具有准确能量解释的端点和带实用偏置的整个训练家族。理解这条边界，才能判断证明覆盖了哪些实验设置。

## Energy distance给出吸引与排斥的系数

对条件 $c$，生成分布为 $P_\theta(\cdot\mid c)$，数据分布为 $Q(\cdot\mid c)$。在有限一阶矩条件下，欧氏空间的 energy distance为

$$
D_E^2(P,Q)=2\mathbb E\|x_p-x_r\|_2-\mathbb E\|x_p-x_s\|_2-\mathbb E\|x_r-x_r'\|_2,
$$

其中 $x_p,x_s$ 独立来自 $P$，$x_r,x_r'$ 独立来自 $Q$。论文优化条件平均 $F(\theta)=\mathbb E_c\tfrac12D_E^2(P_\theta,Q)$。第三项对生成器是常数；第一项缩小生成与真实之间的距离，第二项奖励生成分布保持必要的展开程度。欧氏距离的 strong negative type性质保证总体 energy distance为零当且仅当两种分布相同。[原论文，第3页，式1—3](https://arxiv.org/pdf/2607.18198#page=3)

对每个可微的 $x_p=g_\theta(z,c)$，另外采样真实点 $x_r$ 与独立噪声产生的 $x_s=g_\theta(z_s,c)$，将 source detach。定义两个单位方向

$$
b_r=\frac{x_r-x_p}{\|x_r-x_p\|_2},\qquad
b_s=\frac{x_s-x_p}{\|x_s-x_p\|_2},\qquad
\widehat v=b_r-b_s.
$$

第一项朝向真实点，减去第二项则远离生成点。以总体分布和正确的独立采样为前提，这个随机向量的条件期望等于 energy distance的负 Wasserstein梯度场。每个事件只涉及常数个点，因此 $B$ 个 projectile需要 $O(B)$ 次样本交互，而非完整的 $B^2$ 核矩阵。

独立性不是可随意删除的实现细节。若 $x_s$ 恰好就是 $x_p$，生成—生成项就无法估计分布内部的相互作用；如果把source的梯度一并纳入而不调整推导，也改变了预期的更新系数。论文在重合点将 bearing设为零，实际分母平滑则对应另一种平滑距离势，不能声称数值稳定技巧对几何完全没有影响。

## 回归目标的梯度匹配，强于一句“让loss变小”

TBSM为当前 projectile建立停止梯度目标

$$
x_{\mathrm{target}}=\operatorname{sg}\left[x_p+\widehat v(\operatorname{sg}(x_p);x_r,x_s)\right],\qquad
\mathcal L_{\mathrm{scat}}=\frac12\mathbb E\|g_\theta(z,c)-x_{\mathrm{target}}\|_2^2.
$$

生成器一侧的梯度是输出 Jacobian乘以负位移。结合独立采样，对当前参数取期望，就得到energy目标的参数梯度。这个结论说的是局部期望梯度一致性。回归损失本身的数值等于散射方向范数的一部分，并不是一个无偏的 energy distance数值估计，不能用它的绝对大小直接比较两个生成模型的分布质量。[原论文，第4页](https://arxiv.org/pdf/2607.18198#page=4)

训练还存在一个共享参数约束。粒子流推导允许每个位置沿自身场独立运动，神经网络则通过同一组参数同时改变所有样本。论文给出的收敛论证依赖精确场、正则性、斜率条件或梯度主导等假设；这些条件并未为任意高维网络加SGD自动成立。实际贡献是把一个有总体意义的更新落实成可训练样本目标，而非证明所有实现都全局收敛。

## Tracker在估计平均运动，也可能引入新的偏差

只取一个真实source和一个生成source会带来较大方向方差。作者训练向量网络 $v_\phi$，回归即时散射向量，再用混合场指导生成器

$$
v_{\mathrm{mix}}=(1-\rho)\widehat v_\lambda+\rho v_\phi(\widetilde x,c),\qquad
\widehat v_\lambda=b_r-\lambda b_s.
$$

$\rho$ 控制依赖学习到的场的比例。$\lambda$ 同时控制排斥强度和tracker查询位置

$$
\widetilde x=\alpha x_r+(1-\alpha)\operatorname{sg}(x_p),\qquad
\alpha\sim\mathcal U(0,1-\lambda).
$$

当 $\lambda=1$ 时，查询恰好位于生成点，tracker试图学习同一个总体散射场。令即时估计的条件方差为 $s_\theta$，tracker相对真实场的均方误差为 $e_\phi$，论文给出的误差分解是

$$
\operatorname{MSE}(v_{\mathrm{mix}})=(1-\rho)^2s_\theta+\rho^2e_\phi,
\qquad \rho^*=\frac{s_\theta}{s_\theta+e_\phi}.
$$

这把tracker的价值说得很清楚：它用可积累的学习过程压低一次随机事件的方差，但误差过大的tracker同样会伤害生成器。完全依赖tracker并不天然优于混合，取决于 $e_\phi$ 与 $s_\theta$ 的相对大小。[原论文，第5—6页](https://arxiv.org/pdf/2607.18198#page=5)

当 $\lambda<1$ 时情况更复杂。即使只看即时场，对应目标也变成

$$
F_\lambda=\mathbb E\|x_p-x_r\|_2-\frac\lambda2\mathbb E\|x_p-x_s\|_2
=F_1+\frac{1-\lambda}{2}\mathbb E\|x_p-x_s\|_2+\text{constant}.
$$

多出来的项惩罚生成分布的展开程度，真实分布通常不再是唯一应当满足的最优点。同时，tracker开始在真实与生成之间的corridor上接受查询，其条件期望不再自动等同于生成点上的原梯度。即便tracker在自己的回归任务上达到理想解，也不能沿用 $\lambda=1$ 的无偏性结论。

## 设计图展示的是连接，不是四种方法的严格等价

论文用 $(\rho,\lambda)$ 平面组织训练家族。$(0,1)$ 是即时能量散射，与Drift-like粒子运动相近，但使用常数规模三样本估计；$(1,1)$ 是学习同一场的tracked energy端点。$(0,0)$ 只向真实source吸引，若要严格变成去噪训练，还需要跨噪声级别的配对、时间条件和相应clean／noise／velocity target，仅有纯噪声输入并不够。

$(1,0)$ 的GAN-like解释也有额外条件。论文的势函数类比使用将单位方向替换成位移的版本，不能直接把原unit-bearing tracker叫作GAN判别器。实际向量tracker还避免了通过标量势取梯度造成的高阶自动微分开销，却不保证整个学到的场严格保守。[原论文，第7—8页](https://arxiv.org/pdf/2607.18198#page=7)

四角实验保持生成器更新次数一致，$(1,1)$ 的FID4.71优于$(0,1)$ 的10.31；只吸引的$(0,0)$ 为38.65，却有最高IS386.12。这种“IS很高而FID很差”的组合与分布收缩相容。它并不是完全因子化的消融，因为改变 $\lambda$ 同时改变排斥和查询corridor，改变 $\rho$ 又改变tracker参与程度。匹配生成器更新次数也没有匹配tracker带来的总计算量。

## 表征让三体规则进入图像，但同时决定它能看见什么

高维图像实验在冻结特征空间里分别计算散射。每种编码器有自己的场、tracker和损失，再通过对应编码器的Jacobian回传到共同图像。不同维度的特征向量并没有被直接相加。论文还对最终特征使用EMA whitening与逐通道L2处理，使各表示的尺度更可控。

在匹配预算的表征消融中，单个编码器并不充分，不同组合也没有统一占优。[原论文，第9—10页，Table 2](https://arxiv.org/pdf/2607.18198#page=9)

| Representation | FID ↓ | FDr6 ↓ | IS ↑ | Time / iter (s) ↓ |
| --- | ---: | ---: | ---: | ---: |
| ResNet18 | 13.47 | 36.49 | 104.58 | 0.1389 |
| SigLIP2-B | 21.87 | 39.01 | 131.49 | 0.1736 |
| MAE-B | 16.18 | 27.74 | 93.25 | 0.1583 |
| ResNet18 + SigLIP2-B | 9.12 | 27.49 | 149.91 | 0.1982 |
| SigLIP2-B + MAE-B | 9.36 | 21.80 | 161.36 | 0.2184 |
| ResNet18 + MAE-B | 11.45 | 27.50 | 113.14 | 0.1832 |
| All three | 8.29 | 22.25 | 152.23 | 0.2411 |

三编码器组合的FID最低，但SigLIP2＋MAE在FDr6、IS和速度上更好。后续主要实验选择全部三种表示，是对配置的固定选择，不是所有指标严格占优的证明。特征空间中energy distance的properness只保证对应投影分布匹配；图像中被编码器丢弃的细节仍可能出错。

## 一次求值的主结果，需要连同初始化和资源一起看

论文的大规模ImageNet实验使用已有diffusion／flow生成器初始化；FD-loss refinement是额外的细化案例。ImageNet规模从随机初始化训练的效率与质量没有被验证，因此不能把没有教师预测的训练目标理解成完全从零、没有预训练成本。[原论文，第9—11页](https://arxiv.org/pdf/2607.18198#page=9)

| Generator | Space | $\rho$ | $\lambda$ | NFE | FID ↓ | FDr6 ↓ |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| JiT-B | Pixel | 1.0 | 1.0 | 1 | 3.09 | 10.73 |
| JiT-B | Pixel | 0.9 | 1.0 | 1 | 3.35 | 11.60 |
| JiT-B | Pixel | 0.9 | 0.9 | 1 | 2.92 | 13.21 |
| JiT-B, longer training | Pixel | 0.9 | 0.9 | 1 | 2.69 | 13.21 |
| PixelDiT-XL, 797M | Pixel | 0.9 | 1.0 | 1 | 2.23 | 7.15 |
| PixelDiT-XL, 797M | Pixel | 0.9 | 0.9 | 1 | 2.23 | 7.59 |
| DiT-XL/2, 675M | Latent | 0.9 | 0.9 | 1 | 1.63 | 6.76 |

JiT-B上降低 $\lambda$ 使FID3.35改善到2.92，IS205.3升到228.7，但FDr6从11.60恶化到13.21。这准确体现了一个带收缩倾向的调节参数可能改变不同质量指标，不能把它描述成无代价地强化理论目标。PixelDiT-XL两种设置FID均四舍五入为2.23，IS则由210.0升到230.9；它也只是经验上类似guidance的质量—多样性调节，并未实现标准CFG。

在512分辨率课程设置下，latent DiT-XL/4达到FID1.92，PixelDiT-XL为3.84。一次NFE统计生成器求值，latent路线还需解码器；训练的线性样本交互成本之外，也包括独立source生成、冻结编码器前向与反传、tracker学习。论文没有给出相对成熟扩散系统的完整计算匹配训练优势，因此“线性交互”和“总体训练更便宜”需要分别验证。

TBSM的采用价值，在于把分布级吸引与自排斥压缩成清楚的样本级接口，并提供tracker方差—偏差分析。若要检验理论机制，优先从 $\lambda=1$、独立sources、正确detach与可控特征空间开始；若追求最佳FID，可以调 $\lambda<1$，但应同时观察多表示指标和多样性。对于每个强条件只有单个真实样本的数据，经验条件目标还可能鼓励复现那一个配对，需要数据增强或跨条件共享结构补充统计支持。[原论文，第11页](https://arxiv.org/pdf/2607.18198#page=11)
