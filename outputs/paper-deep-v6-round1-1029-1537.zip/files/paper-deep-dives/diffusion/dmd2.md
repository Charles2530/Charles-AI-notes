---
paper_date: 2024-05
paper_title: "Improved Distribution Matching Distillation for Fast Image Synthesis"
paper_topic: 扩散模型
---

# DMD2：更稳的少步分布匹配蒸馏

!!! info "论文信息"
    **论文题名：** Improved Distribution Matching Distillation for Fast Image Synthesis。<br>
    **作者：** Tianwei Yin、Michaël Gharbi、Taesung Park、Richard Zhang、Eli Shechtman、Fredo Durand、William T. Freeman。<br>
    **机构：** 未在公开元数据中稳定解析；以 arXiv/PDF 或官方页 affiliation block 为准。<br>
    **时间 / 主题：** 2024-05；扩散模型。<br>
    **arXiv / 官方报告：** arXiv：[2405.14867](https://arxiv.org/abs/2405.14867)；官方材料：[tianweiy.github.io/dmd2/](https://tianweiy.github.io/dmd2/)。<br>
    **GitHub / 项目：** GitHub：[github.com/tianweiy/DMD2](https://github.com/tianweiy/DMD2)；项目页：[tianweiy.github.io/dmd2/](https://tianweiy.github.io/dmd2/)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2405.14867)；[GitHub API / repo](https://github.com/tianweiy/DMD2)；[官方 / 项目材料](https://tianweiy.github.io/dmd2/)；Checked Date：2026-06-04；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 从取消回归到修复两种估计误差

DMD2 的出发点是 [DMD](dmd.md) 留下的一笔额外成本。DMD 已经用分布目标训练学生，却仍依赖预计算噪声—图像对来稳定学习。SDXL 为 1200 万条提示各生成一张配对图片，按原文每张约 5 秒估算，约需 700 A100 天，超过 DMD2 全部训练计算的四倍。去掉回归既能省下数据构造，也能解除学生对教师某条确定轨迹的依赖。[↗](https://arxiv.org/pdf/2405.14867#page=5)

但删除损失不等于解决问题。作者把训练不稳追到 fake score 不能及时跟踪学生分布；把剩余质量差距追到教师 real score 的近似误差；把多步学生的退化追到训练输入与部署输入不同。DMD2 分别加入更快的 fake score 更新、真实图像上的 GAN 监督，以及模拟学生自身推理的 backward simulation。

先看下面的 SDXL 样本，关注四步生成的局部纹理和整体构图。展示说明方法能扩展到百万像素，但是否超过教师，要由后文的 FID、Patch FID 和偏好比较共同判断。

![DMD2 SDXL teaser](../../assets/images/paper-deep-dives/diffusion/dmd2/teaser.png){ width="720" }

<small>图源：`Improved Distribution Matching Distillation for Fast Image Synthesis`，Figure 1。</small>

## 生成器、分数网络和判别器怎样配合

方法图保留了 DMD 的红色分布梯度通路，新增绿色 GAN 通路。判别头接在 fake diffusion denoiser 的瓶颈特征上，与 fake score 共享部分表示；冻结教师仍提供真实分布方向。

![DMD2 method](../../assets/images/paper-deep-dives/diffusion/dmd2/method.png){ width="830" }

<small>图源：`Improved Distribution Matching Distillation for Fast Image Synthesis`，Figure 3。</small>

设生成器输出 $x=G_\theta(z)$，加噪算子为 $F(x,t)=\alpha_t x+\sigma_t\epsilon$。去噪器与分数的关系为

$$
s(x_t,t)=-\frac{x_t-\alpha_t\mu(x_t,t)}{\sigma_t^2}.
$$

分布匹配更新仍由 $s_{\mathrm{real}}-s_{\mathrm{fake}}$ 决定。真实分数模型冻结，fake score 网络对当前生成图像做去噪学习；更新生成器时，将两者差值通过生成样本回传。DMD2 改变的是估计与监督条件，并没有用 GAN 完全替换这条路径。[↗](https://arxiv.org/pdf/2405.14867#page=5)

### fake score 必须比学生变化更快

直接取消回归后，生成图像的平均亮度等统计量会持续振荡。原因在于学生不断变化，在线训练的 fake score 估计器尚未学会当前分布，就要为下一次学生更新提供梯度。DMD2 使用 Two Time-scale Update Rule，每更新一次生成器，更新 fake score 五次。

下面亮度轨迹先看振荡幅度，再看训练后段是否稳定；收敛图则比较达到相近 FID 所需的训练进度。两张图支持的是在线估计跟踪与训练稳定性的改进，不能把“五次”解读为任意规模都固定最优的常数。

![DMD2 ImageNet brightness stability](../../assets/images/paper-deep-dives/diffusion/dmd2/imagenet-brightness.png){ width="820" }

<small>图源：`Improved Distribution Matching Distillation for Fast Image Synthesis`，Appendix Figure 8。</small>

![DMD2 ImageNet convergence](../../assets/images/paper-deep-dives/diffusion/dmd2/imagenet-convergence.png){ width="820" }

<small>图源：`Improved Distribution Matching Distillation for Fast Image Synthesis`，Appendix Figure 9。</small>

### 真实数据让监督不再完全受教师约束

教师的分数估计也有误差。若学生只学教师，无法得到直接修正教师偏差的信号。新增判别器同时看到加噪真实图像 $F(x,t)$ 与加噪生成图像 $F(G_\theta(z),t)$，在多个噪声尺度上区分两者。生成器的非饱和对抗项可写为

$$
\mathcal L_{G,\mathrm{GAN}}
=-\mathbb E_{z,t}\log D\big(F(G_\theta(z),t)\big).
$$

$D$ 为真实概率判别头。它与分布梯度共同优化生成器，fake score 仍学习自己的去噪任务。真实数据带来的是独立于教师采样路径的分布监督，因此学生有可能改善某项教师指标；这里的“超过教师”也意味着训练信息增加了，而非无额外数据的纯压缩。[↗](https://arxiv.org/pdf/2405.14867#page=7)

## 为什么多步学生要在自己的输入上训练

一步对 SDXL 这样的高分辨率模型仍很吃力。DMD2 支持多步生成，每步先预测干净图像，再加回下一时间的噪声

$$
\hat x_{t_i}=G_\theta(x_{t_i},t_i),
\qquad
x_{t_{i+1}}=\alpha_{t_{i+1}}\hat x_{t_i}
+\sigma_{t_{i+1}}\epsilon.
$$

原文四步日程为 $999,749,499,249$。关键不只在日程，而在第二步以后的输入。真实图像加噪得到的训练样本，和学生先生成再加噪得到的部署样本并不相同。若只训练前者，网络可能从未学过怎样修正自己的误差。

下图左右两条路径的差别就在中间状态的来源。backward simulation 从噪声运行当前学生，走到所需时间，再对该步输出施加分布与对抗监督。前面的模拟用于构造部署时会遇到的状态，监督不要求它复刻教师同一种子的轨迹。

![DMD2 backward simulation](../../assets/images/paper-deep-dives/diffusion/dmd2/backward-simulation.png){ width="830" }

<small>图源：`Improved Distribution Matching Distillation for Fast Image Synthesis`，Figure 4。</small>

这条改动的成本是训练中增加少量学生前向；由于学生只有数步，比为每个训练样本运行完整教师便宜。它也是这篇论文特别可复用的设计——少步模型扩展到多步时，先让训练覆盖自己的滚动输入，再讨论增加步数能否改善质量。

## ImageNet 消融把三个作用分开

Table 3 逐项检验取消回归、加速 critic 更新和加入 GAN 的作用。

| Configuration | ImageNet-64 FID ↓ |
| --- | ---: |
| DMD | 2.62 |
| DMD, no regression | 3.48 |
| no regression + TTUR | 2.61 |
| no regression + TTUR + GAN | 1.51 |

删除回归单独做会退化；TTUR 先把它拉回到 DMD 水平；GAN 再改善 1.10 FID。纯 GAN 在该消融中为 2.56，加入 TTUR 后为 2.52，说明完整结果也不能归因于“只要训练判别器更久”。[↗](https://arxiv.org/pdf/2405.14867#page=9)

主表区分了普通与更长训练。DMD2 一步为 1.51，延长训练后为 1.28；教师 EDM 使用 511 次前向，ODE 采样为 2.32，SDE 采样为 1.36。只拿学生 1.28 和教师 ODE 2.32 比较，会遗漏同一个教师换随机采样器后的表现。

![DMD2 ImageNet samples](../../assets/images/paper-deep-dives/diffusion/dmd2/imagenet-visual.png){ width="760" }

<small>图源：`Improved Distribution Matching Distillation for Fast Image Synthesis`，Appendix Figure 12。</small>

上图样本展示类别内的外观变化；它补充分布指标，但“多样性”仍不能由几张图穷尽。

## SDXL 的结果为何不能只看一个 FID

文本实验使用 LAION-Aesthetics 的 300 万条提示，并为 GAN 收集 50 万张真实图像。SDXL 主表在 COCO 2014 的 10K 提示上评估，Patch FID 使用中心裁剪的 299 像素区域，专门观察高分辨率细节。[↗](https://arxiv.org/pdf/2405.14867#page=8)

| Method | # Fwd Pass ↓ | FID ↓ | Patch FID ↓ | CLIP ↑ |
| --- | ---: | ---: | ---: | ---: |
| LCM-SDXL | 4 | 22.16 | 33.92 | 0.317 |
| SDXL-Turbo | 4 | 23.19 | 23.27 | 0.334 |
| SDXL-Lightning | 4 | 24.46 | 24.56 | 0.323 |
| DMD2 | 1 | 19.01 | 26.98 | 0.336 |
| DMD2 | 4 | 19.32 | 20.86 | 0.332 |
| SDXL Teacher, cfg=6 | 100 | 19.36 | 21.38 | 0.332 |

一步的整体 FID 略低于四步，四步的 Patch FID 却明显更好。这正是增加步数的收益所在——局部高分辨率细节改善，不必同时让所有指标单调提高。下面的跨方法图可沿相同提示看局部材质、结构和提示遵循，避免把整体清晰感替代成单一分数。

![DMD2 SDXL comparison](../../assets/images/paper-deep-dives/diffusion/dmd2/sdxl-comparison.png){ width="720" .atlas-figure-tall }

<small>图源：`Improved Distribution Matching Distillation for Fast Image Synthesis`，Figure 6。</small>

更有解释力的是 SDXL 消融。去掉 distribution matching 后整体 FID 降到 13.77，看似更优，但 Patch FID 变为 27.96，CLIP 降到 0.307；完整模型分别为 19.32、20.86、0.332。单看 FID 会选中语义与细节更差的模型。去掉 GAN 则得到 26.90 FID、27.66 Patch FID；去掉 backward simulation 为 20.66、24.21，CLIP 仍是 0.332。后者主要支持细节与生成分布的改善，不宜写成文本理解能力的大幅提升。

![DMD2 SDXL ablation](../../assets/images/paper-deep-dives/diffusion/dmd2/sdxl-ablation.png){ width="560" .atlas-figure-tall }

<small>图源：`Improved Distribution Matching Distillation for Fast Image Synthesis`，Figure 7。</small>

上图从相同提示对应的消融列阅读，检查过饱和、过平滑和结构问题如何与表中变化相互印证。偏好实验另取 PartiPrompts 的 128 条提示，每次比较由五名评价者分别判断视觉吸引力和文本对齐；下图的两类问题应分别看，不把它们合并成一个“胜率”。

![DMD2 human evaluation](../../assets/images/paper-deep-dives/diffusion/dmd2/human-eval.png){ width="920" }

<small>图源：`Improved Distribution Matching Distillation for Fast Image Synthesis`，Figure 5。</small>

## 获得低延迟之前需要付出的训练成本

DMD2 最直接的收益是取消昂贵的配对数据构造，同时把一套分布目标扩展到一至数步生成。它没有取消 critic 训练成本，5:1 的更新比例反而有意给 fake score 更多计算；GAN 还需要真实图像。因此，它适合能集中训练、随后大量部署的场景。

其方法选择可以概括为三个具体操作。生成分布变化太快时，提高估计器的跟踪能力；教师误差成为瓶颈时，用真实数据提供额外分布监督；模型滚动运行时，让训练输入来自同一滚动过程。它们分别处理不同问题，也解释了为什么只删回归、只加 GAN 或只增加采样步数都不能等价替代完整方案。
