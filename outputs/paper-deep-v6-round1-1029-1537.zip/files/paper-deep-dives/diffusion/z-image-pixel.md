---
paper_date: 2026-08
paper_title: "An Empirical Study of Training Pixel-Space Text-to-Image Diffusion Models"
paper_topic: 扩散模型 / 像素空间后训练
---

# Z-Image-Pixel：像素扩散更适合 post-training，而不是 pre-training

!!! info "论文信息"
    **论文题名：** An Empirical Study of Training Pixel-Space Text-to-Image Diffusion Models。<br>
    **作者：** Dengyang Jiang、Ruoyi Du、Zhennan Chen、Dongyang Liu、Zanyi Wang、Mingzhe Zheng、Xiangpeng Yang、Huanqia Cai、Aiming Hao、Yuming Jiang、Peng Gao、Harry Yang、Steven Hoi。<br>
    **机构：** Alibaba Token Hub, Alibaba Group；The Hong Kong University of Science and Technology；Nanjing University；University of California, San Diego。<br>
    **时间 / 主题：** arXiv v1：2026-08-17；论文未标注会议接收信息。主题是大规模像素空间文生图、latent-to-pixel 权重迁移和像素扩散后训练配方。<br>
    **arXiv / PDF：** arXiv：[2608.16887](https://arxiv.org/abs/2608.16887)；PDF：[arxiv.org/pdf/2608.16887](https://arxiv.org/pdf/2608.16887)；TeX source：[arxiv.org/e-print/2608.16887](https://arxiv.org/e-print/2608.16887)。<br>
    **相关官方仓库：** [Tongyi-MAI/Z-Image](https://github.com/Tongyi-MAI/Z-Image)。截至核验日，仓库公开的是 Z-Image 基础模型与推理代码，论文对应的 pixel checkpoint 和完整 post-training code 未在论文或仓库 README 中明确发布。<br>
    **元数据来源与核验口径：** 来源：arXiv 页面、论文 PDF、arXiv TeX source、Z-Image 官方 GitHub；Checked Date：2026-08-18；Repro Status：Paper and source reviewed, base-model repository available, paper-specific pixel training code/weights not confirmed, independent reproduction not claimed。

## 像素空间适合最终输出，不一定适合从零学习

这项研究对 Z-Image 做受控比较，发现相同架构、数据与计算条件下，直接像素预训练比 latent 预训练更慢形成全局结构和文本对应关系。作者因此采用 latent-to-pixel 路线，先在紧凑表示中取得生成能力，再迁移到 RGB 输出，最后结合大 patch 与少步蒸馏降低部署成本。[↗](https://arxiv.org/pdf/2608.16887#page=3)

先看下方相同训练迭代的 GenEval 与 DPG 曲线，再对照相同提示的样本。它检验的是本文规模和配方下的学习效率，不能推出所有像素模型都不适合预训练。

![Latent versus pixel pre-training curves](../../assets/images/paper-deep-dives/diffusion/z-image-pixel/figure-2-pretraining-bench.png){ width="900" }

<small>图源：`An Empirical Study of Training Pixel-Space Text-to-Image Diffusion Models`，Figure 2。两条曲线使用相同训练设置，只改变 prediction space。</small>

![Latent versus pixel qualitative progression](../../assets/images/paper-deep-dives/diffusion/z-image-pixel/figure-3-pretraining-visual.png){ width="900" }

<small>图源：论文 Figure 3。上排是 pixel-space，下排是 latent-space；列方向展示 2K、10K、50K、150K training iterations。</small>

VAE 在这里不仅压缩计算，也提供已有视觉表示，减少冗余与高频变化。论文将像素路线的额外难度解释为同时学习结构、细节与去噪，这与受控结果相容；直接实验观察仍是匹配预算下的收敛差距。

## 迁移先保住原来的分布，再纠正原来的缺陷

像素模型从 latent 主干初始化，明显快于相同设置从零训练。数据选择却不能只用“质量越高越好”概括。源模型自己的生成数据与主干已有条件分布接近，迁移较快；只用真实图片则分布改变较大、收敛慢；只用源模型生成图又继承其 VAE 和文字伪影。

下图先比较 real-only、source-generated 与混合数据的曲线，再看文字或细节是否仍保留源模型缺陷。它们支持将源模型生成数据作为迁移桥梁、真实图片作为直接像素纠错信号。

![Post-training data ablation curves](../../assets/images/paper-deep-dives/diffusion/z-image-pixel/figure-6-data-bench.png){ width="900" }

<small>图源：论文 Figure 6。比较 Real、Self Latent Generated、Other Model Generated 与 Mix Real & Self 四种数据来源。</small>

![Qualitative effect of mixed post-training data](../../assets/images/paper-deep-dives/diffusion/z-image-pixel/figure-7-data-visual.png){ width="900" }

<small>图源：论文 Figure 7。每组依次为 latent baseline、只用 source latent data 的 pixel model、real + self mixed data 的 pixel model。</small>

不同模型生成的数据效果更弱，进一步支持分布接近的重要性，但不能由此断言所有合成数据质量差异都只来自分布偏移。实际采用时，数据来源与初始化来源应一并考虑。[↗](https://arxiv.org/pdf/2608.16887#page=5)

## 预测目标和像素解码头要一起设计

原 latent 主干使用 $v$-prediction；像素后训练中，良好初始化使 $v$ 与 $x$ 两种预测都能收敛，但 $x$-prediction 持续更好。下图比较同一训练进度的两条曲线，结论是该迁移设置更偏好直接预测干净图像，并不是本文验证了 $v$-prediction 在所有像素模型上必然发散。

![Prediction target ablation](../../assets/images/paper-deep-dives/diffusion/z-image-pixel/figure-8-prediction-target.png){ width="900" }

<small>图源：论文 Figure 8。两组实验共享 latent initialization、flow path、timestep sampler、noise scale、decoder、loss weighting 与 solver。</small>

接下来固定主干与训练设置，比较输出头。Table 1 的延迟只算 decoder，在单张 H800 上输出 1024×1024 图像。

| Decoder | GenEval ↑ | DPG ↑ | Params (M) ↓ | Latency (ms) ↓ | GFLOPs ↓ |
| --- | ---: | ---: | ---: | ---: | ---: |
| JiT | 0.7380 | 86.19 | 2.95 | 0.07 | 24.16 |
| DiP | 0.7545 | 87.54 | 10.09 | 6.02 | 834.03 |
| PiT | 0.7697 | 86.36 | 2249.82 | 74.96 | 19731.88 |
| Deco | 0.7347 | 86.10 | 315.92 | 5.01 | 2587.05 |
| VAE | — | — | 49.55 | 91.88 | 10472.20 |

PiT 的 GenEval 最高，却增加约 2.25B 参数和很大计算。JiT 极快，但局部 patch 边界容易出现网格。作者选择轻量卷积 DiP，在该主干中取得较好的质量—成本折中。下图先看跨 patch 的连续边缘，观察卷积局部交互怎样缓和边界；这不能归纳为所有 PiT 架构都低效，因为这里是接在 6B 主干上的具体头配置。

![JiT versus DiP decoder artifacts](../../assets/images/paper-deep-dives/diffusion/z-image-pixel/figure-9-decoder-head.png){ width="860" }

<small>图源：论文 Figure 9。上排 JiT linear head 在 patch 边界出现块状不连续；下排 DiP head 用局部卷积交互平滑相邻 patch。</small>

## 噪声尺度不能只按分辨率比例搬运

论文以数据在 $t=1$、噪声在 $t=0$ 的约定定义路径

$$
x_t=tx_0+(1-t)\gamma\epsilon,
\qquad \epsilon\sim\mathcal N(0,I).
$$

这与常见 $(1-t)x_0+t\epsilon$ 的时间方向相反，复现时必须一起调整。若 RGB 每边比 latent 大 $r$ 倍，平均池化会使独立像素噪声方差降低 $r^2$，于是简化分析为

$$
\operatorname{SNR}_{\mathrm{pixel}}^{\downarrow r}(t)
\approx\frac{r^2}{\gamma^2}\operatorname{SNR}_{\mathrm{latent}}(t).
$$

仅按空间分辨率匹配可得 $\gamma=r=8$，但 VAE 并非平均池化，信号统计和预测目标也改变。实际消融为

| Noise scale γ | 1 | 2 | 4 | 8 |
| --- | ---: | ---: | ---: | ---: |
| GenEval ↑ | 0.6811 | 0.7545 | 0.7413 | 0.7316 |
| DPG ↑ | 84.03 | 87.54 | 86.01 | 85.64 |

最优是 2，而不是参考推导的 8。下图按同一提示比较颜色和明暗，帮助确认分数变化对应何种可见失真。[↗](https://arxiv.org/pdf/2608.16887#page=6)

![Noise scale qualitative comparison](../../assets/images/paper-deep-dives/diffusion/z-image-pixel/figure-10-noise-scale.png){ width="760" }

<small>图源：论文 Figure 10。比较 $\gamma\in\{1,2,4,8\}$；$\gamma=1,4,8$ 出现不同程度色偏，$\gamma=2$ 的颜色更平衡。</small>

## 大 patch 的收益来自逐步适应

1024 图像、patch 16 对应 $64\times64=4096$ 个 token，与原 latent 模型有效空间粒度相同。直接从 latent 转到 pixel patch 32，同时改变预测空间和 token 粒度，训练较慢且局部伪影明显。

作者先完成 ps16 迁移，再适应 ps32，使 token 数降到 1024，即四分之一。下图比较 direct ps32 与 ps32-adapt16 的收敛；进一步到 ps64 虽继续省 token，却重新损伤局部细节，因此不能线性外推压缩收益。

![Progressive patch-size adaptation curves](../../assets/images/paper-deep-dives/diffusion/z-image-pixel/figure-11-patch-adaptation.png){ width="900" }

<small>图源：论文 Figure 11。虚线是 ps16 reference；ps32-adapt16 明显快于 direct ps32，并接近 ps16。</small>

最后对像素模型用 Decoupled-DMD 与 DMDR 做少步蒸馏。没有固定 VAE 解码开销后，减少 denoising 次数更直接转化为端到端收益；但大 patch、像素输出与步数减少是三个不同因素。

## 速度表必须连同 NFE、指标与设备读

Table 3 使用原始 benchmark prompts，不使用 prompt-enhanced 版本，并将延迟标为单张 H800、1024×1024、无系统优化。以下取 Z-Image 系列。

| Model | NFE | Latency (s) ↓ | GenEval ↑ | DPG ↑ | OneIG ↑ | LongText ↑ |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Z-Image latent | 100 | 20.12 | 0.7510 | 86.91 | 0.566 | 0.9332 |
| Ours pixel | 100 | 4.56 | 0.7644 | 87.60 | 0.564 | 0.9252 |
| Z-Image-Turbo latent | 4 | 0.95 | 0.7625 | 85.31 | 0.520 | 0.8639 |
| Ours-Turbo pixel | 4 | 0.20 | 0.7698 | 86.85 | 0.512 | 0.8732 |

同为四次评估，$0.95/0.20=4.75$ 倍；若比较原 100 NFE latent 与最终四步 pixel，才是 $20.12/0.20=100.6$ 倍，后者叠加了步数与表示变化。OneIG 并没有提高，100 NFE 的 LongText 也略低，因此更准确的结论是相近或较好的综合质量与明显提速，而非全指标无损。

![End-to-end latency decomposition](../../assets/images/paper-deep-dives/diffusion/z-image-pixel/figure-13-inference-latency.png){ width="760" }

<small>图源：论文 Figure 13。图注标注单张 NVIDIA H100、1024x1024、无 FlashAttention 等系统优化；Table 3 的系统对比则标注 H800，硬件口径不能混为同一组测量。</small>

延迟分解图应先看固定 VAE 部分与逐步 denoising 部分。该图注标注 H100，与 Table 3 的 H800 不一致，因而具体表值按各自设备说明使用，不把两处当作严格同硬件测速。[↗](https://arxiv.org/pdf/2608.16887#page=8)

同一配方迁移到 FLUX2-klein 家族，在 100 NFE 时从 20.25 秒降到 6.38 秒，四次评估从 0.92 秒降到 0.28 秒，显示它不只作用于 Z-Image。最可复用的顺序是保留 latent 主干知识、用混合数据和轻量像素头完成迁移、校准噪声，再增大 patch、最后蒸馏步数；一次改变全部环节会失去判断退化来源的机会。
