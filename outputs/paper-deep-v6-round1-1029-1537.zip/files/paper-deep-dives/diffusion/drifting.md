---
paper_date: 2026-02
paper_title: "Generative Modeling via Drifting"
paper_topic: 扩散模型
---

# Drifting：把生成分布的迭代搬到训练阶段

!!! info "论文信息"
    **论文题名：** Generative Modeling via Drifting。<br>
    **作者：** Mingyang Deng、He Li、Tianhong Li、Yilun Du、Kaiming He。<br>
    **机构：** MIT、Harvard University。<br>
    **时间 / 主题：** 2026-02，v2；扩散模型与一步生成。<br>
    **arXiv / 项目页：** [2602.04770](https://arxiv.org/abs/2602.04770)；[Generative Modeling via Drifting](https://lambertae.github.io/projects/drifting/)。<br>
    **代码：** 项目页提供 JAX 代码、预训练权重与 toy demo。<br>
    **元数据与核验口径：** 来源为 arXiv HTML、项目页；Checked Date：2026-09-07；Repro Status：Paper / official project materials reviewed, independent reproduction not claimed。

## 推理只做一次前向，分布怎样逐渐变好

Drifting 的问题从一个很朴素的观察出发。扩散模型让同一个样本在推理时经历多次更新，训练好的神经网络负责解释每一步往哪里走。可是训练生成器时，参数本身也在不断更新。固定一个噪声 $\epsilon$，第 $i$ 次迭代的输出 $f_{\theta_i}(\epsilon)$ 与下一次输出本来就不同。如果能把这种变化直接组织成通向真实分布的运动，推理就可以只计算最终的 $f_\theta(\epsilon)$。

因此，论文建模的对象是训练过程中生成分布的演化。令先验噪声分布为 $p_\epsilon$，生成分布为 $q_\theta=(f_\theta)_\#p_\epsilon$，真实分布为 $p$。每轮训练先观察当前输出，再根据真实样本和生成样本构造漂移场 $V_{p,q_\theta}(x)$，最后更新共享的生成器参数，让输出向漂移后的目标移动。这没有要求生成器学习带时间索引的去噪轨迹，也不要求先训练一个多步教师。[原论文，第2—3页](https://arxiv.org/pdf/2602.04770#page=2)

这个视角也限制了“一步”的含义。它减少的是生成时的网络求值次数。训练仍有大量参数更新，并且高维图像实验依赖冻结特征编码器、正负样本和大批量计算。判断是否值得采用，要同时看一步输出的质量和这套训练监督从哪里来。

## 漂移场必须同时知道真实样本在哪里、生成样本挤在哪里

只把生成图像拉向附近真实图像，很容易让大量噪声都产生相似输出。Drifting 用一对对称结构处理这个问题。对当前生成点 $x$，分别定义真实样本的吸引与生成样本的排斥

$$
V_p^+(x)=\frac{\mathbb E_{y^+\sim p}[k(x,y^+)(y^+-x)]}{Z_p(x)},\qquad
V_q^-(x)=\frac{\mathbb E_{y^-\sim q}[k(x,y^-)(y^--x)]}{Z_q(x)},
$$

$$
V_{p,q}(x)=V_p^+(x)-V_q^-(x),\qquad
Z_p(x)=\mathbb E_{y^+\sim p}k(x,y^+),\quad
Z_q(x)=\mathbb E_{y^-\sim q}k(x,y^-).
$$

$k$ 衡量点之间的相似性，$Z$ 将权重归一化。第一项指向真实邻居的加权均值，第二项减去生成邻居的加权均值；生成点越挤在同一个区域，排斥项就越能阻止进一步聚集。两个式子里的 $-x$ 抵消，还可以把总场写成真实与生成样本差 $y^+-y^-$ 的成对加权平均。这说明它比较的是两种局部分布，而非给每个噪声指定唯一真实配对。

论文使用的核是

$$
k(x,y)=\exp\left(-\frac{\|x-y\|_2}{\tau}\right).
$$

这里的欧氏距离没有平方，不能直接替换成常见高斯核。温度 $\tau$ 决定邻域宽度。实现中对 source 维度做 softmax，并额外在生成点维度归一化，使有限批量的交互更稳定；正样本来自数据，负样本可以复用生成批量。[原论文，第3—4页，式8—12](https://arxiv.org/pdf/2602.04770#page=3)

构造的关键性质是交换 $p,q$ 后方向翻转，即 $V_{p,q}=-V_{q,p}$，所以 $p=q$ 时场为零。这提供了正确分布应当停止漂移的必要结构。它本身没有证明所有零漂移状态都是正确分布。原论文在讨论中也明确将“$V\to0$ 在什么条件下推出 $q\to p$”列为开放问题，不能把这个固定点论证扩大为任意神经网络训练的全局收敛保证。

## 停止梯度的位置决定了模型究竟在学什么

理想的粒子更新是 $x\leftarrow x+V(x)$。神经网络不能为每个训练噪声单独存一个自由粒子位置，因此作者通过回归实现这次运动

$$
\mathcal L(\theta)=\mathbb E_\epsilon\left\|f_\theta(\epsilon)-\operatorname{sg}\left[f_\theta(\epsilon)+V_{p,q_\theta}\big(f_\theta(\epsilon)\big)\right]\right\|_2^2.
$$

$\operatorname{sg}$ 表示停止梯度。当前生成图像及其漂移先被合成一个固定 target，梯度只经过左侧预测。就损失数值而言，它等于当前场的平方范数；就参数梯度而言，它是把输出推向一个冻结位置的回归，不能当作对 $\|V_{p,q_\theta}\|^2$ 做完整自动微分。后一种写法会把生成分布和漂移场对参数的依赖也纳入梯度，训练规则已经变了。[原论文，第3页，式6](https://arxiv.org/pdf/2602.04770#page=3)

实际执行一次更新时，先采样噪声并生成图像，计算真实与生成特征之间的距离和归一化权重，得到漂移向量；再把漂移后的特征作为 detached target，回传到生成器。许多噪声共享参数，网络更新只能近似同时实现所有粒子的位移。因此，“分布迭代”是理解训练的方式，也需要模型容量、优化和批量估计共同支持。

## 图像训练真正依赖的是特征空间

直接在高维像素或 VAE latent 中度量邻近关系，未必能表达语义上的相似。论文的 ImageNet 实验必须引入特征编码器才能得到有效结果，使用 VAE 并未自动解决这一问题。对冻结编码器 $\phi$，损失变成

$$
\mathcal L_\phi=\mathbb E_\epsilon\left\|\phi(f_\theta(\epsilon))-\operatorname{sg}\left[\phi(f_\theta(\epsilon))+V\big(\phi(f_\theta(\epsilon))\big)\right]\right\|_2^2,
$$

并在不同层级、空间尺度上求和。这里冻结的是编码器参数，预测侧仍须通过编码器的 Jacobian 把梯度传回图像和生成器。如果把预测特征也 detach，生成器就收不到这部分监督。

论文探索了两类编码器。MoCo、SimCLR 在 RGB 图像上提取特征，latent 生成器训练时需要先通过 VAE 解码；定制 latent-MAE 直接处理 latent，避免每步解码，但需要额外的表示预训练。Table 3 展示出表示质量对最终结果的影响，远大于“有一个冻结 encoder”这种二元选择。[原论文，第4—6页](https://arxiv.org/pdf/2602.04770#page=4)

| Feature encoder | Feature width | SSL epochs | FID ↓ |
| --- | ---: | ---: | ---: |
| SimCLR, ResNet bottleneck | 256 | 800 | 11.05 |
| MoCo-v2, ResNet bottleneck | 256 | 800 | 8.41 |
| Latent-MAE, ResNet basic | 256 | 192 | 8.46 |
| Latent-MAE, ResNet basic | 640 | 192 | 6.30 |
| Latent-MAE, ResNet basic | 640 | 1280 | 4.28 |
| Latent-MAE + classification fine-tuning | 640 | 1280 | 3.36 |

这些结果是在该表的生成器训练设置下得到的。扩大表示宽度、延长表示预训练、加入分类微调都能继续改善 FID，所以最终模型的质量不能只归因于漂移公式。另一方面，latent 与 pixel 两条路线共享同一监督思想，说明它不受 VAE 架构限制。

## 条件引导被写进负样本分布

扩散 CFG 通常在推理时组合条件和无条件网络输出。一步模型若照搬两次前向，便失去最简的一次求值接口。Drifting 将引导强度放进训练的分布比较：把负分布替换为

$$
\widetilde q=(1-\gamma)q_\theta(\cdot\mid c)+\gamma p_{\mathrm{data}}(\cdot\mid\varnothing).
$$

在理想的零漂移关系下，条件真实分布与 $\widetilde q$ 匹配，形式上可得

$$
q_\theta(\cdot\mid c)=\alpha p_{\mathrm{data}}(\cdot\mid c)-(\alpha-1)p_{\mathrm{data}}(\cdot\mid\varnothing),\qquad \alpha=\frac1{1-\gamma}.
$$

它加强条件特有的内容，削弱普遍出现的无条件内容。这个带负系数的表达式是解释 guidance 方向的形式关系，并不保证右侧处处为非负密度。实现中训练生成器接受随机引导强度作为条件，推理时可以选择 $\alpha$，同时保留一次前向。[原论文，第5页](https://arxiv.org/pdf/2602.04770#page=5)

## 消融揭示了三个真正影响训练的因素

首先是吸引和排斥的平衡。Table 1 使用 B/2 生成器训练100 epochs，默认 $V^+-V^-$ 的 FID 为8.46；只把吸引系数放大为1.5，FID变成41.05；只把排斥系数放大为1.5，变成46.28；取消排斥则恶化到177.14。它支持对称结构对该实现十分关键，不能被解释为任意形式的非对称漂移在理论上都失败。

其次是每个条件下参考样本的数量。固定64个条件、每个条件64个生成样本时，真实正样本数从1增加到16、32、64，FID依次为20.43、10.39、8.97、8.46。保持生成总批量4096，将每个条件的正负样本数从8增加到64，同样有利。总 batch 相同，分配给同一条件的样本更多，局部分布估计才更可靠。这也说明强条件任务若每个条件只有一个真实配对，不能直接期待复现 ImageNet 的统计优势。

最后是训练量和模型规模。Table 4 从较强编码器下的 B/2、100 epochs、FID3.36，推进到320 epochs的2.51；延长到1280 epochs并调整超参数后为1.75，扩大到 L/2 后为1.54。后两步包含训练与配置变化，不能把全部提升解释成单一 scaling law。[原论文，第6—7页，Tables 1—4](https://arxiv.org/pdf/2602.04770#page=6)

## 一步结果很强，但参数、输出空间和任务要分开读

ImageNet-256 的主结果按50K样本 FID报告，适用时使用 CFG。latent 模型先生成 SD-VAE 的 $32\times32\times4$ 表示，还需约49M参数的解码器；pixel 模型直接生成 $256\times256\times3$ 图像。[原论文，第7—8页，Tables 5—6](https://arxiv.org/pdf/2602.04770#page=7)

| Model | Space | Generator params | NFE | FID ↓ | IS ↑ |
| --- | --- | ---: | ---: | ---: | ---: |
| Drifting B/2 | Latent | 133M | 1 | 1.75 | — |
| Drifting L/2 | Latent | 463M | 1 | 1.54 | — |
| Drifting B/16 | Pixel | 134M | 1 | 1.76 | 299.7 |
| Drifting L/16 | Pixel | 464M | 1 | 1.61 | 307.5 |
| PixelDiT/16 | Pixel | 797M | 200×2 | 1.61 | 292.7 |
| StyleGAN-XL | Pixel | 166M | 1 | 2.30 | 265.1 |

pixel L/16以一次求值达到与表中多步 PixelDiT 相同的1.61 FID；论文报告其生成计算量87G FLOPs，对照 StyleGAN-XL 的1574G FLOPs。这些是所列系统配置的比较，训练表示和训练预算并不相同。latent的一次生成器求值还没有计入解码步骤，不能把不同空间的 NFE 当成完全相同的终端延迟。

机器人实验进一步检验该规则是否只能在视觉语义特征里工作。作者直接对控制表示计算 drifting loss，将 Diffusion Policy 的100 NFE替换为1 NFE，在多项任务中保持相近成功率。BlockPush第二阶段由0.11提高到0.16，但 ToolHang视觉任务由0.73降到0.67，Kitchen第四阶段由0.99降到0.96。因此证据支持一步控制的可行性，未支持所有任务全面胜出；表中还是最后10个 checkpoint 的平均成功率，不能当作最佳单次成绩。

Drifting 最有用的贡献，是提供了一个可复用的训练接口：先在当前生成分布上设计合理运动，再让共享网络追随这个运动。采用时最值得优先复现的是对称正负场、正确的停止梯度、足够的同条件参考以及多层特征监督。仅保留“一步生成”外形而省去这些条件，很难重现其质量。原论文也留下了明确的研究问题，包括零漂移的可辨识条件、核与温度设计，以及怎样减少对强表示预训练的依赖。[原论文，第8页](https://arxiv.org/pdf/2602.04770#page=8)
