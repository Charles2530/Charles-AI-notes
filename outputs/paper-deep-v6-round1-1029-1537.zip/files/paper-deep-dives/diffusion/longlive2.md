---
paper_date: 2026-05
paper_title: "LongLive-2.0: An NVFP4 Parallel Infrastructure for Long Video Generation"
paper_topic: 扩散模型 / 长视频生成系统
---

# LongLive-2.0：NVFP4 长视频生成基础设施

!!! info "论文信息"
    **论文题名：** LongLive-2.0: An NVFP4 Parallel Infrastructure for Long Video Generation。<br>
    **作者：** Yukang Chen、Luozhou Wang、Wei Huang、Shuai Yang、Bohan Zhang、Yicheng Xiao、Ruihang Chu、Weian Mao、Qixin Hu、Shaoteng Liu、Yuyang Zhao、Huizi Mao、Ying-Cong Chen、Enze Xie、Xiaojuan Qi、Song Han。<br>
    **机构：** NVIDIA。<br>
    **时间 / 主题：** 2026-05；长视频生成、视频扩散系统、NVFP4 训练与推理。<br>
    **arXiv / 官方报告：** arXiv：[2605.18739](https://arxiv.org/abs/2605.18739)；PDF：[arxiv.org/pdf/2605.18739](https://arxiv.org/pdf/2605.18739)。<br>
    **GitHub / 项目：** GitHub：[github.com/NVlabs/LongLive](https://github.com/NVlabs/LongLive)。<br>
    **元数据来源与核验口径：** 来源：arXiv v2、论文 PDF、官方 GitHub README；Checked Date：2026-07-25；Repro Status：Paper / official GitHub reviewed, independent reproduction not claimed。

## 长视频需要同时解决训练、缓存和解码

LongLive-2.0 是围绕 Wan2.2-TI2V-5B 的长视频系统。它将长、多镜头、可切换提示的自回归训练与少步蒸馏分开，再以 Balanced SP、NVFP4 计算、低比特 KV cache 和异步 VAE 解码降低全流程成本。直接 AR 微调获得长视频能力，独立 LoRA 再赋予二至四步生成能力。[↗](https://arxiv.org/pdf/2605.18739#page=2)

下图从训练侧的两条路径开始读。AR 微调处理长视频与镜头条件，DMD 生成少步 LoRA；部署时再组合计算精度、cache 与解码管线。它没有把所有能力都压到一个复杂蒸馏阶段中。

![LongLive-2.0 框架](../../assets/images/paper-deep-dives/diffusion/longlive2/figure-2-framework.png){ width="860" }

<small>图源：`LongLive-2.0: An NVFP4 Parallel Infrastructure for Long Video Generation`，Figure 2。原图左侧是 AR training、Balanced SP、NVFP4 training 与 standalone LoRA step-distill；右侧是 W4A4 NVFP4 inference、KV-cache compression、parallel dequantization 和 async VAE decode。</small>

## Balanced SP 让每张卡同时拥有上下文和监督目标

高效 teacher forcing 将干净历史与带噪目标放入同一序列。每个 noisy chunk 可以看之前的 clean chunks 和自己，不能偷看同时间的干净答案，一次前向监督全部目标块。

若简单把 $[z_{\mathrm{clean}};z_{\mathrm{noisy}}]$ 连续切给不同卡，有的 rank 几乎只有上下文，有的主要承担目标损失，VAE 编码还可能在各 rank 重复。Balanced SP 按时间归属配对分片

$$
z^{(p)}=[z_{\mathrm{clean}}^{(p)},z_{\mathrm{noisy}}^{(p)}]
\in\mathbb R^{(L/P)\times H\times d}.
$$

$P$ 是 SP 组大小，$L$ 为 clean 与 noisy 总 token 数，$H,d$ 为 head 数与维度。每个 rank 拿同一时间片的干净与带噪版本，因而监督量更均衡。

下图先对照左、中两栏的 loss 所在 GPU，再看下方 VAE 分工，最后读右栏低精度 GEMM。Balanced SP 与 NVFP4 是可叠加的两项优化，不能把全部增益都归于 FP4。

![LongLive-2.0 训练基础设施](../../assets/images/paper-deep-dives/diffusion/longlive2/figure-3-training-infra.png){ width="860" }

<small>图源：`LongLive-2.0: An NVFP4 Parallel Infrastructure for Long Video Generation`，Figure 3。原图比较 naive SP 与 Balanced SP，并展示 NVFP4 training 对 GEMM 和显存的作用。</small>

VAE 同样按时间切块，每张卡处理自己的视频与覆盖时间感受野的左侧 halo，编码后丢弃 halo 对应 latent。每卡编码量从 $O(F)$ 降到 $O(F/P+h)$，其中 $h$ 是 halo 长度。Ulysses All-to-All 后直接按通信产生的 token 顺序构造 attention mask，省去每层重新排列成“全部 clean、全部 noisy”的操作。[↗](https://arxiv.org/pdf/2605.18739#page=3)

## NVFP4 并不把所有状态都压成四比特

NVFP4 用 E2M1 表示四比特值，配合微块缩放；训练中权重采用二维 block scaling，激活和梯度采用一维 scaling。归约、归一化统计和优化器状态保留较高精度。权重梯度 GEMM 对量化敏感，作者在相关操作数上使用 Random Hadamard Transform 降低异常值影响。

DMD 阶段的 real-score、fake-score、generator 都使用 W4A4 主干，冻结量化权重，仅更新 BF16 LoRA

$$
W\simeq\operatorname{Dequant}(Q_{\mathrm{search}}(W_0))
+\frac{\alpha_{\mathrm{LoRA}}}{r}BA.
$$

$W_0$ 是预训练权重，$A,B$ 是 rank $r$ 的可训练适配器。scale search 在目标幅度 6 与 4 中选择块误差较低的量化形式。该训练配置让蒸馏与部署的低精度主干更一致，也限制了可训练参数空间。[↗](https://arxiv.org/pdf/2605.18739#page=4)

## KV 量化与异步解码优化不同资源

长历史 KV 随时间增长，模型权重压缩后它会占据更大比例。作者按 frame chunk 量化 KV，对 K 做通道均值 smoothing，并以并行 CUDA 内核按窗口反量化。忽略摊销尺度与 padding，K/V 存储由 $4T_cHd$ bytes 降为 $\tfrac98T_cHd$ bytes，压缩比约为 $4/(9/8)=3.56$。

cache 量化省内存，但有量化和反量化开销，因此不保证速度同步提升。VAE 则通过逐块解码和立即卸载避免累计全部 latent；另用一张 GPU 解码，让第 $c$ 块解码与第 $c+1$ 块 DiT 去噪重叠。若去噪较慢，$C$ 块的串行时间

$$
C(t_{\mathrm{DiT}}+t_{\mathrm{VAE}})
$$

可接近

$$
Ct_{\mathrm{DiT}}+t_{\mathrm{VAE}}.
$$

它是额外设备换取管线重叠，不能把异步结果说成纯单卡加速。[↗](https://arxiv.org/pdf/2605.18739#page=5)

## 多镜头连续性由两组固定上下文维持

每个 latent chunk 绑定自己的文本 $T_i$，以 $\operatorname{CrossAttn}(Z_i,T_i)$ 读取条件，提示可以在块边界切换。为限制历史计算，系统使用滑动窗口；为避免丢掉角色或场景，额外保留 global sink 与 shot-level sink。

有效 KV 集合是

$$
\mathcal K_{\mathrm{eff}}(t)
=\mathcal A_g\cup\mathcal A_s\cup\mathrm{KV}[t-W,t),
$$

其中全局 anchor 保持视频初始身份，当前镜头 anchor 在镜头切换时重新绑定。两者重叠 token 去重，shot-level anchor 以指针管理。提示切换同时刷新未来块的 cross-attention cache，已经生成的历史不需要重算。这是长视频“可交互”的具体接口，而非任意时刻修改已输出帧。[↗](https://arxiv.org/pdf/2605.18739#page=6)

## 训练收益随视频变长而扩大

Table 1 与实验正文将一次训练迭代报告为秒；Figure 1 图注却写成毫秒，两处单位不一致。以下保留训练表口径，速度比则不受该单位冲突影响。

| Input Length | BF16 + SP (s) | BF16 + Balanced SP (s) | NVFP4 + Balanced SP (s) |
| --- | ---: | ---: | ---: |
| 16s | 52.2 | 45.8 | 40.1 |
| 32s | 162.7 | 136.8 | 119.3 |
| 64s | 1372.9 | 1196.5 | 639.5 |

64 秒视频相对 BF16+SP 为 $1372.9/639.5\approx2.15$ 倍；只把精度从 Balanced SP BF16 换到 NVFP4，则为 $1196.5/639.5\approx1.87$ 倍。没有 SP 的 BF16 在该长度 OOM。DMD 三模型逐步量化后，每 GPU 峰值显存从 70.5 降到 49.0 GB，节省 21.5 GB。[↗](https://arxiv.org/pdf/2605.18739#page=7)

## 最快设置明确交换了一部分质量

推理实验使用 GB200 180 GB，异步解码另外占一张 GPU。下面保留 64 秒目标视频的整段耗时，避免将模型吞吐与端到端混为一谈。

| Configuration | FPS ↑ | 64s E2E Generation (s) ↓ | Memory (GB) ↓ |
| --- | ---: | ---: | ---: |
| BF16 | 24.8 | 112.9 | 36.4 |
| NVFP4 | 32.0 | 96.0 | 29.7 |
| + NVFP4 KV Cache | 29.7 | 99.5 | 19.4 |
| + Async Decoding | 29.7 | 57.6 | 19.4 |
| 2 Steps | 45.7 | 36.3 | 19.4 |

KV 量化将内存显著降低，但 FPS 从 32.0 降到 29.7；异步解码不改变表中 DiT 侧 FPS，却把整段时间压到 57.6 秒。最后二步同时减少计算并影响模型质量，不能把 1.84 倍吞吐增益全部归因于量化。

同为 5B、1280×720，VBench Total 从 BF16 四步的 85.06，变成 NVFP4 四步的 84.51、二步的 83.14；Semantic 分别为 78.63、76.81、74.12。长视频 60 秒评估中，NVFP4 subject consistency 为 97.62，较 BF16 97.48 接近，但 dynamic degree 从 60.62 降到 45.88。部署应按连续性、动作强度和吞吐共同选档，不能称所有维度无损。[↗](https://arxiv.org/pdf/2605.18739#page=8)

这套系统最值得复用的是统一时间块所有权——VAE、SP、监督、prompt 与 KV 都按块对齐，随后再叠加低精度计算。Blackwell 的原生 FP4 支持决定相应 GEMM 加速；非 Blackwell 设备采用 SP 路线，需要按设备数量和通信成本重新衡量。
