---
paper_date: 2025-03
paper_title: "Wan: Open and Advanced Large-Scale Video Generative Models"
paper_topic: 扩散模型
---

# Wan2.1：开源视频生成系统路线

!!! info "论文信息"
    **论文题名：** Wan: Open and Advanced Large-Scale Video Generative Models。<br>
    **作者：** Team Wan、Ang Wang、Baole Ai、Bin Wen、Chaojie Mao、Chen-Wei Xie、Di Chen、Feiwu Yu、Haiming Zhao、Jianxiao Yang 等（共 62 人）。<br>
    **机构：** 未在公开元数据中稳定解析；以 arXiv/PDF 或官方页 affiliation block 为准。<br>
    **时间 / 主题：** 2025-03；扩散模型。<br>
    **arXiv / 官方报告：** arXiv：[2503.20314](https://arxiv.org/abs/2503.20314)；官方材料：[huggingface.co/Wan-AI](https://huggingface.co/Wan-AI)。<br>
    **GitHub / 项目：** GitHub：[github.com/Wan-Video/Wan2.2](https://github.com/Wan-Video/Wan2.2)；项目页：[huggingface.co/Wan-AI](https://huggingface.co/Wan-AI)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2503.20314)；[GitHub API / repo](https://github.com/Wan-Video/Wan2.2)；[官方 / 项目材料](https://huggingface.co/Wan-AI)；Checked Date：2026-06-04；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 为什么这份报告需要沿着整条视频链路读

Wan2.1要建立的是可扩展的视频生成底座。输入文字和可选视觉条件，输出时序一致的视频；模型必须同时解决语义对齐、细节重建、动作变化和长序列计算。这里任何一环都可能成为上限。VAE若丢掉文字笔画，后面的DiT只能学习有损表示；caption若只描述静态物体，模型很难知道动作与镜头怎样发生；全时空注意力若无法训练，增加数据和模型规模也不能自然兑现质量。

因此报告的主要价值在于把数据、压缩表示、流匹配训练、并行系统和任务扩展连成一个实际系统。其1.3B与14B版本还分别承担易部署基线与高质量底座的角色。摘要中8.19GB显存的描述对应1.3B模型，不能扩展成14B或后续所有Wan模型的硬件门槛。[原论文，第1页](https://arxiv.org/pdf/2503.20314#page=1)

先看报告的总结果图。不同评测覆盖语义、画质与动态，综合领先需要再拆到分项和评测版本中理解。

![Wan comparison results](../../assets/images/paper-deep-dives/diffusion/wan/figure-1-results.png){ width="920" }

<small>图源：`Wan: Open and Advanced Large-Scale Video Generative Models`，Figure 1。</small>

样例图则提供另一种阅读入口。应分别观察运动前后主体形状是否保持、文字是否可读、镜头变化是否带来背景一致性问题；静态截图只能展示其中一部分，不能代替视频级检验。

![Wan generated examples](../../assets/images/paper-deep-dives/diffusion/wan/figure-2-examples.png){ width="720" .atlas-figure-tall }

<small>图源：`Wan: Open and Advanced Large-Scale Video Generative Models`，Figure 2。</small>

## 数据既要筛掉坏视频，也要教会模型怎样描述变化

报告的数据管线从大量图像与视频出发，逐步执行基础清洗、质量与内容筛选，再选择用于后训练的高质量子集。它不是只用一个美学分数挑选漂亮画面。视频的运动幅度、连续性、主体内容、画面质量和文字都影响模型会学到什么，例如把所有强运动都当作“不稳定”过滤，会削弱模型生成动作的能力。[原论文，第4—8页](https://arxiv.org/pdf/2503.20314#page=4)

数据流程图应沿着筛选阶段与不同用途的分流读，而不把它理解成一次固定阈值过滤。预训练需要覆盖面，后训练强调最终视频观感，二者的数据分布不同。

![Wan data provisioning](../../assets/images/paper-deep-dives/diffusion/wan/figure-data-stage.png){ width="920" }

<small>图源：`Wan: Open and Advanced Large-Scale Video Generative Models`，Figure 3。</small>

视觉文字又有专门的数据需求。报告结合真实场景文字、多OCR结果，以及白底中文合成文字图像，补足中英文字符与视觉形态之间的联系。能理解提示词中的中文，并不自动意味着能在画面里正确写出中文；前者依赖文本编码，后者还需要像素重建与视觉文字监督。

视频caption同样不能停留在“一个人在房间里”。作者训练dense caption模型，描述物体、动作、镜头角度与运动、颜色、场景和事件，再用不同长度与风格的caption拓宽训练接口。在十个维度上，每个维度抽1000个视频，按照CAPability式F1比较caption与Gemini 1.5 Pro。自有caption在事件、镜头角度、镜头运动、风格和物体颜色上更强，Gemini在动作、OCR、场景、物体类别和计数上更强。这是特定标注评价的互有胜负，不是caption模型全面超越通用多模态模型的结论。[原论文，第8—10页](https://arxiv.org/pdf/2503.20314#page=8)

推理端的prompt rewrite与这条训练链路直接相关。用户输入往往短于dense caption，报告用Qwen2.5-Plus补充场景、自然动作和镜头描述，使提示形式接近训练caption。它会改变生成器真正看到的条件，所以对比系统表现时应记录是否开启重写，也应确认新增细节符合用户意图。[原论文，第19—20页](https://arxiv.org/pdf/2503.20314#page=19)

## Wan-VAE把长视频压缩成怎样的表示

Wan-VAE使用3D因果结构，将输入视频

$$
V\in\mathbb R^{(1+T)\times H\times W\times3}
$$

编码成

$$
z\in\mathbb R^{(1+T/4)\times(H/8)\times(W/8)\times16}.
$$

第一帧只做空间压缩，后续帧按时间4倍压缩，空间按8倍压缩。保留第一帧的特殊处理使图像和视频能共享接口，也对后面的首帧条件生成有用。图中的橙色与绿色下采样模块分别对应时空压缩和只做空间压缩。[原论文，第10—11页](https://arxiv.org/pdf/2503.20314#page=10)

![Wan-VAE framework](../../assets/images/paper-deep-dives/diffusion/wan/figure-3-vae.png){ width="920" }

<small>图源：`Wan: Open and Advanced Large-Scale Video Generative Models`，Figure 5。</small>

结构上有两个容易被忽略的决定。首先，用RMSNorm替代GroupNorm，以避免归一化操作破坏时间因果性，并支持分块缓存。其次，空间上采样层的输入通道减半，报告称由此使推理显存下降33%；整个VAE约127M参数。这个33%是具体模块调整在该实现中的收益，不是视频模型总显存按同样比例下降。

VAE分三阶段训练。先训练对应的2D图像VAE，再膨胀成3D因果结构，以低分辨率128×128、5帧视频学习时间压缩；这一阶段L1、KL与LPIPS权重分别为3、$3\times10^{-6}$和3。最后在高质量、多分辨率和多帧数视频上微调，加入3D判别器的GAN损失。这个顺序让空间先验帮助视频重建，不必完全从零学习每一种视觉结构。

长视频解码的关键是feature cache。普通时间卷积核为3时，后一个chunk保留前两个历史特征；时间stride为2的下采样处使用相应的单帧缓存管理。每次处理对应一个latent时间位置、至多4个视频帧的chunk，既避免整段视频激活同时驻留，又保留跨chunk卷积上下文。

这支持长度不预先固定的VAE编码和重建。它没有证明生成DiT能在任意长时间内保持人物、事件和场景逻辑。压缩模块的分块推理与语义层面的长视频生成，需要分开判断。

VAE比较使用200段25帧、720×720视频，报告PSNR和处理效率；Wan-VAE在同硬件上相对Hunyuan Video VAE有2.5倍重建速度。部分对照的时间、空间压缩率和latent通道不同，因此该图是系统级质量—速度比较，不能视为严格统一信息瓶颈的纯架构消融。[原论文，第11—12页](https://arxiv.org/pdf/2503.20314#page=11)

## DiT为何采用全时空建模与独立文本交叉注意力

VAE latent再通过核为 $(1,2,2)$ 的3D patchifying卷积，得到序列长度

$$
L=(1+T/4)\frac H{16}\frac W{16}.
$$

这个式子显示长视频、高分辨率为何迅速变贵。时间和两个空间维度都增加token，全时空self-attention的成对交互随 $L^2$ 增长。文字则由umT5编码成512 tokens，通过cross-attention进入DiT，不必与视频token争用同一种输入表示。

架构图应从VAE压缩、文本编码、时间条件三条输入读到DiT，再看预测latent如何解码。文字负责指定内容，时间条件负责说明当前噪声阶段，二者不能互相替代。

![Wan DiT architecture](../../assets/images/paper-deep-dives/diffusion/wan/figure-4-dit.png){ width="920" }

<small>图源：`Wan: Open and Advanced Large-Scale Video Generative Models`，Figure 9。</small>

时间调制MLP预测六组调制参数，在不同Transformer block间共享，每个block保留独立bias。这减少了约25%的参数开销，让相同参数预算可以增加主干深度。报告专门比较了完整共享、部分共享与不共享的adaLN设置，而非仅凭参数量决定使用哪个结构。[原论文，第14页](https://arxiv.org/pdf/2503.20314#page=14)

## 流匹配的时间方向与分阶段训练

报告的符号中 $x_0$ 是高斯噪声，$x_1$ 是数据latent，训练时构造

$$
x_t=t x_1+(1-t)x_0,\qquad v_t=x_1-x_0,
$$

$$
\mathcal L=\mathbb E_{x_0,x_1,c,t}\|u_\theta(x_t,c,t)-v_t\|_2^2.
$$

$t$ 从logit-normal分布采样，网络预测噪声到数据的速度。每个训练例可以直接插值得到任意 $x_t$；推理仍须用数值积分器多次求值，学习flow-matching目标本身不会自动带来一步采样。这里的 $t=1$ 是数据端，与部分推理代码或后续README“时间步越大噪声越大”的约定不同，引用时不能直接混用。[原论文，第14—15页，式1—3](https://arxiv.org/pdf/2503.20314#page=14)

14B模型先做256px图像预训练，再转向图像视频联合训练。原因具体而实际：直接处理81帧、1280×720视频会显著降低单位GPU-hour的数据吞吐，也因显存压缩batch导致梯度方差和训练不稳定。课程先训练256px图像与192px、16fps、5秒视频，再将图像视频提升至480px，最后到720px，视频时长保持5秒。后训练使用更高质量视频，在480px和720px联合微调。

基础配置为BF16混合精度与AdamW，weight decay为 $10^{-3}$，初始学习率 $10^{-4}$，依据FID与CLIP Score平台期降低。VAE和文本编码器冻结，优化主要集中在DiT。这个配置说明“模型变强”既包含空间语义预训练，也包含视频课程与数据后训练，不能把所有提升归因于14B参数规模。

## 并行训练处理的是序列、参数和重复计算三种瓶颈

报告将DiT主要计算写成

$$
C\approx L_{\mathrm{depth}}\left(\alpha bsh^2+\beta bs^2h\right),
$$

$b$ 是micro-batch，$s$ 是序列长，$h$ 是隐藏宽度。第一项来自线性层，第二项来自attention。随着视频token增长，attention会成为主导。文中的百万token、超过8TB激活分析是极长序列场景，用来说明系统瓶颈，不是所有5秒生成都固定使用这个长度。[原论文，第15—17页](https://arxiv.org/pdf/2503.20314#page=15)

作者用FSDP切分参数、梯度和优化器状态，用2D context parallelism切分长序列。内层Ulysses适合高速互联范围内的交换，外层Ring将跨机器通信与计算重叠。256K序列、两机16GPU的例子中，通信开销由单用Ulysses的超过10%降至低于1%。

并行图的组是相交的，不能把图上的所有数字直接相乘。128GPU例子中CP为16，由Ulysses8与Ring2组成；FSDP为32，外部DP为4，全局batch是micro-batch的8倍。

![Wan DiT parallelism](../../assets/images/paper-deep-dives/diffusion/wan/figure-5-parallel.png){ width="820" }

<small>图源：`Wan: Open and Advanced Large-Scale Video Generative Models`，Figure 11。</small>

还有一个跨模块问题。DiT的CP组需要共享同一视频，但VAE和文本编码器若也让组内所有设备处理相同输入，会重复计算。Wan先让组内设备处理不同数据，再依次broadcast进入DiT，使这些前置模块在每轮中的摊销比例降至原来的 $1/\mathrm{CP}$。这项收益来自合理调度，不是编码器本身被加速同样倍数。

显存优化则结合activation offloading与gradient checkpointing。长序列下计算量增长快于激活体积，部分CPU传输能与1—3个DiT层计算重叠，因而offload有机会比大量重计算更合适；CPU内存同样有限，所以作者仍对高显存／计算比的层使用checkpoint。硬件带宽、序列长度和层选择共同决定收益。

## 推理提速必须保持各项收益的测量范围

基础视频生成一般需要约50次采样步骤，报告分别优化跨卡并行、跨步冗余和低精度计算。attention cache复用相邻采样步的注意力结果；CFG cache利用后期条件与无条件分支相似性，配合残差补偿，Wan14B T2V报告1.62倍推理提速。缓存步由验证集选择，这不是任意提示与任意步数下严格无损的数学保证。[原论文，第17—19页](https://arxiv.org/pdf/2503.20314#page=17)

FP8 GEMM采用权重per-tensor、激活per-token量化，算子层面约两倍性能转化为DiT模块1.13倍加速。attention则没有直接照搬原生FP8：报告对 $QK^\top$ 与 $PV$ 使用混合8-bit策略，并在跨block累加中保留FP32，缓解长序列数值误差。其8-bit FlashAttention报告超过1.27倍效率提升，H20上的95% MFU是该内核口径，不能写成端到端视频服务利用率。

这些加速数字来自不同优化层级，直接相乘并不能得到已经测量的总收益。部署时还需计入文本编码、VAE解码、专家或参数换入、以及多卡通信。

## 评测证明了综合能力，也暴露了分项差距

Wan-Bench含动态质量、画面质量、指令跟随三类共14个指标。RAFT用于运动和部分镜头分析，DINO用于身份一致性，Qwen2-VL判断复杂动作、空间关系与物理合理性，画面质量结合多个预测器。超过5000组成对人工比较用于确定维度权重，主对比每模型生成1035个样本。因此它是一套经过人类偏好校准的自动评测，物理合理性分数仍是视觉模型代理判断。[原论文，第20—22页](https://arxiv.org/pdf/2503.20314#page=20)

| Wan-Bench metric | Hunyuan | Sora | Wan 1.3B | Wan 14B |
| --- | ---: | ---: | ---: | ---: |
| Large Motion Generation | 0.413 | 0.482 | 0.468 | 0.415 |
| ID Consistency | 0.935 | 0.925 | 0.938 | 0.946 |
| Physical Plausibility | 0.898 | 0.933 | 0.912 | 0.939 |
| Stylization Ability | 0.386 | 0.606 | 0.430 | 0.328 |
| Spatial Position Accuracy | 0.464 | 0.458 | 0.476 | 0.590 |
| Weighted Score | 0.673 | 0.700 | 0.689 | 0.724 |

14B综合分最高，身份一致性和空间位置也有优势，但大幅运动低于Sora和自身1.3B，风格化甚至低于表中多个模型。模型规模改变了能力组合，不能从综合分推导每项都增强。

公开VBench的表格又采用另一套维度与权重。报告列出的版本中，Wan14B质量86.67%、语义84.44%、总分86.22%；1.3B总分83.96%；Sora84.28%、Hunyuan83.24%。这些是报告时点与所列版本的成绩，不应作为持续更新榜单的当前排名。[原论文，第24页，Table 4](https://arxiv.org/pdf/2503.20314#page=24)

架构消融主要在1.3B级、图像预训练阶段完成。相同约1.5B参数时，共享adaLN并增加深度的35层模型，比把参数花在不共享调制MLP上收敛更好；不共享的1.7B也未胜出。文本编码器消融中umT5胜过所测decoder-only方案，即使后者加入双向refiner；Qwen-VL倒数第二层FID42.91与umT5的43.01接近，但模型更大。这些证据支持该训练体系内的结构选择，未单独测量每个选择对最终视频综合分的贡献。[原论文，第24—26页](https://arxiv.org/pdf/2503.20314#page=24)

## 条件接口怎样从首帧扩展到编辑和声音

I2V把首帧与其余零帧一起经VAE编码，得到condition latent，再附加显式mask，标识保留和待生成帧。噪声latent、condition latent与重排mask沿通道拼接；latent通道 $c=16$、时间stride $s=4$ 时输入为 $2c+s=36$ 通道。新增投影以零初始化承接T2V权重，CLIP图像特征经过MLP后通过解耦cross-attention提供全局视觉条件。[原论文，第26—27页](https://arxiv.org/pdf/2503.20314#page=26)

下图中mask是任务接口的核心。改变已知帧位置，就能在同一预训练框架里覆盖首帧生成、续写、首尾帧过渡与随机插帧，再分别微调。数据筛选也随任务调整：首帧生成偏好首帧与后续内容相近的视频，首尾过渡则需要更明显的变化。

![Wan-I2V framework](../../assets/images/paper-deep-dives/diffusion/wan/figure-6-i2v.png){ width="920" }

<small>图源：`Wan: Open and Advanced Large-Scale Video Generative Models`，Figure 18。</small>

编辑扩展VACE使用文本、帧序列、mask组成的Video Condition Unit。它把待编辑与保留部分分为 $F_c=F\odot M$ 和 $F_k=F\odot(1-M)$，分别编码后组织成context tokens。这里mask中1表示待编辑，与前面I2V的“1表示保留帧”口径不同，不能在实现中不加区分地复用。

![Wan video editing framework](../../assets/images/paper-deep-dives/diffusion/wan/figure-editing.png){ width="920" }

<small>图源：`Wan: Open and Advanced Large-Scale Video Generative Models`，Figure 21。</small>

图中两种训练路径分别是全量微调Wan，以及增加可插拔Context Adapter、冻结底座。前者改变主模型，后者保留主权重但增加参数与推理模块。共同价值是把局部编辑、扩图、姿态和深度条件写进统一输入接口。[原论文，第31—33页](https://arxiv.org/pdf/2503.20314#page=31)

V2A又是单独的音频生成分支。它在原始波形上训练1D-VAE，使latent时间轴显式保留；逐帧CLIP视觉特征通过重复适配到音频时间率，再投影并与音频特征相加，umT5提供文字控制。图中应重点看Temporal Alignment，而不是把视频VAE与音频VAE当成同一个编码器。

![Wan V2A framework](../../assets/images/paper-deep-dives/diffusion/wan/figure-7-v2a.png){ width="920" }

<small>图源：`Wan: Open and Advanced Large-Scale Video Generative Models`，Figure 32。</small>

这一分支生成环境声和背景音乐，训练数据明确过滤语音与人声音乐，不能据此推断报告中的模型已经支持配音、说话口型或音频驱动视频。后来的S2V属于另外的任务发布。[原论文，第44—45页](https://arxiv.org/pdf/2503.20314#page=44)

## Wan2.2补充：按噪声阶段分工，与高压缩5B路线

以下四张图和相应机制来自[Wan2.2官方README](https://github.com/Wan-Video/Wan2.2#introduction-of-wan22)，属于2.1报告之后的官方技术补充。A14B系列与TI2V-5B是两条不同路线，不能把MoE与5B高压缩结构合成一个模型。

A14B按去噪阶段切换两个约14B专家，高噪声专家负责初期整体布局，低噪声专家负责后期细节。官方给出约27B总参数、每步14B激活参数。它的稀疏性发生在整个去噪阶段的模型选择上，不是每个token在同一层选择不同FFN专家。

![Wan2.2 MoE architecture](../../assets/images/paper-deep-dives/diffusion/wan/wan22-moe-arch.png){ width="920" }

<small>图源：`Wan-Video/Wan2.2` 官方 README，`assets/moe_arch.png`。</small>

这能增加整体容量而维持单步主计算量，但两套权重的存储、驻留和换入仍取决于部署策略，不能只用激活参数估算整机内存。官方按噪声／SNR阶段划分专家，README的时间步方向也与2.1正文中数据端 $t=1$ 的写法不同。

![Wan2.2 MoE SNR switch](../../assets/images/paper-deep-dives/diffusion/wan/wan22-moe-snr.png){ width="920" }

<small>图源：`Wan-Video/Wan2.2` 官方 README，`assets/moe_2.png`。</small>

图中的验证曲线比较Wan2.1、只替换高噪声专家、只替换低噪声专家和完整双专家。完整版本loss最低，支持两阶段专门化在该设置下有效。验证loss是训练目标上的证据，不等价于证明所有类型视频的分布距离或人类偏好都最优。

TI2V-5B则使用dense5B模型，统一文生视频与图生视频。其VAE时间／空间压缩为 $4\times16\times16$，加入patchification后，进入DiT的token网格相当于 $4\times32\times32$ 的采样间隔。这个几何压缩率与包含latent通道后的总元素压缩率不是同一概念。

![Wan2.2 high-compression VAE](../../assets/images/paper-deep-dives/diffusion/wan/wan22-vae.png){ width="920" }

<small>图源：`Wan-Video/Wan2.2` 官方 README，`assets/vae.png`。</small>

官方支持720P、24fps输出；5B命令使用1280×704或704×1280，开启model offload、dtype转换与T5 CPU选项后可在24GB显存设备运行。24fps是生成视频的播放帧率，README同时说明单消费级GPU生成5秒720P视频需不到9分钟，显然不能将它写成24fps实时生成。A14B的单卡示例则要求至少80GB显存，这与2.1的1.3B门槛完全不同。

2.2还扩大图像和视频数据，并加强光照、构图、对比度、色调等美学标注。官方性能图使用Wan-Bench2.0及对应商业模型版本，应在该评价口径内理解。

![Wan2.2 performance comparison](../../assets/images/paper-deep-dives/diffusion/wan/wan22-performance.png){ width="920" }

<small>图源：`Wan-Video/Wan2.2` 官方 README，`assets/performance.png`。</small>

Wan最适合作为后续研究的完整底座阅读。VAE与patch接口决定可处理的token量，文本和mask接口决定怎样加条件，数据课程决定能力范围，并行与缓存决定能够承担的计算量。少步蒸馏、流式改造或量化可以在这些接口上继续推进，但每次改动都应重新检查运动、指令和细节是否保持，不能只继承原底座的一组综合分。
