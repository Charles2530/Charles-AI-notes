---
paper_date: 2025-10
paper_title: "Phased DMD: Few-step Distribution Matching Distillation via Score Matching within Subintervals"
paper_topic: 扩散模型
---

# Phased DMD：分阶段少步蒸馏

!!! info "论文信息"
    **论文题名：** Phased DMD: Few-step Distribution Matching Distillation via Score Matching within Subintervals。<br>
    **作者：** Xiangyu Fan、Zesong Qiu、Zhuguanyu Wu、Fanzhou Wang、Zhiqian Lin、Tianxiang Ren、Dahua Lin、Ruihao Gong、Lei Yang。<br>
    **机构：** SenseTime Research, 2 Beihang University。<br>
    **时间 / 主题：** 2025-10；扩散模型。<br>
    **arXiv / 官方报告：** arXiv：[2510.27684](https://arxiv.org/abs/2510.27684)；官方材料：[x-niper.github.io/projects/Phased-DMD/](https://x-niper.github.io/projects/Phased-DMD/)。<br>
    **GitHub / 项目：** GitHub：[github.com/ModelTC/LightX2V-Wan2.2-Lightning](https://github.com/ModelTC/LightX2V-Wan2.2-Lightning)；项目页：[x-niper.github.io/projects/Phased-DMD/](https://x-niper.github.io/projects/Phased-DMD/)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2510.27684)；[GitHub API / repo](https://github.com/ModelTC/LightX2V-Wan2.2-Lightning)；[官方 / 项目材料](https://x-niper.github.io/projects/Phased-DMD/)；Checked Date：2026-06-04；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 少步蒸馏为什么会学成一步任务

Phased DMD 针对大规模图像、视频模型中的一个训练折中。完整地对四步生成过程反向传播，会增加激活内存与优化难度；DMD2 风格的 stochastic gradient truncation strategy（SGTS）只对随机选中的一步保留梯度，但这一步被要求直接到干净端点。抽到第一步时，训练事实上变成从纯噪声一步生成干净样本。

论文观察到，这种压力会牺牲多样性和视频运动。Phased DMD 保留真正的中间终点，让低信噪比阶段先形成构图和运动，再由高信噪比阶段完善纹理。关键技术不是简单增加专家，而是让没有干净图像的中间阶段仍能进行正确的分布匹配。[↗](https://arxiv.org/pdf/2510.27684#page=5)

下图先看每个阶段箭头落在哪里，再看哪些网络需要梯度。中间专家的目标是下一个噪声分布；后一阶段训练时，前面的专家固定。原文还把分阶段与阶段内部 SGTS 结合，构成四步、两阶段方案。

![Phased DMD schematic](../../assets/images/paper-deep-dives/diffusion/phased-dmd/phased-diagram.png){ width="820" }

<small>图源：`Phased DMD`，Figure 1。</small>

## 中间分布需要自己的加噪公式

考虑正向扩散

$$
p(x_t\mid x_0)=\mathcal N(\alpha_t x_0,\sigma_t^2I).
$$

若手里只有 $s>0$ 时的中间状态 $x_s$，不能把它直接当干净 $x_0$ 代入同一公式。利用 Markov 性，正确的转移为

$$
p(x_t\mid x_s)=\mathcal N(\alpha_{t\mid s}x_s,\sigma_{t\mid s}^2I),
\quad
\alpha_{t\mid s}=\frac{\alpha_t}{\alpha_s},
\quad
\sigma_{t\mid s}^2=\sigma_t^2-\alpha_{t\mid s}^2\sigma_s^2.
$$

这里 $s<t$，即从较干净的中间状态重新加噪。第 $k$ 个生成专家把 $p(x_{t_{k-1}})$ 映射到 $p(x_{t_k})$，训练时从这个输出继续加噪到 $t>t_k$，再比较教师与 fake score。这样分布约束作用在真正的阶段终点，而无需让每个专家都输出干净图像。[↗](https://arxiv.org/pdf/2510.27684#page=3)

每阶段只训练一个生成专家，fake score 从教师重新初始化。noise timestep 的采样区间采用 $(t_k,1)$，不是仅限于当前相邻区间 $(t_k,t_{k-1})$。下图先看这些区间如何反向嵌套，再理解后期仍能用更高噪声比较分布的原因——新阶段初期，生成分布仍可能远离教师分布，足够的加噪能让比较更稳定。

![Timestep intervals](../../assets/images/paper-deep-dives/diffusion/phased-dmd/timestep-intervals.png){ width="570" }

<small>图源：`Phased DMD`，Figure 9。</small>

## 子区间训练最容易出错的是预测目标

DMD 梯度成立需要两个 score 的尺度与偏置对应。如果教师以全区间 flow matching 训练，fake 网络却把 $x_s$ 当干净样本、直接回归 $\epsilon-x_s$，两者输出已不再表示同一坐标体系的分数；相减就会带系统性偏差。

原文 Eq. 11 对 velocity 网络 $\psi$ 给出子区间目标

$$
\mathbb E\left\|
\psi(x_t,t)-
\left(
\frac{\alpha_s^2\sigma_t+\alpha_t\sigma_s^2}
{\alpha_s^2\sigma_{t\mid s}}\epsilon
-\frac{x_s}{\alpha_s}
\right)\right\|^2,
$$

其中 $x_t=\alpha_{t\mid s}x_s+\sigma_{t\mid s}\epsilon$，$t\in(s,1)$。修正项补偿了中间样本自身已经含有的噪声，使 fake 网络仍与全区间教师的分数表示相容。对 $x$-prediction，原文 Eq. 12 的目标则是

$$
\frac{x_s}{\alpha_s}
-\frac{\alpha_t\sigma_s^2}{\alpha_s^2\sigma_{t\mid s}}\epsilon.
$$

当 $t\to s$，$\sigma_{t\mid s}\to0$，直接求上述比值会数值不稳。作者把 $\sigma_{t\mid s}$ 乘进残差，再将外部 $1/\sigma_{t\mid s}^2$ 权重限制在 $[0,10]$。这会改变接近区间边界时的数值权重，但保住有限精度训练的可行性。[↗](https://arxiv.org/pdf/2510.27684#page=6)

一维实验专门检验目标是否正确。数据只取 $\{-1,0,1,2\}$，模型为四层、隐藏宽度 512 的 MLP；全区间目标、正确子区间目标、错误的 $\epsilon-x_s$ 目标分别训练，再用 100 步 Euler 画轨迹。正确子区间模型在重叠区间接近全区间模型，错误目标产生偏移。这项实验验证的是公式和参数化一致性，不直接等价于视频质量证明。

下图从左到右分别是完整区间、正确子区间和错误子区间的轨迹。重点看中间图与左图在共同区间里的方向是否一致，以及右图的终点如何偏离四个目标位置。

<table>
  <tr>
    <th>Full interval objective</th>
    <th>Correct subinterval objective</th>
    <th>Incorrect subinterval target</th>
  </tr>
  <tr>
    <td><img src="../../../assets/images/paper-deep-dives/diffusion/phased-dmd/toy-flow-full.png" alt="Full interval objective" /></td>
    <td><img src="../../../assets/images/paper-deep-dives/diffusion/phased-dmd/toy-flow-unbiased.png" alt="Correct subinterval objective" /></td>
    <td><img src="../../../assets/images/paper-deep-dives/diffusion/phased-dmd/toy-flow-biased.png" alt="Incorrect subinterval target" /></td>
  </tr>
</table>

<small>图源：`Phased DMD`，Figure 2。</small>

## 训练规模与专家分工

主要实验使用 64 张 GPU、batch size 64、FSDP、gradient checkpointing，视频另用 context parallelism。fake score 全参数训练，学习率 $4\times10^{-7}$；生成器以 rank 64、$\alpha=8$ 的 LoRA 更新，学习率 $5\times10^{-5}$。AdamW 的 $\beta_1=0,\beta_2=0.999$，fake score 与生成器更新比仍为 5:1。

四步两阶段方案对应两个专家。Wan 日程为 $1000,938,833,625$，Qwen-Image 为 $1000,900,750,500$，backward simulation 使用 Euler。Wan2.2 本来已有两个专家，因此它与 DMD2 的比较能维持相同专家数量，更有助于区分分阶段训练机制和单纯参数增加的作用。四步四阶段能进一步改善部分结果，但也增加系统复杂度与参数，不能和两阶段结果当成同预算比较。[↗](https://arxiv.org/pdf/2510.27684#page=7)

## 视频实验关心的是运动有没有被蒸馏掉

T2V 使用 220 条提示，I2V 使用 220 组图片—提示，每条固定 seed 42 生成一个视频。教师为 40 步、CFG 4，蒸馏模型为四步、CFG 1。Table 2 中 FID/FVD 的参考分布是教师生成视频，所以教师一行为零；这不是教师在真实视频数据上的 FID/FVD 为零。

| Method | T2V OF ↑ | T2V DD ↑ | T2V FID ↓ | T2V FVD ↓ | I2V OF ↑ | I2V FVD ↓ |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Base model | 10.26 | 79.55% | 0.0 | 0.0 | 9.32 | 0.0 |
| DMD2 | 3.23 | 65.45% | 55.70 | 763.1 | 7.87 | 370.0 |
| Phased DMD | 9.30 | 82.27% | 47.24 | 700.9 | 9.84 | 334.7 |

OF 是 UniMatch 计算的平均绝对光流，DD 是 VBench dynamic degree。T2V 光流从 DMD2 的 3.23 提升到 9.30，更接近教师 10.26；FID/FVD 同时下降，支持运动恢复并非仅靠引入杂乱变化。I2V 的改进较小，提示初始图像已提供结构约束后，问题严重程度不同。[↗](https://arxiv.org/pdf/2510.27684#page=9)

论文也报告了一个很有用的反例。部分 VBench 美学、平滑和一致性指标反而给 DMD2 更高分，作者的视频比较却认为它运动弱、镜头容易变成特写。因而这里应把运动幅度、镜头遵循和一般视觉指标分开分析；“更平滑”可能来自更少运动，并不自动代表更好视频。

两组视频预览分别观察跑酷动作幅度和跟随镜头。每行依次为教师、DMD2与Phased DMD；前一组看主体移动距离，后一组看镜头是否退化成缺少视角变化的近景。它们解释了光流统计所捕捉的现象，但少量截图不能替代完整视频的时间一致性检查。

<table>
  <tr>
    <th>Base</th>
    <th>DMD2</th>
    <th>Phased DMD</th>
  </tr>
  <tr>
    <td><img src="../../../assets/images/paper-deep-dives/diffusion/phased-dmd/video-speed-base.jpg" alt="Video speed base" /></td>
    <td><img src="../../../assets/images/paper-deep-dives/diffusion/phased-dmd/video-speed-dmd2.jpg" alt="Video speed DMD2" /></td>
    <td><img src="../../../assets/images/paper-deep-dives/diffusion/phased-dmd/video-speed-phased-dmd.jpg" alt="Video speed Phased DMD" /></td>
  </tr>
</table>

<small>图源：`Phased DMD`，Figure 4。</small>

<table>
  <tr>
    <th>Base</th>
    <th>DMD2</th>
    <th>Phased DMD</th>
  </tr>
  <tr>
    <td><img src="../../../assets/images/paper-deep-dives/diffusion/phased-dmd/camera-base.jpg" alt="Camera base" /></td>
    <td><img src="../../../assets/images/paper-deep-dives/diffusion/phased-dmd/camera-dmd2.jpg" alt="Camera DMD2" /></td>
    <td><img src="../../../assets/images/paper-deep-dives/diffusion/phased-dmd/camera-phased-dmd.jpg" alt="Camera Phased DMD" /></td>
  </tr>
</table>

<small>图源：`Phased DMD`，Figure 5。</small>

## 图像多样性结果并非处处一致

图像评估使用 21 条简短提示，每条八个随机种子。DINOv3 特征平均两两余弦相似度越低，LPIPS 平均距离越高，代表该协议下更强的变化。

| Method | Wan2.1 DINOv3 ↓ | Wan2.1 LPIPS ↑ | Wan2.2 DINOv3 ↓ | Wan2.2 LPIPS ↑ | Qwen DINOv3 ↓ | Qwen LPIPS ↑ |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Base model | 0.708 | 0.607 | 0.732 | 0.531 | 0.907 | 0.483 |
| DMD2 | 0.826 | 0.521 | 0.828 | 0.447 | 0.941 | 0.309 |
| Phased DMD | 0.782 | 0.544 | 0.768 | 0.481 | 0.958 | 0.322 |

Wan 两组指标一致支持多样性更接近教师；Qwen 的 LPIPS 略升，但 DINOv3 相似度也升到 0.958，方向并不一致。不能把摘要中的“preserves diversity”写成所有模型所有指标都改善。Qwen 文本渲染示例承担的是能力保留的定性证据，与多样性指标回答不同问题。[↗](https://arxiv.org/pdf/2510.27684#page=10)

下面的Qwen-Image样例把注意力放在文字笔画、画面构成与复杂对象上。它们显示四步模型仍能产生这些内容，不能单独量化相对教师的能力保持率。

<table>
  <tr>
    <td><img src="../../../assets/images/paper-deep-dives/diffusion/phased-dmd/qwen-image-1.jpg" alt="Qwen Image example 1" /></td>
    <td><img src="../../../assets/images/paper-deep-dives/diffusion/phased-dmd/qwen-image-2.jpg" alt="Qwen Image example 2" /></td>
    <td><img src="../../../assets/images/paper-deep-dives/diffusion/phased-dmd/qwen-image-3.jpg" alt="Qwen Image example 3" /></td>
    <td><img src="../../../assets/images/paper-deep-dives/diffusion/phased-dmd/qwen-image-4.jpg" alt="Qwen Image example 4" /></td>
  </tr>
</table>

<small>图源：`Phased DMD`，Figure 7。</small>

## 哪些噪声区间提供稳定的训练信号

附录比较只用低SNR专家与加入高SNR专家后的输出。先看整体形状和运动是否已确定，再看后者补上的纹理和边缘，这比把两专家分别笼统叫作“粗”和“细”更具体。

<table>
  <tr>
    <th>low-SNR only</th>
    <th>low-SNR + high-SNR</th>
  </tr>
  <tr>
    <td><img src="../../../assets/images/paper-deep-dives/diffusion/phased-dmd/low-snr-only.jpg" alt="Low SNR only" /></td>
    <td><img src="../../../assets/images/paper-deep-dives/diffusion/phased-dmd/low-plus-high-snr.jpg" alt="Low SNR plus high SNR" /></td>
  </tr>
</table>

<small>图源：`Phased DMD`，Figure 12。</small>

另一组图比较互不重叠的训练区间与反向嵌套区间。后者允许每个阶段继续在较高噪声处比较分布，样例中脸部结构与色调更正常。这里的解释是训练初期生成与真实分布重叠不足时，较高噪声能改善score比较的可靠性。

<table>
  <tr>
    <th>Disjoint Intervals</th>
    <th>Reverse Nested Intervals</th>
  </tr>
  <tr>
    <td><img src="../../../assets/images/paper-deep-dives/diffusion/phased-dmd/disjoint-intervals.jpg" alt="Disjoint intervals" /></td>
    <td><img src="../../../assets/images/paper-deep-dives/diffusion/phased-dmd/reverse-nested-intervals.jpg" alt="Reverse nested intervals" /></td>
  </tr>
</table>

<small>图源：`Phased DMD`，Figure 10。</small>

固定加噪时间的消融进一步展示这一点。左图仅用$t=0.357$，右图仅用$t=0.882$；在该Wan2.1 T2I设置中，较低噪声训练失败，较高噪声能得到正常结果。这是特定教师与初始化下的稳定性证据，并不意味着所有DMD任务都应删除低噪声监督。

<table>
  <tr>
    <th>t = 0.357</th>
    <th>t = 0.882</th>
  </tr>
  <tr>
    <td><img src="../../../assets/images/paper-deep-dives/diffusion/phased-dmd/fixed-timestep-0357.jpg" alt="Fixed timestep 0.357" /></td>
    <td><img src="../../../assets/images/paper-deep-dives/diffusion/phased-dmd/fixed-timestep-0882.jpg" alt="Fixed timestep 0.882" /></td>
  </tr>
</table>

<small>图源：`Phased DMD`，Figure 11。</small>

低 SNR 专家固定后，延长高 SNR 专家训练主要改善光照与纹理而较少改变布局。这是阶段分工的实用价值。若目标是在数步视频生成中保留运动和镜头变化，可以把分阶段终点和正确的子区间 score 目标作为一个整体采用；只切分时间、仍用错误的干净样本目标，会丢掉论文最重要的理论条件。
