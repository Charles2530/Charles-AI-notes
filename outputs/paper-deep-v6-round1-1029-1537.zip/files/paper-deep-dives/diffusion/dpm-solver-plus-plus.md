---
paper_date: 2022-11
paper_title: "DPM-Solver++: Fast Solver for Guided Sampling of Diffusion Probabilistic Models"
paper_topic: 扩散模型
---

# DPM-Solver++：为 Guidance 场景设计的扩散 ODE 求解器

!!! info "论文信息"
    **论文题名：** DPM-Solver++: Fast Solver for Guided Sampling of Diffusion Probabilistic Models。<br>
    **作者：** Cheng Lu、Yuhao Zhou、Fan Bao、Jianfei Chen、Chongxuan Li、Jun Zhu。<br>
    **机构：** 未在公开元数据中稳定解析；以 arXiv/PDF 或官方页 affiliation block 为准。<br>
    **时间 / 主题：** 2022-11；扩散模型。<br>
    **arXiv / 官方报告：** arXiv：[2211.01095](https://arxiv.org/abs/2211.01095)。<br>
    **GitHub / 项目：** GitHub：[github.com/LuChengTHU/dpm-solver](https://github.com/LuChengTHU/dpm-solver)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2211.01095)；[GitHub API / repo](https://github.com/LuChengTHU/dpm-solver)；Checked Date：2026-06-04；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 引导强度改变了求解器面对的问题

DPM-Solver++ 解决的是无需再训练模型的引导采样加速。较高阶的求解器在无条件生成中很好用，但把 classifier guidance 或 classifier-free guidance 开大后，少步结果可能比一阶 DDIM 更差。论文把问题分成两层。引导放大网络输出及其导数，使高阶近似需要更小步长；像素预测还可能越出训练图像的取值范围，即使积分已经收敛也会过饱和。[↗](https://arxiv.org/pdf/2211.01095#page=5)

下面固定 ImageNet 256×256、guidance 8、15 次函数评估，应横向看不同求解器，而非把阶数当作质量排序。高阶方法的失败说明，阶数是步长趋近于零时的性质，实际只有十几次网络调用时还要考虑稳定性。

![Guided sampling instability 原论文图](../../assets/images/paper-deep-dives/diffusion/dpm-solver-plus-plus/figure-1-guided-instability.png){ width="670" }

<small>图源：[DPM-Solver++](https://arxiv.org/abs/2211.01095)，Figure 1。</small>

论文给出的改动是转向干净数据预测参数化、利用历史预测构成二阶多步法，并在有界像素空间中支持 dynamic thresholding。它保留原模型权重，改变每次网络输出怎样被用于更新状态。

## 同一个 ODE，为何换参数化会改变数值效果

正向扰动写作 $x_t=\alpha_t x_0+\sigma_t\epsilon$。一个噪声预测网络可直接转换成数据预测

$$
x_\theta(x_t,t)=\frac{x_t-\sigma_t\epsilon_\theta(x_t,t)}{\alpha_t}.
$$

因此不需要把原网络重新训练成另一种输出目标。论文用 $\lambda_t=\log(\alpha_t/\sigma_t)$ 作为积分变量，它是信噪比平方根的对数。采样时 $t$ 从大到小，$\lambda$ 从小到大。

以数据预测表示时，原文 Proposition 4.1 的精确解为

$$
x_t=\frac{\sigma_t}{\sigma_s}x_s
+\sigma_t\int_{\lambda_s}^{\lambda_t}
 e^\lambda\hat x_\theta(\hat x_\lambda,\lambda)\,d\lambda,
\qquad t<s.
$$

帽号表示将时间坐标换成 $\lambda$。前一项可精确计算；求解器只需近似指数加权的网络输出积分。与 DPM-Solver 的噪声预测积分相比，连续方程等价，但数值算法分别精确处理了不同线性项、近似了不同函数，高阶截断误差因而不同。不能由“预测可相互转换”推出两个求解器的少步输出相同。[↗](https://arxiv.org/pdf/2211.01095#page=6)

对 $\hat x_\theta$ 作 Taylor 展开后，指数与多项式乘积的积分可以解析计算，剩余困难集中在估计沿轨迹的导数。一阶近似退化为 DDIM；二阶需要额外的一阶变化信息。

## 2S 与 2M 交换的是网络调用和历史信息

2S 是二阶单步法，每次大步内另取中间点，用两次网络调用估计变化。2M 是二阶多步法，缓存前一次预测，用历史值与当前值估计变化。这里的 “multistep” 是数值方法术语，指一次更新使用多个历史状态，并不是“生成过程用了多步”这个泛称。

下图左右算法可先比较 $D_i$ 的来源。左侧使用本步新算的中间状态，右侧使用缓存中的历史输出。

![DPM-Solver++ algorithms 原论文图](../../assets/images/paper-deep-dives/diffusion/dpm-solver-plus-plus/algorithms-1-2.png){ width="670" }

<small>图源：[DPM-Solver++](https://arxiv.org/abs/2211.01095)，Algorithm 1/2。</small>

令 $h_i=\lambda_{t_i}-\lambda_{t_{i-1}}$，$r_i=h_{i-1}/h_i$。2M 的核心更新为

$$
D_i=\left(1+\frac{1}{2r_i}\right)x_\theta(\tilde x_{t_{i-1}},t_{i-1})
-\frac{1}{2r_i}x_\theta(\tilde x_{t_{i-2}},t_{i-2}),
$$

$$
\tilde x_{t_i}
=\frac{\sigma_{t_i}}{\sigma_{t_{i-1}}}\tilde x_{t_{i-1}}
-\alpha_{t_i}(e^{-h_i}-1)D_i.
$$

$\tilde x$ 是数值近似状态。首步没有足够历史，用一阶更新启动。后续每步只需新增一次预测；同一 NFE 预算下，2M 能走更多、更短的时间间隔。这解释了它在强引导时的优势，也解释了为什么优势不只来自“二阶”两个字。

thresholding 则解决另一件事。像素图像训练值有界，预测越界时可裁剪或缩放数据预测。它会改变实际积分的向量场及其收敛解，不只是减少离散误差。潜空间变量没有相同的像素边界，论文的 Stable Diffusion 实验明确不使用 thresholding。[↗](https://arxiv.org/pdf/2211.01095#page=11)

## 把参数化、历史复用与阈值的贡献分开

消融图从左到右分别改变预测参数化、单步或多步、是否 thresholding。应比较相同 NFE 位置，并留意曲线最终收敛高度是否也改变。前两项主要针对少步误差，thresholding 还改变最终样本的范围与视觉表现。

![DPM-Solver++ ablation 原论文图](../../assets/images/paper-deep-dives/diffusion/dpm-solver-plus-plus/figure-3-ablation.png){ width="670" }

<small>图源：[DPM-Solver++](https://arxiv.org/abs/2211.01095)，Figure 3。</small>

原文 Table 3 在 ImageNet 256×256、guidance 8 下的部分结果如下，全部为 10K 样本 FID。

| Sampling Method | Thresholding | NFE 15 | NFE 20 | NFE 25 |
| --- | --- | ---: | ---: | ---: |
| DDIM | No | 11.27 | 10.21 | 9.87 |
| DPM-Solver-2 | No | 44.05 | 20.33 | 9.84 |
| DPM-Solver++(2S) | No | 9.85 | 9.19 | 9.32 |
| DPM-Solver++(2M) | No | 9.46 | 9.10 | 9.11 |
| DDIM | Yes | 9.53 | 9.12 | 8.94 |
| DPM-Solver++(2M) | Yes | 8.64 | 8.50 | 8.39 |

15 NFE 时 DPM-Solver-2 仍明显未收敛，而 ++ 的两种形式已到较好区间；这验证的是强引导少步稳定性。2M 并非在每个预算或 guidance 下都赢，原文也指出较小引导下 2S 可能更好。表中 2S 从 20 到 25 NFE 的 FID 甚至略升，说明生成质量指标不必与步数单调对应。[↗](https://arxiv.org/pdf/2211.01095#page=21)

下面的收敛图前三个面板比较不同 guidance 的像素 FID，第四个面板改为潜空间误差。阅读时必须先换指标，再比较曲线。

![DPM-Solver++ convergence 原论文图](../../assets/images/paper-deep-dives/diffusion/dpm-solver-plus-plus/figure-4-convergence.png){ width="670" }

<small>图源：[DPM-Solver++](https://arxiv.org/abs/2211.01095)，Figure 4。</small>

![ImageNet samples 原论文图](../../assets/images/paper-deep-dives/diffusion/dpm-solver-plus-plus/figure-5-imagenet-samples.png){ width="670" }

<small>图源：[DPM-Solver++](https://arxiv.org/abs/2211.01095)，Figure 5。</small>

ImageNet 样本图把前述数字对应到可见图像，关注相同预算下的主体完整性和过饱和情况。

## 潜空间实验与随机版本补充了什么

Stable Diffusion 的 VAE 解码器能把尚未精确收敛的 latent 变成看起来不错的图像，导致不同求解器在十步时已有接近的 FID。作者因此固定 10K 份初始噪声，比较 latent 输出与高步数 DDIM 参考解的距离。正文将误差定义为 $\|x_0-x_0^*\|_2/\sqrt D$，表中标签写作 MSE；解读时应以实际定义为准。

在 guidance 7.5 下，20 NFE 的表值为 DDIM 0.48、PNDM 0.50、DPM-Solver++(2M) 0.34、DEIS-1 0.34。DPM-Solver++ 与 DEIS 在这组潜空间误差上相近，不能把像素强引导优势扩大成对所有模型的全面优势。论文比较中的时间点统一采用 uniform $t$，也对基线阶数进行了选择。[↗](https://arxiv.org/pdf/2211.01095#page=21)

![Stable Diffusion castle samples 原论文图](../../assets/images/paper-deep-dives/diffusion/dpm-solver-plus-plus/figure-6-stable-diffusion-castle.png){ width="670" }

<small>图源：[DPM-Solver++](https://arxiv.org/abs/2211.01095)，Figure 6。</small>

上图固定城堡提示，可以观察同一种子下布局随求解器和预算的变化。后续版本还推导随机的 SDE-DPM-Solver++，把噪声项纳入更新；DeepFloyd IF 图应在相同 NFE 行内比较随机与确定性算法，随机性改变的是采样过程本身。

![DeepFloyd IF capybara samples 原论文图](../../assets/images/paper-deep-dives/diffusion/dpm-solver-plus-plus/figure-2-deepfloyd-capybara.png){ width="670" }

<small>图源：[DPM-Solver++](https://arxiv.org/abs/2211.01095)，Figure 2。</small>

![DeepFloyd IF samples 原论文图](../../assets/images/paper-deep-dives/diffusion/dpm-solver-plus-plus/figure-7-deepfloyd-lemon.png){ width="670" }

<small>图源：[DPM-Solver++](https://arxiv.org/abs/2211.01095)，Figure 7。</small>

## 实际选用时的三个接口

这篇论文适合已有预训练模型、无法承担再训练、又需要把几十至几百步降到十几步的场景。接入时先确认网络输出如何转成 $x_\theta$，再确认噪声日程与 $\lambda$ 的定义，最后确认数据是否真正有可用于 thresholding 的边界。

它不承诺把任意扩散模型无损压到一步。其可复用认识是，网络参数化、时间坐标和缓存策略共同决定少步误差；高阶理论只有在实际步长、引导强度与数据空间相容时才转化为速度收益。
