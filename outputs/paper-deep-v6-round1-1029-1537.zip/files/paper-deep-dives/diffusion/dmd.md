---
paper_date: 2023-11
paper_title: "One-step Diffusion with Distribution Matching Distillation"
paper_topic: 扩散模型
---

# DMD：一步扩散蒸馏

!!! info "论文信息"
    **论文题名：** One-step Diffusion with Distribution Matching Distillation。<br>
    **作者：** Tianwei Yin、Michaël Gharbi、Richard Zhang、Eli Shechtman、Fredo Durand、William T. Freeman、Taesung Park。<br>
    **机构：** 未在公开元数据中稳定解析；以 arXiv/PDF 或官方页 affiliation block 为准。<br>
    **时间 / 主题：** 2023-11；扩散模型。<br>
    **arXiv / 官方报告：** arXiv：[2311.18828](https://arxiv.org/abs/2311.18828)；官方材料：[tianweiy.github.io/dmd/](https://tianweiy.github.io/dmd/)。<br>
    **GitHub / 项目：** GitHub：未找到官方链接；项目页：[tianweiy.github.io/dmd/](https://tianweiy.github.io/dmd/)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2311.18828)；[官方 / 项目材料](https://tianweiy.github.io/dmd/)；Checked Date：2026-06-04；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 一步生成的难点在于该学什么

DMD 把一个多步扩散模型变成一次前向的生成器。它最有价值的改变是训练信号的组织方式。学生不必为每个噪声种子复刻教师完整的去噪轨迹，而是让一批输出在分布上接近目标图像。教师由此多了一种用法——提供图像分布的梯度，而不只是生成监督图片。[↗](https://arxiv.org/pdf/2311.18828#page=3)

点对点回归并非没有价值。多步教师从噪声 $z$ 生成的图像 $y$ 能告诉学生大致构图，但复杂的噪声到图像映射很难由一步网络精确拟合。只优化这类距离容易得到缺乏细节的图像；只沿教师认为更真实的方向移动，又会把不同种子吸引到少数模式。因此，DMD 把分布匹配作为主目标，把少量预计算的噪声—图像对作为结构正则。

先沿下图左侧的生成器向右看。图像加噪后进入两个去噪器，两者之差回传给生成器；下方另一条路径才是配对回归。部署时只留下左侧生成器，两个分数模型服务于训练。

![DMD overview](../../assets/images/paper-deep-dives/diffusion/dmd/overview.png){ width="920" }

<small>图源：`One-step Diffusion with Distribution Matching Distillation`，Figure 2。</small>

## 两个分数为何能替代不可计算的分布距离

设 $z\sim\mathcal N(0,I)$，一步生成器为 $x=G_\theta(z)$，输出分布为 $p_{\mathrm{fake}}$。目标是减小反向 KL

$$
D_{\mathrm{KL}}(p_{\mathrm{fake}}\Vert p_{\mathrm{real}})
=\mathbb E_{x\sim p_{\mathrm{fake}}}
\left[\log\frac{p_{\mathrm{fake}}(x)}{p_{\mathrm{real}}(x)}\right].
$$

高维图像的密度难以直接计算，但训练只需要它对 $\theta$ 的梯度。原文将梯度表示为

$$
\nabla_\theta D_{\mathrm{KL}}
=\mathbb E_z\left[
\big(s_{\mathrm{fake}}(x)-s_{\mathrm{real}}(x)\big)
\frac{dG_\theta(z)}{d\theta}\right],
\qquad
s(x)=\nabla_x\log p(x).
$$

这里 $s_{\mathrm{real}}$ 指向目标分布密度增大的方向，$s_{\mathrm{fake}}$ 描述当前生成分布自己的密度变化。梯度下降实际上沿 $s_{\mathrm{real}}-s_{\mathrm{fake}}$ 移动输出。减去 fake score 能抵消“生成器自己已经非常集中的位置”带来的吸引，但这不意味着反向 KL 自动保证所有模式都被覆盖。[↗](https://arxiv.org/pdf/2311.18828#page=4)

干净图像附近的真实与生成分布可能几乎不相交，直接估计上述差值很困难。DMD 因而先按扩散过程扰动样本

$$
x_t=\alpha_t x+\sigma_t\epsilon,
\qquad \epsilon\sim\mathcal N(0,I).
$$

$\alpha_t$ 控制信号，$\sigma_t$ 控制噪声。下图应先看加噪前后两种分布的重叠程度；其作用是说明为何在多个噪声尺度上比较比在干净样本上比较更容易，并非质量指标本身。

![DMD diffusion score intuition](../../assets/images/paper-deep-dives/diffusion/dmd/intuition_figure.png){ width="630" .atlas-figure-compact }

<small>图源：`One-step Diffusion with Distribution Matching Distillation`，Figure 4。</small>

对于预测干净图像的去噪器 $\mu$，分数可写为

$$
s(x_t,t)=-\frac{x_t-\alpha_t\mu(x_t,t)}{\sigma_t^2}.
$$

于是冻结的预训练模型 $\mu_{\mathrm{real}}$ 提供 real score；另一个模型 $\mu_{\mathrm{fake}}^\phi$ 用学生当前生成的图像训练，提供 fake score。后者必须在线更新，因为 $G_\theta$ 一变，待估计的分布也跟着变。用一份固定的旧生成样本训练它，无法长期代表当前学生。

实际使用的近似梯度为

$$
\nabla_\theta D_{\mathrm{KL}}
\simeq\mathbb E_{z,t,\epsilon}
\left[w_t\alpha_t\big(s_{\mathrm{fake}}(x_t,t)-s_{\mathrm{real}}(x_t,t)\big)
\frac{dG_\theta(z)}{d\theta}\right].
$$

原文采用 $t\sim U(0.02T,0.98T)$，避免两个极端噪声端点，并用

$$
w_t=\frac{\sigma_t^2}{\alpha_t}
\frac{CS}{\|\mu_{\mathrm{real}}(x_t,t)-x\|_1}
$$

归一化不同噪声尺度的梯度大小。$C$ 为通道数，$S$ 为空间位置数；$CS$ 将求和误差转换为与平均绝对误差相关的量。这一权重并不是额外的生成过程，而是控制某个噪声尺度对一次参数更新的影响。[↗](https://arxiv.org/pdf/2311.18828#page=5)

## 回归正则保住哪些信息

下图把相同初始化分别放进三种优化过程。只用 real score 会集中到最近模式；加入 fake score 后仍可能漏掉另一模式；再加入回归，才恢复两侧覆盖。这是低维示例对优化行为的解释，实际图像上的作用还需要消融检验。

![DMD objective comparison](../../assets/images/paper-deep-dives/diffusion/dmd/matching_sim_figure.png){ width="630" .atlas-figure-compact }

<small>图源：`One-step Diffusion with Distribution Matching Distillation`，Figure 3。</small>

DMD 预先用确定性教师采样器构造 $\mathcal D=\{(z_{\mathrm{ref}},y_{\mathrm{ref}})\}$，加入

$$
\mathcal L_{\mathrm{reg}}
=\mathbb E_{(z_{\mathrm{ref}},y_{\mathrm{ref}})\sim\mathcal D}
\operatorname{LPIPS}\big(G_\theta(z_{\mathrm{ref}}),y_{\mathrm{ref}}\big).
$$

生成器同时接受分布梯度与 $\lambda_{\mathrm{reg}}\mathcal L_{\mathrm{reg}}$ 的梯度，默认 $\lambda_{\mathrm{reg}}=0.25$。fake score 网络则对停止梯度的生成图像做普通去噪学习。生成器和 fake score 都从预训练模型初始化，但两者优化的目标不同。

文本生成还把 classifier-free guidance 纳入 real score 和配对样本的生成过程，使学生学到特定 guidance scale 对应的分布。这里的 guidance 已进入蒸馏目标；不能把一步学生当作仍可任意改变教师引导强度的原始采样器。

## 主结果与消融分别回答什么

ImageNet-64 的主实验检验一步模型是否真正保留分布质量。Table 1 的可比结果如下，FID 越低越好，前向次数是模型调用数。

| Method | # Fwd Pass ↓ | FID ↓ |
| --- | ---: | ---: |
| Consistency Model | 1 | 6.20 |
| Diff-Instruct | 1 | 5.57 |
| DMD | 1 | 2.62 |
| EDM Teacher | 512 | 2.32 |

DMD 与教师相差 0.30 FID，并把 512 次调用减到一次。这个结果支持“大幅减少采样计算而接近教师”，但 512 倍是调用次数之比，不能直接当成包含数据传输等开销的端到端测速。[↗](https://arxiv.org/pdf/2311.18828#page=6)

随后要区分效果究竟来自分布匹配还是回归。Table 2 同时报告两个数据集。

| Training loss | CIFAR-10 FID ↓ | ImageNet-64 FID ↓ |
| --- | ---: | ---: |
| w/o Distribution Matching | 3.82 | 9.21 |
| w/o Regression Loss | 5.58 | 5.61 |
| DMD | 2.66 | 2.62 |

两个损失缺一都会变差，但失败方式不同。下面的 ImageNet 与 CIFAR 消融图应分别看结构真实性和重复模式，而非只数清晰纹理。它们与表格共同表明，回归对这套训练配置有稳定作用，分布匹配负责把回归输出推向更真实的图像分布。

![DMD ablation ImageNet](../../assets/images/paper-deep-dives/diffusion/dmd/imagenet_pdf_crop.png){ width="630" .atlas-figure-compact }

<small>图源：`One-step Diffusion with Distribution Matching Distillation`，Figure 5 上半部分。</small>

![DMD ablation CIFAR](../../assets/images/paper-deep-dives/diffusion/dmd/cifar10_pdf_crop.png){ width="630" .atlas-figure-compact }

<small>图源：`One-step Diffusion with Distribution Matching Distillation`，Figure 5 下半部分。</small>

相同表还把权重 $\sigma_t/\alpha_t$、$\sigma_t^3/\alpha_t$ 与本文归一化权重作比较，CIFAR-10 FID 分别为 3.60、3.71、2.66。因而实际复现不宜只实现 score difference 而忽略时间权重；它改变了优化稳定性。[↗](https://arxiv.org/pdf/2311.18828#page=7)

文本生成结果需要连同 guidance 一起阅读。SD v1.5、COCO-30k、512 分辨率、batch size 1 的低 guidance 实验给出 DMD 11.49 FID、0.09 秒，教师为 8.78 FID、2.59 秒；速度比按 $2.59/0.09$ 计算约为 28.8。该模型采用 guidance 3，并以 LAION-Aesthetics-6.25+ 蒸馏，训练约 36 小时、72 张 A100。训练投入与部署收益属于两个不同的预算。

高 guidance 8 的模型用于更偏视觉质量的比较，DMD 为 14.93 FID、0.320 CLIP，教师为 13.45、0.322；不能将前一模型的 11.49 FID 与这一模型的 CLIP 拼成同一个配置。下图按同一提示横向比较，重点看一步模型能否同时保留主体结构、材质和提示细节。

![DMD qualitative comparison](../../assets/images/paper-deep-dives/diffusion/dmd/gallery2_newest.png){ width="920" }

<small>图源：`One-step Diffusion with Distribution Matching Distillation`，Figure 6。</small>

## 适合采用的方式

DMD 把昂贵的教师计算前移到训练，以一次前向提供交互式预览或高吞吐生成。它还保留一定的种子到构图对应关系，使低延迟预览与多步结果有衔接基础。实际采用需要准备预训练教师、配对采样数据，并在训练时容纳生成器、冻结教师和可训练 fake score；一步推理便宜并不意味着蒸馏训练轻量。

理解这篇论文最关键的接口是“任意可微生成器输出 → 加噪 → 两个分数之差 → 回传到生成器”。后续少步、视频或更复杂条件的蒸馏可以替换生成器与条件形式，但只要 fake score 无法跟上学生分布，这个接口产生的梯度就会有偏。DMD 的回归正则是在当时配置下处理这一问题的具体办法，也是 [DMD2](dmd2.md) 继续改动的环节。
