---
paper_date: 2024-10
paper_title: "Representation Alignment for Generation: Training Diffusion Transformers Is Easier Than You Think"
paper_topic: 扩散模型 / 表征对齐
---

# REPA：把扩散模型隐式学习表征的负担变成显式监督

!!! info "论文信息"
    **论文题名：** Representation Alignment for Generation: Training Diffusion Transformers Is Easier Than You Think。<br>
    **作者：** Sihyun Yu、Sangkyung Kwak、Huiwon Jang、Jongheon Jeong、Jonathan Huang、Jinwoo Shin、Saining Xie。<br>
    **机构：** KAIST、Korea University、Scaled Foundations、New York University。<br>
    **时间 / 会议：** arXiv v1 提交于 2024-10-09；当前核验版本为 v4（2025-06-18）；ICLR 2025 Oral。<br>
    **论文 / 项目页：** arXiv：[2410.06940](https://arxiv.org/abs/2410.06940)；[PDF v4](https://arxiv.org/pdf/2410.06940v4)；[项目页](https://sihyun.me/REPA/)。<br>
    **代码 / 权重：** [github.com/sihyun-yu/REPA](https://github.com/sihyun-yu/REPA)。官方仓库提供 ImageNet、512 分辨率与 MS-COCO 训练脚本，并提供最终 SiT-XL/2 checkpoint。<br>
    **元数据来源与核验口径：** 来源为 arXiv v4、ICLR 论文、项目页与官方代码仓库；Checked Date：2026-08-25；Repro Status：Paper / official code / official checkpoint reviewed，未声明本站已独立复现。官方仓库同时提示，代码清理过程可能导致结果不能精确复现论文数字。

## 去噪网络不必从零学会视觉语义

REPA 把预训练视觉编码器的干净图像表示，作为扩散 Transformer 中间层的训练目标。扩散模型仍学习原来的去噪或速度预测，新增的表示对齐帮助前段网络更快形成语义，再让后段处理细节。推理时不需要外部编码器，因此它改变的是训练过程，而非增加采样步骤。[↗](https://arxiv.org/pdf/2410.06940#page=6)

下图先看干净图像如何进入冻结视觉编码器，再看带噪 latent 的隐藏表示如何经过投影对齐；右侧收敛曲线衡量训练进度。这里的教师是视觉表示模型，不是提供多步生成轨迹的扩散教师。

![REPA overview and convergence](../../assets/images/paper-deep-dives/diffusion/repa/figure-1-overview.png){ width="900" }

<small>图源：`Representation Alignment for Generation`，Figure 1。左图是训练期表征对齐分支，右图是 DiT / SiT 的 FID-50K 收敛曲线；本站由论文原始子图按原布局组合。</small>

## 先确认表示学习确实留下了缺口

作者用 ImageNet linear probe 测量隐藏特征的语义信息，用 CKNNA 测量与 DINOv2 的邻域表示一致性。长时间训练的 SiT 已能产生有用表征，但与自监督编码器仍有差距；中后层的线性分类性能先升后降，提示最后的去噪输出还承担了语义之外的细节任务。

下图先沿层深看线性分类峰值，再看模型规模和训练时长是否自然消除差距。结果支持“训练扩散模型会形成语义，但形成得慢”，尚不足以单靠相关性认定表示就是唯一瓶颈。

![Representation gap before REPA](../../assets/images/paper-deep-dives/diffusion/repa/figure-2-representation-gap.png){ width="900" }

<small>图源：论文 Figure 2。左：SiT 各层 linear probing；中：SiT 与 DINOv2-g 的 CKNNA；右：模型规模和训练时长对 alignment 的影响。本站由论文原始子图按原布局组合。</small>

REPA 随后直接干预这个环节。若在同等训练量下同时改善表示与生成质量，才能把观察推进到有用的训练方案。

## 同一张图的干净表示与带噪隐藏状态怎样对齐

训练图像为 $x^*$，冻结编码器输出 $y^*=f(x^*)\in\mathbb R^{N\times D}$。图像先由 VAE 编码成 latent $z$，加噪得到 $z_t$，扩散模型前段产生隐藏状态 $h_t$。可训练 MLP $h_\phi$ 将其投影到目标特征维度，按 patch 对齐

$$
\mathcal L_{\mathrm{REPA}}
=-\mathbb E\left[\frac1N\sum_{n=1}^N
\operatorname{sim}\big(y^{*[n]},h_\phi(h_t^{[n]})\big)\right].
$$

$N$ 为 patch 数，$\operatorname{sim}$ 可取 cosine similarity 或 NT-Xent 所构造的相似性目标。总损失为

$$
\mathcal L=\mathcal L_{\mathrm{velocity}}+\lambda\mathcal L_{\mathrm{REPA}},
$$

其中线性插值 $z_t=(1-t)z+t\epsilon$ 的速度目标为 $\epsilon-z$。辅助目标要求带噪表示保留对应干净图像的语义，不要求最终生成输出只保留视觉编码器关注的信息。[↗](https://arxiv.org/pdf/2410.06940#page=6)

下面的对齐图要同时看 linear probe、CKNNA 和 FID 三组关系。表示指标提高且 FID 降低，才支持对生成训练有益；仅把隐藏向量变得像 DINO 并不是最终目标。

![REPA closes the representation gap](../../assets/images/paper-deep-dives/diffusion/repa/figure-3-gap-bridging.png){ width="900" }

<small>图源：论文 Figure 3。左：REPA 提高早期层 linear probing；中：第 8 层附近与 DINOv2-g 的 alignment 显著增强；右：同一模型中更好的表征与更低 FID 同步出现。本站由论文原始子图按原布局组合。</small>

## 为什么不把对齐一直延伸到最后

Table 2 用同一 SiT-L/2、400K iterations、batch 256、$\lambda=0.5$，无 CFG、250 NFE 的 SDE Euler-Maruyama 采样比较组件。

| Target / Setting | Alignment Depth | FID ↓ | Linear Probe Acc. ↑ |
| --- | ---: | ---: | ---: |
| Vanilla SiT-L/2 | — | 18.8 | — |
| MAE-L, NT-Xent | 8 | 12.5 | 57.3 |
| DINOv2-L, NT-Xent | 8 | 10.0 | 68.1 |
| DINOv2-L, NT-Xent | 16 | 12.1 | 71.1 |
| DINOv2-L, Cos. sim. | 8 | 9.9 | 68.2 |

深度从八变十六，分类准确率继续升，但 FID 变差。它说明生成任务需要的不只是一份更便于线性分类的表示；后段有必要自由恢复细节。作者据此采用较早层对齐，并选实现简单、后期表现相近的 cosine 目标。

编码器大小也不是越大越好。DINOv2-B、L、g 的 FID 分别为 9.7、10.0、9.8；同一家族的表示相近，升级教师规模未带来单调收益。跨家族从 MAE、CLIP 到 DINOv2 的总体趋势更明显，但仍应按表中的实际组合选成本。[↗](https://arxiv.org/pdf/2410.06940#page=7)

![REPA scalability](../../assets/images/paper-deep-dives/diffusion/repa/figure-5-scalability.png){ width="900" }

<small>图源：论文 Figure 5。左：不同视觉教师的 linear probing 与 FID；中：REPA 对更大 SiT 的相对收敛收益更明显；右：固定 DINOv2-B 时，模型训练沿着更强表征与更低 FID 的方向共同移动。本站由论文原始子图按原布局组合。</small>

规模图先看固定模型训练进度的差值，再看扩散模型变大后的收益。REPA 在大模型上加速更明显，显示额外语义监督能释放更大主干的学习能力。

## 17.5 倍是达到相近 FID 的迭代数比

无 CFG 的主结果如下。

| Model | Training Iterations | FID ↓ |
| --- | ---: | ---: |
| SiT-XL/2 | 400K | 17.2 |
| SiT-XL/2 | 7M | 8.3 |
| SiT-XL/2 + REPA | 400K | 7.9 |
| SiT-XL/2 + REPA | 1M | 6.4 |
| SiT-XL/2 + REPA | 4M | 5.9 |

$7\text{M}/400\text{K}=17.5$，所以论文加速主张首先是迭代数到质量门槛的比较。REPA 每步还要计算冻结编码器与投影头，且借用了其预训练知识；它不是单次训练迭代或整个从零知识获取成本缩短 17.5 倍。

下图固定初始噪声、sampler 与采样步数比较 100K、200K、400K 的样本进展，可观察语义结构何时成形，而不是选择不同随机种子后比较个别好图。

![Training progression with and without REPA](../../assets/images/paper-deep-dives/diffusion/repa/figure-4-training-progression.png){ width="900" }

<small>图源：论文 Figure 4。每组三列为 100K、200K、400K iterations；上下分别为 vanilla SiT-XL/2 与 SiT-XL/2 + REPA。两者使用相同 initial noise、sampler、sampling steps，且均未使用 CFG。</small>

最终有 CFG 的系统表另报告 800 epochs、普通 CFG 1.80 FID；加 guidance interval 后为 1.42。1.42 包含采样引导日程的贡献，不能与无 CFG 的 7.9 一起当作同一配置的训练曲线。[↗](https://arxiv.org/pdf/2410.06940#page=9)

## 迁移价值在于一个训练期接口

论文还将 REPA 扩展到更高分辨率和文本生成。下面 COCO 示例在对应提示下比较主体和布局，承担迁移的定性补充；不应由展示图推断所有文本属性都有量化改善。

![MS-COCO qualitative comparison](../../assets/images/paper-deep-dives/diffusion/repa/figure-37-coco-qualitative.png){ width="900" }

<small>图源：论文 Figure 37。每个 prompt 上方为 MMDiT，下方为 MMDiT + REPA；定性图使用 CFG scale 4.0，Table 12 的 FID 使用 CFG scale 2.0，二者口径不同。</small>

采用时需要让图像增强、patch 空间位置与目标特征对齐，保留原生成损失，并给后层足够自由。外部编码器固定后，目标表示可在合适的数据流程中复用，但缓存策略要和图像增强一致。推理主干保持不变，是这一方案容易集成的原因。

REPA 的关键认识是生成模型内部的语义可以通过已有视觉知识加速形成，而辅助表示不必成为最终输出空间。对齐越强、层数越深未必越好；表中的分类—生成分歧正好提供了选层和选教师的依据。
