---
paper_date: 2024-12
paper_title: From Slow Bidirectional to Fast Autoregressive Video Diffusion Models
paper_topic: 扩散模型
---

# CausVid：流式自回归视频扩散

!!! info "论文信息"
    **论文题名：** From Slow Bidirectional to Fast Autoregressive Video Diffusion Models。<br>
    **作者：** Tianwei Yin、Qiang Zhang、Richard Zhang、William T. Freeman、Fredo Durand、Eli Shechtman、Xun Huang。<br>
    **机构：** MIT 2、Adobe。<br>
    **时间 / 主题：** 2024-12；扩散模型。<br>
    **arXiv / 官方报告：** arXiv：[2412.07772](https://arxiv.org/abs/2412.07772)；官方材料：[causvid.github.io/](https://causvid.github.io/)。<br>
    **GitHub / 项目：** GitHub：[github.com/tianweiy/CausVid](https://github.com/tianweiy/CausVid)；项目页：[causvid.github.io/](https://causvid.github.io/)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2412.07772)；[GitHub API / repo](https://github.com/tianweiy/CausVid)；[官方 / 项目材料](https://causvid.github.io/)；Checked Date：2026-06-04；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 把整段等待改成逐块输出

CausVid 将双向视频扩散教师蒸馏成四步因果学生。它同时处理两个等待来源——多步去噪需要反复计算，双向注意力必须等整段视频完成后才能输出。学生在时间块之间保持因果性，完成一个块后立即解码，并缓存历史 KV。原文在单张 H100 上生成 640×352、120 帧视频时报告首块延迟 1.3 秒、持续吞吐 9.4 FPS。[↗](https://arxiv.org/pdf/2412.07772#page=10)

下图先比较第一批可见画面出现的位置，再比较后续帧的输出节奏。首块延迟决定用户何时看到反馈，吞吐决定后续播放能否跟上，两者不能互相替代。

![CausVid teaser 原图](../../assets/images/localized-remote/paper-deep-dives/diffusion/causvid/causvid-teaser-原图.png){ width="920" }

<small>图源：`CausVid` 官方项目页，对应论文 Figure 1。原图对比传统 bidirectional diffusion 生成完整 128-frame 视频需要 219s，而 CausVid 通过 asymmetric distillation with DMD 得到 causal student，初始延迟 1.3s，随后约 9.4 FPS 流式生成。</small>

## 因果约束放在块之间

3D VAE 把 16 帧像素压成含五个 latent frames 的块，DiT 在块内保留双向注意力、块间使用因果注意力。以帧索引 $i,j$、块长 $k$ 表示，mask 为

$$
M_{i,j}=\begin{cases}
1,&\lfloor j/k\rfloor\le\lfloor i/k\rfloor,\\
0,&\text{otherwise}.
\end{cases}
$$

当前块能看同块与历史块，不能看未来。块内双向并不增加此 VAE 的首块等待，因为解码器本来就要等这一组 latent 完成才能输出像素；进一步降低延迟需要同时改变 VAE 接口。[↗](https://arxiv.org/pdf/2412.07772#page=7)

## 为什么教师继续使用双向模型

直接把教师也改成因果模型再蒸馏，会把因果教师自己的错误累积和质量损失交给学生。DMD 的监督只要求输出分布接近，不要求教师与学生具有相同注意力结构，因此 CausVid 保留更强的双向教师。

训练分两阶段。先从教师生成少量 ODE 轨迹，取学生将使用的时间点，用回归初始化因果学生。然后进入 asymmetric DMD：学生对各块独立加噪的视频预测干净结果，再将整段预测统一加噪给教师和 fake score 网络评估。教师冻结，fake score 追踪学生分布。

下图先读上方 ODE 初始化，再读下方分布匹配。两种注意力结构出现在不同角色中，不意味着学生推理偷看未来。

![CausVid method 原图](../../assets/images/localized-remote/paper-deep-dives/diffusion/causvid/causvid-method-原图.jpg){ width="920" }

<small>图源：`CausVid` 官方项目页，对应论文 Figure 6。该图展示两阶段训练：先用 bidirectional teacher 的 ODE solution pairs 初始化 causal student，再用 bidirectional teacher 对 causal student 做 asymmetric DMD distillation。</small>

分布梯度由

$$
\nabla_\phi\mathcal L_{\mathrm{DMD}}
\approx-\mathbb E\left[
\big(s_{\mathrm{data}}(\Psi(G_\phi(\epsilon),t),t)
-s_{\mathrm{gen}}(\Psi(G_\phi(\epsilon),t),t)\big)
\frac{dG_\phi(\epsilon)}{d\phi}
\right]
$$

给出，$\Psi$ 为正向加噪，$s_{\mathrm{data}}$ 来自双向教师，$s_{\mathrm{gen}}$ 来自在线 fake 模型。它评价生成视频的分布，不要求每个因果块重现教师同一种子的路径。[↗](https://arxiv.org/pdf/2412.07772#page=6)

需要区分这种训练和后续完全 on-policy 的自回归训练。原文 Algorithm 1 的输入来自数据视频，各块独立选噪声时间；它没有把每条训练轨迹都替换成学生完整滚动。因此 DMD 的分布监督缓解质量问题，并不自动消除所有训练与部署输入差异。

## KV cache 如何与多步去噪相容

生成当前块时，历史块 KV 复用，当前块从随机噪声经过四次去噪。该块完成后，论文再以 $t=0$ 前向一次，计算干净块对应的 KV 并追加缓存。缓存的是已经确定的历史，而不是任取某一去噪中间步骤的激活。

这个接口让未来块不用重复计算过去，也让推理时可以只对当前块使用快速双向注意力实现，因为未来 token 根本尚未进入缓存。长视频通过滑动窗口延续，保留前一段最后若干帧作为上下文；这仍然是有限历史机制，而非无限容量记忆。[↗](https://arxiv.org/pdf/2412.07772#page=9)

## 消融先验证教师和初始化的分工

同为十秒视频，Table 4 给出如下结果。

| Configuration | # Fwd Pass | Temporal Quality ↑ | Frame Quality ↑ | Text Alignment ↑ |
| --- | ---: | ---: | ---: | ---: |
| Bidirectional teacher | 100 | 94.6 | 62.7 | 29.6 |
| Many-step causal model | 100 | 92.4 | 60.1 | 28.5 |
| No ODE init, bidirectional teacher | 4 | 93.4 | 60.6 | 29.4 |
| ODE init only | 4 | 92.9 | 48.1 | 25.3 |
| ODE init + causal teacher | 4 | 91.9 | 61.7 | 28.2 |
| ODE init + bidirectional teacher | 4 | 94.7 | 64.4 | 30.1 |

直接因果化的多步模型已退化；只回归 ODE 轨迹更弱；双向教师和初始化结合才得到完整结果。这支持 DMD 在此处不仅压缩步数，也把强双向模型的生成能力转给不同结构的学生。作者同时指出学生的 temporal flickering 和输出多样性仍弱于教师，不能由三个聚合分数都上升推断所有维度获益。[↗](https://arxiv.org/pdf/2412.07772#page=11)

下面偏好图与雷达图补充了聚合表。偏好图分别看视觉与文本问题，雷达图沿时间稳定性、运动和语义等轴看是否有互相交换；单个总分会掩盖这些差别。

![CausVid preference 原图](../../assets/images/localized-remote/paper-deep-dives/diffusion/causvid/causvid-preference-原图.jpg){ width="820" }

<small>图源：`CausVid` 官方项目页，对应论文的人类偏好实验可视化。CausVid 在偏好研究中相对 PyramidFlow、CogVideoX、MovieGen 取得明显优势，并与 bidirectional teacher 接近。</small>

![CausVid radar 原图](../../assets/images/localized-remote/paper-deep-dives/diffusion/causvid/causvid-radar-原图.jpg){ width="820" }

<small>图源：`CausVid` 官方项目页。Radar plot 展示 CausVid 在 VBench 多项指标上的表现，项目页报告其 VBench 总分为 84.27。</small>

## 延迟收益与能力范围

Table 3 测试包含文本编码器、扩散模型和 VAE 解码器，目标视频统一为十秒、120 帧、640×352。

| Method | Latency (s) ↓ | Throughput (FPS) ↑ |
| --- | ---: | ---: |
| CogVideoX-5B | 208.6 | 0.6 |
| Pyramid Flow | 6.7 | 2.5 |
| Bidirectional Teacher | 219.2 | 0.6 |
| CausVid | 1.3 | 9.4 |

相对 CogVideoX，按表值计算首块延迟约降 160 倍、吞吐约升 15.7 倍。这两种比例描述不同收益，均不能写成“整段视频 1.3 秒生成完”。9.4 FPS 还低于训练视频的 12 FPS，因此其价值首先是流式交互和显著缩短等待，而非在该配置下无条件保证实时播放。

约 30 秒的长视频评估中，CausVid 的 temporal quality 为 94.9、frame quality 为 63.4、text alignment 为 28.9；FIFO-Diffusion 分别为 93.1、57.9、29.9。视觉与时间表现更好，但文本对齐并未逐项领先。十四分钟样例展示可持续滚动，也出现轻微过曝；极长视频仍会退化。[↗](https://arxiv.org/pdf/2412.07772#page=11)

论文还展示流式视频编辑和无需额外训练的图生视频。编辑先对输入块加噪，再按文本去噪；图生视频把初始图片复制成第一段，再接着生成。对希望构建连续生成接口的系统，最可复用的组合是块内双向、块间因果、干净历史 KV 与少步学生。若需要更低首帧等待，必须把 VAE 最小解码块一起纳入设计。
