---
paper_date: 2026-04
paper_title: "PixelDiT: Pixel Diffusion Transformers for Image Generation"
paper_topic: 扩散模型 / 像素空间图像生成
---

# PixelDiT：无 VAE 的像素空间 DiT

!!! info "论文信息"
    **论文题名：** PixelDiT: Pixel Diffusion Transformers for Image Generation。<br>
    **作者：** Yongsheng Yu、Wei Xiong、Weili Nie、Yichen Sheng、Shiqiu Liu、Jiebo Luo。<br>
    **机构：** NVIDIA、University of Rochester。<br>
    **时间 / 主题：** arXiv v1：2025-11-25；arXiv v2：2026-04-16；CVPR 2026 Oral，GitHub README 标注为 CVPR 2026 Best Paper Finalist。主题是像素空间扩散、Diffusion Transformer、无 VAE 图像生成。<br>
    **arXiv / 项目：** arXiv：[2511.20645](https://arxiv.org/abs/2511.20645)；项目页：[pixeldit.github.io](https://pixeldit.github.io/)；PDF：[arxiv.org/pdf/2511.20645](https://arxiv.org/pdf/2511.20645)。<br>
    **GitHub / 模型：** GitHub：[github.com/NVlabs/PixelDiT](https://github.com/NVlabs/PixelDiT)；Hugging Face ImageNet models：[nvidia/PixelDiT-ImageNet](https://huggingface.co/nvidia/PixelDiT-ImageNet)；T2I model：[nvidia/PixelDiT-1300M-1024px](https://huggingface.co/nvidia/PixelDiT-1300M-1024px)。<br>
    **元数据来源与核验口径：** 来源：arXiv 页面、论文 PDF、项目页、官方 GitHub README；Checked Date：2026-07-31；Repro Status：Paper / official project / official code and models reviewed, independent reproduction not claimed。

## 去掉 VAE 后，计算该放在哪里

PixelDiT 直接在 RGB 像素上做扩散，同时用两级 Transformer 分配计算。patch-level DiT 负责全局语义，窄的 pixel-level DiT 负责逐像素细节。它避免 VAE 编解码的有损瓶颈，但没有天真地让上百万像素 token 彼此做完整全局注意力。[↗](https://arxiv.org/pdf/2511.20645#page=3)

下图编辑实例先看 VAE 单独重建的墙面文字，再看将自行车改成摩托车后的文字。背景细节在编辑前的 VAE 往返中就可能损坏，后续扩散无法保证复原。PixelDiT 的价值是消除这一步固定的信息损失；示例并不意味着任意编辑都能完全保持背景。

![PixelDiT FlowEdit editing comparison](../../assets/images/paper-deep-dives/diffusion/pixeldit/figure-1-editing.png){ width="900" }

<small>图源：`PixelDiT: Pixel Diffusion Transformers for Image Generation` 项目页 / Figure 1(b) 对应 FlowEdit 对比。图中比较真实图像、FLUX 和 PixelDiT 的局部编辑结果，重点看红砖墙上的小字。</small>

## 双层路径沿同一噪声图像汇合

输入 $x\in\mathbb R^{B\times C\times H\times W}$ 先分为 $p\times p$ patches，形成

$$
L=(H/p)(W/p)
$$

个语义 token。宽的 patch DiT 在这条短序列上做全局建模。另一条路径把每个像素嵌入到很窄的 $D_{\mathrm{pix}}$ 维空间，例如 16 维，再接收语义路径的输出。

下面架构图从同一 noisy image 的两条分支看起。patch 路径最后的语义 token 与时间 embedding 共同调制 pixel 路径；图像细节仍留在逐像素表示和残差连接中。

![PixelDiT dual-level architecture](../../assets/images/paper-deep-dives/diffusion/pixeldit/figure-2-architecture.png){ width="900" }

<small>图源：`PixelDiT: Pixel Diffusion Transformers for Image Generation` 项目页 / Figure 2。左侧是 dual-level PixelDiT，右侧是 PiT block 内部结构。</small>

ImageNet XL 配置包含 26 层 patch blocks、四层 pixel blocks，宽度分别为 1152 与 16，总参数 797M。昂贵语义计算集中在较短序列，并不意味着 pixel 路径“免费”；其调制和展开成本仍需在更大分辨率与宽度下重新检查。

## Pixel-wise AdaLN 与 token compaction 分别解决什么

若把一个全局条件向量广播给所有像素，局部位置差异难以表达；若每个 patch 只重复同一组调制参数，patch 内仍共享同样更新。PixelDiT 用语义 token 为 patch 内每个像素生成独立调制

$$
\Theta=\Phi(s_{\mathrm{cond}})
\in\mathbb R^{(B L)\times p^2\times6D_{\mathrm{pix}}}.
$$

六组参数分别服务于 attention 与 FFN 的 scale、shift、gate。下图从 A 到 C 观察条件的粒度，不是简单增加一个更大 MLP，而是把空间位置分辨率引入调制。

![PixelDiT AdaLN modulation](../../assets/images/paper-deep-dives/diffusion/pixeldit/figure-3-adaln.png){ width="520" }

<small>图源：`PixelDiT: Pixel Diffusion Transformers for Image Generation`，Figure 3 裁剪。原图比较 naive global AdaLN、patch-wise AdaLN 和 pixel-wise AdaLN。</small>

直接对 $HW$ 像素做 attention 仍不可承受，所以 PiT block 先用线性映射 $\mathcal C$ 把一个 patch 内 $p^2$ 个 pixel tokens 压成一个 token，在 $L$ 个 token 上做全局 attention，再用 $\mathcal E$ 展开回像素。

$$
\mathcal C:\mathbb R^{p^2\times D_{\mathrm{pix}}}\to\mathbb R^D,
\qquad
\mathcal E:\mathbb R^D\to\mathbb R^{p^2\times D_{\mathrm{pix}}}.
$$

$p=16$ 时注意力序列长度缩为原来的 $1/256$。这只是 attention 分支的临时压缩，像素残差路径绕过它，因此与先由固定 VAE 有损编码、最后再解码的生成空间不同。[↗](https://arxiv.org/pdf/2511.20645#page=5)

## 训练并非只有像素回归

PixelDiT 使用 Rectified Flow 的速度匹配目标

$$
\mathcal L_{\mathrm{diff}}
=\mathbb E\|f_\theta(x_t,t,y)-v_t\|_2^2,
\qquad
\mathcal L=\mathcal L_{\mathrm{diff}}+\lambda_{\mathrm{repa}}\mathcal L_{\mathrm{repa}}.
$$

后者把 patch 路径中间层对齐冻结 DINOv2 表示。ImageNet 设置在第八块对齐，$\lambda_{\mathrm{repa}}=0.5$，batch 256、AdamW、BF16、EMA 0.9999。无 VAE 并不等于完全不用外部预训练表示。

256 模型训练 320 epochs；512 模型从该 checkpoint 再微调 530 epochs，因此高分辨率结果包含低分辨率预训练投入。文本版使用冻结 Gemma-2，在 patch 路径中以 MM-DiT 融合文本与图像；pixel 路径不直接接文本 token，只读已融合语义。下图看文本在哪一层进入，便能理解为何低层像素模块可沿用。

![PixelDiT T2I architecture](../../assets/images/paper-deep-dives/diffusion/pixeldit/figure-7-t2i-architecture.png){ width="900" }

<small>图源：`PixelDiT: Pixel Diffusion Transformers for Image Generation` 项目页 / Figure 7。T2I 版本在 patch-level pathway 加入 MM-DiT blocks，pixel-level pathway 保持 dense per-pixel modeling。</small>

文本训练使用约 26M 图文对，先在 512 分辨率预训练，再扩展到百万像素。架构可直接输出像素，但学习语义与条件依然需要相当数据和训练预算。[↗](https://arxiv.org/pdf/2511.20645#page=6)

## 消融说明两个模块都不可少

Table 5 从纯像素 DiT 出发，在同为 80 epochs 的配置中逐项加入组件。

| Model Components | Epoch | gFID ↓ |
| --- | ---: | ---: |
| Vanilla DiT/16 | 80 | 9.84 |
| + RoPE, RMSNorm | 80 | 8.53 |
| + Dual-level, no compaction | 80 | OOM |
| + Pixel Token Compaction | 80 | 3.50 |
| + Pixel-wise AdaLN | 80 | 2.36 |
| Full PixelDiT | 320 | 1.61 |

dual-level 但没有 compaction 的方案内存溢出，说明“多加一条像素路径”本身不足以构成可训练方案。compaction 先解决可行性，pixel-wise 调制再显著改善质量；320 epochs 的进一步提升包含额外训练，不能与前面同预算消融混为单一模块效果。[↗](https://arxiv.org/pdf/2511.20645#page=8)

## 无 VAE 能达到什么水平，代价如何

ImageNet-256 上 797M PixelDiT-XL 的 gFID 为 1.61、sFID 4.68、Recall 0.64；512 上为 1.81、5.61、0.67。它在论文像素方法比较中很强，但部分 latent 方法仍有更低 FID，例如 256 的 RAE-XL 1.13；主张应落在像素路线的可行性和细节接口，而非所有生成模型统一排名第一。

| PixelDiT-T2I Resolution | GenEval ↑ | DPG ↑ | Throughput (samples/s) ↑ |
| --- | ---: | ---: | ---: |
| 512×512 | 0.78 | 83.7 | 1.07 |
| approximately 1024×1024 | 0.74 | 83.5 | 0.33 |

吞吐在单张 A100、FP16 下测量。提高分辨率后 GenEval 略降、计算也上升，显示百万像素生成与组成属性评估并非自动同向改善。[↗](https://arxiv.org/pdf/2511.20645#page=7)

这篇论文提供了一种通用分工方式——宽而短的路径负责语义，窄而密的路径负责细节，再用逐像素调制连接。适合关注小文字、细线条和局部编辑保真的场景；若目标首先是超低延迟，仍要计入 pixel head 每个去噪步骤都执行的成本，不能只用“省掉 VAE”推导整体一定更快。
