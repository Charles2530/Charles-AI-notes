---
paper_date: 2020-11
paper_title: "Score-Based Generative Modeling through Stochastic Differential Equations"
paper_topic: 扩散模型
---

# Score SDE：把扩散模型写成连续时间生成过程

!!! info "论文信息"
    **论文题名：** Score-Based Generative Modeling through Stochastic Differential Equations。<br>
    **作者：** Yang Song、Jascha Sohl-Dickstein、Diederik P. Kingma、Abhishek Kumar、Stefano Ermon、Ben Poole。<br>
    **机构：** 未在公开元数据中稳定解析；以 arXiv/PDF 或官方页 affiliation block 为准。<br>
    **时间 / 主题：** 2020-11；扩散模型。<br>
    **arXiv / 官方报告：** arXiv：[2011.13456](https://arxiv.org/abs/2011.13456)。<br>
    **GitHub / 项目：** GitHub：[github.com/yang-song/score_sde](https://github.com/yang-song/score_sde)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2011.13456)；[GitHub API / repo](https://github.com/yang-song/score_sde)；Checked Date：2026-06-15；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 把加噪、学习和采样拆成三个可组合的问题

Score SDE 将 SMLD 与 DDPM 放进同一个连续时间框架。先设计一个把数据逐渐变成简单噪声的随机过程，再学习各个噪声时刻的分数 $\nabla_x\log p_t(x)$，最后选择数值算法反向生成。这个拆分的价值是训练目标与采样器不再绑死，同一网络可以接随机求解器、Predictor-Corrector 或确定性 ODE，并支持似然计算和条件生成。[↗](https://arxiv.org/pdf/2011.13456#page=4)

下图从数据端沿正向加噪读到高斯先验，再反向看生成路径。反向过程需要的新增信息是各时刻的分数，而不是知道每个样本原来经过哪条随机路径。

![Score SDE reverse process 原图](../../assets/images/paper-deep-dives/diffusion/score-sde/figure-1-reverse-sde.png){ width="720" }

<small>图源：`Score-Based Generative Modeling through Stochastic Differential Equations`，Figure 1。</small>

## 为什么知道分数就能反向生成

正向 Itô SDE 写为

$$
dx=f(x,t)\,dt+g(t)\,dw.
$$

$f$ 是漂移项，决定确定性运动；$g$ 是扩散强度；$w$ 是 Wiener 过程。它把 $p_0$ 演化到易采样的 $p_T$。对这里不依赖状态的标量扩散系数，逆时间过程是

$$
dx=\left[f(x,t)-g(t)^2\nabla_x\log p_t(x)\right]dt
+g(t)\,d\bar w.
$$

这里时间从 $T$ 走向 0，$dt$ 为负，$\bar w$ 是逆时间 Wiener 过程。减号与负时间步必须一起读，不能把公式直接当作正向时间上的普通更新。分数项校正随机扩散造成的概率流，使样本逐渐回到数据分布。

真正的数据密度不可求，但可采样训练图像 $x(0)$，并从已知扰动核 $p_{0t}(x(t)\mid x(0))$ 加噪。原文训练目标为

$$
\mathbb E_{t,x(0),x(t)}\left[
\lambda(t)\left\|s_\theta(x(t),t)
-\nabla_{x(t)}\log p_{0t}(x(t)\mid x(0))\right\|_2^2
\right].
$$

$\lambda(t)>0$ 平衡不同噪声尺度。条件高斯的分数可直接算，而 denoising score matching 保证在理想数据、容量和优化条件下，最优网络学到边缘分数 $\nabla_x\log p_t(x)$。训练因此不需要逐步模拟整条正向 SDE。[↗](https://arxiv.org/pdf/2011.13456#page=4)

下面总图把三个接口连起来。先看正向 SDE 如何确定训练样本，再看同一个 score network 如何供给两种逆过程；随机采样和确定性编码由同一学习结果支持。

![Score SDE overview 原图](../../assets/images/paper-deep-dives/diffusion/score-sde/figure-2-sde-overview.png){ width="920" }

<small>图源：`Score-Based Generative Modeling through SDEs`，Figure 2。</small>

## VE、VP 与 sub-VP 不是三个互不相关的模型

SMLD 对应 Variance Exploding SDE

$$
dx=\sqrt{\frac{d\sigma(t)^2}{dt}}\,dw,
$$

DDPM 的连续极限对应 Variance Preserving SDE

$$
dx=-\tfrac12\beta(t)x\,dt+\sqrt{\beta(t)}\,dw.
$$

前者不断加大方差；后者在初始方差为一时保持该方差。sub-VP 保留 VP 漂移，将扩散强度改为

$$
g(t)=\sqrt{\beta(t)\left(1-e^{-2\int_0^t\beta(s)ds}\right)}.
$$

因此它在相同 $\beta$ 下的中间方差不超过 VP。三者的漂移均为仿射形式，扰动核为可计算高斯，适合相同的训练接口。论文观察到 VE 更有利于样本质量，sub-VP 更有利于似然；这属于实验中的模型与日程组合，并非所有数据上的一般定理。[↗](https://arxiv.org/pdf/2011.13456#page=5)

## Predictor-Corrector 在修正什么

Predictor 先用反向 SDE 的数值离散推进到下一噪声时刻，Corrector 再利用当前时刻分数做 MCMC 修正。Langevin corrector 的基本形式为

$$
x\leftarrow x+\eta s_\theta(x,t)+\sqrt{2\eta}\,z,
\qquad z\sim\mathcal N(0,I).
$$

它在同一个噪声尺度内改善边缘分布，而非进一步降低噪声。SMLD 可视为 predictor 为恒等映射、corrector 为退火 Langevin；DDPM 则使用祖先采样 predictor 而不加 corrector。统一框架使这些组合可以直接比较。

Table 1 特意以模型调用预算区分 P1000、P2000 与 PC1000。后者包含 1000 次 predictor 和 1000 次 corrector，并不是只花 1000 次前向。对 VE 的 reverse diffusion predictor，P1000 FID 为 $4.79\pm0.07$，P2000 为 $4.74\pm0.08$，PC1000 为 $3.60\pm0.02$。同为约 2000 次评估，把预算分给校正优于全部用于更密的 predictor；同时也说明优质 PC 采样本身仍然昂贵。[↗](https://arxiv.org/pdf/2011.13456#page=6)

## Probability flow ODE 打开似然与可逆编码接口

同一正向 SDE 还对应一个确定性过程

$$
dx=\left[f(x,t)-\tfrac12g(t)^2\nabla_x\log p_t(x)\right]dt.
$$

它与 SDE 共享各时刻的边缘概率密度，但不共享单个样本轨迹。注意 score 系数从逆 SDE 中的 1 变成 $1/2$，同时去掉了随机项；不能仅把 SDE 的随机项删掉就得到它。

定义向量场 $v_\theta=f-\tfrac12g^2s_\theta$，连续变量变换给出

$$
\frac{d\log p_t(x_t)}{dt}=-\nabla\cdot v_\theta(x_t,t).
$$

从数据积分到简单先验，累积散度即可求模型密度；反向积分则生成样本。实际计算包含数值积分与迹估计的误差，论文所谓 exact likelihood 是相对于该连续流模型的可计算密度，而非 DDPM 的变分下界。[↗](https://arxiv.org/pdf/2011.13456#page=7)

下图左侧先看不同误差容限如何分配求解点，中部看 NFE 14、86、548 的样本，右侧看 latent 插值。它展示可调计算预算和确定性编码两个用途，单张样例不能替代整体 FID。

![Probability flow ODE 原图](../../assets/images/paper-deep-dives/diffusion/score-sde/figure-3-probability-flow-ode.png){ width="920" }

<small>图源：`Score-Based Generative Modeling through SDEs`，Figure 3。</small>

## 最佳 FID 与最佳似然来自不同配置

CIFAR-10 结果必须分两张表读。Table 3 选训练过程最佳 FID checkpoint，并使用 PC；Table 2 取最终 checkpoint，并用 ODE 计算似然与采样。因此 2.20 FID、2.99 bits/dim 不能写成同一模型同一设置同时取得。

| Configuration | Evaluation | FID ↓ | NLL bits/dim ↓ |
| --- | --- | ---: | ---: |
| NCSN++ | Best checkpoint, PC | 2.45 | — |
| NCSN++ cont. (VE) | Best checkpoint, PC | 2.38 | — |
| NCSN++ cont. (deep, VE) | Best checkpoint, PC | 2.20 | — |
| DDPM++ cont. (deep, VP) | Final checkpoint, ODE | 3.08 | 3.13 |
| DDPM++ cont. (deep, sub-VP) | Final checkpoint, ODE | 2.92 | 2.99 |

从 NCSN++ 到连续时间训练再到更深网络，质量逐步改善，但这些改动不能全归因于 SDE 公式。下面架构消融图正是为了观察组件组合如何影响 FID；阅读入口是同一训练进度下的曲线与配置差别。

![NCSN++ architecture ablation 原图](../../assets/images/paper-deep-dives/diffusion/score-sde/figure-10-architecture-components.png){ width="920" }

<small>图源：`Score-Based Generative Modeling through SDEs`，Figure 10。</small>

![1024 CelebA-HQ samples 原图](../../assets/images/paper-deep-dives/diffusion/score-sde/figure-12-celebahq-1024.png){ width="620" .atlas-figure-tall }

<small>图源：`Score-Based Generative Modeling through SDEs`，Figure 12。</small>

1024×1024 CelebA-HQ 样本展示了框架扩展到高分辨率的可行性；它不提供低成本生成的证明。likelihood 表在 uniformly dequantized CIFAR-10 上比较，和采用其他 dequantization 或离散数据协议的数值应分开。

## 条件生成由分数相加实现

条件分数满足

$$
\nabla_x\log p_t(x\mid y)
=\nabla_x\log p_t(x)+\nabla_x\log p_t(y\mid x).
$$

把它代回逆 SDE 即得到条件采样。标签、部分已知像素或其他观测以相应条件信息进入过程，论文据此展示类别控制、补全和着色。下图按不同任务的已知条件与生成区域看，重点是如何在固定无条件 score 上改变采样约束。

![Controllable generation 原图](../../assets/images/paper-deep-dives/diffusion/score-sde/figure-4-controllable-generation.png){ width="920" }

<small>图源：`Score-Based Generative Modeling through SDEs`，Figure 4。</small>

这篇论文提供的长期价值是一个可替换接口。选择扰动过程决定训练分布，学习 score 决定生成方向，求解器决定计算与误差，条件项决定控制方式。后来的快采样器可以沿这个接口改积分，蒸馏方法可以沿它取分布梯度，而无需把所有改进都重新包装成一种独立生成模型。
