---
paper_date: 2026-05
paper_title: "AnyFlow: Any-Step Video Diffusion Model with On-Policy Flow Map Distillation"
paper_topic: 扩散模型
---

# AnyFlow：任意步视频扩散蒸馏

!!! info "论文信息"
    **论文题名：** AnyFlow: Any-Step Video Diffusion Model with On-Policy Flow Map Distillation。<br>
    **作者：** Yuchao Gu、Guian Fang、Yuxin Jiang、Weijia Mao、Song Han、Han Cai、Mike Zheng Shou。<br>
    **机构：** 未在公开元数据中稳定解析；以 arXiv/PDF 或官方页 affiliation block 为准。<br>
    **时间 / 主题：** 2026-05；扩散模型。<br>
    **arXiv / 官方报告：** arXiv：[2605.13724](https://arxiv.org/abs/2605.13724)；官方材料：[nvlabs.github.io/AnyFlow/](https://nvlabs.github.io/AnyFlow/)。<br>
    **GitHub / 项目：** GitHub：[github.com/NVlabs/AnyFlow](https://github.com/NVlabs/AnyFlow)；项目页：[nvlabs.github.io/AnyFlow/](https://nvlabs.github.io/AnyFlow/)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2605.13724)；[GitHub API / repo](https://github.com/NVlabs/AnyFlow)；[官方 / 项目材料](https://nvlabs.github.io/AnyFlow/)；Checked Date：2026-06-04；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 少步模型还应允许用更多计算换质量

AnyFlow 关注一个常被忽略的部署需求。同一视频模型可能要在预览时只用四次调用，在最终生成时用更多步骤；已有 consistency 蒸馏模型增加步数后，却可能因为反复端点预测与重新加噪而变差。AnyFlow 训练任意时间之间的 flow map，再在学生自身生成的状态上用 DMD 精炼，使一个 checkpoint 支持不同采样预算。[↗](https://arxiv.org/pdf/2605.13724#page=7)

下图先沿横轴增加 NFE，看质量是否继续提高，再比较四步起点。目标是兼顾低预算与可扩展性，不能只选最高预算的一个点。

![AnyFlow test-time scaling 原图](../../assets/images/paper-deep-dives/diffusion/anyflow/figure-1-test-time-scaling.png){ width="920" }

<small>图源：`AnyFlow`，Figure 1(a)。</small>

## 从预测终点改成学习时间间隔

给定 ODE $dz_t/dt=v(z_t,t)$，精确流映射 $\Phi_{r\leftarrow t}$ 将 $z_t$ 运送到 $z_r$，满足恒等与组合性质。AnyFlow 学习

$$
f_\theta(z_t;t,r)\approx z_r,
\qquad
f_\theta(z_t;t,t)=z_t,
$$

并以平均速度表示

$$
f_\theta(z_t;t,r)=z_t-(t-r)u_\theta(z_t;r,t).
$$

$t-r$ 很小时，平均速度接近瞬时速度；$r=0$ 时可直接跳到终点。由此既能走短步精炼，也能作长距离跳跃。下图比较 consistency 的终点映射与 flow map 的区间映射，重点看多步采样是否每次必须先到干净端点再加噪。

![AnyFlow distillation paradigms 原图](../../assets/images/paper-deep-dives/diffusion/anyflow/figure-2-distillation-paradigms.png){ width="920" }

<small>图源：`AnyFlow`，Figure 2。</small>

第一阶段沿用 MeanFlow 关系构造目标

$$
\mathcal L=\mathbb E\|u_\theta-\operatorname{sg}(u_{\mathrm{tgt}})\|_2^2,
\qquad
u_{\mathrm{tgt}}=v-(t-r)\frac{du_\theta}{dt}.
$$

$\operatorname{sg}$ 停止目标分支梯度。为避免大模型 FSDP 下 JVP 的困难，作者用沿数据轨迹的中心有限差分近似导数。需要取 $z_{t\pm\delta}$ 与对应时间联合扰动，不能只变时间标签而固定图像状态。[↗](https://arxiv.org/pdf/2605.13724#page=6)

## 第二个时间条件怎样接到预训练模型

增加终点时间 $r$ 会改变预训练模型的条件接口。作者发现简单新增时间 embedding 容易造成范数偏大、过饱和，因此改用两种时间 embedding 的插值

$$
\gamma\,\operatorname{emb}(t)
+(1-\gamma)\,\operatorname{emb}'(r),
\qquad \gamma=0.25,
$$

其中 $\operatorname{emb}'$ 从预训练 embedding 初始化。$t=r$ 时起点与终点相同，初始化可恢复原来的条件尺度。下面两张图分别从 embedding 范数与可见图像检查这一设计；前者解释输入尺度变化，后者显示与过饱和的对应关系。

![AnyFlow embedding norms 原图](../../assets/images/paper-deep-dives/diffusion/anyflow/figure-8-embedding-norms.png){ width="820" }

<small>图源：`AnyFlow`，Figure 11(a)。</small>

![AnyFlow timestep conditioning visual 原图](../../assets/images/paper-deep-dives/diffusion/anyflow/figure-9-timestep-conditioning-visual.png){ width="920" }

<small>图源：`AnyFlow`，Figure 11(b)。</small>

CFG 也融入训练。原文使用 $u=[u_c-(1-g)\operatorname{sg}(u_\varnothing)]/g$ 构造预测，再对齐训练目标，使部署不必额外跑无条件分支。这里 $g$ 是 guidance scale，与上面的插值系数 $\gamma$ 不同。省掉 CFG 分支后，四步才真正对应四次网络评估。

从均匀分布独立采样两个时间，再令 $t$ 为较大值、$r$ 为较小值，起点 $t$ 的诱导密度为 $p(t)=2t$。额外损失权重 $w(t)$ 再调节噪声分配，最终加权密度正比于 $p(t)w(t)$；论文消融后在全部实验固定使用 $w(t)=\operatorname{Beta}(2,1.5)$。下图先看最终密度，再看四步与 32 步列。Beta 权重对高预算结果较有利，但四步各设置很接近，不能把微小差异夸大成决定性改进。

![AnyFlow time sampler 原图](../../assets/images/paper-deep-dives/diffusion/anyflow/figure-7-time-sampler.png){ width="660" }

<small>图源：`AnyFlow`，Figure 10(a)。</small>

## 三段 shortcut 让不同预算的训练成本可控

前向 flow map 训练仍会遭遇离散误差和因果滚动的 exposure bias。第二阶段让学生产生自己的样本，再用教师与 fake score 的差值优化输出分布，并同时继续第一阶段目标。

下面流程图先看 synthetic data 上的前向训练，再看学生 rollout 如何进入 DMD。两条路径共同保留瞬时速度能力与部署时的生成质量。

![AnyFlow pipeline 原图](../../assets/images/paper-deep-dives/diffusion/anyflow/figure-3-anyflow-pipeline.png){ width="920" }

<small>图源：`AnyFlow`，Figure 4。</small>

完整模拟 $N$ 步在训练中代价大。AnyFlow 利用近似组合性质

$$
f_\theta(z_t;t,q)
\approx f_\theta\big(f_\theta(z_t;t,r);r,q\big)
$$

将轨迹分成 $T\to t$、$t\to r$、$r\to0$ 三段。中间保留目标采样预算对应的间隔 $t-r=T/N$，两端用 flow map 直接 shortcut；在 $z_0$ 计算分布梯度后，通过整条三段链回传。改变 $N$ 不需要线性增加模拟次数。

下图先找中间被训练的短区间，再看两侧跨过了多少原始采样步骤。这是“any-step”能够训练的计算基础，而不只是给网络多传一个时间变量。[↗](https://arxiv.org/pdf/2605.13724#page=10)

![AnyFlow backward simulation 原图](../../assets/images/paper-deep-dives/diffusion/anyflow/figure-4-backward-simulation.png){ width="820" }

<small>图源：`AnyFlow`，Figure 5。</small>

## 预算扩展是否在实验中成立

主实验以 Wan2.1 为底座，使用教师合成的 256K 提示—视频对，最多 81 帧、480×832，采用 rank 256 LoRA。主表对标注为重新评估的模型统一使用 VBench augmented prompts，其余论文转载行不能视为同一评测运行。

| Model | Architecture | NFE | VBench Total ↑ |
| --- | --- | ---: | ---: |
| rCM-Wan2.1-T2V-14B | Bidirectional | 4 | 83.73 |
| AnyFlow-Wan2.1-T2V-14B | Bidirectional | 4 | 84.04 |
| AnyFlow-Wan2.1-T2V-14B | Bidirectional | 32 | 84.10 |
| Krea-Realtime-Wan2.1-14B | Causal | 4 | 83.25 |
| AnyFlow-FAR-Wan2.1-14B | Causal | 4 | 84.05 |
| AnyFlow-FAR-Wan2.1-14B | Causal | 32 | 84.41 |

因果 14B 从四次到 32 次评估提高 0.36 分；双向提高 0.06 分。可扩展并不意味着增加八倍调用得到同比质量收益。1.3B 的消融也比较 consistency initialization 与 flow map initialization、两种 backward simulation，支持初始化和 on-policy 模拟各有作用，而不是把改进完全归于网络规模。[↗](https://arxiv.org/pdf/2605.13724#page=12)

I2V 的四次评估结果为 Quality 80.39、I2V 95.35、Total 87.87；Wan2.1-I2V-14B 使用 $50\times2$ 次评估，分别为 80.30、95.12、87.71。87.87 是表中的总分，不能与 I2V 分项 95.35 混称同一列。

## 持续微调与因果视频接口

因果版本采用 FAR 上下文压缩。保留三个完整 token 块，较远块用更大 patch 压缩，以减少训练计算和 KV cache；首块只含一个 latent frame，后续块长为三，使首图条件与运动生成共享模型。

下图把下游训练接到已有 checkpoint，随后在机器人和驾驶场景检查身份与轨迹。应先看同一场景微调前后的物体外观和移动路径，再判断域适应是否解决了原模型的具体失败。

![AnyFlow downstream fine-tuning pipeline 原图](../../assets/images/paper-deep-dives/diffusion/anyflow/figure-5-downstream-finetuning-pipeline.png){ width="820" }

<small>图源：`AnyFlow`，Figure 7。</small>

![AnyFlow downstream results 原图](../../assets/images/paper-deep-dives/diffusion/anyflow/figure-6-downstream-results.png){ width="920" }

<small>图源：`AnyFlow`，Figure 8。</small>

AnyFlow 的实际采用价值是保留一个可继续训练、可改变推理预算的接口。预览与最终生成可使用相同权重，领域数据也能继续用于训练；代价是合成训练集、两阶段蒸馏、fake score 和三段模拟。论文的机器人视频与驾驶视频展示支持视觉域适应，不直接提供动作闭环成功率。
