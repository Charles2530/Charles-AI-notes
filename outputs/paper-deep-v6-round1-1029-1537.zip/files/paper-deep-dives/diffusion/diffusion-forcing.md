---
paper_date: 2024-07
paper_title: "Diffusion Forcing: Next-token Prediction Meets Full-Sequence Diffusion"
paper_topic: 扩散模型
---

# Diffusion Forcing：next-token 与全序列扩散

!!! info "论文信息"
    **论文题名：** Diffusion Forcing: Next-token Prediction Meets Full-Sequence Diffusion。<br>
    **作者：** Boyuan Chen、Diego Marti Monso、Yilun Du、Max Simchowitz、Russ Tedrake、Vincent Sitzmann。<br>
    **机构：** 未在公开元数据中稳定解析；以 arXiv/PDF 或官方页 affiliation block 为准。<br>
    **时间 / 主题：** 2024-07；扩散模型。<br>
    **arXiv / 官方报告：** arXiv：[2407.01392](https://arxiv.org/abs/2407.01392)；官方材料：[www.boyuan.space/diffusion-forcing/](https://www.boyuan.space/diffusion-forcing/)。<br>
    **GitHub / 项目：** GitHub：[github.com/buoyancy99/diffusion-forcing](https://github.com/buoyancy99/diffusion-forcing)；项目页：[www.boyuan.space/diffusion-forcing/](https://www.boyuan.space/diffusion-forcing/)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2407.01392)；[GitHub API / repo](https://github.com/buoyancy99/diffusion-forcing)；[官方 / 项目材料](https://www.boyuan.space/diffusion-forcing/)；Checked Date：2026-06-04；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 每个 token 的噪声水平也是条件

Diffusion Forcing 把“哪些过去已经确定、哪些未来仍不确定”变成模型可见的输入。普通 teacher forcing 通常给干净历史、预测下一 token；全序列扩散通常让整个序列共享噪声水平。本文为每个时间位置独立采样噪声级别，再训练因果模型去噪，因此一个模型能处理干净、部分损坏或完全未知的历史和未来。[↗](https://arxiv.org/pdf/2407.01392#page=4)

下面能力图先看不同位置的噪声配置如何变化。自回归生成、全轨迹引导、带噪观测和保留远期不确定性都来自同一个训练接口，而非分别训练四个模型。

![Diffusion Forcing capabilities 原图](../../assets/images/localized-remote/paper-deep-dives/diffusion/diffusion-forcing/diffusion-forcing-capabilities-原图.png){ width="920" }

<small>图源：`Diffusion Forcing` 官方项目页，对应论文 Figure 1。原图表达：用 Guidance、Tree Search、Compositionality、Causal Uncertainty 和 Flexible Horizon 对比 Teacher Forcing、Full-Seq. Diffusion 与 Diffusion Forcing。本站读法：这张图先看能力列，再回到训练目标；DF 的卖点不是某个单独任务分数，而是“独立噪声水平”让同一个因果序列模型拥有整段 guidance 和 flexible horizon。</small>

## 两条时间轴如何进入训练

用 $t$ 表示序列位置、$k_t$ 表示该位置的扩散噪声级别，$x_t^{k_t}$ 为加噪 token。$k_t=0$ 对应完全已知，$k_t=K$ 近似纯噪声。训练中 $k_1,\ldots,k_T$ 独立采样，使模型见到多种噪声组合。

论文的主要实现是递归网络。它用状态 $z_{t-1}$ 汇总过去，然后结合当前带噪 token 与噪声级别更新

$$
z_t\sim p_\theta(z_t\mid z_{t-1},x_t^{k_t},k_t).
$$

实现中隐藏状态更新是确定性的，用该向量表达信念信息。噪声预测目标为

$$
\mathcal L(\theta)=\mathbb E\sum_{t=1}^T
\left\|\epsilon_t-\epsilon_\theta(z_{t-1},x_t^{k_t},k_t)\right\|_2^2.
$$

当前 token 干净时，状态吸收可靠观测，类似 Bayes filtering 的后验更新；当前 token 完全是噪声时，状态只能依赖历史，类似先验预测。噪声级别因此也是模型判断观测可信程度的接口。[↗](https://arxiv.org/pdf/2407.01392#page=5)

下图从输入 token、噪声标签到 recurrent latent 顺序阅读。因果性限制信息只能从过去进入未来，而不是禁止训练时同时对多个未来 token 施加损失。

![Diffusion Forcing method 原图](../../assets/images/localized-remote/paper-deep-dives/diffusion/diffusion-forcing/diffusion-forcing-method-原图.png){ width="920" }

<small>图源：`Diffusion Forcing` 官方项目页，对应论文 Figure 2。原图展示 noise as masking、Diffusion Forcing、Teacher Forcing 和 Full-Seq. Diffusion 的训练与采样差异。</small>

原文证明该训练对应混合噪声序列似然的一个加权 ELBO；在其条件下，它同时覆盖多种噪声配置。这个结果解释训练目标的合理性，并不意味着有限网络在任意未见时长上都无误差。

## 推理变成设计一张二维去噪日程

推理用矩阵 $\mathcal K\in[K]^{M\times T}$ 指定每轮、每个时间位置的噪声水平。列对应序列时间，行对应去噪轮次。全同步下降接近全序列扩散；先清理近处、再推进远处，则形成 zig-zag 或滑动计划。

例如三个未来 token 可以依次经历

$$
[x_1^K,x_2^K,x_3^K]
\rightarrow[x_1^0,x_2^{K/2},x_3^K]
\rightarrow[x_1^0,x_2^0,x_3^{K/2}]
\rightarrow[x_1^0,x_2^0,x_3^0].
$$

近处先确定，远处仍能表达多种可能；若把整个未来都过早去噪成一条确定轨迹，规划容易依赖某个尚未发生的偶然结果。下图的采样路径应沿时间轴与噪声轴一起读，区别在于何时作出确定承诺。

![Diffusion Forcing usage 原图](../../assets/images/localized-remote/paper-deep-dives/diffusion/diffusion-forcing/diffusion-forcing-usage-原图.png){ width="920" }

<small>图源：`Diffusion Forcing` 官方项目页。原图表达：同一个 DF 模型可以通过不同噪声日程支持稳定自回归 rollout、因果不确定性、整段轨迹 guidance 和 corrupted observation conditioning。本站读法：把每个小图都当成“采样日程改法”，而不是四个新模型。</small>

生成长视频时，作者还用略带噪声的历史来更新 latent，避免把自己上一步生成的图像当成绝对可靠事实。训练本就见过带噪历史，因此推理可以在这一接口上降低错误积累。相同 RNN 架构的 teacher-forcing 与全序列扩散基线，使比较更集中于训练和采样方式。

![DMLab video prediction 原图](../../assets/images/localized-remote/paper-deep-dives/diffusion/diffusion-forcing/dmlab-video-prediction-原图.png){ width="760" }

<small>图源：`Diffusion Forcing` 官方项目页。DMLab 结果展示 DF 的视频预测样例，红框是 conditioning frames。</small>

![Minecraft video prediction 原图](../../assets/images/localized-remote/paper-deep-dives/diffusion/diffusion-forcing/minecraft-video-prediction-原图.png){ width="920" }

<small>图源：`Diffusion Forcing` 官方项目页。原图表达：DF 在 128x128 Minecraft 视频上的自回归预测样例。本站读法：沿时间检查视角、地形块和物体身份是否保持连续；它支撑长 rollout 稳定性，不支撑高分辨率真实视频生成能力。</small>

DMLab 与 Minecraft 的图从共同起始帧向远期读，观察场景连续性和视角移动，而非只看单帧锐度。原文展示到 1000 帧的滚动；这些示例支持长于训练窗口的稳定性，未提供“任意长度始终一致”的保证。[↗](https://arxiv.org/pdf/2407.01392#page=8)

## 从生成序列到闭环规划

规划将 token 定义为 $x_t=[a_t,r_t,o_{t+1}]$，包括动作、回报和下一观测。模型从历史状态生成未来 $H$ 步计划，执行第一步动作，收到环境实际反馈后更新状态并重新规划。$H$ 可改变，因而同一模型既能做短时低计算策略，也能做较长时域规划。

指导梯度可从未来目标通过因果状态传向较早动作；Monte Carlo Guidance（MCG）对可能的未来进行采样，以优化预期回报。它与保留远期噪声配合，使较早动作不只迎合一条虚构的未来轨迹。

Table 1 的迷宫结果包含一个容易忽视的动作接口差异。Diffuser* 用生成状态交给手工 PD 控制器；“Diffuser w/ diffused action”直接执行生成动作。后者明显变差，因此不能把这些列当作同一种控制方式。

| Environment | Diffuser* | Diffuser w/ diffused action | Ours w/o MCG | Ours |
| --- | ---: | ---: | ---: | ---: |
| Maze2D U-Maze | 113.9 ± 3.1 | 6.3 ± 2.1 | 110.1 ± 3.9 | 116.7 ± 2.0 |
| Maze2D Medium | 121.5 ± 2.7 | 13.5 ± 2.3 | 136.1 ± 10.2 | 149.4 ± 7.5 |
| Maze2D Large | 123.0 ± 6.4 | 6.3 ± 2.1 | 142.8 ± 5.6 | 159.0 ± 2.7 |
| Multi2D U-Maze | 128.9 ± 1.8 | 32.8 ± 1.7 | 107.7 ± 4.9 | 119.1 ± 4.0 |
| Multi2D Large | 132.1 ± 5.8 | 6.9 ± 1.7 | 129.8 ± 1.5 | 167.1 ± 2.7 |

这些是回报分数，不能写成成功率百分比。DF 在平均回报上领先，但 Multi2D U-Maze 的 119.1 低于 Diffuser* 的 128.9，因此“六项都超过所有基线”不符合表格。MCG 消融主要支持对多种未来进行指导的价值，动作直接执行结果则支持联合建模的因果一致性。[↗](https://arxiv.org/pdf/2407.01392#page=8)

## 机器人实验检验记忆，不只是生成动作

真实 Franka 任务要求用第三个槽位交换苹果和橙子的位置。初始布局随机，中间同一个观测可能对应两个不同目标，策略必须记住起点。下面先比较 Case A 与 Case B 的相同中间画面，再看目标为何不同；这是设计有记忆任务的关键。

![Robot imitation learning 原图](../../assets/images/localized-remote/paper-deep-dives/diffusion/diffusion-forcing/robot-imitation-learning-原图.png){ width="920" }

<small>图源：`Diffusion Forcing` 官方项目页，对应论文 Figure 4。原图表达：有记忆依赖的水果交换任务、生成视频预测和双相机观测。本站读法：先看任务为什么需要记住初始状态，再看 DF 如何把动作和未来观测绑在同一序列里；这张图支撑的是部分可观测控制，不是开放世界机器人泛化。</small>

论文报告 DF 成功率 80%，无记忆的 diffusion policy 在该任务失败。这个结果支持 recurrent latent 在特定长期模仿任务中的作用；同一模型生成视频的展示说明表示可复用，但不等价于机器人依靠视频预测进行了通用规划。[↗](https://arxiv.org/pdf/2407.01392#page=9)

实际迁移本文时，最值得复用的是三件连在一起的设计。独立 token 噪声使历史可信度可调；二维采样日程决定何时确定近远期动作；执行后用真实观测更新状态，避免把模型计划当成实际经历。其代价是去噪与规划仍要多次模型调用，长时域引导和 Monte Carlo 样本也增加推理预算，具体控制频率需要随动作接口另行测量。
