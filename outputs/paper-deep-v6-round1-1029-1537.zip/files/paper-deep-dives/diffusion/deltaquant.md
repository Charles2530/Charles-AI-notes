---
paper_date: 2026-06
paper_title: "DeltaQuant: 4-bit Video Diffusion Models with Spatiotemporal Delta Smoothing"
paper_topic: 扩散模型 / 视频生成量化
---

# DeltaQuant：视频扩散的 4-bit core-delta 量化

!!! info "论文信息"
    **论文题名：** DeltaQuant: 4-bit Video Diffusion Models with Spatiotemporal Delta Smoothing。<br>
    **作者：** Xingyang Li、Samuel Tesfai、Zhekai Zhang、Haocheng Xi、Shuo Yang、Lvmin Zhang、Yufei Sun、Kelly Peng、Maneesh Agrawala、Ion Stoica、Kurt Keutzer、Jun-Yan Zhu、Song Han、Yujun Lin、Muyang Li。<br>
    **机构：** MIT、Nunchaku AI、NVIDIA、UC Berkeley、Stanford、First Intelligence、CMU。<br>
    **时间 / 主题：** CVPR 2026；扩散模型、视频生成、低比特推理。<br>
    **CVF / 官方报告：** CVF Open Access：[paper HTML](https://openaccess.thecvf.com/content/CVPR2026/html/Li_DeltaQuant_4-bit_Video_Diffusion_Models_with_Spatiotemporal_Delta_Smoothing_CVPR_2026_paper.html)；PDF：[CVF PDF](https://openaccess.thecvf.com/content/CVPR2026/papers/Li_DeltaQuant_4-bit_Video_Diffusion_Models_with_Spatiotemporal_Delta_Smoothing_CVPR_2026_paper.pdf)。<br>
    **GitHub / 项目：** 本次未在 CVF 页面确认官方代码仓库；CVF 页面说明 code and models will be released upon publication，作者主页提供 Paper / Supp / Video 链接。<br>
    **元数据来源与核验口径：** 来源：CVF Open Access HTML、本地 PDF `Li_DeltaQuant_4-bit_Video_Diffusion_Models_with_Spatiotemporal_Delta_Smoothing_CVPR_2026_paper.pdf`、作者主页检索；Checked Date：2026-07-25；Repro Status：Paper / official metadata reviewed, independent reproduction not claimed。

## 注意力加速之后，线性层成为下一处瓶颈

DeltaQuant 研究视频 DiT 的权重与激活四比特量化。稀疏注意力和低比特 attention 已降低注意力成本，原文分析中线性层转而占优化后工作负载的 65%。仅压缩权重能减少显存，却未必加速计算密集的矩阵乘；要让消费级 GPU 更快生成视频，还需要量化激活。

难点在于视频去噪过程中，异常激活的通道与幅度会随时间改变，固定的通道 smoothing 很难同时适配全部步骤。DeltaQuant 改为利用每次前向实际出现的局部时空冗余，把共享的大幅度成分与细小差分分开。[↗](https://openaccess.thecvf.com/content/CVPR2026/papers/Li_DeltaQuant_4-bit_Video_Diffusion_Models_with_Spatiotemporal_Delta_Smoothing_CVPR_2026_paper.pdf#page=3)

下图比较 SVDQuant 与 DeltaQuant，先看 activation 如何被拆分。权重的低秩残差仍可沿用，本文新增的是随输入变化的 core-delta 分解。

![DeltaQuant 方法对比](../../assets/images/paper-deep-dives/diffusion/deltaquant/figure-2-svdquant-vs-deltaquant.png){ width="860" }

<small>图源：`DeltaQuant: 4-bit Video Diffusion Models with Spatiotemporal Delta Smoothing`，Figure 2。原图对比 SVDQuant 的 weight low-rank / residual decomposition 与 DeltaQuant 的 activation core / delta decomposition。</small>

## 时空相邻 token 共享异常成分

视频在时空上相邻的 token 往往有相似激活。下图分别看时间相邻帧和空间相邻 token；比较原值、均值、减均值后的残差。均值集中承载共同的大幅度结构，残差范围更小，因而低比特量化的动态范围更容易分配。

![DeltaQuant 时空相似性](../../assets/images/paper-deep-dives/diffusion/deltaquant/figure-5-spatiotemporal-similarity.png){ width="860" }

<small>图源：`DeltaQuant: 4-bit Video Diffusion Models with Spatiotemporal Delta Smoothing`，Figure 5。原图展示 Wan2.2 T2V activation 在连续帧与局部空间 token 上的相似性，以及减去平均 token 后 outlier 和方差变小。</small>

这不是假定整个视频都近似静止。方法将 $X\in\mathbb R^{N\times C_i}$ 先还原成 $T\times H\times W$ 网格，再分为小的 $t\times h\times w$ cubes。每个 cube 有独立 core，避免把距离很远、内容不同的 token 混合。

$$
\bar X^{(k)}=\frac1{thw}\sum_{n=1}^{thw}X_n^{(k)},
\qquad
\tilde X^{(k)}=X^{(k)}-\bar X^{(k)}.
$$

$\bar X^{(k)}$ 沿 token 广播。一个 cube 只保存一份高精度 core，所有 token 的 delta 用四比特。下图可以从六个 token、两个 cube 的例子入手，检查减去各自均值后极值如何缩小，再看共享 core 如何加回来。

![DeltaQuant 工作流](../../assets/images/paper-deep-dives/diffusion/deltaquant/figure-6-workflow.png){ width="620" }

<small>图源：`DeltaQuant: 4-bit Video Diffusion Models with Spatiotemporal Delta Smoothing`，Figure 6。原图用两个 cube 演示 mean core 与 delta token 的 mixed-precision quantization。</small>

## 三条计算支路如何还原线性层

忽略权重低秩分解时，矩阵乘近似为

$$
X^{(k)}W\approx
Q_8(\bar X^{(k)})Q_4(W)
+Q_4(\tilde X^{(k)})Q_4(W).
$$

$Q_8$ 与 $Q_4$ 分别为八比特、四比特量化。第一项只计算一个 core token，再广播到整个 cube，可视为输入相关的动态偏置；第二项处理大量 delta token，使用 FP4 Tensor Cores。core 分支用 FP8 Tensor Cores，因此“W4A4”并不表示每一个运算都只有四比特。

再结合 SVDQuant 的 $W=L_1L_2+R$，得到

$$
X^{(k)}W\approx X^{(k)}L_1L_2
+Q_8(\bar X^{(k)})Q_4(R)
+Q_4(\tilde X^{(k)})Q_4(R).
$$

低秩分支保留权重的重要结构，core 分支吸收当前输入的共享异常值，delta 分支承担主要低比特计算。三者解决不同误差来源。[↗](https://openaccess.thecvf.com/content/CVPR2026/papers/Li_DeltaQuant_4-bit_Video_Diffusion_Models_with_Spatiotemporal_Delta_Smoothing_CVPR_2026_paper.pdf#page=5)

内核实现决定这种分解能否真正提速。作者把 core 生成融合进 activation quantization，定制 core 的 W4A8 GEMM，并把其部分和累加融入 delta 的 W4A4 GEMM，减少中间张量与独立 kernel 启动。cube 越大，core 相对开销越小，但 token 相似性也降低，量化误差上升；选 cube 大小因此是误差与吞吐的折中。

## 质量保持与 BF16 相似性是两种指标

实验包括 Wan2.2 I2V/T2V 和 LTX-Video。Wan 为五秒 720p，T2V 77 帧、I2V 81 帧；LTX 为八秒 512p、121 帧。LPIPS、PSNR、SSIM 比较同种子 BF16 输出，Vision Reward 与 VBench 评价输出质量。

| Model / Method | LPIPS ↓ | PSNR ↑ | SSIM ↑ | Vision Reward ↑ |
| --- | ---: | ---: | ---: | ---: |
| Wan2.2 I2V / BF16 | — | — | — | 0.145 |
| Wan2.2 I2V / SVDQuant | 0.165 | 21.9 | 0.686 | 0.146 |
| Wan2.2 I2V / DeltaQuant | 0.128 | 23.2 | 0.742 | 0.143 |
| LTX T2V / SVDQuant | 0.193 | 20.1 | 0.714 | 0.130 |
| LTX T2V / DeltaQuant | 0.159 | 21.6 | 0.751 | 0.135 |

I2V 上 DeltaQuant 更接近 BF16，但 Vision Reward 0.143 略低于 SVDQuant 的 0.146；Wan T2V 的 DeltaQuant Vision Reward 为 0.083，也低于 BF16 0.091。质量保持应理解为多数指标接近、相似性改善，不是每项指标无损或全胜。GGUF W4A16 在部分相似性指标也很有竞争力，但激活未量化，速度机制不同。[↗](https://openaccess.thecvf.com/content/CVPR2026/papers/Li_DeltaQuant_4-bit_Video_Diffusion_Models_with_Spatiotemporal_Delta_Smoothing_CVPR_2026_paper.pdf#page=7)

## 111.8 倍来自整套优化，DeltaQuant 的增量约三倍

原文 Table 2 的 Wan2.2 I2V 链式实验如下。

| Configuration | Latency (s) ↓ | Speedup | Vision Reward ↑ |
| --- | ---: | ---: | ---: |
| Original | 4818 | 1.0× | 0.145 |
| + LightX2V | 196.8 | 24.5× | 0.144 |
| + Radial & Sage | 131.0 | 36.8× | 0.145 |
| + DeltaQuant | 43.1 | 111.8× | 0.148 |

因此 DeltaQuant 在已有少步和注意力加速之上带来的增量是 $131/43.1\approx3.04$ 倍，而 111.8 倍包含前面全部优化。峰值显存从图示的 61.3 GB 降到 26.8 GB，使 Wan2.2 能放进 32 GB RTX 5090；此时避免 CPU offload 也是部署价值的一部分。

![DeltaQuant 效率与消融](../../assets/images/paper-deep-dives/diffusion/deltaquant/figure-8-9-efficiency-ablation.png){ width="860" }

<small>图源：`DeltaQuant: 4-bit Video Diffusion Models with Spatiotemporal Delta Smoothing`，Figure 8 和 Figure 9。上半部分报告 Wan2.2 model size、inference memory 和 single-step latency；下半部分报告 cube size、low-rank rank、core precision 和 adaptive cube schedule 的消融。</small>

效率与 cube 消融图要先分模型存储、峰值运行显存、单步时间和整段视频时间，再看 cube 大小的质量曲线。低比特峰值吞吐不能直接推导整个 pipeline 加速，尤其不同分辨率、attention 实现和 offload 条件会改变瓶颈。

DeltaQuant 最适合具有局部时空相似性、线性层已经成为主要成本的视频 DiT。复用的关键不是只存一个低比特 checkpoint，而是保留时空 token 排列、动态计算 core，并部署对应融合内核。其收益依赖 FP4/FP8 硬件与实现；同样的分解搬到缺乏相关 Tensor Core 支持的设备上，未必获得表中的速度。
