---
paper_date: 2025-09
paper_title: "Coefficients-Preserving Sampling for Reinforcement Learning with Flow Matching"
paper_topic: 扩散模型
---

# CPS：Flow-RL 中的系数保持采样

!!! info "论文信息"
    **论文题名：** Coefficients-Preserving Sampling for Reinforcement Learning with Flow Matching。<br>
    **作者：** Feng Wang、Zihao Yu。<br>
    **机构：** CreateAI。<br>
    **时间 / 主题：** 2025-09；扩散模型 / Flow Matching / RL 采样。arXiv 当前版本为 v4，2025-12-08。<br>
    **适合读者：** 已了解 [Flow Matching 的基础采样与噪声日程](../../diffusion/noise-schedules-and-parameterization.md) 和 [PPO / GRPO](../../reinforcement-learning/policy-gradient-actor-critic-ppo-grpo.md) 基本概念，想理解随机 rollout 如何影响 reward 的读者。<br>
    **arXiv / 官方报告：** arXiv：[2509.05952](https://arxiv.org/abs/2509.05952)；PDF：[arxiv.org/pdf/2509.05952](https://arxiv.org/pdf/2509.05952)。<br>
    **GitHub / 项目：** GitHub：[github.com/IamCreateAI/FlowCPS](https://github.com/IamCreateAI/FlowCPS)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2509.05952)、[PDF](https://arxiv.org/pdf/2509.05952)、[官方代码仓库](https://github.com/IamCreateAI/FlowCPS)；Checked Date：2026-07-08；Repro Status：Paper + official code reviewed, independent reproduction not claimed。论文标注为 work in progress。

本文只追一个问题：Flow Matching 的 RL rollout 加入随机性后，怎样避免采样器把额外噪声带进 reward 输入？读完后，你应能检查少步 Flow-SDE 是否超出 scheduler 的噪声预算，判断更换 sampler 时是否必须同步调整 log-prob / KL，以及代理 reward 上升能否支持真实人评结论。

## 在线 RL 需要随机性，但噪声预算也要对得上

Flow Matching 的 ODE 采样是确定性的，而 GRPO 需要同一提示下的多个随机结果和可计算的转移概率。常见做法给 ODE 添加随机项，变成 SDE，再离散成有限步采样。CPS 发现，Flow-GRPO 与 Dance-GRPO 使用的有限步更新会给下一状态留下超过 scheduler 规定的噪声，少步和较强探索时尤其明显，奖励模型因而常在带噪伪影的图像上评分。[↗](https://arxiv.org/pdf/2509.05952#page=5)

下图先固定提示和随机强度比较 Flow-SDE 与 Flow-CPS，观察噪声颗粒是否随着探索增强而出现。问题在于采样分布偏离模型训练过的噪声水平，而不只是图像主观上“不够好看”。

![Flow-SDE 与 Flow-CPS 采样图像对比](../../assets/images/paper-deep-dives/diffusion/cps/figure-1-flow-sde-vs-cps.png){ width="920" }

<small>图源：[原论文，Figure 1](https://arxiv.org/abs/2509.05952)。</small>

## 用信号和噪声系数检查一次更新

Rectified Flow 使用 $x_t=(1-t)x_0+tx_1$，$x_0$ 是数据、$x_1$ 是标准高斯。网络预测速度 $\hat v$ 后，可还原两个端点估计

$$
\hat x_0=x_t-t\hat v,
\qquad
\hat x_1=x_t+(1-t)\hat v.
$$

设下一时间 $s=t-\Delta t$。Euler ODE 更新恰好为 $(1-s)\hat x_0+s\hat x_1$，信号系数和噪声系数与训练插值一致。若再加入新的独立高斯 $\epsilon$，总噪声应按方差相加，而非直接相加系数。

论文分析的 Flow-SDE 离散更新为

$$
x_s=(1-s)\hat x_0+
\left(s-\frac{\sigma_t^2\Delta t}{2t}\right)\hat x_1
+\sigma_t\sqrt{\Delta t}\epsilon.
$$

在把预测噪声视作单位方差、且与新噪声独立的假设下，总噪声方差为

$$
\sigma_{\mathrm{total}}^2
=s^2+\frac{(\sigma_t\Delta t)^2}{t}
+\left(\frac{\sigma_t^2\Delta t}{2t}\right)^2\ge s^2.
$$

非零随机性和有限步长下，多出来的两项不会消失。它是所分析离散化的误差，不能泛化为“所有连续 SDE 理论都错误”。下图分别比较 1000、16、4 步；步数减少时误差增大，端点附近还受到具体 $\sigma_t$ 日程的影响。

![Flow-SDE 噪声水平偏离 scheduler](../../assets/images/paper-deep-dives/diffusion/cps/figure-2-noise-level-mismatch.png){ width="920" }

<small>图源：[原论文，Figure 2](https://arxiv.org/abs/2509.05952)。</small>

## CPS 让旧噪声让出恰好的方差

CPS 保留信号系数 $1-s$，给新噪声分配标准差 $\sigma$，同时把旧噪声系数改成 $\sqrt{s^2-\sigma^2}$。为保证根号非负，采用角度参数化

$$
x_s=(1-s)\hat x_0
+s\cos\left(\frac{\eta\pi}{2}\right)\hat x_1
+s\sin\left(\frac{\eta\pi}{2}\right)\epsilon,
\qquad 0\le\eta\le1.
$$

两个独立噪声项的系数平方和恰好是 $s^2$。$\eta=0$ 回到确定性更新，$\eta=1$ 把当前噪声方向完全替换成新噪声。下图可先看噪声向量所在的圆，再看信号方向保持不变；它与 DDIM 的联系在于为新增随机性相应减少旧噪声，而不是直接往 ODE 输出上继续叠加。[↗](https://arxiv.org/pdf/2509.05952#page=6)

![CPS 与 DDIM 的几何直觉](../../assets/images/paper-deep-dives/diffusion/cps/figure-3-cps-geometry.png){ width="920" }

<small>图源：[原论文，Figure 3](https://arxiv.org/abs/2509.05952)。</small>

需要保留一个推导条件。模型预测的 $\hat x_1$ 只是在近似标准高斯，有限容量与误差可能使实际分布偏离；CPS 严格保持的是系数预算，而非保证每一步样本精确等于真实边缘分布。

## RL 实现同时改变了概率权重

标准高斯转移 log-prob 包含

$$
\log p_\theta(x_s\mid x_t)
=-\frac{\|x_s-\mu_\theta(x_t,t)\|^2}{2\sigma^2}
+\text{constant}.
$$

CPS 作者另外去掉 $2\sigma^2$ 分母，使用 $-\|x_s-\mu_\theta\|^2$ 作为优化中的 log-prob 形式，以避免末步极小方差造成不稳定，并改变早晚时间步的权重。它因此是一个优化替代形式，不再等于原高斯转移的完整归一化 log-prob。

这一区别直接影响实验归因。主结果同时改变采样规则和 log-prob 定义，不能把全部收益只归给系数保持；原文为 log-prob 另做附录消融。接入现有 GRPO 代码时也应同时核对 ratio、KL 与 timestep 权重，避免只替换采样式而假定目标完全不变。[↗](https://arxiv.org/pdf/2509.05952#page=10)

## 实验更强地支持收敛改善，而非所有最终分数都更高

实验在八张 A100 上，以 Flow-GRPO 和 Dance-GRPO 为基础，覆盖组合属性、OCR 和偏好奖励。部分主结果如下。

| Model / Task | Base | RL baseline | Flow-CPS |
| --- | ---: | ---: | ---: |
| FLUX.1-schnell / PickScore ↑ | 21.86 | 23.39 | 23.78 |
| FLUX.1-dev / PickScore ↑ | 22.06 | 23.90 | 24.25 |
| SD3.5-M / OCR ↑ | 0.579 | 0.966 | 0.975 |
| SD3.5-M / GenEval, w/ KL ↑ | 0.63 | 0.97 | 0.97 |

GenEval 最终打平，主要差别在达到高分的速度。下图 PickScore 要分开训练与评估线：dev 使用六步训练、28 步评估，schnell 均为四步，评估时不注入额外随机性。训练曲线起点差异首先可能来自采样图像更干净，后续确定性评估曲线才检验参数学习的收益。

![PickScore reward 曲线](../../assets/images/paper-deep-dives/diffusion/cps/figure-4-pickscore-curves.png){ width="920" }

<small>图源：[原论文，Figure 4](https://arxiv.org/abs/2509.05952)。</small>

GenEval 的图另比较是否 KL 正则。去掉 KL，两种方法都会退化或崩溃，表明更好的 sampler 不能替代约束奖励投机的训练设计；该任务作者使用 $\beta=0.001$。HPSv2 图只提供训练曲线及滑动平均，不能将它等同于每一步都有独立在线评估。

![GenEval 与 HPSv2 reward 曲线](../../assets/images/paper-deep-dives/diffusion/cps/figure-5-geneval-hpsv2-curves.png){ width="920" }

<small>图源：[原论文，Figure 5](https://arxiv.org/abs/2509.05952)。</small>

OCR 随 $\eta$ 的消融最直接检查探索强度。两种方法均在 $\eta=0.7$ 得到较好结果，而 $\eta=0.1$ 都不能良好收敛；CPS 的优势是可以保留有效随机性而不同时积累过量噪声。

![OCR reward 曲线](../../assets/images/paper-deep-dives/diffusion/cps/figure-6-ocr-reward-curves.png){ width="920" }

<small>图源：[原论文，Figure 6](https://arxiv.org/abs/2509.05952)。</small>

CPS 可作为 Flow Matching 在线 RL 的小型接口改动，尤其适合四至十几步采样预算。其实际收益是提高奖励输入质量和训练稳定性，不提供额外的通用奖励模型；最终模型仍可能针对 PickScore、OCR 或组合属性过拟合，具体任务需要以相应独立评估判断。
