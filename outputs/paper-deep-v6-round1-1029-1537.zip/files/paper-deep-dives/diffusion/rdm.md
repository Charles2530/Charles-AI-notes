---
paper_date: 2026-07
paper_title: "Representation Distribution Matching for One-Step Visual Generation"
paper_topic: 扩散模型
---

# RDM：用表征分布匹配训练一步视觉生成器

!!! info "论文信息"
    **论文题名：** Representation Distribution Matching for One-Step Visual Generation。<br>
    **作者：** Lan Feng、Wuyang Li、Éloi Zablocki、Matthieu Cord、Alexandre Alahi。<br>
    **机构：** EPFL、Valeo.ai、Sorbonne Université。<br>
    **时间 / 主题：** 2026-07；扩散模型与一步视觉生成。<br>
    **arXiv / 项目页：** [2607.02375](https://arxiv.org/abs/2607.02375)；[alan-lanfeng.github.io/rdm](https://alan-lanfeng.github.io/rdm/)。<br>
    **代码：** 论文项目页提供 GitHub 链接。<br>
    **元数据与核验口径：** 来源为 arXiv HTML、论文项目页；Checked Date：2026-09-07；Repro Status：Paper / project page reviewed, independent reproduction not claimed。

## 一步生成缺少的监督，究竟是哪一部分

RDM 研究的是一种直接路线。让生成器 $g_\theta(z)$ 一次产生图像，把生成图像与真实图像送进冻结编码器，然后比较两组特征的分布。如果这个比较足够准确、特征足够丰富，模型便不必沿着教师的去噪轨迹学习，也不需要一个在线对抗判别器。困难在于，“特征分布已经接近”可能只说明某个有限样本估计器或某个编码器被满足，并不代表图像已经可信。

论文把这两个问题分开。第一条轴是怎样比较分布，包括使用什么距离、怎样估计、真实参考是否每轮重新采样，以及条件任务比较边缘分布还是联合分布。第二条轴是在哪些表示里比较，以及多个编码器怎样分配权重。iRDM 是在这两条轴上组合出的具体方案，RDM 则是更一般的表示分布匹配框架。[原论文，第3—4页](https://arxiv.org/pdf/2607.02375#page=3)

它的实验主要是后训练：ImageNet从已发布的 pMF-H FD-SIM checkpoint 出发，文生图从四步 FLUX.2 [klein] 出发。因此“没有在线教师”描述本轮优化目标，不意味着模型没有继承已有生成器的训练成本或离线教师参考。

## 同一个 MMD，估计方式不同会产生不同生成行为

设冻结编码器为 $\phi$，输出特征的推前分布为 $\phi_*p$。基本目标是

$$
\mathcal L(\theta)=\mathcal D(\phi_*p_\theta,\phi_*p_{\mathrm{data}}).
$$

iRDM 选择高斯核的平方最大均值差异 MMD

$$
\operatorname{MMD}^2(P,Q)=\mathbb E_{u,u'\sim P}k(u,u')-2\mathbb E_{u\sim P,v\sim Q}k(u,v)+\mathbb E_{v,v'\sim Q}k(v,v'),
$$

$$
k(u,v)=\exp\left(-\frac{\|u-v\|_2^2}{2\sigma_\phi^2}\right).
$$

每个编码器用 median heuristic 确定一个带宽并固定下来。特征空间中的高斯核具有 characteristic 性质，理想总体 MMD为零对应特征分布相同。但从图像映射到特征可能丢失信息，所以这一步尚不能推出图像分布相同。

三项的作用很具体。真实—真实项对生成器参数是常数，可以从训练损失中去掉。生成—真实项带负号，鼓励生成点靠近真实数据；生成—生成项带正号，最小化它会阻止样本全挤在一起。后者是保持多样性的排斥机制，不能因为它涉及样本对就随意采用过于粗糙的近似。[原论文，第4页，式1—3](https://arxiv.org/pdf/2607.02375#page=4)

作者于是对两项采取不同的估计器。生成批量内部保留精确核矩阵；真实侧则使用全量训练数据预计算的冻结参考。令 $g_i=\phi(g_\theta(z_i))$，批量为 $B$，实际目标为

$$
\widehat{\mathcal L}_\phi=\frac1{B^2}\sum_{i,j}k(g_i,g_j)-\frac2B\sum_i\psi(g_i)^\top\bar\mu_\phi.
$$

第一项包含批量中所有 $i,j$，是论文采用的估计形式。第二项的 $\psi$ 是 Nyström 特征映射，$\bar\mu_\phi$ 是全量真实参考在这个映射下的均值。其优势并非计算一个“新的距离”，而是让每轮吸引都参照同一份较完整的数据分布，消除反复抽取少量真实样本带来的参考采样噪声。

## Nyström 把真实参考压缩在哪里

ImageNet设置下，作者在真实特征上用 k-means放置 $m=4096$ 个 landmarks $\ell_j$。设这些点的核矩阵为 $K_{mm}$，则

$$
\psi(u)=K_{mm}^{-1/2}[k(u,\ell_1),\ldots,k(u,\ell_m)]^\top,\qquad
\bar\mu_\phi=\frac1n\sum_{t=1}^n\psi(r_t),
$$

其中 $r_t$ 是真实训练图像的编码特征，$n=1.28$M。$\psi(u)^\top\psi(v)$ 近似原核，两者的内积使每轮生成样本与全量参考的比较降为 $O(Bm)$。精确的生成批量排斥仍是 $O(B^2)$；不能把吸引项的复杂度当作整个训练的复杂度。

这份参考是有限秩近似，并非无损保存所有真实图像。其关键取舍是将近似能力用在真实数据所在的区域。Random Fourier Features 使用覆盖整个环境空间的随机基，Nyström 的基由真实特征决定，在高维、低维流形集中的场景里更符合计算预算。固定参考消除了每步重抽真实样本的方差，但保留 landmarks和核近似的误差。

论文用嵌入64维空间的二维螺旋检验这些选择。生成器和预算保持一致，batch取8、32、128，比较 anchor recall 与到曲线的 median distance。batch128时，Nyström MMD的 recall为1.00、medDist为0.03，接近真实数据0.033；exact MMD为1.00／0.04，RFF MMD为0.98／0.11。小batch8时，Nyström仍有0.98／0.16，exact MMD为0.98／0.20。实验说明完整参考和数据相关近似在这个诊断任务中有效；它没有证明任意大规模数据上 Nyström必然胜过所有其他估计器。[原论文，第4—5页，Figure 3](https://arxiv.org/pdf/2607.02375#page=5)

## 真实侧可以冻结，生成侧必须保持新鲜

真实训练集不随参数变化，冻结它的统计量是合理的；生成分布每轮都在变化，旧生成样本队列会让当前参数接受过时分布的监督。iRDM因此每次重新生成大批量样本，并用 gradient caching 分块计算完整批量的梯度。这样缓解激活显存压力，同时保留跨样本分布估计，并没有消除大批量所需的总前向计算。

作者在相同 wall-clock预算下扫描批量，并按 $\sqrt N$ 缩放学习率。小批量带来的更多优化器更新不能弥补分布估计噪声；质量随批量增加改善，随后出现较宽的最优区域。最终 ImageNet使用 $N=5120$，FLUX后训练使用 $N=10240$。这里的证据是预算内的折中，不能只读成“batch越大越好”。[原论文，第6页，Figure 4](https://arxiv.org/pdf/2607.02375#page=6)

对于文生图，还有另一种更隐蔽的错误目标。生成器完全可以把总体图像分布做得很好，却忽视某个 prompt要求的数量、位置或属性。只比较图像边缘分布无法发现这种错配。作者将图像特征与冻结文本特征拼接

$$
\Phi(x,c)=\phi(x)\oplus\tau(c),\qquad
\mathcal L_{\mathrm{joint}}=\mathcal D(\Phi_*p_\theta,\Phi_*p_{\mathrm{data}}).
$$

生成图像必须与产生它的提示配对，参考图像也保留对应caption。此时核相似度同时受图像与文本影响，同一生成图像主要受到相似条件参考的吸引。原有估计器无需改写，只需把 landmarks建在联合特征空间里。[原论文，第6页，式4](https://arxiv.org/pdf/2607.02375#page=6)

## 十个编码器仍需要一种不会偷懒的权重规则

单一编码器的失效不是抽象警告。只优化 DINOv2，使用5120批量训练1000 steps，模型的 $\mathrm{SW}_{\mathrm{dino}}$ 从1.81降到1.01，真实验证参考为1.00。但样例中的打字机仍有明显不合理键盘结构。一个语义表征可以认为两批图像极接近，同时忽略人能看出的局部错误。

iRDM在十个冻结编码器上训练，希望不同表征的盲区互相补充。固定等权仍可能让模型优先改善最容易的空间，所以作者给每个编码器设置真实验证基准 $b_\phi$，以当前分数超额 $e_\phi=s_\phi-b_\phi$ 控制权重。达到或优于基准的编码器退出本轮约束；尚未满足的编码器通过 softmax分享固定总权重，超额越大权重越高。若全部达到基准，权重归零。[原论文，第6—7页](https://arxiv.org/pdf/2607.02375#page=6)

这种 proportional Lagrangian控制把训练压力放在尚未解决的表征上。Table 3的100步消融从同一 pMF-H起点出发，SWr14由2.09降至 gated weighting的1.88，uniform weighting为1.90；最差编码器距离从4.83分别降到3.49与4.06。平均指标改善不大，但最薄弱表示的差距更明显，符合控制器的设计目的。

多个编码器扩大约束范围，却仍不能无条件证明完整像素分布可辨识。原文对联合核的 characteristic描述应当结合映射保留信息的条件理解。经验上的多视角约束、理论上的特征分布匹配、完整图像分布相等，是三个不同强度的结论。

## ImageNet结果改变了评价口径，也保留了未满足的表示

主要评价 SWr14 对14个编码器分别计算 sliced-Wasserstein距离，再除以真实验证集对训练集的距离并取平均

$$
\mathrm{SWr}_k=\frac1k\sum_{e=1}^k
\frac{\mathrm{SW}(\phi_{e*}p_\theta,\phi_{e*}p_{\mathrm{train}})}{\mathrm{SW}(\phi_{e*}p_{\mathrm{val}},\phi_{e*}p_{\mathrm{train}})}.
$$

真实验证参考按定义为1。这是归一化参照，不是有限样本下不可能突破的数学下界；Table 1本身就有小于1的分项。评价使用16384样本和1024投影，与训练的核MMD估计器不同，另有四个编码器完全不进入训练。不同估计器与留出表征降低直接适配训练损失的风险，仍不能让指标免疫所有形式的优化偏差。[原论文，第7—8页](https://arxiv.org/pdf/2607.02375#page=7)

| Model | SWr14 ↓ | Held-out SWr4 ↓ |
| --- | ---: | ---: |
| Drifting-L | 5.93 | 4.91 |
| iMF-XL | 5.02 | 4.08 |
| REPA-E SiT-XL/1 | 2.40 | 2.14 |
| pMF-H FD-SIM | 2.05 | 1.98 |
| iRDM | 1.30 | 1.54 |
| Real validation reference | 1.00 | 1.00 |

iRDM从 FD-SIM起点训练4000 steps，学习率 $1.6\times10^{-6}$，每轮使用十个编码器。它显著改善整体和留出指标，但并非所有分项最优：起点在 Inception、ConvNeXt、MAE等空间甚至有更低数值。这与论文要避免“只把少数表征做到极低”的动机一致。

PickScore提供另一种模型代理评价。对同噪声、同类别的4000对样本，iRDM相对起点获71.2%的偏好率，平均PickScore20.61升到20.96；与真实图像参考比较为63.6%。这些数字由学习到的偏好模型给出，不是人类盲测，也不能推出生成图像总体比真实照片更真实。

## 文生图后训练的收益与离线参考成本

四步 FLUX.2 [klein] 被直接用一步生成器形式后，GenEval从0.794降到0.474。后训练恢复了大部分能力，联合条件目标进一步提升整体对齐。[原论文，第9页，Table 2](https://arxiv.org/pdf/2607.02375#page=9)

| Method | Steps | GenEval overall ↑ | PickScore ↑ |
| --- | ---: | ---: | ---: |
| FLUX.2 [klein] base | 4 | 0.794 | 22.58 |
| One-step initialization | 1 | 0.474 | 19.95 |
| DMD2 | 1 | 0.804 | 22.36 |
| iRDM, image marginal | 1 | 0.801 | 22.70 |
| iRDM, joint image–text | 1 | 0.826 | 22.76 |

联合目标使 two-object从边缘版本的0.899升至0.924，attribute binding从0.608升至0.708。不过 counting为0.756，仍低于四步教师0.791，整体提升不代表所有能力均超过教师。

训练使用约30万张一次收集并冻结的教师图像，包含按PickScore筛选的COCO生成图，以及经过检测器验证满足GenEval条件的样本，然后压缩成Nyström参考。因此文生图训练确实没有在线教师，却有离线教师生成和质量筛选；不能把ImageNet设置下“不直接优化PickScore”的描述扩大成整个系统完全没有使用偏好模型。后训练本身为180 steps，批量10240、学习率 $2.83\times10^{-6}$，约90 H200 GPU-hours，这个数字也没有替代基础模型和参考数据的前期成本。

iRDM最值得迁移的是估计器的拆分：生成侧使用新鲜大批量与精确排斥，真实侧使用全量冻结参考，条件信息进入联合分布，多种表征通过约束控制共同工作。它适合已有生成器、能够预计算参考并承担多编码器训练成本的场景。若只有一个容易饱和的编码器、很小的批量或错配的条件参考，单独套用MMD公式不足以获得论文中的质量。
