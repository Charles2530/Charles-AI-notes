---
paper_date: 2026-03
paper_title: "Attn-QAT: 4-Bit Attention With Quantization-Aware Training"
paper_topic: 高效训练
---

# Attn-QAT：4-bit Attention 量化感知训练

!!! info "论文信息"
    **论文题名：** Attn-QAT: 4-Bit Attention With Quantization-Aware Training。<br>
    **作者：** Peiyuan Zhang、Matthew Noto、Wenxuan Tan、Chengquan Jiang、Will Lin、Wei Zhou、Hao Zhang。<br>
    **机构：** 未在公开元数据中稳定解析；以 arXiv/PDF 或官方页 affiliation block 为准。<br>
    **时间 / 主题：** 2026-02；高效训练。<br>
    **arXiv / 官方报告：** arXiv：[2603.00040](https://arxiv.org/abs/2603.00040)。<br>
    **GitHub / 项目：** GitHub：未找到官方链接。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2603.00040)；Checked Date：2026-06-04；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 把 attention 压到 4 bit，误差会进入两个矩阵乘法

Attn-QAT 研究的是 attention 运算的量化，而不只是把模型权重保存为 4 bit。标准 attention 先计算 $QK^\top$，经过 Softmax 得到概率 $P$，再做 $PV$。当两次矩阵乘法都使用极低精度时，Q/K 的误差会改变注意力分布，P/V 的误差又会改变聚合结果。论文在 Wan 视频模型中观察到，直接替换为 FP4 attention 会明显损害画面与运动表现。

作者选择让模型在训练时适应误差。关键工作是把 quantization-aware training（QAT）正确嵌入 FlashAttention 的分块前后向：不仅前向要模拟推理的量化，反向重计算和 Softmax 梯度也必须与这个前向相匹配。[↗](https://arxiv.org/pdf/2603.00040#page=2)

先看原图中 BF16、直接低比特替换和 Attn-QAT 的视频对比。相同提示下的可见差异用于建立问题，但判断“恢复到什么程度”仍要结合后面的分项指标，而不能仅凭挑选的画面。

![Attn-QAT video quality comparison 原图](../../assets/images/paper-deep-dives/foundations/attn-qat/figure-1-video-quality.png)

## Fake quantization 让模型看到部署时的离散误差

设 $\phi$ 为量化，$\phi^{-1}$ 为反量化。训练使用

$$
X^F=\phi^{-1}(\phi(X))
$$

得到落在低比特可表达值附近、但以高精度数据类型承载的张量。前向在 Q、K、V 和 P 的对应位置插入 fake quantization，让模型经历未来推理时会遇到的舍入与缩放误差；反向通过直通估计等 QAT 约定传播梯度。

论文使用 NVFP4 的块量化：16 个元素共享 E4M3 缩放因子，元素采用 4-bit 表示。这个格式与 block size 为 32、使用 E8M0 scale 的 MXFP4 不相同。格式、分组、scale 的选择都属于数值计算的一部分，不能把“FP4”当成唯一确定的算子。[↗](https://arxiv.org/pdf/2603.00040#page=2)

主计算可概括为：

$$
S=\frac{Q^F(K^F)^\top}{\sqrt d},\qquad
P=\operatorname{softmax}(S),\qquad
O=P^F V^F.
$$

$d$ 是 attention head 维度。Softmax 保持高精度，低比特重点作用在矩阵乘法输入。训练 kernel 用 BF16 GEMM 配合 FP4 模拟，推理 CUDA kernel 才使用原生 FP4 GEMM。因此，“4-bit attention”不能理解成所有训练运算和梯度都在 4 bit 中完成。

## FlashAttention 反向有两个容易被忽略的不一致

### 重计算的 P 也必须经过量化

FlashAttention 不保存整个 $N\times N$ 的概率矩阵，而是在反向根据输入和前向保存的 log-sum-exp 重新计算。因此，如果前向 $PV$ 使用 $P^F$，反向却直接用未经量化的 $P$ 来计算 $dV$，两次使用的激活就不同。

对 $O=P^F V^F$，相关梯度包含

$$
dV=(P^F)^\top dO,\qquad dP=dO(V^F)^\top.
$$

Attn-QAT 在反向重新插入 P 的 fake quantization，确保用于相应矩阵乘法的激活精度与前向一致。它保留了不物化完整 P 的内存优势，同时修正重新生成激活的数值路径。

### Softmax 导数需要另一个输出 O′

对一行概率 $P_i$，Softmax 导数为

$$
dS_i=P_i\odot dP_i-(P_i^\top dP_i)P_i.
$$

其中 $P_i$ 是高精度 Softmax 的结果。FlashAttention 为避免保存完整行，利用内积关系计算标量 $P_i^\top dP_i$。但量化后，模型实际输出 $O_i=\sum_jP_{ij}^F V_j^F$ 不再满足所需恒等式。论文额外计算

$$
O'_i=\sum_jP_{ij}V_j^F,
\qquad
P_i^\top dP_i=dO_i^\top O'_i.
$$

于是反向的行归约使用 $D_i=\mathrm{rowsum}(dO_i\odot O'_i)$。$O'$ 中 P 未量化，V 仍是 $V^F$；它不是重新计算一遍全部高精度 attention，也不作为模型前向输出。[↗](https://arxiv.org/pdf/2603.00040#page=4)

这解释了为什么“低精度前向加现成 BF16 反向”并不是正确 QAT 的自动实现。原反向代码依赖的代数关系已经变了，即使张量形状和接口都不变，也需要检查其数学前提。

## 视频质量恢复了多少，哪些能力仍有差距

Wan 2.1 14B 的主表中，Overall Quality 提升不等于每个维度都恢复。以下保留总分与尤其能体现差异的 Dynamic Degree；数值是原表分数，越高越好。[↗](https://arxiv.org/pdf/2603.00040#page=5)

| Wan 2.1 14B | 额外 QAT | Overall Quality ↑ | Dynamic Degree ↑ |
| --- | --- | ---: | ---: |
| BF16 | 无 | 0.8335 | 0.5193 |
| FP4 直接替换 | 无 | 0.7968 | 0.2983 |
| SageAttention3 | 无 | 0.8203 | 0.4751 |
| Attn-QAT | 有 | 0.8279 | 0.3646 |

Attn-QAT 的综合分数更接近 BF16，但动态程度仍低于 BF16，也低于 SageAttention3。主体一致性等分项改善与运动幅度恢复不完全可以同时发生。因此，这张表支持在训练预算下明显恢复质量，不支持“所有指标无损”的更强结论。

作者还对 99 个 VBench 提示做人工评估。下面的图补充自动指标，比较人对视频质量的判断；它与 Dynamic Degree 的测量对象不同，不能用来抹掉分项差距。

![Attn-QAT human evaluation 原图](../../assets/images/paper-deep-dives/foundations/attn-qat/figure-2-human-eval.png)

训练成本也影响采用方式。Wan 1.3B 使用 16 张 B200，训练 4000 steps，约 12.5 小时，最终选择约 3000 step 的检查点；14B 使用 64 张 H200，结合序列并行，以 global batch 32 训练 400 steps，约一天。数据主要来自合成视频 latent，14B 实验使用约 13K 个 720P 示例。这里的恢复效果附带额外训练，不是完全免费的后处理。[↗](https://arxiv.org/pdf/2603.00040#page=11)

## 消融把“必须正确”与“有助稳定”分开

Wan 1.3B 的消融直接测试两个反向设计，而不是只比较最终模型。

| Wan 2.1 1.3B 配置 | Overall Quality ↑ | Dynamic Degree ↑ |
| --- | ---: | ---: |
| BF16 | 0.8267 | 0.3923 |
| FP4 直接替换 | 0.7785 | 0.1160 |
| Attn-QAT | 0.8252 | 0.3039 |
| 去掉反向所需的高精度 $O'$ | 0.7185 | 0.0331 |
| 去掉反向 P 的 fake quantization | 0.8254 | 0.2652 |

把 $O'$ 换成低精度 O 后，梯度和 loss 出现明显不稳定，质量大幅下降。去掉反向 P 的量化，综合分数却没有降低，甚至有极小上升；作者观察到的主要问题是梯度范数噪声更大。这两项消融支持不同强度的判断：前者对该训练设置十分关键，后者主要改善训练动态，不能声称二者一旦移除都会造成同样程度的崩溃。[↗](https://arxiv.org/pdf/2603.00040#page=6)

下面的图先看 Wan 的梯度范数，再对照 loss。只看最终 loss 容易忽略反向不一致带来的噪声；只看噪声也不能虚构一个原表没有出现的最终质量下降。

![Attn-QAT training dynamics 原图](../../assets/images/paper-deep-dives/foundations/attn-qat/figure-3-training-dynamics.png)

额外加入 K smoothing 或两级 P 量化没有带来一致的分项改善。这为减少推理预处理提供了实验依据，但范围是已经接受 QAT 的模型，而不是证明这些技巧对所有 PTQ 方法都无用。

## 语言模型验证的是适用范围，不是相同程度的恢复

作者在 Qwen3-14B 与 Llama 3.1-70B 上做 C4 continued training，以及 Dolci-Instruct SFT。前者测试低比特误差能否通过继续训练恢复；后者测试能否直接把 QAT 融合进常规 SFT，省掉单独的量化适应阶段。

| SFT 模型与精度 | MMLU-Redux ↑ | IFEval ↑ | GPQA-Diamond ↑ | MATH-500 ↑ |
| --- | ---: | ---: | ---: | ---: |
| Qwen3-14B BF16 | 0.8316 | 0.7107 | 0.4495 | 0.8060 |
| Qwen3-14B Attn-QAT | 0.8392 | 0.7306 | 0.4394 | 0.7840 |
| Llama 3.1-70B BF16 | 0.7928 | 0.8637 | 0.4091 | 0.5300 |
| Llama 3.1-70B Attn-QAT | 0.7823 | 0.8532 | 0.3838 | 0.5120 |

Qwen 的部分任务略升、部分下降；70B 在这些列中都存在差距。作者认为预算和超参数调节受限可能解释 70B 恢复不充分，但这是解释，不能替代更大预算实验。语言模型评估使用修改后的 vLLM paged attention 进行 NVFP4 模拟，也应与视频中原生 FP4 CUDA 部署区分。[↗](https://arxiv.org/pdf/2603.00040#page=7)

## 数值一致性与 kernel 加速是两项不同检查

训练用 fake quant，推理用原生 FP4；两者若存在明显偏差，训练适应的误差就可能失效。论文在同样提示下比较两种实现，下面的图显示视觉结果接近。这是部署一致性的证据，不是对所有输入逐元素完全相等的证明。

![Attn-QAT fake real quant comparison 原图](../../assets/images/paper-deep-dives/foundations/attn-qat/figure-4-fake-real-quant.png)

吞吐测试使用 RTX 5090、batch 16、16 个 attention heads，分别考察 head dimension 128 与 64。下图应在同一序列长度和 head dimension 内比较；测量包含输入预处理，因此减少 Q/K smoothing 和两级量化的开销会反映在结果里。

![Attn-QAT kernel throughput head dim 128 原图](../../assets/images/paper-deep-dives/foundations/attn-qat/figure-5-kernel-throughput-hdim128.png)

![Attn-QAT kernel throughput head dim 64 原图](../../assets/images/paper-deep-dives/foundations/attn-qat/figure-5-kernel-throughput-hdim64.png)

作者报告相对 SageAttention3 约 1.1–1.5 倍 attention 吞吐提升。这是该算子实现及测量边界下的收益，不能直接当作整段视频生成或 LLM 服务的加速倍数。[↗](https://arxiv.org/pdf/2603.00040#page=8)

Attn-QAT 给出的可复用经验是：量化不只改变存储格式，也会改变优化 kernel 内部依赖的代数恒等式。部署这条路线时，应先对齐 fake/real quant 的数值定义，再核对重计算和 Softmax 反向，最后把训练成本、分项质量与端到端收益放在同一份评估中。
