---
paper_date: 2025-09
paper_title: "SLA / SLA2: Sparse-Linear Attention for Diffusion Transformers"
paper_topic: 高效训练
---

# SLA / SLA2：DiT 稀疏线性 Attention

!!! info "论文信息"
    **论文题名：** SLA2: Sparse-Linear Attention with Learnable Routing and QAT。<br>
    **作者：** Jintao Zhang、Haoxu Wang、Kai Jiang、Kaiwen Zheng、Youhe Jiang、Ion Stoica、Jianfei Chen、Jun Zhu、Joseph E. Gonzalez。<br>
    **机构：** 未在公开元数据中稳定解析；以 arXiv/PDF 或官方页 affiliation block 为准。<br>
    **时间 / 主题：** 2026-02；高效训练。<br>
    **arXiv / 官方报告：** arXiv：[2602.12675](https://arxiv.org/abs/2602.12675)。<br>
    **GitHub / 项目：** GitHub：[github.com/thu-ml/SLA](https://github.com/thu-ml/SLA)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2602.12675)；[GitHub API / repo](https://github.com/thu-ml/SLA)；Checked Date：2026-06-04；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 少数大权重与大量小权重，需要不同的计算方式

视频 DiT 的 token 数可以达到数万乃至更多，完整 attention 的二次计算逐渐成为主要延迟来源。纯稀疏方法丢掉小权重，却很难在极高稀疏率下维持质量；纯线性 attention 便宜，但其低秩结构又难以表达少数尖锐、复杂的关注关系。SLA 把这两种缺点放到同一个注意力矩阵中分析，再让稀疏分支与线性分支分工。[↗](https://arxiv.org/pdf/2509.24006#page=3)

原文从 Wan 采样的例子中，约 8.1% 权重大于均值 $1/N$，约 45% 小于 $1/(100N)$。丢掉最小 45% 时，输出相对 L1 误差不到 3%；只留最大约 8% 时，误差升到约 33%。这解释了中间那一大批小权重的作用：每个都不大，合起来却不能直接忽略。

下面的图先看权重分布，再看相同矩阵在不同删除比例下的输出误差。这里的比例是采样实例，不是所有层和时间步共享的定律。

![SLA attention distribution 原图](../../assets/images/localized-remote/paper-deep-dives/foundations/sla-sparse-linear-attention/sla-attention-distribution-原图.png)

## SLA 的分解依据是“稀疏部分复杂，剩余部分低秩”

SLA 写出分解：

$$
P=P\odot M+P\odot(1-M),
$$

其中 $P$ 为完整 Softmax attention，$M$ 选择少量重要位置。这个恒等式本身不节省计算；节省来自后续用稀疏精确计算处理前一部分、用线性近似补偿后一部分。

下面的原图展示一个样本的 stable rank：完整矩阵约 6226，Top-8% 约 6230，Bottom-92% 约 9。应关注的是截去大权重后剩余结构明显更容易低秩表示。stable rank 是连续的有效秩度量，不能把这些数不加区分地当成严格代数秩。

![SLA attention decomposition 原图](../../assets/images/localized-remote/paper-deep-dives/foundations/sla-sparse-linear-attention/sla-attention-decomposition-原图.png)

这也说明为什么直接把所有注意力换成线性形式容易失败：少数大权重虽然数量少，仍保留复杂结构。另一方面，只计算这些大权重又缺少大量边缘信息。SLA 的核心假设是让两个分支承担各自较擅长的部分，而不是要求其中一个完整替代另一个。

## 第一代 SLA 如何把分工落实到 kernel

如果先算完整 P 再找重要位置，选择成本已经是二次的。SLA 先对 Q/K 沿 token 维度均值池化，得到块级代理：

$$
P_c=\operatorname{Softmax}\left(\frac{\operatorname{pool}(Q)\operatorname{pool}(K)^\top}{\sqrt d}\right).
$$

每行最高 $k_h\%$ 块为 critical，最低 $k_l\%$ 为 negligible，其余为 marginal。critical 块进入稀疏 FlashAttention，negligible 块跳过，marginal 块进入线性分支。均值池化只是低成本重要性估计，模型需要通过微调适应其误差。

对 query 块 $Q_i$，线性分支先聚合对应 marginal key/value 块：

$$
H_i=\sum_{j:M_c[i,j]=0}\phi(K_j)^\top V_j,\qquad
Z_i=\sum_{j:M_c[i,j]=0}\operatorname{rowsum}(\phi(K_j)^\top),
$$

$$
O_i^l=\frac{\phi(Q_i)H_i}{\phi(Q_i)Z_i},\qquad
O=O^s+\operatorname{Proj}(O^l).
$$

$H_i$ 为 $d\times d$，$Z_i$ 为 $d\times1$，避免在边缘部分逐个计算 query-key 对；$\operatorname{Proj}$ 是可学习线性映射。论文明确把它理解为对稀疏输出的可学习补偿，而不是保证精确重建原 P 的被删部分。[↗](https://arxiv.org/pdf/2509.24006#page=5)

下面的总览应沿 pooled Q/K、块分类、双分支和输出相加的顺序阅读。实际实现把两条路线融合，并提供反向 kernel，因而模型可以端到端微调，不局限于训练后替换。

![SLA overview 原图](../../assets/images/localized-remote/paper-deep-dives/foundations/sla-sparse-linear-attention/sla-overview-原图.png)

第一代主实验对 Wan2.1-1.3B 使用 2 万个约 5 秒、480p 视频，batch 64，微调 2000 steps；$k_h=5\%$、$k_l=10\%$，query/key block 均为 64，线性特征映射选用 Softmax。这些设置下的 95% 稀疏率指只有约 5% 块走昂贵分支，另外仍有线性计算和路由开销。

## 第一代实验检验的是质量与成本能否一起保住

| Wan2.1-1.3B 方法 | Imaging Quality ↑ | Overall Consistency ↑ | Subject Consistency ↑ | Vision Reward ↑ | FLOPs ↓ |
| --- | ---: | ---: | ---: | ---: | ---: |
| Full Attention | 62.5 | 23.3 | 93.0 | 0.059 | 52.75T |
| VMoBA，85% sparsity | 58.0 | 18.8 | 89.9 | -0.175 | 7.91T |
| VSA，89% sparsity | 60.6 | 22.4 | 83.6 | -0.069 | 5.92T |
| SLA，95% sparsity | 62.2 | 23.6 | 93.1 | 0.048 | 2.74T |

这里不同方法并非相同稀疏率。表格说明 SLA 在更低算量下保持接近完整 attention 的多个质量维度；仍有分项略低，因此不能把接近解释成严格无损。单独稀疏、单独线性以及简单叠加两者的消融，用来检验分工与融合是否有必要。[↗](https://arxiv.org/pdf/2509.24006#page=8)

下面的视觉比较应看主体结构、场景与运动的连续性，配合量化分数判断。图片无法完整呈现视频时间维度，不能仅根据单帧推断全部运动质量。

![SLA qualitative comparison 原图](../../assets/images/localized-remote/paper-deep-dives/foundations/sla-sparse-linear-attention/sla-qualitative-comparison-原图.png)

速度图给出另一个边界。RTX 5090 上，SLA 前向 kernel 相对 FlashAttention2 最高约 13.7 倍，反向约 6.8 倍；完整视频生成中的 attention 时间从 97 秒降到 11 秒，其余约 62 秒，整体约 $(97+62)/(11+62)=2.18$ 倍，对应论文报告的 2.2 倍。

![SLA efficiency 原图](../../assets/images/localized-remote/paper-deep-dives/foundations/sla-sparse-linear-attention/sla-efficiency-原图.png)

这组数字说明算子加速如何被其他计算限制。减少 95% 昂贵 attention 工作，并不意味着整模型也减少 95% 时间。

## SLA2 先修正两个分支的归一化关系

SLA2 进一步追问：稀疏 FlashAttention 输出是否真的等于 $P\odot M$ 对 V 的贡献？设

$$
P_1=P\odot M,\qquad \alpha=P_1\mathbf1.
$$

$\alpha$ 是每个 query 保留部分的概率质量。只在选中 key 上做 Softmax，会把它们重新归一化，因此得到的分布是 $P_s=P_1/\alpha$，其输出 $O_s=P_sV$。原分布中这一部分应贡献 $P_1V=\alpha\odot O_s$。第一代直接相加时，线性分支的投影既要补剩余信息，又要补尺度失配。

SLA2 因而改用

$$
O=\alpha\odot O_s+(1-\alpha)\odot O_l.
$$

推导中的 $\alpha$ 是原分布概率质量；实现中使用可学习的混合系数，减少直接计算完整 P 的需求。这个区别很重要：公式给出设计依据，并不意味着部署时已计算了昂贵的完整注意力。[↗](https://arxiv.org/pdf/2602.12675#page=3)

## 可学习路由与 QAT 共同扩大可用稀疏率

第二代把池化后的 Q/K 再经过可学习投影，使 Top-k 路由能把更适合低秩近似的部分交给线性分支，而不只是机械保留池化分数最大的块。初始化阶段用采集的 Q/K/V，对完整 attention 输出做 MSE 拟合，优化 router 与 $\alpha$。为穿过 Top-k 的离散选择，使用 SoftTop-k 代理；其逐行和约束保持选择预算。

随后进入端到端 diffusion 微调，使用硬 Top-k，并固定 router，更新模型参数与 $\alpha$。这避免把 SoftTop-k 训练时的软选择直接当作推理硬路由。SLA2 在稀疏分支引入 QAT，前向用低比特 attention，反向保持 FP16；它与 Attn-QAT 的 FP4 数值设计是不同实现，不能混用二者的梯度描述。

下面的 pipeline 应看路由、低比特 sparse 分支、linear 分支与混合权重分别在哪里产生。被排除的 key 不参与稀疏 Softmax；不能把原文简写 mask 运算误读成“把不可见位置的 logit 乘为零”，因为零 logit 仍会产生非零概率。

![SLA2 attention pipeline 原论文图](../../assets/images/localized-remote/paper-deep-dives/foundations/sla-sparse-linear-attention/sla2-attention-pipeline-原论文图.png)

## 第二代结果需要保持独立实验口径

SLA2 使用约 3000 个 5 秒视频、Qwen3-VL-Flash 生成 caption，微调 500 steps；1.3B/14B 的 batch 分别为 64/15，block size 为 $b_q=128,b_k=64$。这些数据与第一代主实验不同，所以不能直接把两篇表格的质量分数相减，声称所有增量都来自算法。

| SLA2 论文中的设置 | IQ ↑ | OC ↑ | AQ ↑ | SC ↑ | Vision Reward ↑ | FLOPs ↓ |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Wan1.3B Full Attention | 63.67 | 20.27 | 64.41 | 95.40 | 0.1084 | 52.75T |
| Wan1.3B SLA2，97% | 66.64 | 21.42 | 64.62 | 94.83 | 0.1039 | 1.82T |
| Wan14B Full Attention | 68.01 | 22.44 | 64.66 | 95.93 | 0.1238 | 292.6T |
| Wan14B SLA2，97% | 66.93 | 21.12 | 65.14 | 94.42 | 0.1149 | 9.26T |

高稀疏率下仍保留较好的整体质量，但 14B 的 OC、SC、Vision Reward 等低于完整模型。完整基线在该表中未接受相同额外训练，部分分项超过基线也不能全归因于稀疏机制。[↗](https://arxiv.org/pdf/2602.12675#page=6)

消融中移除 QAT、改用普通 Top-k router 都损害多个质量指标，支持它们共同作用。效率上，论文报告约 18.6–18.7 倍前向 kernel 加速；1.3B 的完整生成约 2.30 倍，14B 约 4.35 倍。14B 超出单张 RTX 5090 显存，测试使用 CPU offloading，而报告延迟排除了 offloading 开销，所以 4.35 倍不能直接当成含数据搬运的用户实际等待时间改善。[↗](https://arxiv.org/pdf/2602.12675#page=7)

两代方法合起来给出一个清楚的设计演进：先通过稀疏加线性补偿找到可微调的高稀疏计算，再修正概率质量分配、学习路由并叠加量化。采用时最该检查的是自己的 attention 是否具有类似结构、是否能承担适应训练，以及节省后的 attention 是否仍是整模型瓶颈。
