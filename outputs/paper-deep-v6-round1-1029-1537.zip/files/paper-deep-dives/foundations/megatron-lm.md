---
paper_date: 2019-09
paper_title: "Megatron-LM: Training Multi-Billion Parameter Language Models Using Model Parallelism"
paper_topic: 高效训练
---

# Megatron-LM：Tensor Model Parallel 的大模型训练栈

!!! info "论文信息"
    **论文题名：** Megatron-LM: Training Multi-Billion Parameter Language Models Using Model Parallelism。<br>
    **作者：** Mohammad Shoeybi、Mostofa Patwary、Raul Puri、Patrick LeGresley、Jared Casper、Bryan Catanzaro。<br>
    **机构：** 未在公开元数据中稳定解析；以 arXiv/PDF 或官方页 affiliation block 为准。<br>
    **时间 / 主题：** 2019-09；高效训练。<br>
    **arXiv / 官方报告：** arXiv：[1909.08053](https://arxiv.org/abs/1909.08053)；官方材料：[docs.nvidia.com/megatron-core/developer-guide/latest/api-guide/tensor_parallel.html](https://docs.nvidia.com/megatron-core/developer-guide/latest/api-guide/tensor_parallel.html)。<br>
    **GitHub / 项目：** GitHub：[github.com/NVIDIA/Megatron-LM](https://github.com/NVIDIA/Megatron-LM)；项目页：[docs.nvidia.com/megatron-core/developer-guide/latest/api-guide/tensor_parallel.html](https://docs.nvidia.com/megatron-core/developer-guide/latest/api-guide/tensor_parallel.html)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/1909.08053)；[GitHub API / repo](https://github.com/NVIDIA/Megatron-LM)；[官方 / 项目材料](https://docs.nvidia.com/megatron-core/developer-guide/latest/api-guide/tensor_parallel.html)；Checked Date：2026-06-04；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 把一个 Transformer 层拆开时，先找可以延后同步的位置

Megatron-LM 的方法建立在一个简单观察上：矩阵可以沿不同维度分片，但后续非线性是否允许局部计算，决定了分片究竟能省多少通信。论文为 Transformer 的 MLP 和多头注意力选择相互配合的切分方式，使每个块内部连续完成两个大矩阵乘法，把归约放在块的边界。[↗](https://arxiv.org/pdf/1909.08053#page=4)

这解决了数据并行的单卡容量限制。数据并行把样本分开，每卡仍保存完整参数与优化器状态；本文的层内模型并行把同一个层的参数和计算分给多个 GPU。它与按层划分的流水线并行可以组合，但本文的关键机制发生在一个层内部。

先沿 Figure 2 找出 attention 和两层 MLP。并行设计需要保留残差路径、归一化和 dropout 的数值语义，而不能只拆最昂贵的 GEMM。

![Transformer 中模型并行进入的计算块](../../assets/images/paper-deep-dives/foundations/megatron-lm/figure-2-transformer-architecture.jpeg){ width="420" .atlas-figure-tall }

图源：Megatron-LM，Figure 2。每个块输出回到完整隐藏状态，块内中间维度则分布在各 GPU。

## MLP 为什么采用先按列、再按行的切分

令 $X$ 为输入，$A$ 和 $B$ 为 MLP 两层权重。第一层计算

$$
Y=\operatorname{GeLU}(XA).
$$

若沿输入维度切分，使 $XA=X_1A_1+X_2A_2$，就必须在 GeLU 之前求和。由于

$$
\operatorname{GeLU}(X_1A_1+X_2A_2)
\ne \operatorname{GeLU}(X_1A_1)+\operatorname{GeLU}(X_2A_2),
$$

直接让两张卡各算非线性再相加，会改变模型本身。它们必须先同步得到完整的线性输出，这多出一个通信点。

论文改为按输出列分割 $A=[A_1,A_2]$。每张卡收到相同的 $X$，独立计算

$$
Y_i=\operatorname{GeLU}(XA_i),\qquad Y=[Y_1,Y_2].
$$

GeLU 逐元素作用，所以不同输出列之间没有依赖。第二层权重随之按行分割，各卡直接使用自己的 $Y_i$，计算局部贡献 $Z_i=Y_iB_i$，最后归约

$$
Z=\sum_i Z_i.
$$

这些式子对应论文公式 1–3 与 Figure 3a 的矩阵分解。$A_i$ 负责产生一部分扩展通道，$B_i$ 把这一部分通道对最终输出的贡献投影回来；第二层的求和恢复完整 MLP 输出。

![MLP 的列并行与行并行配对](../../assets/images/paper-deep-dives/foundations/megatron-lm/figure-3a-mlp-model-parallel.png){ width="760" }

图源：Megatron-LM，Figure 3a。先看两卡之间在 GeLU 前后是否出现箭头，再看输出处的 $g$。省掉的同步来自分片维度与非线性的配合。

用形状看更直观。若 $X$ 为 $[S,H]$，中间宽度为 $4H$，两路切分后每卡保存 $A_i\in\mathbb R^{H\times2H}$ 和 $B_i\in\mathbb R^{2H\times H}$。中间激活 $Y_i$ 只有一半宽度，而局部输出 $Z_i$ 形状都为 $[S,H]$。这最后两个同形张量相加，才是下一模块使用的完整结果。

## Attention 沿 head 切分，把输出投影留到最后归约

多头注意力提供了天然的独立计算单元。Q、K、V 投影按列划分，使完整的某些 heads 位于同一张卡上。每卡可以完成自己的 attention scores、softmax 和 value 加权，不需要在 head 内跨卡交换中间结果。

最后的输出线性层按行切分，接收本卡的 attention heads，得到对完整隐藏状态的局部贡献，再 all-reduce。它与 MLP 的配对结构一致：块内独立，块末求和。

![多头注意力的局部计算与输出归约](../../assets/images/paper-deep-dives/foundations/megatron-lm/figure-3b-attention-model-parallel.png){ width="820" }

图源：Megatron-LM，Figure 3b。应沿 Q/K/V 到输出投影的箭头看，每个 attention head 的完整计算留在同一个分片内。

这也解释了切分粒度的限制。增加张量并行度会减小每卡矩阵，但通信次数不会随矩阵同比下降；局部 GEMM 太小或跨越较慢互联后，更多 GPU 可能主要增加等待。模型并行度因此受隐藏维度、head 数和通信拓扑共同约束。

## 前向与反向如何保持一致

论文用两个互为配对的操作标记通信。

| Operator | Forward | Backward |
| --- | --- | --- |
| $f$ | identity | all-reduce |
| $g$ | all-reduce | identity |

$f$ 前向把同一个输入交给多个分支，反向将这些分支对输入的梯度相加。$g$ 前向汇总局部输出，反向让每个分支取得对应的输出梯度。这个安排依据计算图中的复制与求和关系，不能把每个位置都随意换成双向 all-reduce。

![一个 Transformer 层的前后向通信](../../assets/images/paper-deep-dives/foundations/megatron-lm/figure-4-forward-backward-operators.png){ width="820" }

图源：Megatron-LM，Figure 4。MLP 与 attention 各需要一次前向归约和一次反向归约，合计每层前向两次、反向两次。这个计数对应本文结构，不代表所有后续 Megatron 配置都只有这些通信。

输出后的 dropout 还需要一致的随机语义；分片 attention 内的随机数与复制残差路径上的随机数，不能简单使用同一种独立播种策略。复现时，应同时比较单卡与并行实现的输出、损失和梯度，而不仅检查 loss 能否下降。

## 词表并行避免收集巨大的 logits

语言模型的输出维度是词表大小 $v$。如果先 all-gather 全部词表 logits，再计算交叉熵，需要传输约 $bsv$ 个元素，$b$ 为 batch，$s$ 为序列长度。论文沿词表维度切分共享的输入/输出 embedding，并把输出 GEMM 与交叉熵融合，使需要交换的量缩小到每个 token 对应的标量级，而不收集整张 logits 表。[↗](https://arxiv.org/pdf/1909.08053#page=5)

这种优化利用的是最终消费者的需求：训练损失需要正确计算 softmax 归一化与目标 token 的概率，并不要求把所有词的 logits 放到每卡上。它比单纯把大矩阵切开更进一步，连同下游操作一起选择通信形式。

## 数据并行与模型并行使用不同的通信组

论文大规模配置采用 8 路模型并行与 64 路数据并行，总计 512 张 V100。一个模型并行组协作处理同一批输入；不同组处理不同数据。数据并行归约则连接不同模型副本中拥有同一参数分片的进程。

![模型并行与数据并行的分组](../../assets/images/paper-deep-dives/foundations/megatron-lm/figure-8-hybrid-mp-dp.png){ width="760" }

图源：Megatron-LM，Figure 8。看图时固定一块参数，沿它在各副本上的位置寻找 DP group；再固定一份输入，寻找共同处理它的 MP group。

这两个组不能混用。前者汇总同一参数在不同样本上的梯度，后者恢复同一样本的层内计算。使用错误的 group 有时仍能产生形状正确的张量，却不再等价于原训练目标。

## 扩展性实验与模型能力实验各自证明了什么

首先看 Figure 1 的应用级 FLOPS，再看 Figure 5 的弱扩展效率。单 GPU 基线是 1.2B 模型，约 39 TFLOPS；8.3B 模型在 512 GPU 上达到约 15.1 PFLOPS。按 $15.1\times10^{15}/(512\times39\times10^{12})$ 计算，效率约为 75.6%，与论文摘要的 76% 一致。

![应用级 FLOPS 随 GPU 数变化](../../assets/images/paper-deep-dives/foundations/megatron-lm/figure-1-flops-scaling.png){ width="820" }

图源：Megatron-LM，Figure 1。

![模型规模随设备扩大的弱扩展实验](../../assets/images/paper-deep-dives/foundations/megatron-lm/figure-5-weak-scaling.png){ width="780" }

图源：Megatron-LM，Figure 5。这里模型规模也随设备数变化，因此 76% 不能解释为同一个固定模型用 512 张卡获得了线性强扩展。论文的互联配置包括节点内 NVSwitch 和节点间多路 InfiniBand，改变这些条件需要重新测量。

其次，Figure 6 检验更大模型是否产生有效的语言建模收益。它比较不同规模模型的 validation perplexity，而非仅报告 GPU 利用率。

![不同规模 GPT 类模型的验证困惑度](../../assets/images/paper-deep-dives/foundations/megatron-lm/figure-6-validation-perplexity.png){ width="760" }

图源：Megatron-LM，Figure 6。曲线支持扩大模型可以改善本文训练设置下的验证损失；下游评测进一步检查这种改善是否转化为任务能力。

| Model / evaluation | Reported result | Interpretation |
| --- | ---: | --- |
| GPT-like 8.3B, WikiText103 | 10.8 perplexity | 数值越低越好 |
| GPT-like 8.3B, LAMBADA | 66.5% accuracy | 上下文词预测能力 |
| BERT-like 3.9B, RACE | 90.9% accuracy | 微调后的阅读理解结果 |

这些结果说明该系统能够完成有用的大模型训练。它们同时受数据、模型规模和训练方案影响，不能用作层内并行本身提高准确率的消融证据。

## 为什么训练稳定性也进入了系统论文

BERT 类模型放大后，原有 LayerNorm 与残差安排出现训练退化。作者调整其位置，使更大模型能够稳定训练。Figure 7 对比的就是这一结构变化对训练损失的影响。

![BERT 中归一化与残差位置的影响](../../assets/images/paper-deep-dives/foundations/megatron-lm/figure-7-bert-layernorm-residual.png){ width="820" }

图源：Megatron-LM，Figure 7。并行系统解决“算得动”，归一化安排解决“规模放大后学得好”，两个问题需要分别验证。

训练配方同样属于结果的条件。GPT 类实验使用 300k iterations，学习率从 warmup 后的 $1.5\times10^{-4}$ 余弦衰减到 $10^{-5}$；BERT 类实验采用 batch 1024、$10^{-4}$ 学习率、10k warmup，并使用 sentence order prediction 与 whole-word n-gram masking。不能只搬用 GPU 数与 hidden size，就声称复现了论文模型。

## 这项设计留下的通用方法

Megatron-LM 最可复用的是一种分解顺序：先确定每个算子的输入输出语义，再选择分片维度，把能够连续进行的局部计算放在一起，直到完整结果确实被下游消费时才同步。

采用时可先用小张量检查 MLP 的分解等式及前后向梯度，再测试真实形状的 GEMM 与 collective。之后才决定并行度、设备分组和 batch。现代训练栈加入流水线、序列并行或状态分片后，仍应重新画出这张通信与状态图；本文 2019 年的通信计数不能代替新实现的时间线。
