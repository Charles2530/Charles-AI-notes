---
paper_date: 2019-10
paper_title: "ZeRO: Memory Optimizations Toward Training Trillion Parameter Models"
paper_topic: 高效训练
---

# ZeRO：数据并行真正浪费的是训练状态副本

!!! info "论文信息"
    **论文题名：** ZeRO: Memory Optimizations Toward Training Trillion Parameter Models。<br>
    **作者：** Samyam Rajbhandari、Jeff Rasley、Olatunji Ruwase、Yuxiong He。<br>
    **机构：** 未在公开元数据中稳定解析；以 arXiv/PDF 或官方页 affiliation block 为准。<br>
    **时间 / 主题：** 2019-10；高效训练。<br>
    **arXiv / 官方报告：** arXiv：[1910.02054](https://arxiv.org/abs/1910.02054)；官方材料：[www.microsoft.com/en-us/research/publication/zero-memory-optimizations-toward-training-trillion-parameter-models/](https://www.microsoft.com/en-us/research/publication/zero-memory-optimizations-toward-training-trillion-parameter-models/)。<br>
    **GitHub / 项目：** GitHub：未找到官方链接；项目页：[www.microsoft.com/en-us/research/publication/zero-memory-optimizations-toward-training-trillion-parameter-models/](https://www.microsoft.com/en-us/research/publication/zero-memory-optimizations-toward-training-trillion-parameter-models/)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/1910.02054)；[官方 / 项目材料](https://www.microsoft.com/en-us/research/publication/zero-memory-optimizations-toward-training-trillion-parameter-models/)；Checked Date：2026-06-15；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 训练显存为什么远大于权重文件

ZeRO 处理的是数据并行训练中的状态冗余。每张卡计算不同样本，却各自保留相同的参数、梯度和优化器状态。增加 GPU 可以处理更多数据，但只要每卡仍保存完整模型状态，单卡装不下的问题就不会消失。ZeRO 把这些状态的所有权分给数据并行进程，并根据计算需要传递参数和梯度，使集群显存能够共同承担同一模型。[↗](https://arxiv.org/pdf/1910.02054#page=2)

先把显存账算清。记参数数量为 $\Psi$，论文采用 FP16 参数、FP16 梯度和混合精度 Adam。除低精度权重之外，每个参数还需要 FP32 主权重，以及 Adam 的一阶、二阶统计量。

| State | Bytes / parameter | Why it is needed |
| --- | ---: | --- |
| FP16 parameters | 2 | 前向与反向计算 |
| FP16 gradients | 2 | 当前训练步的更新信号 |
| FP32 master parameters | 4 | 在较高精度下累计参数更新 |
| FP32 momentum | 4 | Adam 一阶统计量 |
| FP32 variance | 4 | Adam 二阶统计量 |
| Total model states | 16 | 尚未包含激活与临时缓冲 |

因此这一配置下的模型状态为 $16\Psi$ 字节。一个 7.5B 参数模型的低精度权重只有 15 GB，训练模型状态却要约 120 GB。这里使用十进制 GB；换成其他优化器、梯度精度或主权重实现，需要重新列账，不能机械套用每参数 16 字节。

论文另外把激活、临时缓冲和碎片归为 residual states。这个分类决定了后面的两条工作线：ZeRO-DP 分割模型状态，ZeRO-R 处理其余占用。只解决第一类，长序列训练仍可能被激活撑满。

## 三个阶段实际改变了哪些对象

Figure 1 应从每行保留的彩色块读起。Stage 1 只改变优化器状态的所有权；Stage 2 进一步让每卡只长期保留自己负责的梯度；Stage 3 再让参数按需出现。计算过程需要的完整参数与长期驻留的参数份额，是两个不同概念。

![ZeRO 三阶段的模型状态分片](../../assets/images/paper-deep-dives/foundations/zero/figure-1-zero-dp-stages.png){ width="860" }

图源：ZeRO，Figure 1。下表按同一混合精度 Adam 假设重写图中的显存关系，$N_d$ 为数据并行度。

| Configuration | Model-state memory per device | $\Psi=7.5$B, $N_d=64$ |
| --- | --- | ---: |
| Standard DP | $16\Psi$ | 120 GB |
| $P_{os}$ | $4\Psi+12\Psi/N_d$ | 31.41 GB |
| $P_{os+g}$ | $2\Psi+14\Psi/N_d$ | 16.64 GB |
| $P_{os+g+p}$ | $16\Psi/N_d$ | 1.875 GB |

表中数值由公式直接计算。它们是模型状态下界，不是包括运行时峰值的 GPU 容量要求。例如 Stage 3 临时收集当前层的完整权重时，实际占用会高于长期分片的 1.875 GB。

### Stage 1：只有拥有者更新这一段参数

每张卡仍用完整 FP16 参数完成自己的前向和反向。优化器状态按参数索引分片，每个进程只保存并更新自己负责的主权重、动量和方差。各分片得到一致的全局梯度后独立更新，随后交换更新后的参数，供下一步计算使用。

这种安排保留了 Adam 的数学更新，仅改变状态放在哪里、由谁执行。它节约的是原来各卡重复保存的 12 字节优化器状态。随着 $N_d$ 增大，这部分趋于零，但完整参数和梯度的 $4\Psi$ 仍然存在，因此模型状态节省趋近 4 倍。

### Stage 2：梯度归约到负责更新的进程

如果某段参数只由一个进程更新，就不需要所有进程都长期保留该段完整梯度。反向生成的梯度可以通过 reduce-scatter 汇总并分发到相应拥有者；不属于本进程的梯度用完即可释放。更新后再 all-gather 参数。

这一阶段的常驻模型状态是

$$
M_{os+g}=2\Psi+\frac{14\Psi}{N_d}.
$$

第一项是完整 FP16 参数，第二项是分片梯度与优化器状态。通信和反向计算的执行顺序会影响梯度桶的瞬时占用，公式不能替代显存时间线。

### Stage 3：按层取得参数，计算后释放

Stage 3 连完整参数副本也不再长期保留。到某层前向或反向时，进程收集计算所需的参数；用完后释放不归自己所有的份额。每张卡仍处理自己的数据，矩阵计算也不因此自动变成张量并行的局部矩阵乘法。[↗](https://arxiv.org/pdf/1910.02054#page=11)

这说明 ZeRO 与张量并行能够组合：前者主要改变数据并行组内的状态驻留，后者把一次层内计算分给多个设备。组合时要同时检查数据并行组、张量并行组和每一步通信发生的位置。

## 为什么前两阶段能省显存而不增加通信量

论文用带宽受限的大张量通信模型分析通信体积。标准数据并行的 all-reduce 可以分解为 reduce-scatter 和 all-gather，每部分约移动 $\Psi$ 个元素，总计约 $2\Psi$。

Stage 2 将这两部分安排到不同对象上。先对梯度执行 reduce-scatter，拥有者更新，再 all-gather 参数，仍约为

$$
V_{os+g}=\Psi+\Psi=2\Psi.
$$

Stage 3 需要在计算期间重新取得参数，论文分析约为 $3\Psi$，相对标准数据并行增加 50%。这个 1.5 倍是该调度模型中的元素通信量比例；它没有包含每次 collective 的启动成本、网络拓扑差异与通信计算重叠程度。[↗](https://arxiv.org/pdf/1910.02054#page=13)

因此，Stage 3 的选型问题是：分片参数所释放的显存，能否换来足够有价值的模型规模、batch 或序列长度，同时使参数收集的成本可接受。参数本来已经放得下时，更多分片不必然更快。

## 模型状态降下来以后，剩余显存如何处理

ZeRO-R 的三项优化分别针对不同的生命周期。

**Partitioned activation checkpointing（分片激活检查点）**利用张量并行组中的激活冗余。保存检查点时分片，反向需要重算时 all-gather 恢复。论文以 100B 模型、batch 32、序列长度 1024、16 路模型并行为例，检查点占用约从 33 GB 降到 2 GB；这些值属于具体配置，不能直接套到任意 Transformer。必要时还能将检查点卸载到 CPU，但要支付传输成本。

**Constant-size buffers（固定大小缓冲）**限制通信和优化器融合缓冲随模型无限增长。大的缓冲有利于带宽利用，却也可能占去大量显存；例如 3B 参数的 FP32 整体缓冲就是 12 GB。固定大小的分桶使额外空间与模型大小脱钩。

**Memory defragmentation（内存去碎片）**则针对长寿命检查点、梯度与短寿命临时张量交错分配的情况。论文通过预分配连续空间等方式减少碎片，让“总空闲内存足够”更有机会转化为一次大分配成功。[↗](https://arxiv.org/pdf/1910.02054#page=12)

## 容量、吞吐与扩展实验回答不同问题

读 Figure 2 时先固定模型规模，比较 ZeRO 与基线的吞吐，再观察规模增加后基线是否被迫跨节点做模型并行。论文的优势来自分片让模型并行留在高带宽节点内部，以及省出的显存改善计算配置。

![ZeRO 与基线的训练吞吐](../../assets/images/paper-deep-dives/foundations/zero/figure-2-throughput-speedup.png){ width="760" }

图源：ZeRO，Figure 2。作者报告在 400 张 V100 上训练 100B 参数模型时，每卡超过 38 TFLOPS，聚合超过 15 PFLOPS，相对同规模基线超过 10 倍。这是完整系统配置的比较，不能归因为某一种 collective 单独快了 10 倍。

论文主要实测实现称为 **ZeRO-100B**，由 $P_{os+g}$ 与 ZeRO-R 组成，配合模型并行支持最高 170B 规模。完整 Stage 3 对万亿参数的支持在本文中主要是容量与通信分析。把标题中的“trillion”理解为已完整训练万亿参数模型，会混淆理论可装载性和实测系统。[↗](https://arxiv.org/pdf/1910.02054#page=4)

接着看容量图与最大显存分配图。前者回答旧系统装不下的配置能否运行，后者解释新增空间来自哪里；二者需要与吞吐结果一起看。

![可支持的模型规模](../../assets/images/paper-deep-dives/foundations/zero/figure-6-max-model-size.png){ width="760" }

图源：ZeRO，Figure 6。

![运行中的最大显存分配](../../assets/images/paper-deep-dives/foundations/zero/figure-7-max-cache-allocated.png){ width="760" }

图源：ZeRO，Figure 7。

作者还报告 60B 模型在 64–400 GPU 区间出现超线性扩展。更多进程降低每卡状态占用，允许增大每卡 batch，从而提高计算效率。这一解释也限定了结果的使用方式：它没有证明固定每卡 batch、固定模型和固定运行配置时，通信越多越能超线性加速。

## 把论文变成训练配置的判断方法

采用 ZeRO 前，先记录参数、梯度、优化器状态和激活各自的峰值。若主要压力来自优化器状态，Stage 1 就可能足够；若梯度也占用显著，Stage 2 有直接收益；若参数本身构成瓶颈，才需要评估 Stage 3 的参数取得与释放。

长上下文任务还应单独测激活检查点和 attention 工作区。推理中的 KV cache 不属于本文的混合精度 Adam 账本。模型状态节省也不自动降低训练 FLOPs；它首先改变可运行的模型、batch 和并行配置，再通过这些改变影响吞吐。

可复用的核心认识是把三个问题分开计算：**谁拥有状态、何时需要完整状态、为了取得它要传多少数据。** 沿这三个问题检查显存与通信时间线，比只比较 Stage 编号更接近实际训练效率。
