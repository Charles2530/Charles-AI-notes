---
paper_date: 2025-02
paper_title: "GPU Utilization is a Misleading Metric"
paper_topic: 高效训练
---

# GPU Utilization：为什么 100% 不等于训练跑满

!!! info "论文信息"
    **论文题名：** GPU Utilization is a Misleading Metric。<br>
    **作者：** Trainy。<br>
    **机构：** Trainy。<br>
    **时间 / 主题：** 2025-02；高效训练。<br>
    **arXiv / 官方报告：** arXiv：未找到专门条目；官方材料：[www.trainy.ai/blog/gpu-utilization-misleading](https://www.trainy.ai/blog/gpu-utilization-misleading)。<br>
    **GitHub / 项目：** GitHub：未找到官方链接；项目页：[www.trainy.ai/blog/gpu-utilization-misleading](https://www.trainy.ai/blog/gpu-utilization-misleading)。<br>
    **元数据来源与核验口径：** 来源：[官方 / 项目材料](https://www.trainy.ai/blog/gpu-utilization-misleading)；Checked Date：2026-06-04；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 训练卡一直忙，为什么模型仍然慢

Trainy 在为一家基础模型公司优化训练时，已经做过数据加载、混合精度、融合优化器和硬件选型等常规调整。监控显示 GPU utilization 达到 100%，功耗也很高，但按模型吞吐计算的 MFU 只有约 20%。这篇工程文章要解释的就是这个落差：设备持续执行任务，并不意味着训练任务正在有效使用它的计算能力。[↗](https://www.trainy.ai/blog/gpu-utilization-misleading)

文章的价值在于提供一条诊断路径。先弄清监控指标的分母，再用 profiler 找出具体算子的瓶颈，最后验证算子替换和并行策略有没有缩短训练时间。它没有提出新的网络或优化器，也没有把客户案例做成可以统一复现实验条件的完整 benchmark。

## GPU utilization 测的是时间，不是算力份额

文章引用的 NVML 定义是，过去一个采样周期内，GPU 上有一个或多个 kernel 正在执行的时间占比。可以用下面这个解释性表达式理解它：

$$
U_{\mathrm{GPU}}=\frac{\text{采样周期内至少一个 kernel 执行的时间}}{\text{采样周期总时长}}.
$$

这个定义不含参与工作的 SM 数，不含每条指令完成了多少浮点运算，也不含读写内存和计算之间的比例。因此，一个持续执行但只使用少量 SM 的 kernel，或者一直搬运数据的 kernel，都可能把这个指标推到 100%。

先看 GH100 的整体结构图。需要注意的是图里的完整芯片结构与具体商品启用的单元数不同：文章使用 144 SM 的 GH100 示意图，而后面的计算以启用 132 SM 的 H100 为例。不能把两个数字当成同一个硬件配置的规格。

![GH100 SM overview 原图](../../assets/images/paper-deep-dives/foundations/gpu-utilization-misleading/figure-1-gh100-sms.png)

再看单个 SM。它管理线程执行，并包含不同类型的执行与存储资源。启动一个 CUDA kernel，只说明有工作被交给 GPU；是否有足够线程块分布到各个 SM、线程是否等待内存、Tensor Core 是否得到合适的矩阵运算，仍是后续问题。

![H100 single SM 原图](../../assets/images/paper-deep-dives/foundations/gpu-utilization-misleading/figure-2-h100-sm.png)

文章给出的极端例子很有用：假设一个 kernel 连续运行 10 秒，却只占用 H100 的一个 SM。时间口径的 GPU utilization 可以是 100%，按活跃 SM 比例理解的活动率则只有 $1/132\approx0.76\%$。这个例子说明指标可以同时为真，并不存在监控系统自相矛盾。

## 把“忙”拆成几种可定位的问题

几个经常被混用的指标回答不同问题。这里的区别决定了下一步应该查数据输入、算子实现，还是通信等待。

| 指标 | 它回答的问题 | 单独使用时不能推断什么 |
| --- | --- | --- |
| GPU utilization | 采样时间里是否有 kernel 执行 | 所有 SM 是否充分工作、有效 FLOPs 是否高 |
| SM activity / efficiency | 有多少 SM 在相应时间窗口内活跃 | 每个活跃 SM 的算术单元是否达到峰值 |
| Achieved occupancy | 驻留活跃 warp 相对硬件容量处于什么水平 | 更多驻留 warp 是否必然减少运行时间 |
| MFU | 模型有效计算吞吐相对所选硬件峰值达到多少 | 某个具体算子慢在哪里 |
| 内存相关利用率 | 内存接口或带宽的忙碌程度 | 模型计算吞吐是否高 |

MFU 通常需要模型计算量、实际吞吐和所用精度对应的峰值。把它展开成一个便于核算的形式，可写为：

$$
\mathrm{MFU}=\frac{F_{\mathrm{model/token}}\times \mathrm{tokens/s}}{N_{\mathrm{GPU}}\times F_{\mathrm{peak/GPU}}}.
$$

这里的分子是按同一模型口径统计的有效计算，分母是全部 GPU 在相应数值精度下的理论峰值。模型规模、序列长度、重计算是否计入、稀疏峰值是否被误用，都会改变这个比值。横向比较时，先对齐口径比先比较百分数更有意义。文章提到的常见 35%–45% MFU 是其 2025 年写作背景下的经验范围，不是所有模型和硬件的合格线。

## 从 Softmax 找到可以实际替换的算子

Trainy 接着检查 PyTorch Profiler。下面这张原图应先看 Softmax 对应的时间与 SM efficiency：设备整体持续繁忙，但具体 kernel 对计算资源的使用很有限。这把排查范围从“整台 GPU 为什么慢”缩小到 Transformer 内的具体算子。

![PyTorch Profiler SM efficiency 原图](../../assets/images/paper-deep-dives/foundations/gpu-utilization-misleading/figure-3-pytorch-profiler-sm-efficiency.webp)

对朴素注意力而言，单独物化注意力分数、执行 Softmax、再读出概率做加权求和，会产生大量中间张量读写。此时，即使算子已被充分并行化，运行时间也可能主要花在数据移动上。低 SM efficiency 是排查线索，但不能仅凭它就把所有问题都归因于线程数量不足。

融合 kernel 的作用，是把连续操作放进同一次设备侧执行，尽可能让中间结果停留在更靠近计算单元的存储中。FlashAttention 是这一路线在注意力中的例子；文章还替换了 MLP，以及 dropout、layer normalization、residual add 等组合。对这些层，减少中间读写、启动开销和临时张量，能够减少每个训练 step 的实际耗时。

下面的图按 Transformer block 的数据流阅读：哪些相邻操作被包进同一块，才是性能变化的来源。它不意味着任意相邻算子都可以无条件融合；替换实现仍需要满足输入形状、数值语义和反向传播要求。

![Kernel fusion 原图](../../assets/images/paper-deep-dives/foundations/gpu-utilization-misleading/figure-4-kernel-fusions.webp)

这次优化主要复用了现有库中的实现，而不是重新写全部 CUDA。实际接入工作在于找到模型里对应的模块，替换后比较输出、梯度和稳定吞吐。文章对 `torch.compile` 与 FSDP、graph break 的讨论描述的是发表时的使用经验；具体框架版本是否仍有这些限制，需要以当前 workload 的编译结果判断。

## 结果支持哪些结论

文章报告客户训练获得约 4 倍加速，MFU 从约 20% 提高到 38%。作者把主要收益归于融合 kernel，以及按照模型大小和 3.2 Tbps InfiniBand 网络调整模型并行程度。[↗](https://www.trainy.ai/blog/gpu-utilization-misleading)

这两个数字不能相互推导。在模型计算量、设备数量和峰值口径完全相同的前提下，$38/20=1.9$ 对应的是有效吞吐提高约 1.9 倍。文章没有给出足以把全部优化阶段对齐的客户配置，因此 4 倍总加速与这组 MFU 变化应作为各自口径的报告结果保留，不能把它们拼成一个未经说明的算式。

同样，文章没有逐项消融融合算子和并行策略，所以不能分配“FlashAttention 贡献多少倍、MLP 贡献多少倍”。它确实支持一个较窄但很实用的结论：100% GPU utilization 下仍可能有大量优化空间，算子级剖析能找出这些空间，而端到端训练时间负责确认改动是否有效。

对实际训练系统，可以复用这条顺序：先看 step time 和模型吞吐是否稳定，再检查设备空闲与通信等待；对持续忙碌但 MFU 低的区间，定位耗时算子及其 SM、内存行为；接入已有融合实现或调整并行策略后，用同样的数据、batch、精度与硬件配置复测。最终目标是更快完成相同训练工作，而不是单独把某个监控百分数推高。
