---
paper_date: 2025-04
paper_title: "MagiAttention: A Distributed Attention Towards Linear Scalability for Ultra-Long Context, Heterogeneous Mask Training"
paper_topic: 高效训练
---

# MagiAttention：超长上下文分布式 Attention

!!! info "论文信息"
    **论文题名：** MagiAttention: A Distributed Attention Towards Linear Scalability for Ultra-Long Context, Heterogeneous Mask Training。<br>
    **作者：** SandAI。<br>
    **机构：** SandAI。<br>
    **时间 / 主题：** 2025-04；高效训练。<br>
    **arXiv / 官方报告：** arXiv：未找到专门条目；官方材料：[sandai-org.github.io/MagiAttention/docs/main/blog/magi_attn.html](https://sandai-org.github.io/MagiAttention/docs/main/blog/magi_attn.html)。<br>
    **GitHub / 项目：** GitHub：[github.com/SandAI-org/MagiAttention](https://github.com/SandAI-org/MagiAttention)；项目页：[sandai-org.github.io/MagiAttention/docs/main/blog/magi_attn.html](https://sandai-org.github.io/MagiAttention/docs/main/blog/magi_attn.html)。<br>
    **元数据来源与核验口径：** 来源：[GitHub API / repo](https://github.com/SandAI-org/MagiAttention)；[官方 / 项目材料](https://sandai-org.github.io/MagiAttention/docs/main/blog/magi_attn.html)；Checked Date：2026-06-04；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 长上下文的困难从“装不下”转向“分不匀”

把一段超长序列分到多张 GPU，只解决了每张卡保存多少 token。真正执行 attention 时，计算量由 query 能看到多少 key 决定。完整注意力、因果注意力、多个样本拼接后的变长注意力，以及视频的 block-causal mask，可能让长度相同的两段 query 承担完全不同的工作量。

MagiAttention 把问题同时落到四个环节：mask 如何表示和交给 kernel、query 如何分配、需要的张量如何传输，以及计算和通信如何重叠。它的目标是对异构 mask 保持精确注意力语义，同时改善超长上下文的分布式效率。增加 GPU 数并不会把稠密 attention 的数学复杂度变成线性；标题中的 linear scalability 指分布式扩展表现。[↗](https://sandai-org.github.io/MagiAttention/docs/main/blog/magi_attn.html)

先沿总览图读一次完整流程：全局 mask 被转换为可分配的工作，调度器生成计算与通信元数据，设备上的 attention kernel 与通信原语按阶段共同执行。单独替换其中一个环节，未必能消除另一环节造成的等待。

![MagiAttention overview 原图](../../assets/images/paper-deep-dives/foundations/magiattention/figure-1-overview.png)

## 为什么 Ring 的均匀切分会遇到异构 mask

Ring Attention 让本地 query 留在设备上，把 key/value 沿设备环流转，利用当前块计算来覆盖下一块的通信。完整 mask 下，各张卡通常有相近的计算量。但因果 mask 下，序列开头的 query 看到的 key 较少，末尾看到的较多；按顺序均分 token，容易形成一部分卡已结束、另一部分仍在算的局面。

zigzag 分配通过搭配序列前后位置改善规则因果 mask 的负载。但多个长度不同的样本打包后，mask 成为多个大小不同的区域；为每个样本套同样策略会增加碎片、padding 和调度复杂度。再加入视频块之间的可见性，固定切分更难同时满足计算均衡和 kernel 连续访存。

下面的图应比较不同 mask 下每个 rank 获得的有效区域面积，而不仅是条带宽度。面积近似反映注意力需要计算的 query-key 对数；同样多 token 并不保证同样多有效区域。

![Ring-Attention load balance 原图](../../assets/images/paper-deep-dives/foundations/magiattention/figure-2-ring-attention-load-balance.png)

此外，把所有 KV 块都送遍整个环，在稀疏可见性下会传输某些 rank 根本用不到的数据。负载失衡与冗余通信又会破坏计算通信重叠，因此需要一起处理。

## AttnSlice 把不规则 mask 变成可执行工作

Flex-Flash-Attention（FFA）使用三元组描述一个可执行子区域：

$$
\mathrm{AttnSlice}=(\mathrm{QRange},\mathrm{KRange},\mathrm{MaskType}).
$$

`QRange` 与 `KRange` 指连续的 query、key 区间，`MaskType` 描述该区域内部的可见性。复杂 mask 被拆成多个这样的单位，跨 rank 重排后仍可重新组合成合法的 kernel 输入。这里的切片描述的是允许参与 attention 的位置，不是额外学习出来的近似稀疏结构。

下图的重点是重分配前后的等价表示。相同的有效区域可以换一种切片组合，而不需要把整个全局 $N\times N$ mask 物化到每张 GPU。

![AttnSlice 原图](../../assets/images/paper-deep-dives/foundations/magiattention/figure-3-attnslice.png)

再看 mask 示例。标准 full/causal/varlen 只是其中一部分；对视频等工作负载，多块组合能表达普通规则接口不容易直接描述的区域。

![Mask patterns 原图](../../assets/images/paper-deep-dives/foundations/magiattention/figure-4-mask-patterns.png)

FFA 建立在 FlashAttention 的分块计算思路上，在 Hopper 路线上利用 FA3 与 TMA，并支持 slice 级并行。不同 slice 可能贡献到同一输出或梯度，必须正确合并。尤其是跨 key 子集的前向输出，不能把分别归一化后的结果直接相加；需要结合局部归一化统计量得到全局一致的 attention。原文的调度因此同时传递 partial output 与 LSE 等信息。

下面的前向/反向示意应沿数据加载、片上计算、归约三个阶段看。灵活 mask 的价值只有在这些操作仍保持高吞吐时才能兑现。

![FFA kernel 原图](../../assets/images/paper-deep-dives/foundations/magiattention/figure-5-ffa-kernel.png)

## Dispatch 同时约束 token 数与注意力面积

全局序列沿 query 维度切成 $n$ 个 chunk，$C_i$ 的有效 mask 面积为 $\mathrm{Area}(C_i)$。调度器把它们分到 $p=\mathrm{cp\_size}$ 个 bucket，希望最慢设备的计算量尽量小，同时每个 bucket 拥有相同数量的 chunk：

$$
f^*=\arg\min_f\max_j\{\mathrm{SumArea}(B_j)\},\qquad
|B_j|=\frac{n}{p}.
$$

实现还要求序列长度能够按 `cp_size × chunk_size` 整除。面积约束改善 attention 的工作量，chunk 数约束则照顾非 attention 层的 token 负载。如果只最小化面积，一张卡可能拿到很多“便宜”的 query，随后在 MLP 等层反而成为瓶颈。

这个组合分配问题不能在每个 micro-batch 上昂贵求解。项目采用排序与 Min-Heap 的贪心近似，给出的复杂度为 $O(n\log n)$。下面的调度图展示的是如何逐步向 bucket 分配工作，而不是能够保证任意 mask 下取得全局最优的证明。

![Dispatch solver 原图](../../assets/images/paper-deep-dives/foundations/magiattention/figure-6-dispatch-solver.png)

分配完成后，attention solver 生成两组接口数据。`CalcMeta` 告诉 FFA 每个 rank、每个阶段应计算哪些 slice；`CommMeta` 描述所需张量来自哪里、发送给谁以及部分梯度如何归约。这样 kernel 不需要自己理解整个训练任务的全局布局。

静态 solver 的重要条件是：micro-batch 的全局 mask 在数据处理阶段已经确定，并在各 attention 层及前后向中保持不变。它采用 KV 通信、Q/O 留本地的调度。官方文档还介绍了允许 Q/O 通信的动态调度方向，但将相应 dynamic solver 标为开发中的能力；不能据此把所有运行时生成的动态稀疏 mask 都视为已经具备同样支持。

## GroupCast 与 GroupReduce 只传递实际需要的数据

对于一个 KV 块，目标 rank 集合由 mask 决定。GroupCast 把块发给真正需要它的设备；反向传播的 GroupReduce 把这些设备产生的局部 dKV 加回拥有者。这比“每个块经过所有设备”更贴合不规则 attention 的数据依赖。

先看 Ring 的冗余示意：对于因果 mask，靠前 KV 可能被大量 query 需要，而靠后 KV 可能仅被本地使用。原文示例中，简单因果 mask 的冗余约 25%，带特殊全局块的不规则 mask 可超过 33%。这些是对应示例布局的通信比例，不是所有训练配置共有的常数。

![Ring P2P redundancy 原图](../../assets/images/paper-deep-dives/foundations/magiattention/figure-7-ring-p2p-redundancy.png)

下面的 GroupCast/GroupReduce 图应把前向发送表与反向归约表对应起来：同一个需求关系，前向分发激活，反向回收梯度。

![GroupCast and GroupReduce 原图](../../assets/images/paper-deep-dives/foundations/magiattention/figure-8-group-collectives.png)

“Zero-redundant”描述的是按需求选择接收者，不代表零通信或零额外开销。基于 AlltoAll-v 的初版需要 Range-Gather、Range-Scatter-Reduce 等预处理和后处理；相同数据发往多个 peer 还可能需要多份发送 buffer。官方后续的 native CUDA 路线进一步去掉这些拷贝，并针对跨节点 RDMA 传输去重。因而逻辑通信量减少与实际链路耗时降低，需要分别衡量。

## 多阶段重叠为什么仍需实际调参

前向先算本地可用块，并预取下一阶段远端 KV；后续阶段把当前 FFA 计算与下一阶段 GroupCast 重叠。反向更复杂，同时涉及下一阶段 KV、当前梯度计算、上一阶段 dKV 归约。

下图中先跟踪同一阶段的数据，再看相邻阶段的时间交叉。流水线头尾总会有不能完全覆盖的部分，且是否真正重叠还受 GPU 资源占用和执行顺序影响。

![Multi-stage overlap 原图](../../assets/images/paper-deep-dives/foundations/magiattention/figure-9-multi-stage-overlap.png)

`overlap_degree` 决定远端工作拆成多少阶段。拆得太粗，通信可能盖不住；拆得太细，kernel 启动和小块处理开销又会增加。官方文档建议实际试验常用的 1、2、3、4，并说明自动搜索依赖准确的计算通信比例估计，可能不如手动调参。这个工程限制直接影响采用方式：不能只开启 overlap 开关，就假定所有硬件和 micro-batch 都有相同收益。

## 性能图应该按硬件、方向与 mask 分别读

项目给出 H100 与 B200 上 varlen causal mask 的分布式性能比较。阅读每组图时，应保持同一硬件、同一前向或反向方向，并沿相同横轴配置比较方法。前向快不自动代表训练总时间快，因为反向多了梯度生成和归约。

![H100 forward 原图](../../assets/images/paper-deep-dives/foundations/magiattention/figure-10-h100-forward.png)

![H100 backward 原图](../../assets/images/paper-deep-dives/foundations/magiattention/figure-11-h100-backward.png)

H100 两图用于观察 Hopper 路线在扩展设备规模与上下文时如何保持吞吐。需要把相对基线的差异与 mask 带来的负载、通信差异联系起来，不能只取一处最高比值作为全部任务的加速倍数。

![B200 forward 原图](../../assets/images/paper-deep-dives/foundations/magiattention/figure-12-b200-forward.png)

![B200 backward 原图](../../assets/images/paper-deep-dives/foundations/magiattention/figure-13-b200-backward.png)

B200 图还涉及后端适配。官方文档说明原 FFA 基于 Hopper FA3，Blackwell 路线使用 FFA_FA4 等适配。因此，跨硬件图的数值不是仅更换设备而其余软件完全不变的对照。[↗](https://sandai-org.github.io/MagiAttention/docs/main/blog/magi_attn.html)

MagiAttention 最值得复用的是把 mask 视为调度输入。采用时先写清实际可见性和是否跨层变化，再选择 solver、chunk 大小和通信实现，最后分别测试 kernel、分布式 attention 与完整训练 step。对长上下文系统，精确语义、可均衡的工作划分、按需通信和真实重叠共同决定收益；任何一项都不能由“序列已分到多张卡”替代。
