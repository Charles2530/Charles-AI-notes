---
paper_date: 2025-02
paper_title: Muon is Scalable for LLM Training
paper_topic: 高效训练
---

# Muon：LLM 预训练优化器

!!! info "论文信息"
    **论文题名：** Muon is Scalable for LLM Training。<br>
    **作者：** Jingyuan Liu、Jianlin Su、Xingcheng Yao、Zhejun Jiang、Guokun Lai、Yulun Du、Yidao Qin、Weixin Xu、Enzhe Lu、Junjie Yan 等（共 28 人）。<br>
    **机构：** Moonshot AI 2 UCLA。<br>
    **时间 / 主题：** 2025-02；高效训练。<br>
    **arXiv / 官方报告：** arXiv：[2502.16982](https://arxiv.org/abs/2502.16982)；官方材料：[huggingface.co/moonshotai/Moonlight-16B-A3B](https://huggingface.co/moonshotai/Moonlight-16B-A3B)。<br>
    **GitHub / 项目：** GitHub：[github.com/MoonshotAI/Moonlight](https://github.com/MoonshotAI/Moonlight)；项目页：[huggingface.co/moonshotai/Moonlight-16B-A3B](https://huggingface.co/moonshotai/Moonlight-16B-A3B)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2502.16982)；[GitHub API / repo](https://github.com/MoonshotAI/Moonlight)；[官方 / 项目材料](https://huggingface.co/moonshotai/Moonlight-16B-A3B)；Checked Date：2026-06-04；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 这篇报告把 Muon 推向大规模训练时补了什么

Muon 已经提出对梯度动量做矩阵正交化。本文关注它在数十亿参数、万亿 token 和分布式训练中是否仍然有效，给出的关键补充是权重衰减、按矩阵形状对齐更新尺度，以及保持完整矩阵语义的分布式实现。Moonlight 则用大规模 MoE 训练检验这些选择。[↗](https://arxiv.org/pdf/2502.16982#page=2)

需要分别理解两类收益。小模型 scaling-law 实验比较达到相同语言模型损失所需的 FLOPs；Moonlight 与同配方 AdamW baseline 的比较检验下游能力。前者约 52% 的计算需求是拟合结果，不能直接换算为任意集群的训练时间减半。

## 更新矩阵怎样从动量得到

普通动量把历史梯度累积起来。论文以 $M_t$ 表示动量，$W_{t-1}$ 表示权重，$\mu$ 为动量系数，$\eta_t$ 为学习率，其 Muon 基本形式为

$$
\begin{aligned}
M_t&=\mu M_{t-1}+\nabla L_t(W_{t-1}),\\
O_t&=\operatorname{NewtonSchulz}(M_t),\\
W_t&=W_{t-1}-\eta_t O_t.
\end{aligned}
$$

实际实现使用 Nesterov-style momentum，把 $\mu M_t+\nabla L_t(W_{t-1})$ 送入迭代。区分这一脚注与概念式很有必要，否则照公式直接实现可能与作者代码行为不同。

若动量的奇异值分解为 $M=U\Sigma V^\top$，理想变换近似取得 $UV^\top$。它保留奇异方向，但压平更新在不同方向上的尺度。相比按元素调整梯度大小的 AdamW，Muon 利用的是一个完整权重矩阵的几何结构。

这不意味着所有方向都获得了相同的训练信息，也不意味着权重矩阵本身每一步都被正交化。被变换的是**更新方向**；权重仍由多次更新累计得到。

### Newton–Schulz 如何避免直接做 SVD

论文先用 Frobenius 范数归一化 $X_0=M/\|M\|_F$，再迭代

$$
X_k=aX_{k-1}+b(X_{k-1}X_{k-1}^\top)X_{k-1}
+c(X_{k-1}X_{k-1}^\top)^2X_{k-1}.
$$

系数采用 $a=3.4445$、$b=-4.7750$、$c=2.0315$。这些矩阵乘法对奇异值施加多项式变换，比直接分解大矩阵更适合加速器。有限次迭代得到近似变换，不应把实际更新写成严格的精确正交矩阵。[↗](https://arxiv.org/pdf/2502.16982#page=3)

## 长训练首先暴露了权重尺度问题

vanilla Muon 在早期下降快，但作者观察到权重和层输出 RMS 随训练增大，长训练优势缩小。于是加入解耦式 weight decay：

$$
W_t=W_{t-1}-\eta_t(O_t+\lambda W_{t-1}).
$$

$\lambda W$ 约束的是权重尺度，不是重新计算一份梯度二阶统计。Figure 2 对一个约 800M 参数模型训练 100B token，约为 compute-optimal token 量的五倍，专门检查收益能否持续到过量训练区间。

![长训练中的 weight decay 对照](../../assets/images/localized-remote/paper-deep-dives/foundations/muon-is-scalable/muon-weight-decay-ablation-原图.png){ width="650" }

图源：Muon is Scalable for LLM Training，Figure 2。先比较 vanilla Muon 前后期相对 AdamW 的位置，再看加 weight decay 后的曲线。实验支持保留衰减对本文长训练设置有帮助，不能仅由曲线断定所有稳定性问题都来自一个因素。

## 相同学习率为什么会对不同矩阵产生不同效果

论文证明，对形状为 $[A,B]$ 的满秩矩阵，理想 Muon 更新的 RMS 为

$$
\operatorname{RMS}(O)=\frac{1}{\sqrt{\max(A,B)}}.
$$

因此正方形 attention 投影与较宽的 MLP 投影，即使共享学习率，也可能得到不同的逐元素更新尺度。模型变宽后，更新还会进一步缩小；反过来，把矩阵切成很多小块分别处理，会改变更新强度和几何语义。

作者采用低成本的形状修正

$$
W_t=W_{t-1}-\eta_t\left(0.2\sqrt{\max(A,B)}\,O_t+\lambda W_{t-1}\right).
$$

系数 0.2 来自与实际 AdamW 更新 RMS 的经验对齐。它使 Muon 更容易复用强 AdamW baseline 的学习率方案，但不是所有数据和网络都通用的理论常数。

Table 1 的控制实验使用约 800M 模型，特意把 MLP 改为宽度 $4H$ 的两层形式，放大形状差异，在 20B-token schedule 的 4B-token 时点评估。

| Methods | Training loss | Validation loss | Query weight RMS | MLP weight RMS |
| --- | ---: | ---: | ---: | ---: |
| Baseline | 2.734 | 2.812 | 3.586e-2 | 2.52e-2 |
| Update Norm | 2.720 | 2.789 | 4.918e-2 | 5.01e-2 |
| Adjusted LR | 2.721 | 2.789 | 3.496e-2 | 4.89e-2 |

Baseline 对所有矩阵使用与 $\sqrt H$ 相关的缩放；Update Norm 直接归一化更新；Adjusted LR 按每个矩阵的形状缩放。后两者验证损失相同，而 Adjusted LR 避免显式 RMS 归一化，因此被用于后续实验。注意这项实验检验的是尺度修正，不是独立证明正交化本身的全部收益。[↗](https://arxiv.org/pdf/2502.16982#page=6)

## 分布式实现必须保留“完整矩阵”的含义

AdamW 的逐元素更新容易按参数任意切片。Muon 的 Newton–Schulz 操作需要矩阵结构，任意分片各自正交化通常不等于完整矩阵的变换。

Distributed Muon 按 ZeRO-1 风格分配优化器计算，在需要的位置收集矩阵相关状态，完成变换后再分发更新。存在 TP 时还要处理跨张量并行组的矩阵重建。这里的设计目标是降低冗余，而不因分片改变优化器。

作者报告优化器本身通常仅占前后向时间的约 1%–3%，通信与计算还可以重叠。它说明本文集群上额外矩阵变换可被控制，但不能推出优化器的开销对小模型、不同网络或不同 microbatch 都可忽略。[↗](https://arxiv.org/pdf/2502.16982#page=5)

## Scaling law 的“约两倍效率”如何读

作者在约 399M–1.5B 非 embedding 参数的 Llama 类 dense 模型上比较 Muon 与 AdamW。AdamW 先做 model size、token 数、学习率和 batch 的搜索；Muon 在更新 RMS 对齐后复用其超参数。这使比较比随意挑一个 AdamW 学习率更有解释力。

![Muon 与 AdamW 的 compute-optimal 比较](../../assets/images/localized-remote/paper-deep-dives/foundations/muon-is-scalable/muon-scaling-law-原图.png){ width="430" .atlas-figure-compact }

图源：Muon is Scalable for LLM Training，Figure 1(a)。先固定纵轴 loss 水平，再比较横轴需要的训练 FLOPs；论文将该范围内的差异概括为 Muon 约需 52% 的 FLOPs。

Table 3 的拟合为

$$
L_{\rm Muon}=2.506C^{-0.052},\qquad
L_{\rm AdamW}=2.608C^{-0.054}.
$$

$C$ 的单位要沿用拟合使用的计算预算口径。两条曲线指数并不完全相同，因此约 0.52 是实验范围内的概括，不是对任意预算恒定成立的比例。训练 FLOPs 还不包括所有系统等待与数据处理成本，部署前仍要测墙钟时间。

## Moonlight 检验了同一配方下的能力差异

Moonlight 采用接近 DeepSeek-V3-Small 的 MoE，非 embedding 参数口径为 15.29B 总量、2.24B 激活量，包含 embedding 时约 16B/3B。预训练上下文为 8K，总计 5.7T token。前 33B token 完成学习率 warmup，随后衰减；最后 500B token 使用更高质量的数学、代码和推理数据进行 cooldown。

优化器归因最有价值的比较是 Table 4 的 **Moonlight-A@1.2T 与 Moonlight@1.2T**。两者采用相同训练设置，主要区别是 AdamW 与 Muon；都是完整训练中途的 checkpoint，还未经历最终 cooldown。

| Benchmark | Moonlight-A@1.2T | Moonlight@1.2T |
| --- | ---: | ---: |
| MMLU | 60.2 | 60.4 |
| MMLU-pro | 26.8 | 28.1 |
| BBH | 45.3 | 43.2 |
| HumanEval | 29.3 | 37.2 |
| MBPP | 49.2 | 52.9 |
| GSM8K | 43.8 | 45.0 |
| MATH | 16.1 | 19.8 |

代码与部分数学任务的改善较明显，但 BBH 在这一 checkpoint 下降。保留这行反例，可以避免把报告写成“Muon 所有能力都更好”。最终 5.7T 模型的 MMLU 70.0、GSM8K 77.4 等成绩表明完整配方有竞争力；与其他公开模型比较时，数据与预算也发生变化，不能把全部差异归给优化器。[↗](https://arxiv.org/pdf/2502.16982#page=8)

![Moonlight 的能力与训练预算位置](../../assets/images/localized-remote/paper-deep-dives/foundations/muon-is-scalable/moonlight-pareto-frontier-原图.png){ width="490" .atlas-figure-compact }

图源：Muon is Scalable for LLM Training，Figure 1(b)。不同公开模型的 Pareto 位置提供选型背景，同配方对照才更适合讨论优化器本身。

## 奇异谱观察提供解释，但不替代能力实验

作者比较权重矩阵的奇异值分布与 SVD entropy，发现许多 Muon 权重具有更平坦的谱。这与更新不被少数大奇异方向主导的直觉相符。

![不同参数组的奇异谱熵](../../assets/images/localized-remote/paper-deep-dives/foundations/muon-is-scalable/muon-svd-entropy-原图.png){ width="760" }

图源：Muon is Scalable for LLM Training，Figure 4。应比较同一参数组内两个优化器随训练的变化；不同组的矩阵形状和功能不同，不能只按熵高低跨组排名。

这项诊断给出一种机制解释，并未单独操纵奇异谱后测能力。实际采用时，应同时跟踪 loss、权重与更新 RMS、attention logits、训练吞吐和下游任务，而不能把“谱更平”作为优化成功的唯一标准。

Muon 的迁移单位也应是完整训练配置：哪些矩阵使用 Muon、哪些参数仍使用 AdamW，weight decay 如何处理归一化参数，矩阵在分布式环境中如何重建，以及学习率如何对应更新尺度。报告的实际价值在于把这些容易被一个优化器名字掩盖的细节，变成可检查的工程条件。
