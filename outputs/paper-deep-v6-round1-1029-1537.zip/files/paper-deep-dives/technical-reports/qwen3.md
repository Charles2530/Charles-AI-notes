---
paper_date: 2025-05
paper_title: "Qwen3 Technical Report"
paper_topic: 技术报告
---

# Qwen3：Thinking 模式、36T 预训练与蒸馏

!!! info "论文信息"
    **论文题名：** Qwen3 Technical Report。<br>
    **作者：** An Yang、Anfeng Li、Baosong Yang、Beichen Zhang、Binyuan Hui、Bo Zheng、Bowen Yu、Chang Gao、Chengen Huang、Chenxu Lv 等（共 60 人）。<br>
    **机构：** 未在公开元数据中稳定解析；以 arXiv/PDF 或官方页 affiliation block 为准。<br>
    **时间 / 主题：** 2025-05；技术报告。<br>
    **arXiv / 官方报告：** arXiv：[2505.09388](https://arxiv.org/abs/2505.09388)。<br>
    **GitHub / 项目：** GitHub：[github.com/QwenLM/Qwen3](https://github.com/QwenLM/Qwen3)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2505.09388)；[GitHub API / repo](https://github.com/QwenLM/Qwen3)；Checked Date：2026-06-15；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 把推理预算变成同一模型的可控接口

Qwen3希望用户不必在通用聊天模型与专用推理模型之间切换。复杂数学、代码和多步推理需要展开计算，普通问答与格式任务则未必值得生成很长的思考过程。报告用同一组权重支持thinking与non-thinking两种模式，再通过推理过程中的预算控制，在二者之间取得不同的质量—计算量组合。

这项能力建立在三层工作上。36T-token预训练提供多语言、知识与代码基础；旗舰模型经过四阶段后训练，先形成推理能力再融合通用行为；小模型通过强到弱蒸馏学习两种模式。阅读时应将这三层分开，否则容易把所有收益都归于一个`/think`标记，或把旗舰的RL配方误认为所有尺寸都完整执行了一遍。[↗](https://arxiv.org/pdf/2505.09388v1#page=2)

## 八种规模怎样共享架构与训练策略

Qwen3包含六个dense模型与两个MoE模型。dense主干使用GQA、SwiGLU、RoPE与pre-RMSNorm，相比此前版本去掉QKV bias并加入QK-Norm，以控制注意力训练稳定性。所有模型采用词表大小151669的byte-level BPE tokenizer。[↗](https://arxiv.org/pdf/2505.09388v1#page=3)

| Models | Layers | Heads (Q / KV) | Tie Embedding | Context Length |
| --- | ---: | --- | --- | --- |
| Qwen3-0.6B | 28 | 16 / 8 | Yes | 32K |
| Qwen3-1.7B | 28 | 16 / 8 | Yes | 32K |
| Qwen3-4B | 36 | 32 / 8 | Yes | 128K |
| Qwen3-8B | 36 | 32 / 8 | No | 128K |
| Qwen3-14B | 40 | 40 / 8 | No | 128K |
| Qwen3-32B | 64 | 64 / 8 | No | 128K |

GQA让多组query共享较少的KV heads，减少KV cache与相应读写量，但表中的query heads仍决定各自的注意力计算。共享embedding与输出投影也不是全系列统一配置，应按具体尺寸检查。

| Models | Total / Activated Parameters | Layers | Heads (Q / KV) | Experts (Total / Activated) | Context Length |
| --- | --- | ---: | --- | --- | --- |
| Qwen3-30B-A3B | 30B / 3B | 48 | 32 / 4 | 128 / 8 | 128K |
| Qwen3-235B-A22B | 235B / 22B | 94 | 64 / 4 | 128 / 8 | 128K |

MoE采用细粒度专家划分，每token激活128个专家中的8个，并取消共享专家。负载平衡使用global-batch loss，使专家能够在更大的数据范围内分工，而非要求每条序列都同样均匀。这里的22B或3B表示每token的激活参数量；权重存储仍对应235B或30B总参数，实际推理速度还受专家通信、batch、显存带宽和序列长度影响。

两张表的128K是支持的上下文口径，不能写成全部模型都原生使用128K序列完成预训练。0.6B、1.7B在报告架构表中仍列32K，其他模型的长上下文还涉及后面的训练与外推设置。

## 36T语料的变化不仅是数量

Qwen3扩大语料到约36T tokens，覆盖119种语言与方言。语料中包含网页与知识文本、代码、STEM、书籍、多语言与合成数据。Qwen2.5-VL先从PDF类材料识别文本，Qwen2.5再清理质量；Qwen2.5、Math与Coder系列又生成教材、问答、指令与代码等内容。作者报告，这两类扩充都达到万亿token规模。[↗](https://arxiv.org/pdf/2505.09388v1#page=4)

数据选择也细化到实例。系统为超过30T tokens标注教育价值、领域和安全等属性，再用小型代理模型做混合比例消融。它与只在“代码占多少、网页占多少”层面调比例不同：同一来源内部的高低质量实例也可分别处理。报告没有给出完整公开语料及全部混合系数，因此架构开放与训练过程完全可复现仍是不同层面的事。

预训练分三阶段。S1在4096序列长度下训练超过30T tokens，主要建立语言与世界知识；S2仍用4096长度，增加约5T高质量STEM、代码、推理与合成数据，同时加快学习率衰减。最后长上下文阶段使用数千亿tokens、32768序列长度，其中75%的文本长16K—32K，25%长4K—16K。

长上下文训练通过ABF将RoPE base从10000提高至1000000；推理再用YaRN与Dual Chunk Attention扩展约四倍。这个顺序包含短序列大规模学习、长序列专门训练和推理外推三种操作，不能只拿最终context length解释训练成本。

## 基础能力为后训练提供了什么

旗舰Base模型的比较使用同一评测流程，下表摘自原文Table 3。MATH采用4-shot CoT，EvalPlus是HumanEval、MBPP及其增强测试的平均；这些Base评测与后面的聊天模型评测不是同一套输入格式。

| Benchmark | Qwen2.5-72B-Base | DeepSeek-V3-Base | Qwen3-235B-A22B-Base |
| --- | ---: | ---: | ---: |
| MMLU | 86.06 | 87.19 | 87.81 |
| MMLU-Pro | 58.07 | 59.84 | 68.18 |
| SuperGPQA | 36.20 | 41.53 | 44.06 |
| MATH | 62.12 | 62.62 | 71.84 |
| EvalPlus | 65.93 | 63.75 | 77.60 |
| MMMLU | 84.40 | 85.88 | 86.70 |
| INCLUDE | 69.05 | 75.17 | 73.46 |

Qwen3-235B-A22B-Base在表中15项任务的14项高于V3-Base，例外是区域知识INCLUDE。数学、代码上的改善支持基础模型能力较强，但这是数据、训练策略与结构共同变化后的结果，没有证明某个单独模块贡献了全部提升。[↗](https://arxiv.org/pdf/2505.09388v1#page=6)

参数效率也需要限定含义。作者发现同一训练数据下，MoE可用约五分之一激活参数达到dense模型相近的评测表现；这支持稀疏计算的价值，不等于服务吞吐必然提高五倍。模型尺寸选择仍要测量完整权重驻留与实际负载。

## 旗舰模型先学长推理，再融入两种模式

下图应沿上方四阶段阅读235B-A22B与32B的后训练，再看下方小模型的蒸馏分支。两条路径不同，后面的成本比较也必须明确起点。

![Qwen3 post-training pipeline](../../assets/images/paper-deep-dives/technical-reports/qwen3/figure-1-posttrain-pipeline.png){ width="920" }

<small>图源：`Qwen3 Technical Report`，Figure 1。</small>

**Long-CoT Cold Start**先让模型掌握推理行为。作者收集数学、代码、逻辑与STEM题，每题具备可验证答案或测试，再用Qwen2.5-72B-Instruct剔除难以验证、多子问题或无需CoT也能回答的题目。QwQ-32B生成多个候选回答，过滤错误答案、重复、明显猜测、推理与最终答案矛盾、语言风格混乱及疑似接近验证集的内容。

这一阶段刻意限制样本数与训练步数，目的是建立推理形式并为RL保留改进空间。不能将它描述为直接用庞大推理数据集训练出全部最终能力，也不能把“最终答案正确”当成筛选的唯一条件。[↗](https://arxiv.org/pdf/2505.09388v1#page=10)

**Reasoning RL**使用未参加cold start、对当前模型可学但尽量有挑战、覆盖多个子领域的3995组query-verifier。算法采用GRPO，作者强调较大batch、较多rollout与off-policy样本利用，并控制策略熵保持稳定或逐步增加，避免过早丧失探索。报告例子中，235B-A22B的AIME 2024由70.1升至85.1，经过170个RL steps。

3995是这个阶段的query-verifier数量，不是全模型所有训练问题数；170是一次大规模RL运行的step数，也不能用来推断总GPU成本。报告没有披露足以精确重建该运行的全部rollout与优化器超参数，不宜替它补上一套通用GRPO默认值。

## 模式融合怎样保持统一的对话格式

第三阶段在Reasoning RL模型上继续SFT。thinking数据由第二阶段模型对第一阶段问题进行拒绝采样，保留较强推理能力；non-thinking数据覆盖代码、数学、指令、翻译、写作、问答与角色扮演，并使用自动checklist评估回答质量。低资源语言特别增加翻译任务。

格式控制同时写进训练数据。`/think`与`/no_think`可出现在用户或system消息中，多轮训练会随机插入多个标记，让模型遵循最后出现的模式要求。默认使用thinking，因此部分thinking样本不带显式开关。non-thinking回答仍保留空的`<think>...</think>`块，以保持格式一致。[↗](https://arxiv.org/pdf/2505.09388v1#page=11)

| Mode | Assistant Prefix | Behavior |
| --- | --- | --- |
| Thinking | `<think>`后生成思考内容，再以`</think>`结束 | 先产生思考，再回答 |
| Non-thinking | `<think></think>`空块 | 直接进入回答部分 |

这种接口有两个层次。文本标记是模型学到的行为指令；chat template还可通过`enable_thinking=False`预先拼入空思考块，从生成起点关闭思考部分。使用者应调用对应模型版本的模板，不能只修改界面上的显示方式，就认为底层已经停止生成思考token。

## Thinking budget不是一个独立训练的预算预测器

模式融合之后，模型能从完整思考、没有思考过渡到“已有部分思考，立即作答”。当思考长度达到用户预算时，外部生成流程暂停它，插入要求基于已有思考直接给出答案的stop-thinking提示以及`</think>`，随后继续生成最终回答。

论文明确说，这种处理中途停止的能力没有被单独显式训练，而是在两种模式融合后出现。预算边界由生成流程执行，不能把它说成模型总会自行判断最佳思考长度；预算也只约束思考部分，并非最终答案与全部上下文的总token上限。

下图横轴是1K到32K的thinking budget，纵轴是pass@1。先看1K与non-thinking红色基线的距离，再比较4K、8K、16K的变化，能看到不同任务获得收益的区间并不相同。

![Qwen3 thinking budget](../../assets/images/paper-deep-dives/technical-reports/qwen3/figure-2-thinking-budget.png){ width="820" }

<small>图源：`Qwen3 Technical Report`，Figure 2。</small>

AIME与代码任务在较大预算下明显提升；GPQA在1K—2K之间变化很小，之后才继续提高。图支持这些基准中的可调质量—预算关系，不能推广为每一题都随token单调变好。作者把超过32K后的进一步收益列为未来探索，未在这张图中完成验证。[↗](https://arxiv.org/pdf/2505.09388v1#page=20)

## General RL把“会推理”转化为更稳定的助手行为

第四阶段覆盖20多种任务，包括内容与格式指令、模式切换、人类偏好、工具调用以及RAG中的依据一致性。工具训练允许模型与真实环境完成多轮交互，根据执行反馈更新，不限于学习函数名和JSON外形。

奖励分为三类。可验证任务用规则评分；有参考答案但不能严格字符串匹配的任务，让Qwen2.5-72B-Instruct结合参考评估；开放偏好任务用人类偏好数据训练的标量reward model。这种组合扩大了可训练任务范围，同时不同任务仍具有不同的奖励可靠性，不能把模型评价都当作客观正确性验证。[↗](https://arxiv.org/pdf/2505.09388v1#page=12)

阶段消融比最终排行榜更能解释这一步的作用。下表摘自Table 22，均为Qwen3-32B；除ThinkFollow外，列出thinking模式。星号表示内部数据集。

| Benchmark | Stage 2: Reasoning RL | Stage 3: Thinking Mode Fusion | Stage 4: General RL |
| --- | ---: | ---: | ---: |
| LiveBench 2024-11-25 | 68.6 | 70.9 | 74.9 |
| IFEval strict prompt | 73.0 | 78.4 | 85.0 |
| ThinkFollow* | — | 88.7 | 98.9 |
| ToolUse* | 63.3 | 70.4 | 85.5 |
| MMLU-Redux | 91.4 | 91.0 | 90.9 |
| GPQA-Diamond | 68.8 | 69.0 | 68.4 |
| AIME’24 | 83.8 | 81.9 | 81.4 |
| LiveCodeBench v5 | 68.4 | 67.2 | 65.7 |

模式控制、指令与工具能力改善，但AIME与LiveCodeBench逐步下降。作者主动接受这一取舍，以换取通用性；因此“模式融合保留推理能力”应理解为维持较强能力，而非所有指标无损。ThinkFollow 98.9也属于内部多轮模式测试，不是对任意外部提示保证100%遵循。[↗](https://arxiv.org/pdf/2505.09388v1#page=21)

## 小模型为何使用两阶段蒸馏

0.6B、1.7B、4B、8B、14B和30B-A3B走Strong-to-Weak Distillation。首先使用教师在两种模式下生成的回答进行off-policy蒸馏，学会基础推理与模式格式。随后由学生自己生成序列，教师32B或235B-A22B在这些学生轨迹上提供logits，以KL目标对齐输出分布。

两阶段区别在于训练时访问到的状态。只学习教师回答，学生部署时一旦偏离教师路径，后续上下文可能缺少监督；on-policy阶段直接在学生会产生的前缀上请求教师指导。logits又提供完整的相对token偏好，比单个正确／错误奖励更细。原文只概述KL对齐，没有给出详细损失方向、temperature和所有混合系数，因而不能把某种常见蒸馏实现自动归到这篇报告名下。[↗](https://arxiv.org/pdf/2505.09388v1#page=12)

最直接的证据来自同一个已完成off-policy蒸馏的8B checkpoint。后续两条分支只使用数学与代码问题，Table 21同时报告性能和GPU-hours；括号是pass@64。

| Method | AIME’24 | AIME’25 | MATH500 | LiveCodeBench v5 | MMLU-Redux | GPQA-Diamond | GPU Hours |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Off-policy Distillation | 55.0 (90.0) | 42.8 (83.3) | 92.4 | 42.0 | 86.4 | 55.6 | — |
| + Reinforcement Learning | 67.6 (90.0) | 55.5 (83.3) | 94.8 | 52.9 | 86.9 | 61.3 | 17,920 |
| + On-policy Distillation | 74.4 (93.3) | 65.5 (86.7) | 97.0 | 60.3 | 88.3 | 63.3 | 1,800 |

蒸馏分支使用约十分之一GPU-hours，pass@1与pass@64都提高；直接RL在这里提高了pass@1，但pass@64维持90.0与83.3。这个结果支持强教师能提供学生尚未充分探索到的有效方向，不能推广为所有模型、任务或教师条件下蒸馏必然优于RL。

这张表的1800与17920是从共同checkpoint出发的后续阶段成本，不含建立教师模型、36T预训练或此前off-policy蒸馏的全部投入。正文另有整个轻量后训练流程约节省至十分之一的概述，二者不能混成“从零训练小模型只需十分之一总成本”。[↗](https://arxiv.org/pdf/2505.09388v1#page=21)

## 两种模式的主结果与评测条件

主表采用thinking temperature 0.6、top-p 0.95、top-k 20；non-thinking temperature 0.7、top-p 0.8、top-k 20并使用presence penalty 1.5。两种模式通常都允许32768输出tokens，AIME提高到38912。AIME每年30题、每题采样64次后取平均，GPQA每题采样10次；它们估计单次回答准确率，不是64次投票后的成绩。[↗](https://arxiv.org/pdf/2505.09388v1#page=13)

| Benchmark | Qwen3-235B-A22B Thinking | DeepSeek-R1 | OpenAI-o1 | Qwen3-235B-A22B Non-thinking | DeepSeek-V3 |
| --- | ---: | ---: | ---: | ---: | ---: |
| GPQA-Diamond | 71.1 | 71.5 | 78.0 | 62.9 | 59.1 |
| IFEval strict prompt | 83.4 | 83.3 | 92.6 | 83.2 | 86.1 |
| AIME’24 | 85.7 | 79.8 | 74.3 | 40.1 | 39.2 |
| AIME’25 | 81.5 | 70.0 | 79.2 | 24.7 | 28.8 |
| BFCL v3 | 70.8 | 56.9 | 67.8 | 68.0 | 57.6 |
| LiveCodeBench v5 | 70.7 | 64.3 | 63.9 | 35.3 | 33.1 |
| MMMLU 14 languages | 84.3 | 86.4 | 88.4 | 79.8 | 81.1 |

该表并列原文Table 11和12，便于观察同一Qwen3的模式差异；R1、o1是thinking比较组，V3是non-thinking比较组，不应把所有列当成相同计算预算。Qwen3的数学、代码明显受益于思考，知识与指令跟随仍有落后项，non-thinking AIME 2025也低于V3。

BFCL评价还有接口差异。Qwen3使用FC格式，部分榜单基线采用FC与Prompt格式较高的一项，多轮评测将Qwen3用YaRN部署到64K。LiveCodeBench使用v5、题目时间2024年10月至2025年2月，thinking prompt去掉“只能返回程序”的限制；不能与Kimi K2报告的v6直接横比。CodeForces允许每题最多八次独立推理尝试，2056 rating对应这一评测流程，而不是原样参加真人限时比赛。[↗](https://arxiv.org/pdf/2505.09388v1#page=14)

不同尺寸也维持了较强的推理能力，但不是任意任务等价。最终4B与8B的AIME 2025分别65.6、67.3，LiveCodeBench v5分别54.2、57.5；32B为72.9与65.7。8B蒸馏消融表的65.5、60.3来自特定实验分支，不能与最终发布模型67.3、57.5混成同一个checkpoint。[↗](https://arxiv.org/pdf/2505.09388v1#page=18)

## 多语言与长上下文说明“更多思考”有适用范围

119是训练覆盖的语言与方言数量，不是每个benchmark都测119种。Multi-IF覆盖8种语言，INCLUDE覆盖44种，MMMLU覆盖14种，MT-AIME2024覆盖55种；INCLUDE与MMMLU只抽取原数据的10%以控制评测成本。附录Belebele测80种支持语言，排除了42种未优化语言。理解“多语言能力”时应保留这些覆盖范围，而不是用单个平均分代表所有语言。

长上下文的RULER评测使用YaRN scaling factor 4；thinking模式的思考预算另设8192，以避免超长输入上的冗长推理。表中同一模型的非思考模式往往更好。

| Model | Mode | RULER Avg. | RULER 32K | RULER 128K |
| --- | --- | ---: | ---: | ---: |
| Qwen3-8B | Non-thinking | 89.1 | 91.2 | 77.4 |
| Qwen3-8B | Thinking | 84.4 | 80.8 | 72.0 |
| Qwen3-32B | Non-thinking | 93.7 | 94.4 | 85.6 |
| Qwen3-32B | Thinking | 91.0 | 92.5 | 83.5 |
| Qwen3-235B-A22B | Non-thinking | 95.0 | 95.1 | 90.6 |
| Qwen3-235B-A22B | Thinking | 92.2 | 92.3 | 86.0 |

这与数学预算曲线并不矛盾。检索类任务的关键是从长输入中找准信息，额外推理可能带来干扰；作者将其作为解释假说，并没有证明所有长上下文任务都应关闭thinking。实际系统可以按任务类型选择模式，再通过自己的错误分析校准。[↗](https://arxiv.org/pdf/2505.09388v1#page=23)

## 可迁移的做法与采用边界

Qwen3提供的核心经验是将推理能力、通用行为和计算预算分别训练或控制。旗舰先通过可验证RL提高推理，再用模式融合与General RL恢复广泛可用性；小模型利用教师在自身轨迹上给出的分布信号，减少独立探索的成本。两种训练路径都保留同一模式接口，因而可以在不同参数规模上复用上层应用逻辑。

采用时最先需要固定的是模型版本、chat template、模式、thinking预算与最终输出上限。随后按自己的代码、工具、检索或多语言任务测试质量与延迟；报告没有提供足以将激活参数直接换算成真实业务吞吐的统一硬件基准。数学题可以从增加预算获益，检索与格式任务则应先验证长思考是否有帮助。四阶段消融已经说明，通用助手的提升可能伴随专门能力的回退，模式可控因此是一种可用的决策接口，并非所有指标同时上升的保证。
