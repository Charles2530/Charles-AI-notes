---
paper_date: 2025-01
paper_title: "DeepSeek-R1: Incentivizing Reasoning Capability in LLMs via Reinforcement Learning"
paper_topic: 技术报告
---

# DeepSeek-R1：RL 激发推理能力

!!! info "论文信息"
    **论文题名：** DeepSeek-R1: Incentivizing Reasoning Capability in LLMs via Reinforcement Learning。<br>
    **作者：** DeepSeek-AI、Daya Guo、Dejian Yang、Haowei Zhang、Junxiao Song、Peiyi Wang、Qihao Zhu、Runxin Xu、Ruoyu Zhang、Shirong Ma 等（共 200 人）。<br>
    **机构：** 未在公开元数据中稳定解析；以 arXiv/PDF 或官方页 affiliation block 为准。<br>
    **时间 / 主题：** 2025-01；技术报告。<br>
    **arXiv / 官方报告：** arXiv：[2501.12948](https://arxiv.org/abs/2501.12948)。<br>
    **GitHub / 项目：** GitHub：[github.com/deepseek-ai/DeepSeek-R1](https://github.com/deepseek-ai/DeepSeek-R1)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2501.12948)；[GitHub API / repo](https://github.com/deepseek-ai/DeepSeek-R1)；Checked Date：2026-06-15；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## R1-Zero检验推理能否由结果奖励生长，R1解决怎样把它变成可用助手

这篇报告包含两个不同层次的结果。DeepSeek-R1-Zero直接从DeepSeek-V3-Base做强化学习，不先用人工推理示范做SFT，观察可验证的最终答案奖励能否推动模型形成更有效的解题过程。DeepSeek-R1则在这一发现上加入冷启动、拒绝采样、监督微调与面向通用任务的RL，处理可读性、语言混杂、写作和指令遵循。

因此，“纯RL”只适用于R1-Zero的后训练路径。它依然依赖强大的预训练基础模型、可验证问题与答案、规定输出结构的prompt和大量采样；完整R1也明确使用SFT与偏好模型。将整条路线概括为“没有监督数据即可获得通用智能”，会同时抹去基础模型和后续训练的作用。[↗](https://arxiv.org/pdf/2501.12948v2#page=2)

扩展版报告给出了各阶段checkpoint、训练成本和更多分析，使问题可以拆得更细：RL改变了哪些能力，SFT修复了哪些行为，额外推理token花在哪里，以及大模型获得的轨迹能否交给小模型使用。

## GRPO用同题多解的相对结果替代价值网络

对问题 $q$，旧策略 $\pi_{\theta_{\mathrm{old}}}$ 采样 $G$ 个回答 $o_i$，验证器为每个回答返回奖励 $r_i$。GRPO使用组内标准化优势

$$
A_i=\frac{r_i-\operatorname{mean}(r_1,\ldots,r_G)}{\operatorname{std}(r_1,\ldots,r_G)}.
$$

同一道题中高于平均奖励的回答得到正优势，较差回答得到负优势。它无需额外训练一个与大模型相当规模的critic来预测每个位置的价值，但仍需要为每道题生成多个完整回答。因此省掉价值模型不等于消除采样成本。

令概率比 $w_i=\pi_\theta(o_i\mid q)/\pi_{\theta_{\mathrm{old}}}(o_i\mid q)$，报告用以下形式表达策略目标

$$
\mathcal J_{\mathrm{GRPO}}=\mathbb E\left[\frac1G\sum_{i=1}^G\left(\min\{w_iA_i,\operatorname{clip}(w_i,1-\epsilon,1+\epsilon)A_i\}-\beta\widehat D_{\mathrm{KL}}\right)\right],
$$

$$
\widehat D_{\mathrm{KL}}=\frac{\pi_{\mathrm{ref}}(o_i\mid q)}{\pi_\theta(o_i\mid q)}-\log\frac{\pi_{\mathrm{ref}}(o_i\mid q)}{\pi_\theta(o_i\mid q)}-1.
$$

clip约束当前策略相对采样策略的一次更新，KL项约束相对参考策略的漂移，两者不是同一个参照。式中是论文按回答写出的简式，实际语言模型优化还要落实到token概率与掩码。图中可先找PPO的value分支，再看GRPO如何将一组回答的reward变成advantage。[↗](https://arxiv.org/pdf/2501.12948v2#page=3)

![GRPO 原图](../../assets/images/paper-deep-dives/technical-reports/deepseek-r1/figure-grpo.png){ width="920" }

<small>图源：`DeepSeek-R1`，v2，Figure 3。</small>

算法比较也有边界。附录在16B MoE、2.4B激活参数的DeepSeek-Coder-V2-Lite上比较PPO与GRPO。PPO使用常见GAE $\lambda=0.95$时明显较差，调到1.0后接近GRPO。它支持GRPO在该设置下更省critic资源、较易配置，不支持PPO在原理上无法训练推理模型。[↗](https://arxiv.org/pdf/2501.12948v2#page=16)

## 正确答案奖励为何足够，格式奖励又管了什么

R1-Zero的rule reward由accuracy与format两项等权相加。数学题验证可解析的最终答案，代码题在测试用例上执行，格式奖励要求将推理放入规定标签。这个结构没有逐步给出“应该先做什么再做什么”的教师推理轨迹，但并非完全不约束输出行为。

规则奖励的可靠性来自任务可验证。测试用例覆盖不足、答案解析错误或存在多种等价表示，都会改变模型真正优化的目标。报告因大规模RL中的reward hacking与维护成本，未对这些推理任务采用神经过程奖励模型；这是一种在可验证领域成立的工程选择，而非证明过程监督在所有场景无用。[↗](https://arxiv.org/pdf/2501.12948v2#page=4)

扩展版给出R1-Zero的具体规模：每题16个回答，每训练step32道独立问题，得到512个回答的训练batch；每次rollout生成8192回答，再打散成16个minibatch，仅训练一个inner epoch。学习率 $3\times10^{-6}$，KL系数0.001，rollout temperature为1，每400步将reference更新为当前policy。共10400步，约1.6个训练epochs。

这些数字解释了同题相对学习的成本。训练统计中的“一个step”是一次策略更新，不是只生成一条回答，更不是一次基础模型前向。

## 长思考与反思行为的证据，需要同时看预算变化

AIME训练曲线先区分pass@1与consensus。扩展版报告R1-Zero的AIME2024平均pass@1由15.6%升到77.9%，图中cons@16达到86.7%。后者需要多次采样投票，不能作为单次回答准确率。[↗](https://arxiv.org/pdf/2501.12948v2#page=4)

![](../../assets/images/paper-deep-dives/technical-reports/deepseek-r1/figure-r1-zero-aime.png)

<small>图源：`DeepSeek-R1`，v2，Figure 1(a)。</small>

响应长度也随训练显著增长，模型开始花更多token检验、重算与尝试不同路径。但第8200步存在明确的外部配置变化：最大输出长度由32768提升至65536，性能和长度随后都出现跳升。因此曲线总体支持RL下长推理行为的发展，跳变本身不能只归因于一次突然的“自发顿悟”。

![](../../assets/images/paper-deep-dives/technical-reports/deepseek-r1/figure-r1-zero-length.png)

<small>图源：`DeepSeek-R1`，v2，Figure 1(b)。</small>

反思词统计进一步提供行为线索。词表由三位专家给出，包含wait、mistake、verify、check等；总体出现频率增长约5—7倍，wait在训练后期出现明显增加。下面两图应分别看普遍增长和特定词的阶段变化。[↗](https://arxiv.org/pdf/2501.12948v2#page=38)

![](../../assets/images/paper-deep-dives/technical-reports/deepseek-r1/figure-reflective-words.png)

<small>图源：`DeepSeek-R1`，v2，Figure 9(a)。</small>

![](../../assets/images/paper-deep-dives/technical-reports/deepseek-r1/figure-wait-pattern.png)

<small>图源：`DeepSeek-R1`，v2，Figure 9(b)。</small>

词频本身并不证明推理忠实性或某个词造成准确率提升。回答变长会增加词语出现机会，较强证据来自可验证任务成绩与具体解题轨迹的共同变化。报告展示的“aha moment”是一个有启发性的输出案例，不应被当作人类式意识或内部认知状态的测量。

## 四阶段流水线怎样兼顾探索与可读性

R1从V3-Base重新建立可控的训练路径。冷启动先使用数千条经过整理、具有可读长推理形式的数据，避免模型把探索主要花在混乱输出上；第一次RL继续用推理奖励强化正确性，并加入语言一致性。随后从较强checkpoint做拒绝采样，筛出正确且可读的推理轨迹，与通用数据一起重新SFT。最后的RL将推理任务与一般指令、偏好任务结合。

流程图中最重要的是各个checkpoint之间的数据箭头。Dev2不仅是最终策略的前身，还产生供Dev3监督学习的轨迹；通用SFT数据来自另一条路径，补充单纯数学代码RL无法自动学好的助手行为。[↗](https://arxiv.org/pdf/2501.12948v2#page=6)

![DeepSeek-R1 pipeline 原图](../../assets/images/paper-deep-dives/technical-reports/deepseek-r1/figure-r1-pipeline.png){ width="920" }

<small>图源：`DeepSeek-R1`，v2，Figure 2。</small>

拒绝采样阶段对每题生成多个回答，只保留正确样本，还过滤混合语言、过长段落等低可读输出。约600k推理样本与200k非推理样本组成约800k数据。扩展版Table5的精确统计为804745条，包含395285条数学、211129条代码、10124条STEM、10395条逻辑和177812条通用数据，平均5355.3 tokens。概括分类与精确领域表不是完全相同的分组口径。

SFT不只整理文字风格。通用部分含写作、事实问答、翻译，也加入程序修复与前端开发，让模型能将解题能力用于软件工程。多数样本仍是单轮，这限制了它对复杂多轮助手行为的直接覆盖。[↗](https://arxiv.org/pdf/2501.12948v2#page=26)

## 语言一致性与偏好优化，都有可测的取舍

语言奖励按CoT中目标语言词所占比例计算

$$
R_{\mathrm{language}}=\frac{\operatorname{Num}(\mathrm{Words}_{\mathrm{target}})}{\operatorname{Num}(\mathrm{Words})}.
$$

它将“答案正确”之外的可读性直接加入优化。相应消融在7B学生设置上比较有无语言奖励，应先看语言一致性曲线，再看AIME与LiveCodeBench是否同步改善。

![Language Consistency Reward 原图](../../assets/images/paper-deep-dives/technical-reports/deepseek-r1/figure-language-consistency-reward.png){ width="920" }

<small>图源：`DeepSeek-R1`，v2，Figure 7。</small>

没有语言奖励时语言混杂逐渐恶化；加入后更稳定，数学表现接近，代码表现略有下降。这个结果支持可读性与任务得分存在实际交换，并不是语言纯度越高推理越强。由于消融使用较小模型，也不应把具体损失幅度无条件套到完整671B模型。[↗](https://arxiv.org/pdf/2501.12948v2#page=37)

面向一般任务，R1使用helpfulness和safety reward model。helpfulness重点评估最终回答，避免简单把冗长推理当作优质助手输出；safety评估整段响应。帮助性训练使用66000偏好对，DeepSeek-V3多次交换A/B位置判断并筛掉差距过小的样本，且控制chosen与rejected总体长度分布；安全模型使用106000条有安全标签的prompt-response。[↗](https://arxiv.org/pdf/2501.12948v2#page=7)

第二次RL共1700步，一般指令与模型偏好奖励只在最后400步加入。其原因在下图里十分具体：reward持续上升的同时，Codeforces pass@1反而下降。继续优化同一个代理目标可能使模型更会迎合奖励模型，而损害独立任务能力。

![Reward hacking 原图](../../assets/images/paper-deep-dives/technical-reports/deepseek-r1/figure-reward-hacking.png){ width="760" }

<small>图源：`DeepSeek-R1`，v2，Figure 6。</small>

这比泛泛地说“RL需要对齐”更有操作价值。训练应同时观察独立可验证能力与reward，而不能仅凭reward曲线决定继续训练多久。[↗](https://arxiv.org/pdf/2501.12948v2#page=35)

## 阶段实验说明哪些提升来自哪里

扩展版Table3提供从R1-Zero到完整R1的中间checkpoint。几项指标放在一起，能看到可读冷启动、推理RL、混合SFT与最终RL承担不同角色。[↗](https://arxiv.org/pdf/2501.12948v2#page=9)

| Benchmark | R1-Zero | Dev1 | Dev2 | Dev3 | R1 |
| --- | ---: | ---: | ---: | ---: | ---: |
| AIME 2024 pass@1 | 77.9 | 59.0 | 74.0 | 78.1 | 79.8 |
| GPQA Diamond pass@1 | 75.8 | 66.1 | 70.7 | 71.2 | 71.5 |
| LiveCodeBench pass@1 | 50.0 | 57.5 | 63.5 | 64.6 | 65.9 |
| IFEval Prompt Strict | 46.6 | 71.7 | 72.0 | 78.1 | 83.3 |
| AlpacaEval2 LC-winrate | 24.7 | 50.1 | 55.8 | 62.1 | 87.6 |
| Aider-Polyglot | 12.2 | 6.7 | 25.6 | 44.8 | 53.3 |

冷启动Dev1相对Zero明显改善指令遵循，却降低AIME；第一次RL恢复大量推理能力；混合SFT进一步提升Aider与通用对话；最终RL的主要增幅在偏好和指令任务。最终R1的GPQA71.5仍低于Zero75.8，因此完整助手是综合折中，不能描述成每个阶段、每个任务严格单调变强。

这些阶段同时改变数据、训练目标和模型状态，是整条流水线的行为观察。它们能定位各阶段作用，尚不能将每个差值完全归因于某个单独loss。

## 主结果怎样与o1和普通聊天模型比较

主要评估上限为32768输出tokens，temperature0.6、top-p0.95。AIME与GPQA每题采64次，MATH与Codeforces16次，LiveCodeBench8次，再以回答正确比例估计pass@1。多次采样提高的是估计精度；pass@1仍代表一次随机回答的成功概率，区别于从64次中选对答案或投票。o1-1217成绩来自官方报告，其他系统也有各自工具与评测配置。[↗](https://arxiv.org/pdf/2501.12948v2#page=40)

| Benchmark | DeepSeek-V3 | o1-1217 | DeepSeek-R1 |
| --- | ---: | ---: | ---: |
| AIME 2024 pass@1 | 39.2 | 79.2 | 79.8 |
| MATH-500 pass@1 | 90.2 | 96.4 | 97.3 |
| GPQA Diamond pass@1 | 59.1 | 75.7 | 71.5 |
| LiveCodeBench pass@1 | 36.2 | 63.4 | 65.9 |
| Codeforces rating | 1134 | 2061 | 2029 |
| SWE-bench Verified resolved | 42.0 | 48.9 | 49.2 |
| Aider-Polyglot | 49.6 | 61.7 | 53.3 |

R1在竞赛数学与部分代码任务达到o1-1217附近，但GPQA、Aider有明确差距。SWE-bench使用agentless框架，测量的是模型与该解决流程组合的结果。R1论文中的LiveCodeBench时间范围为2024年8月至2025年1月，与V3原报告较短范围不同，不能把两份报告的同名分数直接混成一张增长曲线。[↗](https://arxiv.org/pdf/2501.12948v2#page=41)

人类比较图还需要区分参赛者均值、竞赛分位与专家基线。Codeforces96.3百分位是该协议下的预计竞赛位置，不能推广成模型在所有软件工程工作中超过96.3%程序员。

![DeepSeek-R1 benchmark against humans 原图](../../assets/images/paper-deep-dives/technical-reports/deepseek-r1/figure-benchmark-human.png){ width="850" }

<small>图源：`DeepSeek-R1`，v2，Figure 10。</small>

## 长推理改善单次解题，多次采样仍有额外作用

在另一组2024数学竞赛题上，R1平均使用8793 thinking tokens，pass@1为61.8%；难题通常产生更长推理。图中难度以问题的pass@1衡量，曲线经过平滑，重点看计算量随难度增加的趋势，而不是将每一个点视为精确预算策略。[↗](https://arxiv.org/pdf/2501.12948v2#page=59)

![Test-time scaling 原图](../../assets/images/paper-deep-dives/technical-reports/deepseek-r1/figure-test-time-scaling.png){ width="850" }

<small>图源：`DeepSeek-R1`，v2，Figure 18。</small>

相关性没有证明强制追加token就能解决所有难题。模型也可能沿错误路径反复检查。AIME2024中R1的pass@1为79.8%，pass@64为90.0%，consensus为86.7%，说明长推理、独立多样本覆盖和投票是三种不同机制。部署时应根据任务价值选择是否多采样，同时保留可靠的答案选择或验证方式。

## 蒸馏把大模型探索变成较小模型的监督数据

R1学生使用约800k轨迹做SFT，没有再加RL；它们是不同Qwen与Llama基座上的独立模型，并非将671B权重简单量化或截断。训练2—3 epochs、最大上下文32768、batch64，学习率随学生规模调整。[↗](https://arxiv.org/pdf/2501.12948v2#page=35)

| Student | AIME pass@1 | AIME cons@64 | MATH-500 | GPQA | LiveCodeBench |
| --- | ---: | ---: | ---: | ---: | ---: |
| Qwen 1.5B | 28.9 | 52.7 | 83.9 | 33.8 | 16.9 |
| Qwen 7B | 55.5 | 83.3 | 92.8 | 49.1 | 37.6 |
| Qwen 14B | 69.7 | 80.0 | 93.9 | 59.1 | 53.1 |
| Qwen 32B | 72.6 | 83.3 | 94.3 | 62.1 | 57.2 |
| Llama 70B | 70.0 | 86.7 | 94.5 | 65.2 | 57.5 |

同为32B，直接做超过10k步RL的Qwen2.5-32B-Zero在AIME为47.0，蒸馏学生为72.6；LiveCodeBench40.2对57.2。这表明在该基础模型、算法和预算下，继承更强模型产生的解题轨迹比让小模型独立探索更有效。它没有证明小模型RL永远无用，也不是两种路线全部前期成本相同的比较。[↗](https://arxiv.org/pdf/2501.12948v2#page=61)

## 成本与基础设施解释了怎样把长轨迹训练跑起来

RL流水线把rollout、reward/reference inference、规则验证与训练分离。rollout使用vLLM、专家并行、热点专家副本与MTP推测解码；代码执行等CPU任务异步重叠。训练按长度排序、Best-Fit packing并平衡各进程chunk数，减少长短轨迹混合造成的padding和尾部等待。下图同时展示阶段切换时模型offload与reload，说明计算阶段并不要求所有大模型始终共驻显存。[↗](https://arxiv.org/pdf/2501.12948v2#page=17)

![RL infrastructure 原图](../../assets/images/paper-deep-dives/technical-reports/deepseek-r1/figure-rl-infra.png){ width="920" }

<small>图源：`DeepSeek-R1`，v2，Figure 5。</small>

| Stage | H800 GPU-hours | Cost at USD 2/GPU-hour |
| --- | ---: | ---: |
| R1-Zero | 101K | 202K USD |
| SFT data creation | 5K | 10K USD |
| R1 | 41K | 82K USD |
| Total reported runs | 147K | 294K USD |

这是扩展版Table7列出的训练运行口径，不包含V3-Base的预训练与全部研究试验。报告使用512张H800，Zero约198小时，R1约80小时；GPU-hour与单机可用时长不能互换。[↗](https://arxiv.org/pdf/2501.12948v2#page=37)

最可迁移的经验是把可靠验证、探索和知识转移分工。对答案可检查的任务，用组内相对奖励推动强基座探索；对可读性与开放任务，用SFT和受监控的偏好训练补充；对有限部署资源，用高质量轨迹训练较小学生。它们分别解决不同瓶颈，只有完整保留奖励可信度、基础模型能力与推理预算，R1的结果才具有可复用含义。
