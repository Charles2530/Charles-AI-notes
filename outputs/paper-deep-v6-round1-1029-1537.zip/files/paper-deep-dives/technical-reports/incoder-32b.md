---
paper_date: 2026-03
paper_title: "InCoder-32B: Code Foundation Model for Industrial Scenarios"
paper_topic: 技术报告
---

# InCoder-32B：工业代码基础模型与执行验证训练

!!! info "论文信息"
    **论文题名：** InCoder-32B: Code Foundation Model for Industrial Scenarios。<br>
    **作者：** Jian Yang、Wei Zhang、Jiajun Wu、Junhang Cheng、Shawn Guo、Haowen Wang、Weicheng Gu、Yaxin Du、Joseph Li、Fanglin Xu 等（共 28 人）。<br>
    **机构：** Beihang University、IQuest Research、Shanghai Jiao Tong University、University of Manchester。<br>
    **时间 / 主题：** 2026-03；技术报告。<br>
    **arXiv / 官方报告：** arXiv：[2603.16790](https://arxiv.org/abs/2603.16790)。<br>
    **GitHub / 项目：** GitHub：[github.com/CSJianYang/Industrial-Coder](https://github.com/CSJianYang/Industrial-Coder)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2603.16790)；[GitHub API / repo](https://github.com/CSJianYang/Industrial-Coder)；Checked Date：2026-06-15；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 工业代码的正确性由什么决定

InCoder-32B 关注一个通用编程模型容易忽略的条件：同样是生成代码，Verilog 要满足接口与时序语义，GPU kernel 要遵守硬件限制并真正提速，嵌入式程序要正确配置外设，CAD 脚本则要生成目标几何。语言上合理、语法上可编译，都只完成了其中一部分。

![InCoder industrial code intelligence scope](../../assets/images/paper-deep-dives/technical-reports/incoder-32b/figure-1-scope.png){ width="920" }

Figure 1 将通用代码能力与工业任务并列。模型仍然需要补全、调试和工具调用，但训练信号必须进一步覆盖芯片设计、GPU 优化、嵌入式／汇编优化与 CAD。论文的主要改变发生在数据覆盖、执行环境和训练过程，而非为每个领域分别提供一个模型。[↗](https://arxiv.org/pdf/2603.16790#page=1)

![CUDA grid configuration example](../../assets/images/paper-deep-dives/technical-reports/incoder-32b/figure-2-cuda-grid.png){ width="920" }

Figure 2 给出具体失误。RMS Normalization 的空间尺寸为 512 × 512，共 262,144 个位置；若把这一规模直接放入 `gridDim.y`，会超过图中给出的 65,535 限制。InCoder 的示例将维度展开为一维 grid，避开该配置错误。这个例子说明“知道归一化算法”和“生成能在指定 GPU 接口运行的实现”之间还隔着硬件知识；单个成功案例不能代表所有 kernel 都正确或更快。[↗](https://arxiv.org/pdf/2603.16790#page=2)

## Code-Flow 如何把源码变成可执行经验

模型训练分成预训练、mid-training 和 post-training。三者分别解决工业代码覆盖不足、跨文件与多步开发上下文不足、以及任务回答缺少执行反馈的问题。

![InCoder Code-Flow pipeline](../../assets/images/paper-deep-dives/technical-reports/incoder-32b/figure-3-code-flow-pipeline.png){ width="920" }

Figure 3 从左到右读。预训练先收集、去重和整理代码；中间阶段把工业问答、提交记录、工具轨迹与工程文件放进逐步扩展的上下文；后训练则围绕领域任务生成候选解，用真实工具链验证，再把失败反馈和修复过程变成监督样本。验证结果在这里用于构造训练数据，不能把整个过程直接称作基于执行奖励的强化学习。[↗](https://arxiv.org/pdf/2603.16790#page=3)

按附录 A、F 给出的可落实配置，InCoder-32B 是约 32B 参数的 dense decoder-only Transformer，64 层、hidden size 5,120、FFN intermediate size 27,648，40 个 attention heads 与 8 个 KV heads，head dimension 128。词表大小 76,800，使用 SiLU、RoPE，最大上下文 131,072，训练精度为 BFloat16。报告重点在统一工业训练流程，这些配置本身不构成新的工业推理机制。[↗](https://arxiv.org/pdf/2603.16790#page=37)

### 预训练先找到容易被通用语料淹没的代码

普通代码仓库中，Verilog 与 VHDL 数量很少，CUDA 可能混在 C/C++ 中，驱动和普通 C 程序也很难仅凭后缀区分。作者采用三层召回：规则寻找明显工业特征，FastText 分类器扩展到统计特征相似的文件，再用领域语义编码器找没有显式关键词的硬件与系统代码。技术书籍、硬件手册 OCR、厂商文档和技术论坛补充仓库外知识。

清洗包括许可证与隐私过滤、凭据移除、无效文件检查，以及精确 hash、token 近重复、仓库 fork 和跨来源去重。整理阶段补充跨文件依赖、平台约束与自然语言说明，并用 AST 比较和重新编译约束改写后的代码。这样做的目的，是提高数据可学习性，同时避免格式整理改变程序语义。[↗](https://arxiv.org/pdf/2603.16790#page=29)

作者报告预训练使用 4,096 张 GPU、15T tokens，学习率为 $3\times10^{-4}$，global batch size 为 2,048。训练目标包括自回归语言建模与 fill-in-the-middle，课程由函数、单文件逐步扩展到多文件和项目级样本，并在每个 batch 保留通用代码与文本。论文没有将完整训练成本折算为可直接复现的 GPU 小时；32B 是模型规模，不能由此推断训练预算很低。[↗](https://arxiv.org/pdf/2603.16790#page=30)

### Mid-training 学习工程上下文，而不只是加长窗口

上下文从 8K 扩展到 32K，再到 128K。第一个阶段偏向 RTL 模块补全、kernel infill 与 testbench 生成；第二个阶段容纳多轮调试、大型硬件工程依赖和多文件修改。两阶段的数据比例也随任务跨度改变。

| Data category | 8K → 32K | 32K → 128K | 提供的监督 |
| --- | ---: | ---: | --- |
| Synthetic reasoning QA | 40% | 25% | 时序、资源、内存安全和数值精度分析 |
| Agent trajectories | 20% | 30% | Thought–Action–Observation 与工具反馈 |
| Code commits | 15% | 10% | 修改意图、修改前后代码与依赖变化 |
| Industrial artifacts | 15% | 10% | testbench、约束文件、综合脚本、profiling 与日志 |
| File-level FIM | 10% | 25% | 在结构边界内完成缺失代码 |

32K 阶段直接训练长至 32K 的序列，不采用位置编码插值；128K 阶段中，超过 32K 的长样本占比从 10% 开始，在前四分之一训练步内线性增至 50%，并回放 5%–10% 的前阶段数据。学习率重置后再次 cosine decay。[↗](https://arxiv.org/pdf/2603.16790#page=31)

![Mid-training loss curves](../../assets/images/paper-deep-dives/technical-reports/incoder-32b/figure-7-midtrain-loss.png){ width="920" }

Figure 7 展示两个扩窗阶段的训练 loss。它支持渐进长样本引入可以维持训练收敛这一观察；loss 下降本身不能替代跨文件调试或 128K 依赖定位的专项测量。

合成 QA 从实际工程场景开始，先明确平台、接口、时序或资源限制，再生成或抽取种子代码，最后构造根因分析、性能诊断与修改权衡问答。验证包含代码执行、静态分析和逻辑一致性检查。轨迹数据则保留编译器、仿真器、综合工具与形式检查器的反馈，使模型接触“上一种修改为什么失败”。源码、提交和工具输出在这里承担不同的信息角色，不能用更多静态代码完全替代。[↗](https://arxiv.org/pdf/2603.16790#page=32)

## 四类执行环境怎样定义监督

工业训练数据的关键是验证器的含义。论文为各领域设置不同环境，其信号覆盖范围也不同。[↗](https://arxiv.org/pdf/2603.16790#page=4)

| Domain | Execution environment | 主要检查 |
| --- | --- | --- |
| RTL / chip design | Icarus Verilog、Verilator、Yosys | 行为仿真、接口与综合可行性，以及面积／时序估计 |
| GPU kernels | A100、CUDA/nvcc、PyTorch runtime compilation、Triton compiler | 可运行性、数值一致性、CUDA events 计时 |
| Parametric CAD | CadQuery / OpenCascade | 脚本执行、实体生成与体素几何重合 |
| Embedded C | ARM GCC、CMSIS、STM32F407 的 Renode 环境 | 固件构建、外设与中断行为 |
| Assembly optimization | 原生 x86-64、固定频率、绑定核心、重复计时 | 测试集正确性与相对 gcc `-O3` 的速度 |

这些环境把领域约束带入样本筛选，但每种验证仍有明确范围。RTL 仿真和综合通过不等于完成物理实现与芯片签核，Renode 通过也不能替代目标板的全部模拟电气与真实时序测试。GPU 计时依赖 A100 与相应工具链；将代码迁到其他设备时仍需重测。

Post-training 构造 2.5M 条 SFT 样本，报告约 4.9K steps、global batch size 512。每个任务规范化为需求、接口、目标平台、工具链、依赖和验证脚本；候选解来自参考改写、模板扰动、跨语言迁移、检索增强与强模型生成等渠道。

未通过的候选不直接丢弃。流水线保存错误代码、编译日志、反例、波形差异或性能瓶颈，再生成修复版本并重新验证。最终语料同时包含直接解答、缺陷修复、性能与结构优化三类。前者学习从需求到实现，后两类学习怎样利用外部证据改变已有实现。[↗](https://arxiv.org/pdf/2603.16790#page=34)

这一流程并没有给部署模型一个自动保证正确的开关。推理时仍然需要把生成结果送到相同类型的工具链，保留反馈并迭代；训练学到的是使用这些证据的倾向和知识。

## 先区分指标，再看工业结果

论文评测 14 个通用代码 benchmark 与 9 个工业 benchmark。工业侧的“成功”差异很大。VeriScope 的 568 个问题按编译失败、可编译但测试失败、测试通过分别计 0/50/100；RealBench 的 Syn 测可编译，Func 进一步测功能；ArchXBench 的 $n$ 是五个候选中可编译的数量，$t$ 是最佳候选通过 testbench assertions 的比例。

GPU 优化还增加性能门槛。KernelBench 的 $\mathrm{fast}_1$ 衡量生成结果既正确、又快于 PyTorch baseline 的任务比例。它与普通 Pass@1 不可互换。CAD-Coder 同时报告脚本执行成功率与几何 IoU；高执行成功率也可能对应错误形状。[↗](https://arxiv.org/pdf/2603.16790#page=10)

![Industrial benchmark comparison](../../assets/images/paper-deep-dives/technical-reports/incoder-32b/figure-4-industrial-benchmarks.png){ width="920" }

Figure 4 展示多个领域的代表指标，适合寻找能力轮廓；各柱的指标定义不同，不能把高度平均成统一工业智能分数。完整结果中的几个关键对比如下，数值按原表保留。

| Benchmark / Metric | InCoder-32B | Claude-Sonnet-4.6 | Kimi-K2.5 | Qwen3.5-397B-A17B |
| --- | ---: | ---: | ---: | ---: |
| VeriScope Score | 80.7 | 87.7 | 73.1 | 44.8 |
| VeriRepair Fix (%) | 80.0 | 83.3 | 83.3 | 86.7 |
| RealBench Module Syn@1 | 74.8 | 69.2 | 43.7 | 35.2 |
| RealBench Module Func@1 | 62.7 | 33.5 | 23.1 | 16.4 |
| RealBench System Syn@1 | 10.0 | 41.2 | 5.0 | 11.2 |
| ArchXBench $t$ | 51.0 | 58.2 | 49.7 | 53.5 |
| CAD-Coder Compilation | 82.0 | 77.0 | 40.0 | 36.0 |
| CAD-Coder IoU | 53.5 | 32.4 | 12.1 | 14.2 |
| EmbedCGen Main (%) | 35.2 | 79.0 | 81.0 | 17.8 |
| SuperCoder Accuracy (%) | 91.0 | 88.0 | 46.0 | 34.0 |
| SuperCoder Average Speedup | 1.3× | 4.6× | 1.9× | 1.2× |
| KernelBench L1 / L2 / L3 | 22.2 / 36.0 / 14.0 | 11.1 / 28.0 / 2.0 | 13.1 / 23.0 / 6.0 | 4.0 / 10.0 / 0.0 |

RealBench 的模块级 Func@1 达到 62.7，说明收益不只是输出更容易编译；但 system-level Syn@1 只有 10.0，从局部模块走向完整层级设计仍然困难。CAD 的执行率和 IoU 同时领先这些对照，支持脚本生成与形状匹配都有改善。KernelBench 三个层级也都更强，说明在这些 workload 上，正确性与速度的联合门槛能够受益于工业训练。[↗](https://arxiv.org/pdf/2603.16790#page=11)

相反，EmbedCGen 只有 35.2%，明显低于 GLM-5 的 90.2%、GLM-4.7 的 89.6% 和上表中的多个模型。SuperCoder 的 91.0% 正确率较高，平均加速却只有 1.3×，低于 Claude 的 4.6×。所以“统一覆盖多个工业领域”成立，并不意味着每个领域或每种优化目标都领先。[↗](https://arxiv.org/pdf/2603.16790#page=12)

TritonBench 更显示了指标口径的重要性。InCoder 的 G-call 为 18.5%，表中 G-exe 为 100.0%；T-call 为 19.3%，T-exe 为 93.8%。由于 execution 数值高于 call 数值，不能把 G-exe 的 100.0% 解读为所有生成任务均端到端正确。实际可调用比例仍然很低，部署判断首先需要关注 call 层面的失败。

## 通用能力保留到什么程度

InCoder 在 HumanEval / HumanEval+ 达到 94.5 / 89.6，BigCodeBench Full / Hard 为 49.8 / 31.1，SWE-bench Verified 为 74.8。其 SWE-bench Verified 高于该表中的 DeepSeek-V3.2 73.1、GLM-4.7 73.8 和 Qwen3-Coder-480B 67.0，但 Terminal-Bench v2.0 为 22.5，低于这些模型中的部分结果。[↗](https://arxiv.org/pdf/2603.16790#page=8)

| Capability | InCoder-32B | 结果含义 |
| --- | ---: | --- |
| LiveCodeBench V5 / V6 | 53.3 / 49.1 | 竞赛编程表现取决于题目版本，不能只引用一个不带版本的分数 |
| Mercury Beyond@1 / Pass@1 | 71.4 / 85.6 | 通用代码效率并非模型最突出维度 |
| BIRD / Spider | 55.4 / 79.7 | 仍保留 Text-to-SQL 能力 |
| SWE-bench Verified | 74.8 | 仓库修复表现强，但结果依赖评测工作流 |
| Terminal-Bench v1.0 / v2.0 | 35.0 / 22.5 | 终端任务与仓库修复没有同步领先 |
| Mind2Web / BFCL V3 | 55.8 / 61.0 | 覆盖网页操作与函数调用 |
| $\tau^2$ Airline / Retail / Telecom | 70.0 / 85.1 / 86.8 | 三个业务环境的表现不同 |

因此，工业数据没有使模型只剩领域模板能力，但也没有消除通用推理与终端操作的短板。对于具体工程任务，应优先选择与目标工作流接近的 benchmark，而不以 SWE-bench 的一个高分替代全部 agentic 能力。[↗](https://arxiv.org/pdf/2603.16790#page=9)

## 扩大 SFT 有效，失败仍然分层出现

作者将工业 SFT 从 83M 扩展到 167M、250M tokens，比较九个工业 benchmark。这是关于工业监督规模的实验，并未单独控制全部语料类别来分离它们各自的因果贡献。

![SFT data scaling](../../assets/images/paper-deep-dives/technical-reports/incoder-32b/figure-6-sft-scaling.png){ width="920" }

Figure 6 中 CAD 编译、VeriRepair、EmbedCGen、SuperCoder 正确率与 KernelBench 大体随规模上升；部分 RealBench 和 TritonBench 子指标在最后阶段波动。应关注同一子图内的趋势，多个面板带双纵轴，正确率和速度不能按曲线的视觉高度直接比较。这个实验支持继续增加经验证工业样本的价值，而不能证明所有指标都会单调变好。[↗](https://arxiv.org/pdf/2603.16790#page=15)

![Industrial benchmark error distribution](../../assets/images/paper-deep-dives/technical-reports/incoder-32b/figure-5-error-distribution.png){ width="920" }

Figure 5 检查 1,882 个失败案例，中心数字是该 benchmark 的失败数量，扇区是失败内部的分类比例。它不是整个测试集的错误率，也不能用某个扇区百分比直接反推主表得分。

失败首先来自精确接口知识。EmbedCGen 的失败中 47% 是链接错误，TritonBench 中 33% 是 NameError、24% 是 TypeError。工业 API 名称、参数与类型约束仍会被用错。第二层是可执行但语义错误：VeriRepair 失败中 79% 属于逻辑／功能问题，ArchXBench 为 49%，CAD 失败大多是几何不匹配。第三层才是性能，KernelBench 失败中约 33% 是正确但不够快，SuperCoder 失败中 83% 没有实现有效优化。[↗](https://arxiv.org/pdf/2603.16790#page=14)

这些层次决定了训练数据该补什么。API 错误需要准确接口与工具反馈；状态机或几何语义需要能区分近似正确与实际正确的测试；性能错误则需要设备相关计时和 profiling。继续增加没有这些判定条件的代码文本，不一定击中同样的瓶颈。

## 可以迁移的是验证器驱动的数据流程

InCoder 最可复用的做法是把平台、接口、依赖与验证脚本一起写入任务，再保留候选失败、工具反馈和修复版本。对于已有模型的领域适配，这一流程比从头复刻 15T-token 预训练更直接：先选择有可靠自动判定的任务，把“编译、功能、性能”逐层记录，避免将它们压成模糊的好坏标签。

结果也给出了采用范围。CAD、部分 GPU workload 和模块级 RTL 是当前较强的应用入口；嵌入式外设、完整硬件系统与激进性能优化需要更谨慎的专项评测。模型可以提出候选并利用反馈，但最终的正确性仍落在目标工具链、测试覆盖和真实设备条件上。
