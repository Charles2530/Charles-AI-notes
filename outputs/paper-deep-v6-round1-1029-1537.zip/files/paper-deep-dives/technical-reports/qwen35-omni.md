---
paper_date: 2026-04
paper_title: "Qwen3.5-Omni Technical Report"
paper_topic: 技术报告
---

# Qwen3.5-Omni：Thinker-Talker 与全模态 Agent

!!! info "论文信息"
    **论文题名：** Qwen3.5-Omni Technical Report。<br>
    **作者：** Qwen Team。<br>
    **机构：** 未在公开元数据中稳定解析；以 arXiv/PDF 或官方页 affiliation block 为准。<br>
    **时间 / 主题：** 2026-04；技术报告。<br>
    **arXiv / 官方报告：** arXiv：[2604.15804](https://arxiv.org/abs/2604.15804)；官方材料：[www.alibabacloud.com/help/en/model-studio/qwen-omni](https://www.alibabacloud.com/help/en/model-studio/qwen-omni)。<br>
    **GitHub / 项目：** GitHub：未找到官方链接；项目页：[www.alibabacloud.com/help/en/model-studio/qwen-omni](https://www.alibabacloud.com/help/en/model-studio/qwen-omni)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2604.15804)；[官方 / 项目材料](https://www.alibabacloud.com/help/en/model-studio/qwen-omni)；Checked Date：2026-06-04；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 实时全模态助手的困难，在于不同信息要按不同速度流动

Qwen3.5-Omni 把多模态理解、文本决策和流式语音放在同一个系统中。它需要从视频和声音判断正在发生什么，决定回答或调用工具，再及时说出来。视频片段、语音帧和文字 token 的时间尺度不同；如果只扩大上下文，系统可能读得更多，却仍然开口很慢，或在文字与声音对齐时跳词。

报告沿用 Qwen2.5-Omni、Qwen3-Omni 的 Thinker–Talker 分工，主要改动是 Hybrid Attention MoE、256K 上下文、显式时间戳、ARIA 文本语音交织，以及更大规模的多语言训练。Plus 与 Flash 都是 instruct 模型，报告称规模扩展到数千亿参数，但没有逐一公开两档模型的精确参数配置。[↗](https://arxiv.org/pdf/2604.15804v2#page=1)

总览图先区分输入、响应和工具动作。模型能接收文字、图像、声音与视频，返回文本或实时语音；音视频工具使用还需要把感知结果变成结构化调用。这些是同一交互系统里的不同能力，不能仅凭输入模态齐全就认定工具任务能够可靠完成。

![Qwen3.5-Omni overview](../../assets/images/paper-deep-dives/technical-reports/qwen35-omni/figure-1-overview.png){ width="920" }

*原文 Figure 1，统一的输入输出与交互任务。*

## Thinker 的中间表示怎样进入 Talker

架构图应从下往上读。Vision Encoder 和 AuT 分别编码视觉与音频，将表示与文字、时间戳交织后送入 Thinker。Thinker 负责理解和文本生成；它的中间层表示、历史对话和当前流式文本继续进入 Talker，使后者不仅知道“说哪句话”，还能够利用声音、画面和对话情境调节韵律、响度与情绪。

![Qwen3.5-Omni architecture](../../assets/images/paper-deep-dives/technical-reports/qwen35-omni/figure-2-architecture.png){ width="920" }

*原文 Figure 2。下方是带时间信息的感知序列，中部是 Thinker 到 Talker 的表示传递，右上方是逐帧语音合成。*

Thinker 和 Talker 均采用 Hybrid MoE。报告特别指出 Gated Delta Net 有助于降低长音视频序列的 KV-cache I/O，改善解码吞吐与并发。混合架构并不意味着所有层都变成相同的线性状态更新；文章没有给出足以独立还原这两个大模型的完整层数与混合比例。[↗](https://arxiv.org/pdf/2604.15804v2#page=6)

Talker 操作 RVQ 多码本语音表示。主干自回归预测当前帧的主要 code，轻量 MTP 模块补齐该帧的 residual codebooks，再由因果 ConvNet Code2Wav 增量还原波形。因此这里的 MTP 主要沿同一声学帧的码本维度补充细节，不能与语言模型一次草拟多个未来文本 token 的推测解码混为一谈。

Talker 另有专门的 system prompt 描述目标声音，可包含文字说明和参考 codec 序列，用于声音定制与控制。这条条件路径比一个固定 speaker embedding 更丰富，但声音相似度、内容正确性与自然度仍要分别测量。[↗](https://arxiv.org/pdf/2604.15804v2#page=5)

## 十小时音频如何进入 256K 上下文

AuT 从音频特征开始压缩。输入先重采样为 16 kHz，以 25 ms 窗、10 ms hop 提取 128 通道 mel-spectrogram；四个 Conv2D block 做 16 倍下采样，再经 attention encoder 输出约 6.25 Hz 的音频表示，即每个输出帧对应约 160 ms。

![Qwen3.5-Omni AuT](../../assets/images/paper-deep-dives/technical-reports/qwen35-omni/figure-3-aut.png){ width="760" }

*原文 Figure 3。关注降采样与编码路径，它们决定送入 Thinker 的音频序列长度。*

按这个速率计算，十小时产生约 $6.25\times3600\times10=225000$ 个音频表示位置，给 262144-token 窗口中的文字和时间戳留下余量。这解释了容量上的可行性，却不是十小时材料任意细节都能正确检索的实验证明。视频还有空间 patch 成本，报告的另一项规格是 720P、1 fps 时约 400 秒；这与动态帧率处理能力也应分开。[↗](https://arxiv.org/pdf/2604.15804v2#page=4)

AuT 使用约 4000 万小时、由 Qwen3-ASR 生成配对监督的音频文本数据训练。中文、英文、多语言比例为 3.5:3.5:3，覆盖二十多种语言；动态 attention window 训练同时照顾实时 prefill cache 与离线理解。这个编码器训练量与整套模型使用超过一亿小时音视频数据的口径不同，也不能再与 Talker 的语音训练量简单相加当作去重后的总小时数。

时间对齐又是另一项设计。单纯将绝对时间映射为越来越大的 temporal position ID，会在长视频中形成稀疏索引。模型保留 TM-RoPE 的时序结构，并在视频或音视频 temporal patch 前加入用秒表示的文本时间戳，音频则在随机间隔插入时间标记。temporal ID 以 160 ms 为时间尺度，不同模态的位置编号保持连续。文本时间戳让“第几秒”成为可直接学习的符号，同时增加少量上下文开销；它没有取消位置编码。

这套表示服务于带时间戳的音视频描述、自动分段和跨模态事件定位。对调用方而言，分辨率、采样帧率和是否保留音频共同决定模型实际看到的证据，输入窗口大小不能替代这些设置。

## ARIA 约束语音进度，避免固定交织率错配语言

同样一句话，不同语言和文字 tokenizer 会产生不同数量的 text tokens，声学编码又按自己的时间粒度产生 speech tokens。固定“若干文字配若干声音”的交织比例容易失配，出现漏词、错音或数字读法混乱。ARIA 将此前双通道组织改为单一交织序列，并对任意前缀的累计比例施加约束。

把原文的文字规则记号化，令前缀中语音、文字 token 数分别为 $S_k,T_k$，该样本整体数量为 $S,T$，则要求

$$
\frac{S_k}{T_k}\leq\frac{S}{T},\qquad T_k>0.
$$

这只是报告对齐原则的数学表达，不是论文另给出的损失函数。它防止语音相对于文字在前缀中过快推进，并允许任意长度文字前缀后接连贯语音。样本之间的比例可以不同，因此比跨语言固定交织率更灵活；也不依赖 MFA 提供逐词强制对齐。报告没有展开部署中全部比例估计与调度细节，不能单靠这个不等式重建 Talker。[↗](https://arxiv.org/pdf/2604.15804v2#page=5)

与 RVQ、MTP、因果波形解码器结合后，ARIA 减少两条生成轨道之间的同步与调度负担。它解决的是流式组织问题，自然度和稳定性的最终效果还包含语音数据、偏好训练和声音微调的共同作用，主结果不能直接当作 ARIA 单独的因果消融。

## 三段预训练与两条后训练路径各补什么能力

预训练首先固定 LLM，分别对视觉和音频路径做 alignment，先训练 adapter，再训练 encoder；主干和视觉编码器从 Qwen3.5 初始化，音频编码器从 AuT 初始化。第二阶段解冻全部参数，以 32768 序列长度混合文字、音频、图像、视频和音视频；第三阶段提高长音频、长视频比例，将最大长度扩到 262144。[↗](https://arxiv.org/pdf/2604.15804v2#page=7)

报告将第二阶段总量写为约 4T tokens，分项为文字 0.92T、音频 1.99T、图像 0.95T、视频 0.14T、音视频 0.29T。这些近似分项合计 4.29T，应保持约数口径。它们描述各表示进入训练的 token 数，不能用来直接比较各模态的原始信息量。

Thinker 后训练分三步。先为文字、代码、agent、视觉和音频分别训练 SFT/RL 专家教师，用教师数据将能力蒸馏进统一模型；再用配对的音频与文字问题，将文字条件下较好的回答作为对应音频问题的目标，缩小“同一个问题说出来后回答变差”的差距。最后通过多轮轨迹的 interaction-aligned RL 改善无意切换语言、角色不一致和长对话指令遗忘。报告将第二步称为 on-policy distillation，但没有披露可复现全部更新的目标公式，不宜自行补成某个特定 RL 算法。

Talker 则先用超过 2000 万小时、带多模态上下文的语音训练；再筛选高质量数据持续预训练，并借助 Qwen3-Omni-Captioner 改善噪声监督，将自身上下文扩至 64K。其后使用人工偏好对做 DPO，结合规则奖励和 GSPO，最后进行轻量 speaker fine-tuning。这里 Talker 的 64K 与 Thinker 的 256K 是不同模块的训练规格。[↗](https://arxiv.org/pdf/2604.15804v2#page=8)

## 首包时间、并发吞吐与生成速度不是同一指标

Table 2 使用内部 vLLM，为 MTP 与 codec decoder 开启 `torch.compile` 和 CUDA Graph，给出报告所称的“理论首包延迟”，对应不同并发下的首包关键路径。下表摘取 Overall Latency 与 Generation RTF；A/V 分别表示音频、视频输入，延迟单位为 ms。

| Variant | Concurrency | Overall Latency A/V (ms) | Generation RTF |
| --- | ---: | ---: | ---: |
| Flash | 1 | 235 / 426 | 0.178 |
| Flash | 4 | 298 / 891 | 0.211 |
| Flash | 8 | 352 / 1625 | 0.257 |
| Plus | 1 | 435 / 651 | 0.187 |
| Plus | 4 | 619 / 1515 | 0.267 |
| Plus | 8 | 955 / 1980 | 0.334 |

RTF 小于 1 说明生成快于对应音频的播放速度，为持续播放留下余量，但不表示第一段声音立即出现。Flash 视频首包从单并发 426 ms 增至八并发 1625 ms，说明提高服务吞吐仍会改变交互等待。Flash 音频 Thinker 的总吞吐由 177 增至 942 tokens/s，也不应解读成单个请求加速 5 倍。[↗](https://arxiv.org/pdf/2604.15804v2#page=6)

Thinker TTFT、Talker TTFC、每 token 时间和 codec 的 3–5 ms 分别对应不同环节。ARIA 交织生成存在重叠和依赖，不能把几行延迟直接相加算首包。Plus 与 Flash 还采用不同资源分配和并行策略，因此两档结果可用于理解各自服务特性，不能作为同硬件预算下的严格架构对照。

## 增加音频之后，原有文字和视觉能力保留了多少

与 Qwen3.5-Plus-Instruct 比较，可以检查统一模型是否明显牺牲原有能力。Table 4 和 Table 6 显示总体接近，但存在下降与提升。

| Benchmark | Qwen3.5-Plus-Instruct | Omni-Plus |
| --- | ---: | ---: |
| MMLU-Pro | 86.8 | 85.9 |
| IFBench | 51.1 | 52.6 |
| AA-LCR | 62.0 | 57.0 |
| LiveCodeBench v6 | 67.1 | 65.6 |
| BFCL-V4 | 66.1 | 63.3 |
| MMMU | 81.0 | 80.1 |
| VideoMME, without subtitles | 81.0 | 81.9 |
| LVBench | 68.6 | 71.2 |

指令遵循和视频理解的部分指标提高，长文本与部分代码、工具任务有所下降。因此“整体保持竞争力”比“无任何退化”更符合表格。报告推测 OPD 和交互 RL 有助于指令遵循，但没有逐项拆开的受控结果，不能把 IFBench 的全部差值独立归因于其中一步。[↗](https://arxiv.org/pdf/2604.15804v2#page=10) [↗](https://arxiv.org/pdf/2604.15804v2#page=12)

## 声音理解和音视频工具使用呈现不同强项

音频理解不仅是转写。MMAU、MMAR 检查声音推理，音乐任务检查结构与语义，语音对话检查是否正确响应，ASR 则以更低的识别错误率为目标。Table 5 中 Omni-Plus 的 MMAU 为 82.2，Gemini-3.1 Pro 为 81.1；RUL-MuchoMusic 为 72.4 对 59.6，VoiceBench 为 93.1 对 88.9。但 MMAR 为 80.0 对 83.7，WildSpeech-Bench 为 75.4 对 76.3，不能将音频优势扩写成每个子任务领先。

FLEURS top60 的识别错误率为 6.55 对 7.32，LibriSpeech clean 为 1.11 对 3.36。附录 Table 13 对特定语言使用 CER，其余使用 WER；多语言总分需沿用作者的混合口径。翻译的 top59 列表又排除了没有对应 S2TT 测试数据的 Afrikaans，不能把 top60 ASR 和 top59 翻译当作完全相同集合。[↗](https://arxiv.org/pdf/2604.15804v2#page=11)

音视频任务需要进一步检查图像与声音能否共同支持回答。

| Benchmark | Gemini-3.1 Pro | Omni-Flash | Omni-Plus |
| --- | ---: | ---: | ---: |
| DailyOmni | 82.7 | 81.8 | 84.6 |
| WorldSense | 65.5 | 57.9 | 62.8 |
| AV-SpeakerBench | 75.1 | 65.2 | 71.3 |
| VideoMME, with audio | 89.0 | 79.3 | 83.7 |
| Qualcomm IVD, audio query | 66.2 | 66.3 | 68.5 |
| Omni-Cloze, caption | 57.2 | 63.0 | 64.8 |
| OmniGAIA, tool use | 68.9 | 33.9 | 57.2 |

Omni-Plus 在 DailyOmni、音频提问和 caption 上较强，但说话者关联、部分视频理解和工具使用仍落后表中对照。OmniGAIA 未加 thinking prompt，也没有 `<answer>` 格式，统一用 DeepSeek-V3.2-Thinking 评分，结果对应这一 harness。报告称 Audio-Visual Vibe Coding 为新出现的能力，展示模态输入可以进入代码生成；这并不提供复杂软件项目长期可靠性的量化保证。[↗](https://arxiv.org/pdf/2604.15804v2#page=13)

## 语音合成必须同时检查内容、声音与语言方向

在 SEED-TTS 的 zero-shot 条件下，Omni-Plus 中文/英文 WER 为 0.99/1.26，Qwen3-Omni 为 1.07/1.39。英文结果改善，但中文仍高于 CosyVoice3 的 0.71。WER 主要检验说出的内容是否与目标一致，不能单独证明声音自然或说话者身份保留得更好。

Table 9 因而同时报告 WER 与 speaker cosine similarity。中文结果为 0.695 WER、0.800 similarity，英语为 0.631、0.833；阿拉伯语的 WER 2.602 高于 MiniMax 的 1.665，尽管 similarity 更高。两项指标可以不同向变化，选择声音系统时应同时检查。[↗](https://arxiv.org/pdf/2604.15804v2#page=14)

另外九种语言使用内部集合，Table 10 的对照列是 Ground Truth 经识别器转写后的错误率，并没有列出其他 TTS 系统。生成语音比原录音得到更低 ASR 错误率，不意味着生成声音在所有方面超过真人，也不能将该表与 Table 9 合成一个所有厂商共同参加的 29 语言排名。

跨语言声音迁移又改变了条件。Table 11 的目标英语使用 WER，其他语言使用 CER；中文到韩文时 Omni-Plus 为 4.03，Qwen3-Omni 为 5.13，CosyVoice3 为 14.4。相对 CosyVoice3 的降低按 $(14.4-4.03)/14.4$ 计算约为 72%，不能把它写成相对上一代 Qwen 的改善。日语到中文则为 3.55，高于 CosyVoice3 的 3.05，语言方向依然影响选择。[↗](https://arxiv.org/pdf/2604.15804v2#page=15)

最后，Table 12 评测 speaker fine-tuning 后的定制声音，商业接口取自 2026 年 3 月，并指定了各自声音。Omni-Plus 在日语、韩语等方向较强，但俄语 WER 4.723 高于表中四个对照。这与直接提供参考语音的 zero-shot 实验是不同设置，不能混成一个单一的 voice cloning 分数。

语言覆盖也应按任务看。Table 3 列出 201 种文字语言、113 种语音输入语言与方言，其中语音输入由 74 种语言和 39 种中文方言组成；语音输出是 29 种语言加 7 种中文方言。支持列表并不代表每项都有同样数量、同样难度的测试，摘要中的 215 项统计也包含语言级子任务，而非 215 个互相独立的大型 benchmark。

## 可以复用的是把感知、表达与服务预算分别设计

这份报告把三类问题连接起来。压缩后的音频与显式时间戳让长序列可用；Thinker 到 Talker 的上下文传递保留声音表达所需的信息；ARIA、RVQ 与流式解码让回答可以逐步播放。专门教师、文字到音频回答迁移和交互 RL，再补上统一训练后仍然存在的能力差距。

实际采用时，可以先用目标任务判断 Plus 或 Flash 的能力是否足够，再固定视频采样方式、上下文长度和并发量测量首包与持续播放。对语音产品，同时测内容错误、声音相似度和长对话一致性；对音视频 agent，另外检查工具最终是否完成任务。报告提供 API 与在线演示，未给出完整可本地复现的模型配置；它最有价值的部分，是将这些原本容易混在一起的接口和测量条件具体化。
