---
paper_date: 2025-10
paper_title: "LongCat-Video Technical Report"
paper_topic: 技术报告
---

# LongCat-Video：长视频生成、GRPO 与高效推理

!!! info "论文信息"
    **论文题名：** LongCat-Video Technical Report。<br>
    **作者：** Meituan LongCat Team、Xunliang Cai、Qilong Huang、Zhuoliang Kang、Hongyu Li、Shijun Liang、Liya Ma、Siyu Ren、Xiaoming Wei、Rixu Xie、Tong Zhang。<br>
    **机构：** Meituan LongCat Team。<br>
    **时间 / 主题：** 2025-10；技术报告、视频生成、长视频、世界模型。<br>
    **arXiv / 官方报告：** arXiv：[2510.22200](https://arxiv.org/abs/2510.22200)。<br>
    **GitHub / 项目：** GitHub：[github.com/meituan-longcat/LongCat-Video](https://github.com/meituan-longcat/LongCat-Video)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2510.22200)；[GitHub](https://github.com/meituan-longcat/LongCat-Video)；Checked Date：2026-07-08；Repro Status：Author Code / Model Weights available, independent reproduction not claimed。

## 长视频首先是一项连续预测任务

LongCat-Video 从视频生成的一个实际瓶颈出发。一个模型能够生成数秒画面，不代表它可以不断续写而不丢失人物、场景和颜色。若基础训练只学习独立短片，长视频推理就会反复把模型送入与训练不同的条件。报告的解决方向是，把 Video Continuation 直接纳入基础训练，与 Text-to-Video、Image-to-Video 共用一个模型，再通过推理蒸馏、粗到细生成和稀疏注意力降低长序列成本。

模型主体是约 13.6B 参数的 DiT。报告在高效配置下用单张 H800 生成 720p、30 fps、约六秒的视频需要 142 秒，并展示了递归续写到数分钟的案例。30 fps 是成片帧率，不能解读成每秒生成 30 帧的实时系统。论文将它视为向世界模型迈进的基础视频模型，结论部分仍把更准确的物理知识、长期记忆和 LLM 知识融合列为后续方向。

![LongCat-Video teaser](../../assets/images/paper-deep-dives/technical-reports/longcat-video/figure-1-teaser.png){ width="920" }

总览图把多种生成方式放在一起。共同能力是从文本与已有画面推演后续视觉内容；是否具有可用于决策的动力学，还需要动作可控性、物理准确性和闭环任务来检验。本文的主要实证集中在视频生成质量、续写一致性与计算效率。[原文 §1、§6](https://arxiv.org/pdf/2510.22200#page=4)

## 三种生成任务怎样进入同一个 DiT

输入视频先经 Wan2.1 VAE 压缩，时间和空间压缩率分别为 4、8、8，再以 $1\times2\times2$ patch 划分 latent。相对于原始视频，最终 token 网格约对应 $4\times16\times16$ 的时空压缩。文本由 umT5 编码，支持中英提示。主体使用 48 层 Transformer、4096 隐藏维度、16384 FFN 维度和 32 个注意力头。[原文 §3.1](https://arxiv.org/pdf/2510.22200#page=7)

三种任务的差别由条件帧数量表示。文生视频没有已有视频帧；图生视频有一帧；续写有多帧历史。条件帧保持干净，时间步标记为零，待生成部分在相应噪声时间步上训练，损失只作用于后者。这种组织让任务差异变成统一序列中的条件长度变化，避免每个任务另建一套模型。

![Unified video architecture](../../assets/images/paper-deep-dives/technical-reports/longcat-video/figure-5-unified-architecture.png){ width="920" }

图中的注意力方向是实现续写和缓存的关键。设条件 token 为 $C$，待生成的噪声 token 为 $X_t$，可以把原文的可见性写成

$$
C\rightarrow C,\qquad X_t\rightarrow [C,X_t].
$$

箭头表示查询能够读取哪些键和值。条件只看条件，因此它在不同去噪步中不会被当前噪声污染；生成部分同时看历史与当前待生成片段。条件的 KV 可以跨去噪步缓存，减少重复计算。这个掩码在“历史条件与新片段”之间具有因果方向，但新片段内部仍联合去噪，不能说每个新视频帧都像语言 token 一样逐帧自回归产生。

训练时，条件帧来自真实视频；递归生成时，条件会包含模型自己生成的结果，两种分布仍有差别。报告对历史帧加入逐帧独立的噪声扰动，训练模型容忍输入历史的质量与颜色变化，降低反复续写时的颜色漂移。它提高的是对不完美历史的稳健性，并没有建立一个无限容量的长期状态记忆。

## 数据管线不仅筛选清晰画面，还要告诉模型发生了什么

![Data curation pipeline](../../assets/images/paper-deep-dives/technical-reports/longcat-video/figure-2-data-curation-pipeline.png){ width="920" }

数据管线先解决重复与片段边界。视频通过标识和 MD5 去重，使用 PySceneDetect、TransNetV2 等工具切分镜头，再处理黑边、尺寸和画幅。随后用美学、模糊、文字水印与光流等信号描述质量。光流在这里帮助判断运动强弱，单纯筛选漂亮静态画面会让模型缺少动作变化的训练信号。

过滤之后还需要重平衡。常见画面可以贡献大量样本，但过度重复会挤占少见场景、动作和构图。报告通过密度相关的采样调整数据分布，使训练既接触主流内容，也有机会学习尾部情形。这一步影响模型会频繁生成什么，不能只用总视频时长概括数据质量。

![Video caption workflow](../../assets/images/paper-deep-dives/technical-reports/longcat-video/figure-3-caption-workflow.png){ width="920" }

字幕工作流把视觉内容拆成不同层次。经微调的 LLaVA-Video 与 Tarsier2 帮助描述事件及时间变化，Qwen2.5-VL 补充镜头与风格信息，再组织中英文描述与摘要。短提示突出核心事件，细提示提供主体、环境、运动和摄影信息。这样的监督让“画面里有什么”与“按怎样的次序发生”都能进入训练，而不只是为整段视频配一个静态标签。[原文 §2](https://arxiv.org/pdf/2510.22200#page=4)

## 分辨率、任务与质量分阶段增加

![Training overview](../../assets/images/paper-deep-dives/technical-reports/longcat-video/figure-6-training-overview.png){ width="920" }

训练图连接了基础模型、质量后训练和加速分支。基础训练先用低分辨率建立内容与运动先验，再逐步引入更长视频、图生视频和续写，最后提高分辨率。这样既减少早期昂贵的高分辨率计算，也避免高质量数据有限时直接从头训练全部能力。

| 原文 Tables 3–4 的阶段 | 分辨率与主要任务 | 训练步数 | 学习率 |
|---|---|---:|---:|
| 图像预训练 | 256p T2I | 285K | $10^{-4}$ |
| 加入视频 | 256p，93 frames，T2I + T2V | 140K | $10^{-4}$ |
| 统一任务训练 | 256p，93 frames，加入 I2V / VC | 164K | $5\times10^{-5}$ |
| 提高分辨率 | 480p | 36K | $5\times10^{-5}$ |
| 混合分辨率 | 480p + 720p | 53K | $2\times10^{-5}$ |
| 高质量监督微调 | SFT | 7.5K | $10^{-5}$ |

基础模型采用 flow matching，用真实视频 latent 与噪声之间的插值构造训练输入，再回归去噪方向上的速度；条件帧不承担预测损失。时间步均匀采样，损失使用类似 logit-normal 的权重，并按目标 token 体积调整时间步偏移，让更长、更高分辨率视频获得合适的噪声分布。续写历史还单独接受逐帧扰动，以适应生成时不完全干净的历史。

监督微调之后还有两条不同目的的路线。GRPO 调整人类偏好、运动与文本对齐；蒸馏和细化专家降低推理成本。后者的步数减少不等于基础训练更少，前者的奖励改善也不自动说明物理规律更准确。实际复现需要明确使用哪一个检查点及其配套推理配置。[原文 §4、Tables 3–4](https://arxiv.org/pdf/2510.22200#page=17)

## GRPO 为什么要修改噪声采样和奖励归一化

视频扩散的奖励通常在成片后给出，而模型在许多去噪步上作出预测。若每一步都注入独立随机性，一个好视频究竟因为哪一步更好就难以判断。LongCat-Video 让同组候选共享初始噪声，并只在一个关键时间步使用随机 SDE 更新，其他步骤使用确定性 ODE 更新。实验从 16 步采样的前 6 步范围中选择关键步，把组内差异更集中地归因到这一处策略变化。

![GRPO quality comparison](../../assets/images/paper-deep-dives/technical-reports/longcat-video/figure-7-grpo-quality.png){ width="920" }

质量对照展示 GRPO 后主体、画面质量与指令响应的变化。它对应的是特定提示下的样例；训练收益是否稳定，还要看奖励曲线与后续评测，不能只靠挑选成片判断。

原文还推导了 flow matching 下奖励梯度随时间步的缩放。记噪声时间为 $t$、离散步长为 $\Delta t$，原始梯度中出现

$$
\kappa(t)=\sqrt{\frac{\Delta t(1-t)}{t}}.
$$

在高噪声端，这一因子可能使有效更新变弱。作者为策略项与 KL 项分别使用

$$
\lambda_{\mathrm{policy}}(t)=\sqrt{\frac{t}{\Delta t(1-t)}},\qquad
\lambda_{\mathrm{KL}}(t)=\frac{t}{\Delta t(1-t)}
$$

做时间重加权，目标是让不同时间步的优化贡献更均衡。实际实现还对噪声系数裁剪，阈值为 0.45。这些都是对扩散策略优化数值性质的调整，不能简单套用语言模型 token 级 GRPO 的直觉。

奖励归一化解决另一个问题。若同一提示生成的四个视频几乎一样，组内奖励标准差很小，逐组除以它可能放大无意义差异。作者对每个奖励维度 $k$ 使用当前批次各提示组的最大标准差作为分母。令提示组为 $j$，候选为 $i$，则其思想可写为

$$
A_{j,i,k}=\frac{R_{j,i,k}-\bar R_{j,k}}{\max_{j'}\sigma_{j',k}},\qquad
A_{j,i}=\sum_k w_k A_{j,i,k}.
$$

$R$ 是该候选的奖励，$\bar R$ 是同提示候选的均值，$w_k$ 是奖励权重。这样仍比较同一提示下谁更好，但不会把几乎无法区分的一组强行拉成很大优势差。[原文 §3.3、附录 A.1](https://arxiv.org/pdf/2510.22200#page=8)

![GRPO reward curves](../../assets/images/paper-deep-dives/technical-reports/longcat-video/figure-8-grpo-reward-curves.jpg){ width="920" }

奖励曲线用于观察优化是否朝各目标前进。报告同时使用画面质量、文本对齐和运动质量，而没有把单一图像审美分数当成视频质量的全部。HPSv3-general 对视频帧做一般质量评分，HPSv3-percentile 用提示计算高分帧部分的对齐表现，MQ 关注运动，TA 关注文本与整段视频的对应。

![Reward hacking example](../../assets/images/paper-deep-dives/technical-reports/longcat-video/figure-9-reward-hacking.png){ width="920" }

奖励投机案例直接解释多目标设计的必要性。单独优化图像偏好可能得到漂亮却近乎静止的视频；引入运动奖励后，模型才有动力让事件真正发生。训练 MQ 奖励模型时，作者使用灰度视频减少颜色等捷径，避免奖励模型把视觉风格误当作运动质量。多奖励降低了报告观察到的一类投机，不代表所有奖励漏洞都被消除。

这阶段只在 T2V 上训练 LoRA，进行 500 次更新，每步 64 个提示、每组 4 个候选，采样 16 步，LoRA rank 为 128。I2V 和续写的收益属于能力迁移，没有直接接受相同任务形式的 RL 训练。把这一点保留下来，才能区分统一底座带来的迁移与任务专用优化。[原文 Table 9](https://arxiv.org/pdf/2510.22200#page=32)

## 先生成低成本运动，再补足清晰度和帧率

高分辨率视频的全程密集去噪很贵。LongCat-Video 先在 480p、15 fps 下生成基本视频，再用细化模型提升到 720p、30 fps。较低成本的阶段确定主体、构图和主要运动，后阶段在此基础上补细节与时间分辨率。

![Coarse-to-fine quality](../../assets/images/paper-deep-dives/technical-reports/longcat-video/figure-11-coarse-to-fine-quality.png){ width="920" }

质量图比较低分辨率结果与细化结果，说明细化阶段承担纹理和局部清晰度恢复。它并不意味着基础阶段的错误运动能自动修正；主体位置与运动安排已经在前一阶段占据主要约束。

![Coarse-to-fine process](../../assets/images/paper-deep-dives/technical-reports/longcat-video/figure-12-coarse-to-fine-process.png){ width="920" }

流程中先将低分辨率 latent 解码到 RGB，做时空三线性上采样，再编码回高分辨率 latent。记这一结果为 $x_{\mathrm{up}}$，细化起点为

$$
x_{\mathrm{up}}=\operatorname{Encode}(\operatorname{Upsample}(\operatorname{Decode}(x_{\mathrm{lr}}))),
$$

$$
x_{t_*}=(1-t_*)x_{\mathrm{up}}+t_*\epsilon.
$$

其中 $\epsilon$ 为噪声，报告选择 $t_*=0.5$，再进行 5 步细化。保留一部分原视频信号，可以减少从纯噪声重新建立全局结构的工作；适量噪声则给模型改写纹理与补帧的空间。$t_*=1$ 会退回从噪声开始的普通生成，不再充分利用粗视频。

基础生成还通过 CFG 蒸馏和一致性蒸馏压到 16 步。细化专家先做密集训练，再训练稀疏注意力版本，以适应实际部署的算子与可见范围。这是一套经过额外训练的推理方案，不能把未经训练的原模型直接换成任意 5 步采样，就期待同样质量。[原文 §3.4.1、§4.3](https://arxiv.org/pdf/2510.22200#page=13)

## 稀疏注意力先找相关块，再在块内计算精细关系

![Block sparse attention](../../assets/images/paper-deep-dives/technical-reports/longcat-video/figure-13-block-sparse-attention.png){ width="920" }

视频 token 被划成三维块，每个块的 query、key 先做平均池化，用低成本的块间得分选择 top-$r$ 个相关 key 块。真正的 token 级注意力只在这些块内计算。池化负责粗筛，保留下来的原始 token 负责精细计算，二者不能混为把整段视频平均成少数向量。

令块内平均后的向量为 $\bar Q$、$\bar K$，筛选分数为

$$
S_{\mathrm{block}}=\frac{\bar Q\bar K^\top}{\sqrt d}.
$$

对每个 query 块选取分数最高的 $r$ 个 key 块，形成注意力掩码。细化专家保留约 $1/16$ 的 key 块，即 93.75% 稀疏率；蒸馏训练的保留比例则为 $1/8$。报告也讨论基于累计概率的选择，但训练时采用固定 top-$r$，使计算形状更可控。

这种注意力是近似选择，遗漏的块不参与本次精细计算。它的质量依赖视频内容中的冗余和后训练适应，不能说与完整注意力数学等价。实现提供前向、反向以及 Ring Context Parallel 版本，多个设备通过交换 key、value 和块级摘要处理长序列。基础训练还结合 ZeRO-2、上下文并行与激活检查点，报告 MFU 为约 33%–38%。[原文 §3.4.2、§4.4、附录 A.2](https://arxiv.org/pdf/2510.22200#page=32)

| 单张 H800，原文 Table 2 | 输出帧数 | 去噪步骤 | 时间 |
|---|---:|---|---:|
| 直接 720p，完整基线 | 93 | 50 | 1429.5 s |
| 直接 720p，蒸馏后 | 93 | 16 | 244.6 s |
| 粗到细，无 BSA | 93 → 93 | 16 + 5 | 135.3 s |
| 粗到细，无 BSA，增加帧率 | 93 → 189 | 16 + 5 | 302.9 s |
| 粗到细，有 BSA | 93 → 93 | 16 + 5 | 116.5 s |
| 粗到细，有 BSA，增加帧率 | 93 → 189 | 16 + 5 | 142.0 s |

最后一行对应论文的 10.1 倍加速表述，但比较基线输出 93 帧，加速配置输出 189 帧，输出量并不相同。它说明整套生成配置在更高成片帧率下仍大幅节省时间，不能把 10.1 倍当成仅替换 BSA 一个模块的纯算子收益。硬件和 FlashAttention3 条件也应与数值一起保留。[原文 Table 2](https://arxiv.org/pdf/2510.22200#page=13)

## 评测揭示了图像质量、运动与对齐之间的取舍

内部评测包含 1628 个样本，T2V 1228 个，其中 500 个用于人工评测、728 个用于自动评测；I2V 400 个，由 100 张图各配详细、简短、矛盾、空提示构成。MOS 使用五分制，人工与自动评估按 2:1 加权；人工通常由三位评审评分，分歧时增加两位。自动评估器与人工的内部相关性高于 0.92，但它仍是团队内部校准的评估系统。[原文 §5.1](https://arxiv.org/pdf/2510.22200#page=19)

![T2V MOS](../../assets/images/paper-deep-dives/technical-reports/longcat-video/figure-14-t2v-mos.png){ width="920" }

| T2V MOS | Veo 3 | PixVerse V5 | Wan 2.2 | LongCat-Video |
|---|---:|---:|---:|---:|
| Text Alignment | 3.99 | 3.81 | 3.70 | 3.76 |
| Visual Quality | 3.23 | 3.13 | 3.26 | 3.25 |
| Motion Quality | 3.86 | 3.81 | 3.78 | 3.74 |
| Overall | 3.48 | 3.36 | 3.35 | 3.38 |

LongCat 的综合得分接近这组对照中的 PixVerse 和 Wan，但运动质量低于表中另外三者。把它概括成所有维度领先，会抹掉模型仍需要改进的地方。综合分的细小差异也应结合成对比较看。

![T2V GSB](../../assets/images/paper-deep-dives/technical-reports/longcat-video/figure-15-t2v-gsb.png){ width="920" }

GSB 图按赢、平、输比较同提示结果。LongCat 对 PixVerse 的 overall 为 242 / 13 / 246，对 Wan 为 250 / 15 / 236，接近均衡；对 Veo 为 156 / 13 / 332，劣势更明显。原表这些计数合计为 501，应保留表值，不能为了吻合正文“500 个样本”而自行改数。这个结果支持“具备竞争力”，没有支持对所有闭源模型的全面领先。

![I2V MOS](../../assets/images/paper-deep-dives/technical-reports/longcat-video/figure-16-i2v-mos.png){ width="920" }

图生视频呈现更明显的取舍。LongCat 的 Visual Quality 为 3.27，在该表最高；Image Alignment 为 4.04，低于 Hailuo 和 Wan 的 4.18；Motion Quality 为 3.59，在表中最低。Overall 为 3.17，而 Seedance、Hailuo、Wan 分别为 3.35、3.27、3.26。高画质可能与较保守的运动并存，单看静态帧难以发现这一点。[原文 §5.1、Figure 16](https://arxiv.org/pdf/2510.22200#page=21)

公开 VBench 2.0 上，LongCat 总分为 62.11，Veo 3 为 66.72，Vidu 为 62.70。LongCat 的 Commonsense 为 70.94，在该表领先，但 Physics 为 59.92，低于 Wan 2.1 的 62.84、Veo 3 的 69.35 和 Vidu 的 71.63。“常识”维度与“物理”维度不是同一个指标，前者领先不能替后者背书。这些比较对应报告采用的 2025 年模型版本与采样配置，并非持续更新的模型排名。[原文 Table 8](https://arxiv.org/pdf/2510.22200#page=21)

## 续写能力的价值与目前的证据范围

![Long video examples](../../assets/images/paper-deep-dives/technical-reports/longcat-video/figure-17-long-video-examples.png){ width="920" }

长视频图展示递归续写后主体、场景与颜色如何延续。它与统一任务训练直接对应，模型在预训练时已经见过根据多个历史帧预测后续片段的任务。历史扰动减轻颜色漂移，条件 KV 缓存和加速配置则让多轮续写的成本更可接受。

报告展示了最长约四分钟的生成案例，这属于长程视觉连续性的定性证据。图中看起来连贯，不代表每个物体都保存了永久状态，也不代表运动符合可用于机器人控制的精确动力学。VBench 的物理维度与 I2V 的运动结果恰好说明，生成长度、画面质量和物理可靠性需要分别提升。

复用这项工作的路径很具体。官方发布模型、推理代码及 BSA 实现，适合研究统一视频条件、长视频续写与低成本生成；训练报告提供阶段划分、GRPO 设置和注意力实现细节，但完整数据来源与全部训练样本并未等价开放。最值得借鉴的机制，是让续写任务进入基础训练，并让缓存、蒸馏、细化和稀疏算子围绕同一推理流程协同工作。[原文 §5.5、§6；官方代码](https://github.com/meituan-longcat/LongCat-Video)
