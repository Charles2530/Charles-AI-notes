---
paper_date: 2025-07
paper_title: "Gemini 2.5: Pushing the Frontier with Advanced Reasoning, Multimodality, Long Context, and Next Generation Agentic Capabilities"
paper_topic: 技术报告
---

# Gemini 2.5：动态 Thinking 与长上下文 Agent

!!! info "论文信息"
    **论文题名：** Gemini 2.5: Pushing the Frontier with Advanced Reasoning, Multimodality, Long Context, and Next Generation Agentic Capabilities。<br>
    **作者：** Gemini Team。<br>
    **机构：** Google DeepMind。<br>
    **时间 / 主题：** 2025-07；技术报告。<br>
    **arXiv / 官方报告：** arXiv：未找到专门条目；官方材料：[storage.googleapis.com/deepmind-media/gemini/gemini_v2_5_report.pdf#page=6](https://storage.googleapis.com/deepmind-media/gemini/gemini_v2_5_report.pdf#page=6)。<br>
    **GitHub / 项目：** GitHub：未找到官方链接；项目页：[storage.googleapis.com/deepmind-media/gemini/gemini_v2_5_report.pdf#page=6](https://storage.googleapis.com/deepmind-media/gemini/gemini_v2_5_report.pdf#page=6)。<br>
    **元数据来源与核验口径：** 来源：[官方 / 项目材料](https://storage.googleapis.com/deepmind-media/gemini/gemini_v2_5_report.pdf#page=6)；Checked Date：2026-06-15；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 推理时间开始成为模型能力的一部分

Gemini 2.5 报告把模型进步放在三个相互牵制的维度里讨论。模型要能解决更难的数学与代码问题，要能读长文档、图像、视频和音频，还要在实际产品能够承担的成本下完成这些工作。2.5 Pro 面向能力上限，2.5 Flash 面向成本与延迟；二者都通过训练学会在回答前进行中间推理，并允许推理预算参与控制。因而，评估对象从一个固定参数模型，扩展为“模型、思考预算、输入表示和工具系统”的组合。

报告公开了训练路线、基础设施和大量评测，却没有公开参数量、专家数量、完整网络配置或可复现训练配方。可以据此分析哪些能力发生了变化、证据来自什么条件，无法据此还原一个同规模 Gemini。报告中的发布规格为 2.5 Pro 和 Flash 支持 1M 输入上下文与 64K 输出，不能把上一代 1.5 Pro 的 2M 规格移植过来。[原文 §2、Table 1](https://storage.googleapis.com/deepmind-media/gemini/gemini_v2_5_report.pdf#page=3)

![Gemini 2.5 cost-quality Pareto original](../../assets/images/localized-remote/paper-deep-dives/technical-reports/gemini-2-5/gemini-2-5-cost-quality-pareto-original.png){ width="920" }

这张图展示发布时期的价格与 Arena 偏好分数。横轴采用对数尺度，向右价格下降，并假设输入与输出 token 数之比为 3:1；Pro 的价格还混合了不同上下文长度区间。它说明团队为何同时训练 Pro、Flash 和 Lite 等档位，不能用来证明同一模型增加思考 token 后的准确率曲线，也不能代表今天的价格或排行榜。

## 从预训练底座到可调节的思考

Gemini 延续稀疏混合专家架构，并在预训练时联合处理文本、代码、图像、视频和音频。多模态信息在模型内部共同参与理解，之后的长上下文和工具能力建立在这个底座上。2.5 模型的预训练数据截止到 2025 年 1 月；这只是预训练材料的时间边界，不意味着每条回答都覆盖此前的全部知识。

较小模型还利用教师模型蒸馏。一个具体的工程选择是只存储教师词表分布中的 $k$ 个条目，用稀疏分布传递监督。完整词表分布既占存储，又消耗训练数据管线带宽；稀疏化使蒸馏信号可以进入大规模训练。报告没有给出足以重建教师组合、所有蒸馏损失与混合比例的细节，因此“有蒸馏”也不等于“小模型只是复制某个大模型的最终答案”。[原文 §2.1–2.3](https://storage.googleapis.com/deepmind-media/gemini/gemini_v2_5_report.pdf#page=3)

后训练加入强化学习，使模型在难题上产生有用的中间推理。奖励来源包括能够验证的任务反馈和模型产生的评价信号。这里可验证的结论是，训练显式利用了更多推理计算，并让模型学习何时继续分析；报告没有披露具体采用 PPO、GRPO 或某种完整策略更新公式，不能替作者补上算法名称。

推理预算也需要区分训练和使用两个阶段。训练时，模型通过奖励学习哪些推理轨迹有价值；使用时，预算限制本次回答可以花多少计算。Figure 3、4 在 AIME、LiveCodeBench 和 GPQA 上显示，增加预算通常带来更高准确率，但收益随任务变化。预算提高的是统计上的成功机会，不保证每次延长思考都能纠正错误。预算受限时，Flash 的意义在于用较低成本达到一个可用点，而不是让所有请求都追求 Pro 的最高分。[原文 §2.5](https://storage.googleapis.com/deepmind-media/gemini/gemini_v2_5_report.pdf#page=5)

Deep Think 是额外的实验性推理模式，会探索并审视多条候选思路。Deep Research 则把模型放进检索、浏览与综合证据的 agent 工作流。二者不能与默认 Pro 的一次无工具回答混为一谈。报告中 HLE 无工具 Pro 得分为 21.6%，Deep Research 为 26.9%，更高计算配置达到 32.4%；差异同时包含工具与计算配置的变化。

## 长上下文首先要求把信息装进去，然后才是找对和用对

1M token 的容量解决输入规模问题，多跳检索和复杂指令解决信息使用问题，二者并不等价。报告为 LOFT 和 MRCR-V2 同时提供较短上下文与恰好 1M 的结果，正好能看出这个区别。

| 原文 Table 3 的评测条件 | Gemini 1.5 Pro | Gemini 2.5 Flash | Gemini 2.5 Pro |
|---|---:|---:|---:|
| LOFT hard retrieval，≤128K 平均 | 75.9 | 82.1 | 87.0 |
| LOFT hard retrieval，1M 点位 | 47.1 | 58.9 | 69.8 |
| MRCR-V2，8 needles，≤128K 平均 | 26.2 | 54.3 | 58.0 |
| MRCR-V2，8 needles，1M 点位 | 12.1 | 21.0 | 16.4 |

LOFT 涉及多跳、多目标检索；MRCR-V2 要在相似的任务与文本中辨认指定对象，并加入更深的条件嵌套。在 1M 点位，两个 2.5 模型仍明显退化，且 Flash 的 MRCR 得分高于 Pro。参数档位与总体排行榜不能代替目标任务上的验证。实际文档系统可以利用更大窗口减少切块，却仍需要检查证据定位、相似段落区分和跨文档推理。[原文 Table 3、附录 Table 11](https://storage.googleapis.com/deepmind-media/gemini/gemini_v2_5_report.pdf#page=13)

视频还有输入表示的成本。报告提供低分辨率媒体选项，把每帧视觉 token 从 258 降为 66，使 1M 窗口能够容纳约三小时而非约一小时的视频。压缩扩大了时间覆盖，代价是保留的空间细节变少；细小文字、局部物体状态和短暂事件对这个选择可能更敏感。模型能读长视频，仍然需要知道送入模型的是怎样的采样与压缩结果。

附录给了一个直观案例，在 46 分钟视频里定位约一秒的机器人叠衣片段。2.5 Pro 三次回答都给出正确颜色，一次时间戳完全正确，另外两次误差在三秒内；1.5 Pro 的时间戳三次都错。这是一个具体定位示例，样本量只有三个重复回答，不能当作长视频全部事件的可靠检索率。[原文附录 §8.5](https://storage.googleapis.com/deepmind-media/gemini/gemini_v2_5_report.pdf#page=73)

## 能力增长最明显的地方，以及分数之间的边界

下表选择同一张主表中的代际比较。数值为百分制分数，指标定义随任务变化，不应跨行求平均。

| Benchmark / setting | Gemini 1.5 Pro | Gemini 2.5 Flash | Gemini 2.5 Pro |
|---|---:|---:|---:|
| LiveCodeBench | 29.7 | 59.3 | 74.2 |
| Aider Polyglot | 16.9 | 56.7 | 82.2 |
| SWE-bench Verified, single attempt | 22.3 | 48.9 | 59.6 |
| SWE-bench Verified, multiple attempts | 34.2 | 60.3 | 67.2 |
| GPQA diamond | 58.1 | 82.8 | 86.4 |
| AIME 2025 | 17.5 | 72.0 | 88.0 |
| Humanity’s Last Exam, no tools | 4.6 | 11.0 | 21.6 |
| SimpleQA | 24.9 | 26.9 | 54.0 |
| MMMU | 67.7 | 79.7 | 82.0 |

代码和数学的提升最突出，也与思考训练的方向相符。不过，报告没有把预训练数据、模型规模、强化学习和推理预算逐项控制后做完整因果消融，所以这些代际差值属于整个系统的进步，不能全部记在某一个训练技巧上。[原文 Table 3](https://storage.googleapis.com/deepmind-media/gemini/gemini_v2_5_report.pdf#page=13)

SWE-bench 两行尤其需要分开。single attempt 是一次 agent 轨迹；multiple attempts 会生成多条轨迹，再由 Gemini 判断并重排候选。这里测的是带仓库浏览、编辑和测试工具的内部 harness。多次候选不仅多花计算，也依赖选择器识别正确修复的能力。不同厂商采用不同 harness，因此跨厂商同名 SWE 分数并不是完全受控的模型单变量比较。

Aider 是三次试验的通过率平均，使用 diff 或 diff-fenced 编辑格式。主表 LiveCodeBench 使用排行榜界面标记为 1/1/2025–5/1/2025 的区间；思考预算图使用另一日期区间，不能把曲线端点直接当成主表分数。本文采用 Table 3 的 1.5 Pro 数值 29.7，原文介绍段另出现 30.5，两处口径没有被报告充分解释。[原文附录 §8.1](https://storage.googleapis.com/deepmind-media/gemini/gemini_v2_5_report.pdf#page=63)

音频与视频也呈现不同的增长形状。FLEURS 的 53 语言子集上，1.5 Pro、2.5 Flash、2.5 Pro 的错误率分别为 7.14、9.95、6.66，越低越好；Flash 并没有随代际全面改善。该集合对四种分词敏感语言使用字符错误率，并剔除了难以公平匹配参考答案的语言。CoVoST 2 的 21 语言到英语翻译 BLEU 则为 37.53、36.15、38.48。

视频评测中，VideoMME 音视频输入的三个结果为 73.2、75.5、84.3，加字幕版本为 79.8、81.5、86.9。但附录说明前者采用 Long 子集，后者采用完整测试集，因此两行之间的差值不能直接解释成“字幕贡献了多少”。1H-VideoQA 上三者为 72.2、67.5、81.0，同样显示 Flash 在成本下降时可能牺牲部分长视频理解。视频通常按 1 fps 处理，再按任务设置帧数上限，分数对应这一输入协议。[原文 Table 5、附录 Table 11](https://storage.googleapis.com/deepmind-media/gemini/gemini_v2_5_report.pdf#page=15)

## Pokémon 通关展示的是一套持续运行的 agent

Gemini Plays Pokémon 是本报告最鲜明的长程任务例子。第二次运行用固定 scaffold 和 Gemini 2.5 Pro Preview 05-06，在 406.5 小时后自主通关。第一次运行耗时 813 小时，开发期间修改过 harness，两次运行不能当作相同条件下的严格速度对照。

系统向模型提供游戏截图和从 RAM 提取后转成文本的状态。地图维护已访问位置、地形与连接关系；每 100 轮压缩一次历史，每 1000 轮再次压缩摘要；每 25 轮让另一个 Gemini 实例观察并提出批评；寻路和推石头谜题也有专门提示的工具实例。这个结构把“记住世界、形成目标、寻找路径、执行动作、检查进展”分配给模型与外部状态管理共同完成。

一个很有解释力的观察是，去掉像素输入后表现大体相近。成功主要依赖 RAM 文本表示和工具，因此不宜描述成模型只看屏幕就学会完整游戏。长上下文也没有消除长程决策失误。报告记录了重复旧动作、陷入局部目标、急于治疗时忽略工具等现象；超过 100K 上下文后出现的重复行为属于案例观察，仍提醒人们，存储更多历史不等于能够更好地决定下一步。[原文 §4.1、附录 §8.2](https://storage.googleapis.com/deepmind-media/gemini/gemini_v2_5_report.pdf#page=16)

对于开发者，这个实验最可迁移的部分是外部记忆、状态结构化和分工明确的工具接口。通关能力来自这些组件与模型的配合，406.5 小时的完成时间也提示，长程可完成性与实际任务的时间预算应分别评估。

## 安全评估出现了能力提升与稳健性不同步的情况

报告将开发期评测、保留的 assurance 测试以及独立外部测试分开。它们回答的问题不同。训练期测试帮助迭代模型，保留测试检查开发过程之外的表现，外部专家会发现内部任务定义未覆盖的风险。将三类结果合并成一个“更安全”的结论，会掩盖条件差异。

一个例子是提示注入。模型作为 agent 读取不可信内容时，攻击者试图让它通过邮件工具泄露秘密。Table 9 在 500 个保留场景上比较三种攻击方法，攻击成功率越低越好。

| Attack method | Gemini 2.5 Flash | Gemini 2.5 Pro |
|---|---:|---:|
| Actor | 40.8% | 61.4% |
| Beam | 4.2% | 63.8% |
| TAP | 53.6% | 30.8% |

Pro 在前两种攻击下更脆弱，在 TAP 下更稳健。这既反对“能力更强就自然更抗注入”，也不支持不分攻击方法地宣布 Pro 全面更差。实验还使用攻击搜索所得触发内容，数字属于定向对抗测试，不能解释成真实业务请求中的泄露概率。[原文 §5.5、Table 9](https://storage.googleapis.com/deepmind-media/gemini/gemini_v2_5_report.pdf#page=25)

前沿能力评估截至 2025 年 6 月 17 日没有达到 Critical Capability Level，但网络能力的 Cyber Uplift 提前预警阈值已经被触发。这两个结论能够同时成立。网络测评的一些成绩采用 best-of-30 到 best-of-50，而其他模型采用 best-of-10 到 best-of-30；困难任务做成一次，不能推成单次稳定成功率。

机器学习研发评估 RE-Bench 使用有限任务集和受控时间预算，部分分析在总计 32 小时的预算内组合许多短尝试，再选最好结果。它展示了模型在某些工程优化任务上的实质能力，但没有覆盖一个研究项目从提出问题、构建数据到验证科学结论的全过程。外部安全测试所用 Pro Preview 05-06 也不应自动替代最终 GA 版本或 Flash 的证据。[原文 §5.7–5.8](https://storage.googleapis.com/deepmind-media/gemini/gemini_v2_5_report.pdf#page=27)

## 训练系统承担了能力扩展的实际成本

报告中的 TPU v5p 训练跨越多个数据中心，使用多个 8960 芯片的 pod，不能把它简写成“总共使用 8960 芯片”。团队强调弹性训练，是因为大规模同步训练会不断遇到设备和数据中心切片故障；若每次故障都停止整项作业，理论算力很难变成有效更新。

系统能够在切片失效时维持约 97% 的吞吐，并将重新配置从十分钟以上压到数十秒。报告记录 93.4% 的墙钟时间用于 TPU 计算，同时单独讨论错误检测、回放与回滚。这些数字属于特定训练系统的运行统计，不是模型架构本身的通用效率。在讨论大模型训练成本时，数据吞吐、容错和错误恢复与单次矩阵乘法同样重要。[原文 §2.3](https://storage.googleapis.com/deepmind-media/gemini/gemini_v2_5_report.pdf#page=4)

Gemini 2.5 最有依据的结论，是推理训练、多模态长上下文与 agent scaffold 共同扩展了模型可以承担的任务。报告同时给出了很具体的反例，1M 检索仍会下降，Flash 并非所有指标都优于上一代 Pro，提示注入也未随总体能力同步解决。实际使用时，需要在目标任务上共同选择模型档位、思考预算、媒体表示与工具权限；公开报告适合指导这些选择，但并未提供可本地复现的权重和完整训练配置。
