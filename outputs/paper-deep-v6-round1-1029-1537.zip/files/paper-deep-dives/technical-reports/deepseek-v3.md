---
paper_date: 2024-12
paper_title: "DeepSeek-V3 Technical Report"
paper_topic: 技术报告
---

# DeepSeek-V3：671B MoE、MLA 与 FP8 训练

!!! info "论文信息"
    **论文题名：** DeepSeek-V3 Technical Report。<br>
    **作者：** DeepSeek-AI、Aixin Liu、Bei Feng、Bing Xue、Bingxuan Wang、Bochao Wu、Chengda Lu、Chenggang Zhao、Chengqi Deng、Chenyu Zhang 等（共 200 人）。<br>
    **机构：** 未在公开元数据中稳定解析；以 arXiv/PDF 或官方页 affiliation block 为准。<br>
    **时间 / 主题：** 2024-12；技术报告。<br>
    **arXiv / 官方报告：** arXiv：[2412.19437](https://arxiv.org/abs/2412.19437)。<br>
    **GitHub / 项目：** GitHub：[github.com/deepseek-ai/DeepSeek-V3](https://github.com/deepseek-ai/DeepSeek-V3)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2412.19437)；[GitHub API / repo](https://github.com/deepseek-ai/DeepSeek-V3)；Checked Date：2026-06-15；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 671B容量怎样在37B激活计算下训练出来

DeepSeek-V3的系统目标，是扩大模型的知识与专家容量，同时控制每个token的实际计算、注意力缓存与跨机器通信。它使用671B总参数、每token约37B激活参数的MoE，在14.8T tokens上预训练，再做上下文扩展与后训练。总参数决定需要管理多少权重，激活参数决定一次token路径使用多少计算，二者不能互相替代。

V3沿用V2的MLA和细粒度DeepSeekMoE，主要新增负载均衡策略、多token训练目标，并将FP8、通信内核与流水并行配成可运行系统。因此读这份报告需要分清算法质量收益与系统效率收益：MTP和均衡范围改变模型学到什么；低精度、DualPipe和路由拓扑决定同样计算能否高效执行。[↗](https://arxiv.org/pdf/2412.19437v2#page=4)

总结果图先按任务读。数学与竞赛代码较强，工程任务仍有与Claude的差距，不能把一个综合领先叙述代替全部分项。

![DeepSeek-V3 benchmark performance](../../assets/images/paper-deep-dives/technical-reports/deepseek-v3/figure-1-performance.png){ width="920" }

<small>图源：`DeepSeek-V3 Technical Report`，Figure 1。</small>

## MLA压缩的是每个历史token的KV表示

普通多头注意力在解码时要缓存每一层、每个历史token的多头keys与values。MLA先把当前隐藏状态 $h_t$ 投影到一个低维共同latent，再从中生成content key与value

$$
c_t^{KV}=W^{DKV}h_t,\qquad
k_t^C=W^{UK}c_t^{KV},\qquad
v_t^C=W^{UV}c_t^{KV}.
$$

位置部分单独生成

$$
k_t^R=\operatorname{RoPE}(W^{KR}h_t),\qquad
k_{t,i}=[k_{t,i}^C;k_t^R].
$$

推理只需要保存压缩latent $c_t^{KV}$ 与共享的RoPE key $k_t^R$，不必将全部展开的多头KV永久存下来。V3配置的KV latent维度为512，RoPE维度为64，因此每层每token缓存576个对应元素；这是表示元素数，实际字节仍取决于精度、布局与实现。[↗](https://arxiv.org/pdf/2412.19437v2#page=7)

架构图蓝框标出真正缓存的部分。读图时将低维KV路径与query压缩分开：query低秩投影主要减少训练激活，而历史KV压缩直接影响自回归解码内存。

![DeepSeek-V3 architecture](../../assets/images/paper-deep-dives/technical-reports/deepseek-v3/figure-2-architecture.png){ width="920" }

<small>图源：`DeepSeek-V3 Technical Report`，Figure 2。</small>

content与位置解耦也让内容投影有机会通过矩阵结合优化，不必为每步显式重建全部历史KV。它保留每个位置的压缩表示，并没有删除历史token，所以更长上下文仍会增加缓存和读取量。后续V4在token轴上进一步压缩，解决的是另一个维度的问题。

## 细粒度专家需要均衡，但每条序列不必使用同一组专家

V3共有61层、隐藏宽7168，前3层FFN为dense，其余使用1个共享专家和256个路由专家，每token选择8个路由专家，专家中间宽2048。共享专家承载普遍使用的变换，路由专家可形成更细的专门化。门控affinity为

$$
s_{i,t}=\operatorname{Sigmoid}(u_t^\top e_i).
$$

选中专家的原始affinity归一化后，作为专家输出的加权系数。与仅扩大dense FFN不同，这允许更多总容量而不让每个token遍历全部专家。[↗](https://arxiv.org/pdf/2412.19437v2#page=8)

问题是路由容易集中在少量专家，既影响学习，也使专家并行中的设备空闲或过载。传统辅助loss通过梯度要求更均匀的路由，但过强的逐序列约束会迫使数学、代码等不同内容使用相似比例的专家。V3改为为每个专家维护bias $b_i$，用

$$
\operatorname{TopK}_i(s_{i,t}+b_i)
$$

决定去哪里，而真正乘在专家输出上的权重仍来自 $s_{i,t}$，不含bias。每步统计整个batch的专家负载，过载专家的bias减去 $\gamma$，欠载专家加上 $\gamma$。控制负载与学习语言建模梯度由此部分分离。

名称中的auxiliary-loss-free描述主要控制机制。正式V3仍保留系数 $10^{-4}$ 的序列级辅助平衡loss，避免单条序列极端不均衡；不能说所有辅助项被彻底删除。bias更新速度在前14.3T tokens为0.001，最后500B设为0。[↗](https://arxiv.org/pdf/2412.19437v2#page=9)

专家负载图比较不同语料域。先看各域峰值是否落在不同专家上，再看全局平均是否仍可均衡；领域内不均匀恰好可以是专门化的表现。

![Expert load comparison](../../assets/images/paper-deep-dives/technical-reports/deepseek-v3/figure-9-expert-load.png){ width="850" }

<small>图源：`DeepSeek-V3 Technical Report`，Figure 9。</small>

最有解释力的额外消融是均衡范围。1B模型逐序列aux-loss验证loss为2.258，aux-loss-free为2.253，而按batch计算aux-loss同样为2.253；3B模型对应2.085、2.080、2.080。这说明收益有一部分来自更宽松的batch级约束，而不能全部归因于“完全不用辅助梯度”。[↗](https://arxiv.org/pdf/2412.19437v2#page=27)

## MTP让当前表示为更远一个token承担训练责任

普通next-token训练只要求位置 $i$ 预测 $t_{i+1}$。V3增加顺序MTP模块，将主干表示与下一个已知token embedding结合，再预测后续token

$$
h_i^{\prime k}=M_k[\operatorname{RMSNorm}(h_i^{k-1});\operatorname{RMSNorm}(\operatorname{Emb}(t_{i+k}))],
$$

$$
h^k=\operatorname{TRM}_k(h^{\prime k}),\qquad
P^k_{i+k+1}=\operatorname{OutHead}(h_i^k),\qquad
\mathcal L_{\mathrm{MTP}}=\frac\lambda D\sum_{k=1}^D\mathcal L^k_{\mathrm{MTP}}.
$$

embedding与输出head同主模型共享，额外Transformer与投影完成各深度的条件化。图中多个模块按顺序连接，保持预测因果链；不是独立多个head同时猜测互不条件化的未来token。正式V3取 $D=1$，即在主干next-token之外再预测一个token。[↗](https://arxiv.org/pdf/2412.19437v2#page=10)

![MTP implementation](../../assets/images/paper-deep-dives/technical-reports/deepseek-v3/figure-3-mtp.png){ width="920" }

<small>图源：`DeepSeek-V3 Technical Report`，Figure 3。</small>

训练时额外loss让表示包含更有助于后续预测的信息。推理可以丢掉MTP模块，主模型仍正常工作；也可以将MTP作为draft，以主模型验证的推测解码加速。两种用途必须分开验证，训练质量提升并不要求部署时保留额外模块。

| Ablation | Scale / training tokens | HumanEval base → MTP | GSM8K base → MTP | MMLU base → MTP |
| --- | --- | ---: | ---: | ---: |
| Small MoE | 15.7B total / 1.33T | 20.7 → 26.8 | 25.4 → 31.4 | 50.0 → 53.3 |
| Large MoE | 228.7B total / 540B | 44.5 → 53.7 | 72.3 → 74.0 | 67.5 → 66.6 |

两组消融保持数据与主干一致，推理丢弃MTP，因而推理参数成本相同。多数任务提高，但大模型MMLU略降，训练还多做了MTP计算，不能说是零成本的全指标提升。部署实验另报告第二token接受率85%—90%、约1.8倍TPS，这是其推测解码设置的结果。[↗](https://arxiv.org/pdf/2412.19437v2#page=26) [↗](https://arxiv.org/pdf/2412.19437v2#page=35)

## DualPipe让专家通信藏在有用计算后面

2048张H800组成训练集群，每节点8GPU，节点内NVLink/NVSwitch，节点间InfiniBand。训练采用16路pipeline parallelism、跨8节点的64路expert parallelism和ZeRO-1数据并行。模型没有使用常规tensor parallelism训练，前提是已经通过重计算、低精度和专家切分控制了显存。

跨节点MoE原本有约1:1的计算与通信时间关系。DualPipe把一个forward／backward chunk拆为attention、dispatch、MLP与combine，并进一步区分backward input和backward weight，使某个chunk等待通信时，另一个chunk还能进行有用计算。下图先辨认通信条带，再看它们是否与前后向计算重叠。[↗](https://arxiv.org/pdf/2412.19437v2#page=12)

![Computation communication overlap](../../assets/images/paper-deep-dives/technical-reports/deepseek-v3/figure-4-overlap.png){ width="920" }

<small>图源：`DeepSeek-V3 Technical Report`，Figure 4。</small>

完整调度从流水线两端同时放入micro-batches，减少填充与排空气泡。图中空白表示设备等待，同框任务体现重叠，不能将所有彩色块简单相加当作串行时长。

![DualPipe schedule](../../assets/images/paper-deep-dives/technical-reports/deepseek-v3/figure-5-dualpipe.png){ width="920" }

<small>图源：`DeepSeek-V3 Technical Report`，Figure 5。</small>

这种调度有资源代价。报告比较中DualPipe保留两份模型参数，峰值activation相对原来的 $PP$ 单位增为 $PP+1$；大专家并行让参数额外开销较可控。接近隐藏通信的效果也依赖计算／通信比例与实际拓扑，不是任何网络上都自动成立。

路由算法同通信内核一起设计。每token最多发送到4个节点，先经IB到目标节点相同GPU索引，再由NVLink转发到实际专家。集群中NVLink与IB带宽约160与50GB/s，20个SM专门承担通信即可利用两级网络。node-limited routing限制了跨机流量，也限制了可选择专家的分布范围；这是一项模型与系统的共同取舍。[↗](https://arxiv.org/pdf/2412.19437v2#page=13)

## FP8成功的关键在于哪些地方没有降到FP8

V3的FP8框架将Linear的forward、activation gradient与weight gradient GEMM都放到FP8，同时对embedding、输出head、router、normalization和attention保留较高精度。master weights与累积梯度为FP32，AdamW一二阶moment可用BF16。图中应沿输入、乘法、累加、输出与优化器分别看精度，不能将“FP8训练”理解为所有状态都是8-bit。[↗](https://arxiv.org/pdf/2412.19437v2#page=15)

![FP8 mixed precision framework](../../assets/images/paper-deep-dives/technical-reports/deepseek-v3/figure-6-fp8-framework.png){ width="860" }

<small>图源：`DeepSeek-V3 Technical Report`，Figure 6。</small>

两项实现细节共同控制误差。激活按每token、128通道的 $1\times128$ tile计算scale，权重按 $128\times128$ block计算scale，避免一个离群值决定整个tensor的动态范围。所有相关FP8张量使用E4M3，精细scale补偿其较窄动态范围。

其次，H800 Tensor Core中的FP8累加有效精度有限，长内积会累积误差。V3每累加128个元素，就把部分结果提升到CUDA Core的FP32寄存器继续累积，同时处理各组scale。下图左侧看scale作用的粒度，右侧看低精度乘法与高精度累加的边界。

![FP8 quantization and accumulation](../../assets/images/paper-deep-dives/technical-reports/deepseek-v3/figure-7-fp8-accumulation.png){ width="860" }

<small>图源：`DeepSeek-V3 Technical Report`，Figure 7。</small>

这既是数值设计，也是内核调度：一个warpgroup提升结果时，另一个继续MMA，减轻精度提升的吞吐损失。MoE dispatch还可发送FP8激活，但combine保留BF16，避免聚合误差。对较小两个规模、约1T tokens的验证中，FP8相对BF16的loss误差保持低于0.25%；这个证据针对训练loss与所测配置，不是所有下游指标完全相等的声明。[↗](https://arxiv.org/pdf/2412.19437v2#page=16)

## 14.8T预训练与128K扩展是不同阶段

V3语料提高数学代码占比，扩展中英文之外的多语言覆盖，并优化去重。训练使用128K词表的byte-level BPE，10%比例采用文档级Prefix-Suffix-Middle格式，以支持代码和文本中间补全。预训练document packing未使用跨样本attention masking；后续SFT packing则使用样本间mask，两阶段不能混为同一数据处理策略。[↗](https://arxiv.org/pdf/2412.19437v2#page=22)

预训练最大序列4K，AdamW的 $\beta_1=0.9,\beta_2=0.95$、weight decay0.1。学习率先warmup至 $2.2\times10^{-4}$，在消耗10T tokens前保持，再逐步衰减；batch从3072增到15360。MTP loss权重前10T为0.3、后4.8T为0.1。

之后用YaRN分两轮扩展4K→32K→128K，每轮1000 steps；batch分别1920和480，学习率均 $7.3\times10^{-6}$。NIAH图先看长上下文端与不同插入深度，检验信息是否能在位置变化后被检索。

![Needle In A Haystack](../../assets/images/paper-deep-dives/technical-reports/deepseek-v3/figure-8-needle.png){ width="920" }

<small>图源：`DeepSeek-V3 Technical Report`，Figure 8。</small>

图支持128K范围内的针式检索能力。FRAMES和LongBench v2则补充长文档任务证据，但也不能将单一needle成功理解成百万字复杂推理已被解决。[↗](https://arxiv.org/pdf/2412.19437v2#page=23)

## 后训练将R1式验证转移到较短的助手回答

V3后训练数据约1.5M条。数学、竞赛代码与逻辑数据借助内部R1系列模型，但作者没有直接复制所有长CoT。流程先训练领域专家，让其学习原始短回答与带系统提示的R1回答，再用RL混合反思、验证与简洁表达，最后拒绝采样供V3 SFT使用。通用写作、角色扮演等数据由V2.5生成并经人工检查。

这解释了V3与R1的关系：V3-Base为R1提供基础，而内部R1系列的推理轨迹又帮助V3聊天后训练。它不是声称两个最终发布模型在时间上互相从零训练。SFT训练两epochs，学习率从 $5\times10^{-6}$ 衰减到 $10^{-6}$；之后GRPO在可验证任务用规则奖励，在开放任务用模型奖励。[↗](https://arxiv.org/pdf/2412.19437v2#page=28)

在V2.5上的蒸馏消融直接量出准确率与长度交换：LiveCodeBench-CoT由31.1升到37.4，平均长度718→783；MATH-500由74.6升到83.2，长度769→1510。数学提升同时接近翻倍输出长度，因此“让标准聊天模型获得推理能力”仍需要支付推理token成本。[↗](https://arxiv.org/pdf/2412.19437v2#page=34)

## 主表显示的是报告版本下的质量范围

基座比较在内部统一框架下进行。V3-Base以37B激活参数在MMLU87.1、HumanEval65.2、MATH61.6上领先表中的Qwen2.5-72B与Llama3.1-405B Base，但RACE、PIQA等不是全部最优。这类比较同时改变训练数据、总参数和架构，不能单独归因为MoE更高效。[↗](https://arxiv.org/pdf/2412.19437v2#page=25)

聊天主表将各模型输出上限设为8K。AIME、CNMO temperature0.7并平均16轮，MATH-500贪心解码；LiveCodeBench使用2024年8—11月题目，SWE-bench Verified使用agentless。[↗](https://arxiv.org/pdf/2412.19437v2#page=31)

| Benchmark | Qwen2.5-72B-Instruct | Claude3.5-Sonnet-1022 | GPT-4o-0513 | DeepSeek-V3 |
| --- | ---: | ---: | ---: | ---: |
| MMLU-Pro | 71.6 | 78.0 | 72.6 | 75.9 |
| GPQA Diamond | 49.0 | 65.0 | 49.9 | 59.1 |
| AIME 2024 | 23.3 | 16.0 | 9.3 | 39.2 |
| MATH-500 | 80.0 | 78.3 | 74.6 | 90.2 |
| LiveCodeBench-CoT | 31.1 | 36.3 | 33.4 | 40.5 |
| SWE-bench Verified | 23.8 | 50.8 | 38.8 | 42.0 |
| Aider-Polyglot | 7.6 | 45.3 | 16.0 | 49.6 |
| SimpleQA | 9.1 | 28.4 | 38.2 | 24.9 |

数学与竞赛代码优势很清楚，但GPQA与SWE修复仍落后Claude，SimpleQA低于GPT-4o。Aider-Polyglot领先也不能覆盖SWE中的另一类工程困难。开放对话评价AlpacaEval2的长度控制胜率70.0、Arena-Hard85.5采用模型裁判，代表指定协议下的偏好，不是人类总体满意度百分比。

## 训练成本低于dense路线的直觉，并不意味着部署轻量

| Stage | H800 GPU-hours | At USD 2/GPU-hour |
| --- | ---: | ---: |
| Pre-training | 2,664,000 | 5.328M USD |
| Context extension | 119,000 | 0.238M USD |
| Post-training | 5,000 | 0.010M USD |
| Total | 2,788,000 | 5.576M USD |

报告的5.576M美元是将正式训练GPU-hour按假设租价换算的结果，明确排除前期架构、算法、数据研究和消融试验。它也不是团队总研发费用或训练集获取成本。预训练平均每1T tokens为180K H800 GPU-hours，2048卡集群上约3.7天。[↗](https://arxiv.org/pdf/2412.19437v2#page=5)

推理部署将prefill与decode分离。报告的高吞吐、SLO导向方案，prefill最小部署单元32GPU，decode为320GPU，并复制热点专家以平衡负载。这里的“最小”属于作者这套服务调度方案，不能说模型在更少GPU上绝对无法推理；反过来，37B激活参数也绝不意味着只需容纳37B权重。[↗](https://arxiv.org/pdf/2412.19437v2#page=19)

V3最可复用的认识，是容量、每token计算、KV缓存、负载均衡和通信必须一起设计。对研究者，MTP和batch级均衡是可以独立验证的训练改动；对系统团队，FP8的精度保留、路由拓扑与DualPipe决定收益能否落地。离开对应硬件、batch和数据分布后，需要重新测量这些接口，不能只复制“671B／37B”两个规模数字。
