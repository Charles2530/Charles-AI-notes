---
paper_date: 2025-07
paper_title: "Kimi K2: Open Agentic Intelligence"
paper_topic: 技术报告
---

# Kimi K2：MuonClip、万亿 MoE 与 Agent 数据

!!! info "论文信息"
    **论文题名：** Kimi K2: Open Agentic Intelligence。<br>
    **作者：** Kimi Team、Yifan Bai、Yiping Bao、Y. Charles、Cheng Chen、Guanduo Chen、Haiting Chen、Huarong Chen、Jiahao Chen、Ningxin Chen 等（共 200 人）。<br>
    **机构：** 未在公开元数据中稳定解析；以 arXiv/PDF 或官方页 affiliation block 为准。<br>
    **时间 / 主题：** 2025-07；技术报告。<br>
    **arXiv / 官方报告：** arXiv：[2507.20534](https://arxiv.org/abs/2507.20534)；官方材料：[huggingface.co/moonshotai/Kimi-K2-Instruct](https://huggingface.co/moonshotai/Kimi-K2-Instruct)。<br>
    **GitHub / 项目：** GitHub：[github.com/MoonshotAI/checkpoint-engine](https://github.com/MoonshotAI/checkpoint-engine)；项目页：[huggingface.co/moonshotai/Kimi-K2-Instruct](https://huggingface.co/moonshotai/Kimi-K2-Instruct)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2507.20534)；[GitHub API / repo](https://github.com/MoonshotAI/checkpoint-engine)；[官方 / 项目材料](https://huggingface.co/moonshotai/Kimi-K2-Instruct)；Checked Date：2026-06-15；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 从“能回答”走向能在环境里完成任务

Kimi K2把模型能力放在一个更具体的使用场景里检验。面对代码仓库、工具返回和多轮用户要求，模型需要选择动作、读取结果、修改计划，并持续保持任务约束。报告围绕这件事连接了三条工作线：用MuonClip稳定训练万亿参数MoE，合成覆盖大量工具和任务的交互轨迹，再把可验证任务与开放任务放进联合强化学习。本文依据2026年2月的v2报告；主结果对应Kimi-K2-Instruct，不应与后来同系列的其他发布版本混用。[↗](https://arxiv.org/pdf/2507.20534v2#page=1)

先看结果图的评测对象。SWE-bench衡量在代理框架中修复仓库问题，LiveCodeBench衡量独立编程题，Tau2-Bench检查多轮工具任务；这些分数覆盖不同能力，不能由一个综合标签互相替代。

![Kimi K2 main results](../../assets/images/paper-deep-dives/technical-reports/kimi-k2/figure-1-k2-results.png){ width="920" }

<small>图源：`Kimi K2: Open Agentic Intelligence`，Figure 1，来自 arXiv source 包 `figures/k2-bench-bar-chart.pdf` 转 PNG。</small>

模型在SWE-bench Verified单次agentic尝试中达到65.8%，LiveCodeBench v6为53.7，AIME 2025为49.5。这些结果均处于报告定义的non-thinking设置，但一般仍允许最多8192个输出token。“不启用扩展思考模式”不意味着没有中间推理，更不意味着每题只输出短答案。

## 万亿参数容量怎样落到每token的计算量

K2采用61层、隐藏维7168的MoE，精确配置约1.04T总参数、32.6B激活参数；摘要将其取整为1T和32B。384个路由专家中每token选择8个，另有1个共享专家，专家中间维度2048；第一个前馈层使用dense结构。注意力沿用MLA，设置64个attention heads。[↗](https://arxiv.org/pdf/2507.20534v2#page=6)

| Configuration | Kimi K2 | DeepSeek-V3 |
| --- | ---: | ---: |
| Total Parameters | 1.04T | 671B |
| Activated Parameters | 32.6B | 37B |
| Layers | 61 | 61 |
| Hidden Dimension | 7168 | 7168 |
| Routed Experts | 384 | 256 |
| Activated Routed Experts | 8 | 8 |
| Shared Experts | 1 | 1 |
| Attention Heads | 64 | 128 |
| Dense Layers | 1 | 3 |

这里增加的是总容量，并非每一步把所有参数都计算一遍。作者以路由专家数除以激活专家数定义稀疏度，K2的值为48。小规模受控实验同时改变模型规模与token数，寻找给定计算量下的配置，而不是直接将一条大模型训练曲线外推。

阅读下图应固定纵轴loss，再比较达到它需要的横轴FLOPs。达到验证loss 1.5时，稀疏度48相对于8、16、32，计算量分别减少1.69、1.39、1.15倍。这是缩放实验的等loss比较，不能写成实际K2全流程训练比V3省了同样倍数。

![Kimi K2 sparsity scaling law](../../assets/images/paper-deep-dives/technical-reports/kimi-k2/figure-5-sparsity-scaling.png){ width="760" }

<small>图源：`Kimi K2: Open Agentic Intelligence`，Figure 5，来自 arXiv source 包 `figures/scaling_law_validation_loss.pdf` 转 PNG。</small>

更多专家也会改变attention与FFN的成本比例。作者在384专家、128K上下文条件下估算，将head数从64增至128会增加83%的推理FLOPs；受控训练中loss改善约0.5%—1.2%。下图应把这点小幅loss收益与长上下文成本放在一起理解，64 heads是容量、训练质量和推理成本的折中。

![Kimi K2 attention heads scaling](../../assets/images/paper-deep-dives/technical-reports/kimi-k2/figure-6-attention-heads.png){ width="760" }

<small>图源：`Kimi K2: Open Agentic Intelligence`，Figure 6，来自 arXiv source 包 `figures/doubleQheads.pdf` 转 PNG。</small>

激活32B并不意味着部署只需存放32B参数。全部专家仍需要存储、分片或换入；长上下文attention、专家间通信和实际batch也影响吞吐。报告的架构比较解释了计算设计，不能单凭激活参数得出端到端服务价格。

## MuonClip控制的是权重增长

Muon通过矩阵更新的正交化利用梯度方向，但放大到大规模时，作者观察到attention logits爆炸。53B总参数、9B激活参数的实验中，最大logit迅速超过1000。soft-cap只能压缩送进softmax的数值，不能直接抑制裁剪前的点积增长；对MLA直接使用普通QK-Norm又会与推理时不显式展开key的实现冲突。[↗](https://arxiv.org/pdf/2507.20534v2#page=3)

下图首先展示未控制时的增长速度。它提供的是稳定性问题的诊断，不能从这张中等规模实验图直接读出K2完整训练的loss。

![Muon logits explosion vs MuonClip](../../assets/images/paper-deep-dives/technical-reports/kimi-k2/figure-2a-muon-logits-mid.png){ width="460" .atlas-figure-compact }

<small>图源：`Kimi K2: Open Agentic Intelligence`，Figure 2(a)，来自 arXiv source 包 `figures/muon-MN-max-logits.pdf` 转 PNG。</small>

对head $h$，作者在当前batch $B$ 记录

$$
S_{\max}^{h}
=\frac{1}{\sqrt d}\max_{X\in B}\max_{i,j}
Q_i^h(K_j^h)^\top,
\qquad
\gamma_h=\min\left(1,\frac{\tau}{S_{\max}^{h}}\right).
$$

$d$ 是head维度，$i,j$ 是序列中的token位置，$\tau$ 是阈值。Muon完成常规权重更新后，QK-Clip依据这个已记录的最大值缩放投影权重；它不改变当前step已经完成的前向与反向计算。

普通多头注意力可分别将query和key投影乘以 $\sqrt{\gamma_h}$。MLA还要区分共享和非共享分量：head独有的内容query、key各乘 $\sqrt{\gamma_h}$，head独有的旋转位置query乘 $\gamma_h$，共享的旋转位置key保持不变。这样每个head的内容点积与位置点积都得到相应缩放，同时避免一个head异常影响所有head。

K2设置 $\tau=100$。下面的最大logit图显示训练早期的约束与后期回落；这是一种用当前batch反馈控制后续权重增长的机制，并非对所有未来输入给出logit上界证明。

![Kimi K2 max logits with MuonClip](../../assets/images/paper-deep-dives/technical-reports/kimi-k2/figure-2b-muonclip-logits-k2.png){ width="460" .atlas-figure-compact }

<small>图源：`Kimi K2: Open Agentic Intelligence`，Figure 2(b)，来自 arXiv source 包 `figures/muon-K2-max-logits.pdf` 转 PNG。</small>

附录补充，前70000步有12.7%的attention heads至少触发过一次裁剪，之后该机制不再实际触发。0.5B激活、3B总参数模型在更激进的 $\tau=30$ 下，带与不带QK-Clip的loss曲线接近，作者也未观察到显著下游退化。这些消融支持“必要时干预”的设计，但没有把MuonClip全部收益与数据、模型配置逐一分离。[↗](https://arxiv.org/pdf/2507.20534v2#page=30)

原文给出的训练loss没有平滑或下采样，因而应检查局部尖峰与整体下降，而非只看曲线外观。报告所称“zero loss spike”对应这次15.5T-token训练运行的观察。

![Kimi K2 training loss curve](../../assets/images/paper-deep-dives/technical-reports/kimi-k2/figure-3-loss-curve.png){ width="760" }

<small>图源：`Kimi K2: Open Agentic Intelligence`，Figure 3，来自 arXiv source 包 `figures/loss_vs_tokens_white.pdf` 转 PNG。</small>

## 重写语料怎样提高同一知识的训练价值

K2的数据覆盖网页、代码、数学与知识内容。作者认为单纯重复高质量知识片段会让模型记住表面文本，因此加入忠实于原内容、但风格和表达多样的重写。重写增加的是学习视角，不能自动创造新的外部知识；其有效性取决于事实保留和语义一致性。

对长材料，系统将输出拆成连续chunk，以原始材料和已生成的重写块为上下文，逐块续写。图中4096-token片段与256-token chunk用于说明这个过程。需要看的是下一块如何继承前文，而非把每块当成互不相干的摘要。

![Kimi K2 chunk-wise rephrasing pipeline](../../assets/images/paper-deep-dives/technical-reports/kimi-k2/figure-4-rephrase-pipeline.png){ width="820" }

<small>图源：`Kimi K2: Open Agentic Intelligence`，Figure 4，来自 arXiv source 包 `figures/synthetic_data_rephrase.pdf` 转 PNG。</small>

原文用SimpleQA观察知识获取的变化，保留重复次数与重写数量才能理解结果。

| Rephrase Count | Training Epochs | SimpleQA Accuracy |
| ---: | ---: | ---: |
| 0 | 10 | 23.76 |
| 1 | 10 | 27.39 |
| 10 | 1 | 28.94 |

多次表达比机械重复原文更有效，但表中10次重写属于实验设置。最终大语料流程对每个corpus至多重写两次，不能把消融配置当成全部15.5T数据的生产配方。[↗](https://arxiv.org/pdf/2507.20534v2#page=5)

主要预训练使用4096上下文、约67M tokens的global batch。500步warmup后，前10T tokens学习率保持 $2\times10^{-4}$，随后5.5T用cosine降至 $2\times10^{-5}$，weight decay为0.1。报告另描述末期annealing与长上下文激活阶段：400B tokens使用4K序列，60B使用32K序列，学习率降至 $7\times10^{-6}$，再用YaRN扩展至128K。阅读训练成本时应保留这些阶段口径，不能只用最终支持的128K反推全部预训练序列长度。[↗](https://arxiv.org/pdf/2507.20534v2#page=9)

## 训练系统围绕万亿参数的驻留成本安排

K2训练节点配备8张H800和2TB内存，跨机使用8路400Gbps RoCE。模型并行采用16-way pipeline parallel与16-way expert parallel，并配合虚拟流水线、ZeRO-1数据并行。256张GPU组成一组模型并行分片；仅BF16参数与FP32梯度约6TB，进一步包含优化器等状态后每GPU约30GB。

这解释了作者为何没有直接沿用DualPipe。双向流水线保留两份参数和梯度，对万亿参数模型代价较大。K2通过增加1F1B warmup、拆分weight-gradient计算等方式，将流水线通信与计算重叠。图中应分别追踪forward、backward、梯度计算与传输，不应把所有空隙都归结为算力不足。

![Kimi K2 training infrastructure overlap](../../assets/images/paper-deep-dives/technical-reports/kimi-k2/figure-7-training-infra.png){ width="920" }

<small>图源：`Kimi K2: Open Agentic Intelligence`，Figure 7，来自 arXiv source 包 `figures/3x_stream.pdf` 转 PNG。</small>

activation还采用选择性重计算与offload。部分保存的activation使用FP8 E4M3，并以 $1\times128$ 分组和FP32 scale控制误差；计算路径则没有采用FP8训练，作者在初步实验中发现质量风险。这里的“FP8存储”与“FP8矩阵计算”是两件不同的事，不能据此把K2描述成V3式FP8计算方案。[↗](https://arxiv.org/pdf/2507.20534v2#page=8)

## 工具训练先构造任务世界，再保留成功轨迹

SFT使用K1.5及内部领域模型生成候选回答，由模型或人工评估质量。工具部分尤其依赖交互轨迹，因为静态“问题—答案”无法展示工具出错后如何继续，也难以覆盖工具间依赖。

流程从工具描述开始。作者从GitHub收集3000多个真实MCP工具，又通过领域层级扩展生成20000多个合成工具，明确接口、描述与操作语义。随后为不同工具组合生成agent系统提示和任务，并给任务附上rubric，定义完成条件与检查点。下图的阅读顺序是工具库→agent配置→带评价标准的任务。

![Kimi K2 tool repository synthesis](../../assets/images/paper-deep-dives/technical-reports/kimi-k2/figure-8a-tool-repo-synthesis.png){ width="460" .atlas-figure-compact }

<small>图源：`Kimi K2: Open Agentic Intelligence`，Figure 8(a)，来自 arXiv source 包 `figures/tool_repo_synthesis.pdf` 转 PNG。</small>

轨迹生成再加入用户模拟器、执行agent、带状态的工具模拟器与judge。工具模拟器需要记住先前动作造成的变化，并产生成功、部分失败和边界情况；judge依据任务rubric筛选成功轨迹，用于后续SFT。下图中“有状态反馈”和“最后过滤”共同决定训练信号，而不只是让多个模型互相对话。

![Kimi K2 tool trajectory synthesis](../../assets/images/paper-deep-dives/technical-reports/kimi-k2/figure-8b-tool-trajectory-synthesis.png){ width="460" .atlas-figure-compact }

<small>图源：`Kimi K2: Open Agentic Intelligence`，Figure 8(b)，来自 arXiv source 包 `figures/tool_traj_synthesis.pdf` 转 PNG。</small>

两张t-SNE图展示真实与合成工具的覆盖分布。真实工具沿原始类别聚集，合成工具按预设领域扩展；它们支持工具来源互补的描述，不能从二维点云推出真实环境完成率或覆盖所有应用。

![Kimi K2 real MCP tools t-SNE](../../assets/images/paper-deep-dives/technical-reports/kimi-k2/figure-9a-tsne-mcp-tools.png){ width="460" .atlas-figure-compact }

<small>图源：`Kimi K2: Open Agentic Intelligence`，Figure 9(a)，来自 arXiv source 包 `figures/tsne_tool_mcp.pdf` 转 PNG。</small>

![Kimi K2 synthetic tools t-SNE](../../assets/images/paper-deep-dives/technical-reports/kimi-k2/figure-9b-tsne-synthetic-tools.png){ width="460" .atlas-figure-compact }

<small>图源：`Kimi K2: Open Agentic Intelligence`，Figure 9(b)，来自 arXiv source 包 `figures/tsne_tool_synthetic.pdf` 转 PNG。</small>

模拟环境的规模优势需要真实执行补足。代码与软件工程任务使用真实sandbox运行代码、测试和开发环境，取得测试通过率等客观反馈。报告明确承认模拟真实性的限制，因此这套流程是“广覆盖模拟＋关键场景真实执行”，不是所有合成工具都已有可运行后端。[↗](https://arxiv.org/pdf/2507.20534v2#page=11)

## 联合强化学习如何容纳不同奖励

后训练的第二个关键是让多类任务共同改进。数学、STEM和逻辑任务按照SFT模型pass@k选择中等难度题，避免全部成功或全部失败造成学习信号不足。代码任务运行测试，复杂指令结合规则验证、模型判断与hack-check，faithfulness则使用句子级judge识别缺乏上下文支持的事实陈述。软件工程sandbox基础设施支持超过10000个并发实例；这是系统能力说明，不是每次RL都必然使用该并发量。

开放任务没有唯一标准答案，K2先在SFT阶段学习偏好判断，再作为critic对候选回答做pairwise比较。判断依据同时包含核心价值rubric、防止reward hacking的规则和任务特定标准。训练中又使用可验证任务的on-policy结果更新critic，将客观执行反馈传入开放任务评价。这个闭环提供持续校准，仍不意味着自评已经等同于外部真实用户偏好。[↗](https://arxiv.org/pdf/2507.20534v2#page=12)

K2采用K1.5的policy优化目标。对问题 $x$，旧策略采样 $K$ 个回答 $y_i$，用组内平均奖励 $\bar r(x)$ 作基线，最小化

$$
\mathcal L_{\mathrm{RL}}(\theta)
=\mathbb E_{x\sim\mathcal D}\left[
\frac1K\sum_{i=1}^{K}
\left(r(x,y_i)-\bar r(x)
-\tau\log\frac{\pi_\theta(y_i\mid x)}{\pi_{\mathrm{old}}(y_i\mid x)}\right)^2
\right].
$$

这让相对旧策略的序列log-probability变化与中心化奖励匹配，$\tau$ 控制更新尺度。它不是将GRPO的clipped surrogate原样搬来；也不能因为两者都采样一组回答，就混写成同一个公式。

联合RL还加入三个实际约束。每类任务有自己的输出token预算，超出后截断并惩罚，抑制收益不足的冗长回答；高质量精选样本提供辅助PTX loss，缓解遗忘；采样temperature从较高逐渐降低，先探索再提高稳定性。报告没有公开一套足以原样复现所有任务的预算、混合比例与完整训练账单，因此这些机制支持训练设计分析，不能据此声称已得到完整复现配方。[↗](https://arxiv.org/pdf/2507.20534v2#page=13)

## RL的长轨迹与权重切换也需要专门处理

训练与推理引擎共置在同一批worker上，轮流使用GPU资源。rollout时训练状态offload到DRAM；更新后，推理引擎需要取得新的权重，而两套引擎的分片方式并不相同。

下图先看checkpoint engine如何取得本地训练参数，再向集群broadcast，最后由推理worker取回所需分片。作者选择广播全量参数，牺牲部分理论最优传输量，换取较少同步、更高带宽利用率以及训练／推理实现解耦。

![Kimi K2 RL checkpoint engine](../../assets/images/paper-deep-dives/technical-reports/kimi-k2/figure-10-rl-checkpoint-engine.png){ width="760" }

<small>图源：`Kimi K2: Open Agentic Intelligence`，Figure 10，来自 arXiv source 包 `figures/rl-ipc.drawio.pdf` 转 PNG。</small>

为控制内存峰值，更新按参数流水执行。报告称K2完整参数更新可在30秒以内完成，这只衡量权重切换，不是一次RL迭代或一次agent任务耗时。长轨迹则使用partial rollout：未完成的尾部任务暂时停下，在下一轮继续，避免所有worker等待最慢任务。重环境独立部署为服务、大量并发rollout摊薄等待，也都是agent训练利用率的一部分。[↗](https://arxiv.org/pdf/2507.20534v2#page=14)

## 主结果需要把框架、尝试次数和输出预算一起读

下表摘取原文Table 3，保留英文任务名与metric。所有模型采用non-thinking配置；星号表示来自对应模型报告或博客，不能当作本报告统一重新运行的数值。LiveCodeBench v6题目覆盖2024年8月至2025年5月。

| Benchmark (Metric) | Kimi-K2-Instruct | DeepSeek-V3-0324 | Qwen3-235B-A22B | Claude Sonnet 4 | GPT-4.1 |
| --- | ---: | ---: | ---: | ---: | ---: |
| LiveCodeBench v6 (Pass@1) | 53.7 | 46.9 | 37.0 | 48.5 | 44.7 |
| SWE-bench Verified Agentless-Single-Patch (Pass@1) | 51.8 | 36.6 | 39.4 | 50.2 | 40.8 |
| SWE-bench Verified Agentic-Single-Attempt (Pass@1) | 65.8 | 38.8 | 34.4 | 72.7* | 54.6 |
| SWE-bench Verified Agentic-Multi-Attempt (Pass@1) | 71.6 | — | — | 80.2* | — |
| SWE-bench Multilingual (Pass@1) | 47.3 | 25.8 | 20.9 | 51.0 | 31.5 |
| AceBench (Acc.) | 76.5 | 72.7 | 70.5 | 76.2 | 80.1 |
| AIME 2025 (Avg@64) | 49.5 | 46.7 | 24.7* | 33.1* | 37.0 |
| GPQA-Diamond (Avg@8) | 75.1 | 68.4* | 62.9* | 70.0* | 66.3 |
| MRCR (Acc.) | 55.0 | 50.8 | — | 74.4 | 66.9 |

同一K2在SWE-bench上由agentless 51.8变为agentic单次65.8，再到多次71.6，展示了交互与额外尝试的价值。多次模式使用内部验证器best-of-N选取结果，不能与单次方法只按最终百分比比较。一般输出上限8192，Agentless SWE-bench提高到16384；长上下文评测使用128K并截断超长输入。Avg@64、Avg@8是重复采样平均，不是多数投票后的consensus准确率。[↗](https://arxiv.org/pdf/2507.20534v2#page=15)

工具结论也应服从表格。K2在Tau2的telecom分项65.8，明显高于表中的其他模型，但retail 70.6和airline 56.5仍低于Claude Opus 4的81.8和60.0；AceBench的76.5也低于GPT-4.1的80.1。摘要的Tau2 micro-average 66.1不能代替三个分项，更不能由正文宣传性措辞推出“所有工具任务都领先”。

Base模型的独立评测补充了基础能力。K2-Base在5-shot SimpleQA上35.25，对照V3-Base 26.49；4-shot MATH为70.22对61.70，EvalPlus为80.33对65.61。但5-shot GPQA-Diamond八次平均为48.11，低于V3-Base 50.51。基础能力整体较强不等于每个维度都最优，且Base与Instruct的prompt、采样和评分不同，不能直接用两表差值量化RL贡献。[↗](https://arxiv.org/pdf/2507.20534v2#page=18)

## 实际使用的收益来自模型与环境共同工作

K2最有说服力的证据集中在可持续交互的代码与工具任务。其训练流程把工具定义、失败反馈、任务rubric和可执行测试纳入数据与奖励；部署时也应提供清晰的工具schema、可验证结果和足够的交互机会。报告明确指出，一次提示生成完整软件项目的成功率低于在agentic coding框架中工作，且无必要地启用工具可能降低某些任务表现。

长上下文与复杂指令同样还有边界。MRCR 55.0落后于表中多种闭源模型；不清晰的工具定义或困难推理可能造成过量token、截断和不完整调用。安全表也并非全面优势，例如Security–Iterative Jailbreak通过率43.90，低于V3-0324的60.97和Qwen3的78.04。该安全评测每类组合只生成少量攻击并加入人工复核，结果用于定位问题，不足以证明开放工具环境中的全面可靠性。[↗](https://arxiv.org/pdf/2507.20534v2#page=19)

因此，这份报告的可迁移经验在于如何把基础模型、轨迹生产、奖励和执行系统接成一个训练闭环。MuonClip解决大规模训练中的具体数值问题；真实sandbox为合成轨迹补上可验证反馈；联合RL与推理预算约束让模型更接近完成任务所需的行为。采用时仍需按自己的任务、工具定义、尝试次数和延迟预算复测，而不能把一个non-thinking主榜分数直接当成完整业务成功率。
