---
paper_date: 2025-01
paper_title: "SpatialVLA: Exploring Spatial Representations for Visual-Language-Action Models"
paper_topic: 具身智能 / VLA
---

# SpatialVLA：3D 空间表征接入 VLA

!!! info "论文信息"
    **论文题名：** SpatialVLA: Exploring Spatial Representations for Visual-Language-Action Model。<br>
    **作者：** Delin Qu、Haoming Song、Qizhi Chen、Yuanqi Yao、Xinyi Ye、Yan Ding、Zhigang Wang、JiaYuan Gu、Bin Zhao、Dong Wang 等（共 11 人）。<br>
    **机构：** Shanghai AI Laboratory,、Fudan University,、Shanghai Jiao Tong University,、Zhejiang University,。<br>
    **时间 / 主题：** 2025-01；具身智能 / VLA。<br>
    **arXiv / 官方报告：** arXiv：[2501.15830](https://arxiv.org/abs/2501.15830)；官方材料：[spatialvla.github.io/](https://spatialvla.github.io/)。<br>
    **GitHub / 项目：** GitHub：[github.com/SpatialVLA/SpatialVLA](https://github.com/SpatialVLA/SpatialVLA)；项目页：[spatialvla.github.io/](https://spatialvla.github.io/)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2501.15830)；[GitHub API / repo](https://github.com/SpatialVLA/SpatialVLA)；[官方 / 项目材料](https://spatialvla.github.io/)；Checked Date：2026-06-15；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 同时改变观察表示与动作词表

SpatialVLA 处理跨机器人操作中的两种不一致。观察来自不同相机位置，RGB 中的二维距离不等于三维距离；动作分布也随工作空间、控制器和任务变化。论文在输入加入相机坐标下的 Ego3D 编码，在输出用数据自适应三维网格表示平移与旋转，并在新机器人微调时重新划分网格。[↗](https://arxiv.org/pdf/2501.15830#page=3)

![SpatialVLA model](../../assets/images/paper-deep-dives/embodied-ai/spatialvla/figure-1-model.png){ width="490" .atlas-figure-compact }

*来源：原论文模型示意。沿 RGB、深度、视觉 token 到三个动作 token 阅读，区分输入空间编码与输出空间离散化。*

模型基于 PaliGemma 2，使用约 1.1M 真实机器人 episodes，来源为 OXE 子集与 RH20T。它并不要求机器人—相机外参标定，但仍需要将像素反投影到相机坐标的内参以及估计深度；“无外参”不等于没有几何条件。

## Ego3D 编码怎样给语义特征加入深度

ZoeDepth 估计深度图，结合内参反投影得到每个视觉 patch 对应的三维位置 $P$。SigLIP 给出二维语义特征 $X$，位置经过正弦频率编码与可学习 MLP 后相加：

$$
O^{3d}=X+\operatorname{MLP}(\gamma(P)).
$$

$X$ 保留预训练视觉语言对齐，$\gamma(P)$ 使特征对同一二维位置下的远近变化敏感。坐标以相机为中心，避免不同机器人外参定义造成直接冲突。不过估计深度的偏差仍会进入编码，这不是有准确三维传感器的等价替代。[↗](https://arxiv.org/pdf/2501.15830#page=4)

## 三个 token 怎样表达七维动作

单步动作分为平移 $a_{trans}$、旋转 $a_{rot}$ 和夹爪 $a_{grip}$。平移先从 $(x,y,z)$ 转到方向与距离 $(\phi,\theta,r)$，旋转使用 roll/pitch/yaw。各变量在对应机器人数据内归一化，再根据全数据混合的高斯拟合分布划分等概率区间。高频区域获得更密集网格，低频区域网格较稀疏；方向分辨率也可高于距离分辨率。

三维格点组合形成平移词表与旋转词表，每个单步只预测一个平移 token、一个旋转 token、一个开合 token。最终词表为 4096 平移类、4096 旋转类、2 夹爪类，共 8194 类，取代逐维预测七个独立数字的方式。

![SpatialVLA adaptive action grids](../../assets/images/paper-deep-dives/embodied-ai/spatialvla/figure-2-action-grids.png){ width="690" }

*来源：原论文 adaptive action grids 图。先比较动作密度，再看网格边界是否在密集区缩小；网格编码的是整组三维动作，不是给每个坐标单独输出一个 token。*

这是序列长度与词表大小之间的交换。三 token 降低自回归步数，组合类别则让词表更大，并要求合适的空间分辨率。过粗网格会丢掉小运动差异；均匀网格把有限类别浪费在很少出现的动作上。

## 新机器人适配时，token 的物理意义也要调整

新数据可能集中在原网格的狭窄区域。Spatial Embedding Adaptation 重新拟合高斯、重划网格，并用旧网格相邻嵌入三线性插值初始化新 token：

$$
e^{i}_{new}=\sum_{j=1}^{K}w_je_j.
$$

$w_j$ 由新格点中心与旧邻居的归一化距离确定。这样保留相近动作的表示关系，同时把分辨率重新分配到新机器人的动作范围。之后继续用 next-token cross-entropy 微调，而不是将所有新动作嵌入重新随机初始化。[↗](https://arxiv.org/pdf/2501.15830#page=5)

![SpatialVLA dataset mixture](../../assets/images/paper-deep-dives/embodied-ai/spatialvla/figure-8-dataset-mixture.png){ width="620" }

*来源：原论文数据配方图。混合权重影响学到的动作统计，因而也影响网格划分和转移起点。*

预训练更新视觉编码器、语言骨干、Ego3D MLP 和动作嵌入，但冻结原文本词嵌入以保留语言能力。最后三分之一训练移除 DROID。使用 64 张 A100、batch size 2048，训练十天。实际策略用一张第三人称图像，输出四步动作块，即 12 个空间动作 token；论文报告单张 RTX 4090 约 20 Hz、8.5GB 显存。部署预算中还应包含深度与输入处理路径。

## 零样本与微调结果不能混在一起

![SpatialVLA experiment setup](../../assets/images/paper-deep-dives/embodied-ai/spatialvla/figure-3-experiment-setup.png){ width="690" .atlas-figure-compact }

*来源：原论文评测设置图。先辨认机器人和是否微调，再比较空间变化、视觉变化与任务变化。*

SimplerEnv Google Robot 中，SpatialVLA 零样本 Visual Matching/Variant Aggregation 平均为 71.9%/68.8%，RT-2-X 为 60.7%/64.3%。在 Fractal 微调后为 75.1%/70.7%。WidowX 零样本总成功率 34.4%，BridgeData V2 微调后 42.7%，但单个任务并非都改善，例如 spoon-on-towel 从 20.8% 降到 16.7%。[↗](https://arxiv.org/pdf/2501.15830#page=6)

LIBERO 使用每套十任务、每任务 50 条示范，SpatialVLA 以 LoRA $r=32,\alpha=32$ 微调 200 epochs。原 Table III：

| Method | Spatial SR (%) | Object SR (%) | Goal SR (%) | Long SR (%) | Average SR (%) |
|---|---:|---:|---:|---:|---:|
| OpenVLA fine-tuned | 84.7 ± 0.9 | 88.4 ± 0.8 | 79.2 ± 1.0 | 53.7 ± 1.3 | 76.5 ± 0.6 |
| SpatialVLA fine-tuned | 88.2 ± 0.5 | 89.9 ± 0.7 | 78.6 ± 0.6 | 55.5 ± 1.0 | 78.1 ± 0.7 |

平均提升 1.6 个百分点，Spatial 最明显，Goal 略低于 OpenVLA。Long 只有 55.5%，说明空间表示改善并没有自动解决长期观察和多阶段记忆。[↗](https://arxiv.org/pdf/2501.15830#page=8)

## 消融怎样支持空间编码与网格设计

控制实验在 Fractal 与 Bridge 混合数据上，用 8 张 A100、batch size 128、120K steps 训练。完整模型的 pick-coke variant aggregation 为 81.6%，换线性 256 bins 为 40.7%，换均匀分布网格为 77.9%，移除 Ego3D 为 68.9%。在 eggplant-in-basket 上，完整模型 87.5%，移除 Ego3D 后 37.5%，说明深度编码的作用具有任务差异。

后训练消融更加直接。LIBERO 上普通 LoRA 的 Spatial/Object/Goal/Long 为 83.6/84.8/76.4/50.1，增加空间嵌入适配后为 88.2/89.9/78.6/55.5。它支持重新分配动作网格是一项有效适配操作，而不只是较大预训练集合的伴随现象。[↗](https://arxiv.org/pdf/2501.15830#page=9)

![SpatialVLA spatial understanding](../../assets/images/paper-deep-dives/embodied-ai/spatialvla/figure-6-spatial-understanding.png){ width="690" }

*来源：原论文空间理解任务图。将高度改变与“离机器人最近”等语言关系分别看，它们检验不同的空间要求。*

SpatialVLA 可复用的部分是把动作离散化视为可学习、可重设的接口。对新机器人，除了微调网络权重，还应检查动作分布和网格分辨率；对新视觉布局，还要检查深度估计是否稳定。该论文给出的是空间感知和动作编码的改进，尚不提供完整的长任务记忆或失败恢复方案。
