---
paper_date: 2026-06
paper_title: "Qwen-RobotManip Technical Report: Alignment Unlocks Scale for Robotic Manipulation Foundation Models"
paper_topic: 具身智能 / VLA
---

# Qwen-RobotManip：先对齐再扩规模的机器人操作基础模型

!!! info "论文信息"
    **论文题名：** Qwen-RobotManip Technical Report: Alignment Unlocks Scale for Robotic Manipulation Foundation Models。<br>
    **作者：** Qwen Team；Haoqi Yuan、Zhixuan Liang、Anzhe Chen、Ye Wang、Haoyang Li、Pei Lin、Yiyang Huang、Zixing Lei、Tong Zhang、Jiazhao Zhang 等（arXiv v2 列出 23 位作者）。<br>
    **机构：** Qwen Team / Alibaba 相关团队；以 arXiv/PDF author block 为准。<br>
    **时间 / 主题：** 2026-06；具身智能 / VLA / 跨 embodiment 机器人操作基础模型。<br>
    **arXiv / 官方报告：** arXiv：[2606.17846](https://arxiv.org/abs/2606.17846)；PDF：[2606.17846v2](https://arxiv.org/pdf/2606.17846v2)；Qwen 官方页：[qwen.ai/blog?id=qwen-robotmanip](https://qwen.ai/blog?id=qwen-robotmanip)。<br>
    **GitHub / 项目：** GitHub：[QwenLM/Qwen-RobotManip](https://github.com/QwenLM/Qwen-RobotManip)。<br>
    **元数据来源与核验口径：** 来源：[arXiv API / v2](https://export.arxiv.org/api/query?id_list=2606.17846)、[arXiv source](https://arxiv.org/e-print/2606.17846)、[GitHub](https://github.com/QwenLM/Qwen-RobotManip)；Checked Date：2026-07-06；Repro Status：Paper / official source and repo reviewed, independent reproduction not claimed。

## 数据规模只有经过物理对齐才有意义

Qwen-RobotManip 面对的是跨机器人数据扩展中的具体障碍。同一个动作在不同数据集中可能使用不同关节顺序、末端定义、坐标原点和速度；如果只把向量补到相同长度，模型仍须花容量解释互相冲突的标签。论文把统一动作语义、统一末端运动坐标、历史执行上下文和多源数据清洗连成一套方案，再用分布外评测检查扩大数据是否真正改善迁移。[↗](https://arxiv.org/pdf/2606.17846#page=3)

![Qwen-RobotManip teaser 原论文图](../../assets/images/paper-deep-dives/embodied-ai/qwen-robotmanip/figure-0-teaser.png){ width="920" }

模型在常用同分布 benchmark 上接近满分，但更有解释力的是未见相机、初始机器人状态、复杂干扰和新本体上的结果。论文将标准 benchmark 与这些条件分开，是为了避免将场景模式记忆误认为基础模型泛化。

## 从 Qwen3.5 到连续动作的计算路径

VLM 使用 Qwen3.5-4B，最后一层宽度为 2560；动作专家是 10 层 DiT，宽度 768、12 个注意力头。每层先对状态和带噪动作做 self-attention，再读取 VLM 最后一层特征。偶数层读视觉 token，奇数层读语言 token，使空间观察与指令条件分别进入动作更新。

![Qwen-RobotManip overview 原论文图](../../assets/images/paper-deep-dives/embodied-ai/qwen-robotmanip/figure-1-overview.png){ width="880" }

总览中值得追踪的是当前状态、历史状态和图像的三条路线。当前状态经专用 MLP 直接进入动作 DiT；历史图像由视觉编码器处理；历史状态与已执行动作则先映射到 VLM 隐藏空间。它们服务于不同条件，不能简单视为把过去视频加长。

设动作块为 $a$，采样 $t\sim\operatorname{Beta}(1,1.5)$，构造

$$
x_t=(1-t)\epsilon+ta,\qquad \epsilon\sim\mathcal N(0,I).
$$

动作专家回归速度 $a-\epsilon$。基础模型执行采用四步 Euler 积分；训练同一次 VLM 前向复用八组独立噪声和时间，提高动作训练利用率。四步是动作采样预算，不是机器人动作执行频率。[↗](https://arxiv.org/pdf/2606.17846#page=10)

## 80 维统一空间必须固定每个槽位的含义

状态与动作使用 80 维 canonical template，每只手臂占 29 个语义槽位：关节 7、末端位置及姿态 9、夹爪 1、灵巧手关节 12；另外保留 22 维容纳移动底盘等通道。只有实际存在的维度参与损失。状态中的姿态用连续 6D rotation，动作姿态增量采用三维 rotation vector，二者不能直接按同一旋转编码解释。

统一槽位解决结构差异，但坐标差异还存在。论文进一步采用 camera-frame delta pose。令 $R_e^c$ 将当前末端坐标转换到参考相机坐标，$R_{e^*}^e,t_{e^*}^e$ 表示未来末端相对当前末端的旋转和位移，则原 Eq. 5 为

$$
a_p=\begin{bmatrix}
R_e^cR_{e^*}^e(R_e^c)^{\mathsf T} & R_e^c t_{e^*}^e\\
0 & 1
\end{bmatrix}.
$$

旋转增量通过共轭变换写进相机轴，平移增量仅旋转到相机轴。这样，画面中看起来相似的运动更容易具有相近数值。原文另比较完整位姿乘积形式，但其平移会与旋转和相机—末端偏移耦合，容易产生长尾并放大标定误差，实际采用上式。[↗](https://arxiv.org/pdf/2606.17846#page=12)

这一接口要求训练和执行具有相机内外参。没有标定的样本由额外 flag 切换为机器人基座相对模式，不能假定所有数据天然都在相机坐标中。Camera Positional Encoding 将相机姿态写入注意力：每个 64 维 head 中 32 维用于 CaPE、32 维用于时间 RoPE，视觉 token 使用所属相机，动作 token 使用选定参考相机。跨视角相对位姿因而进入注意力，而世界原点在相对计算中消去。

## 把人类轨迹转成机器人监督

训练语料约 38100 小时，其中原始机器人数据约 11420 小时、人类第一视角数据 1933 小时、Human-to-Robot 合成数据 24808 小时。合成数据占大部分，不能将总小时数表述成全部真实机器人遥操作。原始来源同时含单臂、双臂、移动与仿真数据。

![Human-to-robot pipeline 原论文图](../../assets/images/paper-deep-dives/embodied-ai/qwen-robotmanip/figure-2-h2r-pipeline.png){ width="920" }

Human-to-Robot 分开处理动作与外观。动作侧先用 MANO 手关键点定义虚拟手指

$$
k_{\mathrm{vf}}=0.7k_{\mathrm{index}}+0.3k_{\mathrm{middle}},\qquad
p=\tfrac12(k_{\mathrm{thumb}}+k_{\mathrm{vf}}),\qquad
w=\|k_{\mathrm{thumb}}-k_{\mathrm{vf}}\|_2.
$$

$p$ 对应夹爪中心，$w$ 对应开口宽度，指尖方向和腕部方向再构造右手旋转坐标系。位置、宽度与旋转分别平滑，降低逐帧手部重建噪声。

视觉侧用 SAM3 分割手臂、ProPainter 补背景。没有天然机器人基座时，围绕轨迹搜索基座位置，以关键帧逆运动学可行为目标；每个机器人形态独立搜索，再通过 MuJoCo IK 跟踪动作。最后用 Depth Anything 3 场景深度与渲染机器人深度判断遮挡，将机器人合成到背景。15 种双臂配置产生对应视觉和动作标签，使同一人类交互可以覆盖不同本体。[↗](https://arxiv.org/pdf/2606.17846#page=5)

合成并不能自动保证控制质量，因此还需要清洗。信号侧依次检查突变、状态—动作趋势对齐、异常值、FK 一致性和基座/末端朝向；视觉侧检查指令与轨迹一致、渲染机器人与图像分割重叠，以及黑帧、模糊和冗余静止。夹爪关闭等关键细微动作被保留，避免以“画面变化小”为由误删有效监督。

![Data curation pipeline 原论文图](../../assets/images/paper-deep-dives/embodied-ai/qwen-robotmanip/figure-3-data-curation.png){ width="920" }

一个具体例子是状态变化不应先于对应动作命令。作者平滑信号、估计互相关时延并比较差分方向，发现 RoboMIND 某 UR 子集约 81% episode 未通过检查。这个比例说明混合前的数据审计可能比名义小时数更重要；它是该子集和该规则下的发现，不能泛化为所有机器人数据的错误率。[↗](https://arxiv.org/pdf/2606.17846#page=7)

## 训练损失如何避免高维机器人支配梯度

有效掩码由三部分相与：本体实际拥有的维度、时间步是否有效、人类手是否处于视野。某时间步异常后，其后续步骤也遮蔽以保持序列一致性。每个样本先按有效元素平均，再对 batch 平均。

$$
\mathcal L_{\mathrm{FM}}=\frac1B\sum_{i=1}^{B}
\frac{\sum_{t,j}m_{i,t,j}(\hat v_{i,t,j}-v_{i,t,j})^2}
{\sum_{t,j}m_{i,t,j}}.
$$

这一步防止双臂、灵巧手等活跃维度更多的样本仅因元素更多而获得更大损失权重。它也明确区分“槽位填零”与“零动作标签”，结构缺失的维度不会被错误监督为必须停止。

预训练另混合约 28M 条 VL 数据，涵盖通用理解、空间推理、OCR、语言指令以及 embodied CoT、第一视角视频理解和二维轨迹预测。VLA 与 VL 使用互斥 batch，数据比例 9∶1，总目标为

$$
\mathcal L=\mathcal L_{\mathrm{FM}}+0.1\mathcal L_{\mathrm{VLM}}.
$$

动作损失更新骨干和动作专家，语言损失维持骨干理解能力。主实验下游 SFT 只优化动作损失，每个域训练一个多任务模型；混合部分预训练数据的 post-training 是另行验证的增强方案，不能作为所有主表结果的默认设置。[↗](https://arxiv.org/pdf/2606.17846#page=15)

## 历史上下文提供执行经验，也增加采样难度

一个 context chunk 包括历史观测、本体状态和当时执行的完整动作块。历史图像与当前图像一起编码，状态和动作经 MLP 加入时间、槽位位置编码，按时间顺序送入 VLM；当前状态仍沿原动作头路径输入。默认 unified 模式让 VLM 同时整合历史、语言和视觉，另有直接把历史送进 DiT 的 dual 模式。

总是提供最近动作容易造成复制捷径。训练因此从 episode 内随机位置采样上下文，使模型学执行速度、抓取方式与本体运动特征；部署才使用最近的滚动窗口。该机制主要用于同一 episode 的策略适配，不等同于跨任务长期记忆或在线参数更新。[↗](https://arxiv.org/pdf/2606.17846#page=14)

缩小规模的消融揭示了成本。结构化 prompt、无历史、四步去噪的 Easy/Hard 均值为 65.9；加入历史但仍四步，均值降为 63.3，作者观察到动作抖动；增加到十步达到 70.9，二十步为 71.0。历史条件增加了动作分布的复杂度，需要足够采样预算。零填充历史还会在 episode 起点造成犹豫，因此上下文版与基础版各有实际用途。[↗](https://arxiv.org/pdf/2606.17846#page=33)

## 标准测试与分布外测试得出不同判断

![IID diagnostic 原论文图](../../assets/images/paper-deep-dives/embodied-ai/qwen-robotmanip/figure-4-iid-vs-ood.png){ width="920" }

同分布条件中，仅用目标域机器人数据训练的 scratch 版本已达 LIBERO 98.2、RoboTwin Easy/Hard 88.7/88.4；完整预训练版本为 99.1、93.4/92.5。差距存在，但高分本身无法说明学到了多强的可迁移结构。

| Model | LIBERO-Plus (%) | RoboTwin-C2R Hard, Joint (%) |
|---|---:|---:|
| StarVLA | 74.1 | 10.6 |
| π0.5 | 84.4 | 47.9 |
| Qwen-RobotManip-scratch | 78.3 | 22.6 |
| Qwen-RobotManip | 89.0 | 62.6 |
| Qwen-RobotManip-Context | 91.4 | 69.4 |

RoboTwin-C2R 仅在 Clean 数据微调，Hard 同时改变背景、照明、干扰物与桌面高度。LIBERO-Plus 的 Robot 扰动下，scratch 为 44.9，基础版 75.5，上下文版 83.9；而语言、照明和背景条件中 scratch 已有较强表现。这说明通用 VLM 已提供部分外观语义鲁棒性，机器人预训练的额外价值更集中于初始构型、空间与交互变化。[↗](https://arxiv.org/pdf/2606.17846#page=21)

![OOD summary 原论文图](../../assets/images/paper-deep-dives/embodied-ai/qwen-robotmanip/figure-5-ood-summary.png){ width="900" }

RoboTwin-IF 在相近视觉场景中使用未见指令模板，平均成功率为基础版 72.2、上下文版 72.0、π0.5 49.6。上下文并非每项都提高，Operated-Stapler 中基础版 90 也略低于 π0.5 的 92。RoboCasa365 未见复合任务为 14.9%，高于 RLDX-1 的 5.4%，但整体仍有多数失败；Context 在该项为 11.2%，再次说明历史收益依赖任务。[↗](https://arxiv.org/pdf/2606.17846#page=22)

## 零样本跨本体的提升与残余差距

RoboTwin-XE 在 AgileX ALOHA 示范上微调，再在 Hard 条件下换成未见机器人，没有目标本体适配数据。

| Method / Action Space | ARX-X5 (%) | UR5-WSG (%) | Franka Panda (%) | Average (%) |
|---|---:|---:|---:|---:|
| π0.5, EEF | 11.5 | 10.0 | 1.1 | 7.5 |
| Qwen-RobotManip, Joint | 37.6 | 4.1 | 1.8 | 14.5 |
| Qwen-RobotManip, Camera EEF | 42.9 | 22.8 | 5.9 | 23.9 |

相机 EEF 平均比自身关节控制高 9.4 个百分点，比 π0.5 EEF 高 16.4 个百分点。UR5 从 4.1 到 22.8 的变化尤其明显，但 Franka 仍只有 5.9%，表明共享笛卡尔接口降低了本体差异，尚未消除视觉、运动范围与形态差异。[↗](https://arxiv.org/pdf/2606.17846#page=24)

![Cross embodiment 原论文图](../../assets/images/paper-deep-dives/embodied-ai/qwen-robotmanip/figure-9-cross-embodiment.png){ width="840" }

真实 ARX 的技能迁移是另一个协议：共同微调 6000 条 CobotMagic 与 130 条 ARX 示范，再测试 ARX 没有目标任务示范的四项组合任务。完整模型平均 55.0%，仅统一槽位而无统一 EEF 为 12.5%，无语义槽位为 7.5%。这证明的是新本体—任务组合迁移，ARX 本体本身在微调中已出现。[↗](https://arxiv.org/pdf/2606.17846#page=27)

## 扩大数据的收益能否稳定出现

![Scaling curves 原论文图](../../assets/images/paper-deep-dives/embodied-ai/qwen-robotmanip/figure-6-scaling-curves.png){ width="920" }

规模实验按本体和任务构造嵌套的 1%、5%、10%、25%、50%、100% 数据子集，测试固定的 15 种本体、154 个训练未见任务。每一点取所有 checkpoint 中最好的验证 MSE，因此它衡量在该训练流程内可达到的误差，不能直接当作固定计算预算的 scaling law。

有语义槽位的两个版本总体呈更稳定的下降，完整相机 EEF 的末端误差最低；原始字段拼接加补零的曲线更不稳定。下游统一微调 80K 步后，完整模型在 OOD Hard 随数据量增加稳定改善，满规模达到 joint 50.2、EEF 56.6；这些属于缩小规模的消融，不能与主表 62.6、60.8 混合成同一配置。[↗](https://arxiv.org/pdf/2606.17846#page=32)

![Downstream scaling 原论文图](../../assets/images/paper-deep-dives/embodied-ai/qwen-robotmanip/figure-7-downstream-scaling.png){ width="920" }

Human-to-Robot 消融在相同训练步骤和超参数下比较 robot-only、加入原始 ego、加入合成 H2R。RoboTwin-C2R Hard 的 EEF 成功率为 54.7、55.0、58.7；LIBERO-Plus 为 87.1、88.4、89.0。原始第一视角数据提供收益，动作与外观对齐后又增加一部分，支持合成管线的具体作用，而非将全部预训练优势都归于合成数据。[↗](https://arxiv.org/pdf/2606.17846#page=34)

![Mixed post-training 原论文图](../../assets/images/paper-deep-dives/embodied-ai/qwen-robotmanip/figure-8-mixed-posttraining-ablation.png){ width="760" }

混合后训练的消融则提示，额外数据需要一致的动作接口。完整对齐下 RoboTwin-IF 分数由 71.6 提到 75.8；移除 UnifiedEEF 后，引入混合数据的特定变体降至 0。这是该配置中强烈的失败证据，说明不对齐的混合可能破坏策略，不能扩展成所有模型都无法使用混合数据的普遍定理。

## 真机结果把泛化放回任务和样本数量中

CobotMagic 用 22.9 小时示范微调，七项 ID 任务各测五次，平均成功率 88.6%，π0.5 为 42.9%；黄色圆片插入只有 2/5，精细接触仍困难。四项 OOD 任务各十次，平均 87.5%，π0.5 为 37.5%，包含新目标、左右关系和动态照明。较少测试次数意味着应同时保留成功次数，不把这些均值解释成长期运行可靠性。[↗](https://arxiv.org/pdf/2606.17846#page=25)

RoboChallenge Table30 v1 使用 generalist track，每个本体训练一个多任务模型，而非单一模型控制所有本体。论文以 Lira_generalist 提交，报告完全成功率 45%、过程分数 59.83；DM0 对照为 37%/48.43。重试案例展示了策略可能在抓取滑落后再次尝试，但论文没有单独量化恢复概率，不能将可视化直接转成新的鲁棒性指标。[↗](https://arxiv.org/pdf/2606.17846#page=28)

部署通过远程服务与 WiFi 传输观测和动作，并用 Real-Time Chunking 在执行当前块时异步生成下一块。采用这条路线时，最值得复用的是先把坐标、语义槽位、有效监督和时间对齐做成明确接口，再观察 OOD 曲线是否随数据扩展改善。模型规模与更多数据只有通过这些接口，才更可能变成跨机器人可用的控制知识。
