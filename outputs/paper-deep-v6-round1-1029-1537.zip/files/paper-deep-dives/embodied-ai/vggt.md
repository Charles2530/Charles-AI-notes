---
title: VGGT：一次前向推理怎样恢复相机、深度、点云与轨迹
paper_date: 2025-03
paper_title: "VGGT: Visual Geometry Grounded Transformer"
paper_topic: 具身智能
---

# VGGT：一次前向推理怎样恢复相机、深度、点云与轨迹

!!! info "论文信息"
    **论文题名：** VGGT: Visual Geometry Grounded Transformer。<br>
    **作者：** Jianyuan Wang、Minghao Chen、Nikita Karaev、Andrea Vedaldi、Christian Rupprecht、David Novotny。<br>
    **机构：** Visual Geometry Group, University of Oxford、Meta AI。<br>
    **时间 / 主题：** 2025-03；具身智能。<br>
    **arXiv / 官方报告：** arXiv：[2503.11651](https://arxiv.org/abs/2503.11651)；官方材料：[vgg-t.github.io/](https://vgg-t.github.io/)。<br>
    **GitHub / 项目：** GitHub：[github.com/facebookresearch/vggt](https://github.com/facebookresearch/vggt)；项目页：[vgg-t.github.io/](https://vgg-t.github.io/)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2503.11651)；[GitHub API / repo](https://github.com/facebookresearch/vggt)；[官方 / 项目材料](https://vgg-t.github.io/)；Checked Date：2026-06-15；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 把几何计算的多数环节放进一次前向

VGGT 将一组 RGB 图像映射为相机、深度、三维点和点跟踪特征。它的贡献是让多视图几何成为可直接调用的预训练网络能力。过去需要匹配、相机求解、三角化和全局优化分别协作的结果，现在可由一个共享骨干同时预测；需要更高精度时，网络输出又能作为 Bundle Adjustment 的初始化。[↗](https://arxiv.org/pdf/2503.11651#page=3)

![VGGT teaser 原论文图](../../assets/images/paper-deep-dives/embodied-ai/vggt/figure-1-teaser.png){ width="920" }

*来源：原论文 Figure 1。按输入视图到几何输出的顺序阅读，区分网络直接预测与可选优化。*

单次前向并不意味着几何约束不再重要。VGGT 把共同坐标系、跨视图交互和多任务监督放进训练，要求网络学会以一致方式解释整组图像。论文同时保留深度、相机和点图这些看似冗余的目标，检验多个几何任务是否能相互提供训练信号。

## 输出接口与坐标系

原文将模型写为

$$
f((I_i)_{i=1}^{N})=(g_i,D_i,P_i,T_i)_{i=1}^{N}.
$$

每张图像 $I_i$ 对应九维相机参数 $g_i=[q_i,t_i,f_i]$，其中四元数 $q_i$ 表示旋转，$t_i$ 表示平移，$f_i$ 为两个视场角；$D_i$ 是深度图，$P_i$ 是三维点图，$T_i$ 是稠密跟踪特征。相机主点假定在图像中心。

所有全局点图和相机都以第一张图的相机为参考，因此第一相机外参固定为单位变换。除了第一张参考图，其他图像的顺序不承担时间含义；网络可以接受无序场景照片。跟踪接口也因此首先面向同一场景中的跨图对应，而不要求输入是视频。

三维坐标的尺度同样存在不可观测性。训练时作者将所有点到原点的平均距离作为共同尺度，归一化平移、深度和点图。网络学习输出这种规范化坐标；预测端不再单独归一化。这使监督唯一化，却没有为未标定图像创造绝对米制尺度。[↗](https://arxiv.org/pdf/2503.11651#page=6)

## 图内注意力与全局注意力怎样分工

图 2 从 DINO 图像 token 开始读。每张图附加一个 camera token 和四个 register tokens，第一视图使用与其他图不同的可学习 token，指示参考坐标系。随后骨干交替执行 frame-wise self-attention 与 global self-attention。

![VGGT architecture 原论文图](../../assets/images/paper-deep-dives/embodied-ai/vggt/figure-2-architecture.png){ width="920" }

*来源：原论文 Figure 2，VGGT 架构。*

图内注意力只在同一图像内部整合外观与布局，全局注意力把所有视图 token 放在一起，让相同物体或表面在不同视角的信息相互影响。这里没有额外 cross-attention 模块。默认分别包含 24 层图内与全局注意力，合计模型约 1.2B 参数。

骨干输出后，camera tokens 经过四层 self-attention 和线性头输出相机；图像 tokens 经 DPT 变成稠密特征，再回归深度和点图。跟踪分支使用 CoTracker2 结构：从查询图的查询像素双线性采样特征，与其他图的特征形成相关图，再预测对应坐标和可见性。因此 $T_i$ 本身不是轨迹，查询点仍需经过跟踪头才能得到跨图坐标。[↗](https://arxiv.org/pdf/2503.11651#page=5)

## 冗余监督为什么值得保留

总体目标为

$$
\mathcal L=\mathcal L_{camera}+\mathcal L_{depth}+\mathcal L_{pmap}
+\lambda\mathcal L_{track},\qquad \lambda=0.05.
$$

相机使用 Huber 误差；深度和点图使用带置信权重的回归及梯度约束；跟踪对可见点坐标计算误差，并训练二元可见性预测。以深度项为例，论文同时约束 $\hat D-D$ 和 $\nabla\hat D-\nabla D$，预测的权重 $\Sigma^D$ 降低难解释像素的贡献，$-\alpha\log\Sigma^D$ 防止模型把所有权重都压到零。这个机制把不确定区域与清晰几何区域区别对待，但输出置信度仍需结合具体部署分布使用。

理论上点图可反求相机，深度加相机也可反投影为点图；训练上却未必等价。原 Table 6 固定点图任务，移除其他监督观察 ETH3D Overall：

| Training supervision | Overall ↓ |
|---|---:|
| w/o camera | 0.834 |
| w/o depth | 0.727 |
| w/o track | 0.790 |
| All tasks | 0.709 |

相机监督的移除影响最大，深度监督的额外收益较小。结果支持在该模型和数据设置中保留相关任务，而不是证明冗余输出在任何几何网络中都必要。[↗](https://arxiv.org/pdf/2503.11651#page=9)

注意力消融保持参数量、层数和隐藏维度一致。ETH3D Overall 从 cross-attention 的 1.061、仅全局 self-attention 的 0.827，降到交替注意力的 0.709。这更直接地支持局部与全局交替的设计，不应将全部收益都归到模型规模。

## 训练预算与数据覆盖

VGGT 在真实采集、SfM 重建与合成引擎提供的多类几何数据上训练，包含室内、室外、物体和动态场景来源。每个 batch 从场景随机取 2–24 帧，图像最大边为 518，并改变长宽比，加入颜色抖动、模糊和灰度增强。这使模型不能只依赖固定视图数或固定相机布局。

训练使用 AdamW、160K iterations、8K warm-up、峰值学习率 $2\times10^{-4}$，64 张 A100 训练九天；采用 bfloat16、gradient checkpointing 和阈值为 1.0 的梯度范数裁剪。这些是预训练成本，不能由部署时的 0.2 秒推断训练也很便宜。另一方面，训练视图数上限不构成接口上的硬编码上限，测试时可输入更多图像，但全局注意力使内存和计算随 token 数增长。[↗](https://arxiv.org/pdf/2503.11651#page=6)

## 相机估计同时改变了精度与时间

原 Table 1 每个场景随机使用十张图，在单张 H100 上计时。Re10K 是所有列出方法均未用于训练的数据集。

| Method | Re10K AUC@30 ↑ | CO3Dv2 AUC@30 ↑ | Time |
|---|---:|---:|---:|
| DUSt3R | 67.7 | 76.7 | ~7 s |
| MASt3R | 76.4 | 81.8 | ~9 s |
| VGGSfM v2 | 78.9 | 83.4 | ~10 s |
| VGGT Feed-Forward | 85.3 | 88.2 | ~0.2 s |
| VGGT with BA | 93.5 | 91.8 | ~1.8 s |

AUC@30 综合相对旋转和相对平移的角误差。前向模式已经超过表中传统优化组合，BA 又明显提高精度，说明学习预测与几何优化仍有互补性。使用者可根据系统需求选择快速初始化或进一步精化，而无需将两者视为互斥路线。[↗](https://arxiv.org/pdf/2503.11651#page=7)

下面的原图包含绘画、缺少重叠和重复纹理等输入。应看相机与点云是否形成合理结构，再看时间标注。它们说明模型先验能在难匹配条件下补充信息，个别成功样例不保证任意非重叠图像都能唯一恢复真实几何。

![VGGT point map visualization 原论文图](../../assets/images/paper-deep-dives/embodied-ai/vggt/figure-3-pointmap.png){ width="920" }

![VGGT vs DUSt3R 原论文图](../../assets/images/paper-deep-dives/embodied-ai/vggt/figure-4-vggt-dust3r.png){ width="920" }

*来源：原论文 Figures 3–4，点云估计与困难场景对照；本地文件名沿用既有资产命名。*

## 点图头与深度加相机，部署应该选哪条路径

ETH3D 实验对十帧预测点云进行 Umeyama 对齐，并使用官方有效区域掩码。直接点图头的 Accuracy/Completeness/Overall 为 0.901/0.518/0.709；把预测深度与相机组合则为 0.873/0.482/0.677。训练中的点图监督有用，并不意味着推理必须使用直接点图输出。将复杂全局坐标回归分解为深度和相机，能在这里得到更好的结果。

DTU 则区分是否给定真值相机。不知道相机的 DUSt3R Overall 为 1.741，VGGT 为 0.382；已知相机的 GeoMVSNet 为 0.295，MASt3R 为 0.374。VGGT 接近若干享有相机条件的方法，但仍不能据此宣称超越所有 MVS 系统，因为输入信息和算法代价不同。[↗](https://arxiv.org/pdf/2503.11651#page=7)

## 从几何输出到可迁移视觉表示

跟踪分支在 ScanNet-1500 的双视图匹配测试中，以 ALIKED 检测点作为查询，再由对应关系估计相对位姿。AUC@5/10/20 为 33.9/55.2/73.4，对照 Roma 为 31.8/53.4/70.9。这里评估的是匹配对相机估计的贡献，不是动态物体的长期身份保持。

![VGGT tracking 原论文图](../../assets/images/paper-deep-dives/embodied-ai/vggt/figure-5-dynamic-track.png){ width="920" }

*来源：原论文 Figure 5。上半部是 VGGT 对无序静态场景图像的对应；下半部是微调几何骨干后增强动态 CoTracker 的结果，两个设置需要分开理解。*

论文还把骨干微调为新视角合成网络：输入图像 token 与目标视角的 Plücker ray token 合并，再通过 DPT 输出目标 RGB。源图相机参数仍不作为输入。GSO 上 PSNR 为 30.41，而已知源相机的 LVSM 为 31.71；两者训练数据量、输入条件及分辨率不同，结果主要说明几何特征可用作另一个任务的初始化。

VGGT 对实际系统的改变，是提供一个输出丰富、延迟较低的几何起点。相机、深度、对应和置信信息可以接入 SfM、重建或后续表示学习；需要米制距离、长期流式地图或高可靠动态理解时，仍要让相应标定和状态维护模块承担其职责。论文最有力的证据来自同一输入条件下的精度—时间对照，以及明确控制了结构与监督的消融。
