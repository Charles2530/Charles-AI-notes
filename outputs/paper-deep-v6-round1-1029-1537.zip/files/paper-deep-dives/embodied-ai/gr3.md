---
paper_date: 2025-07
paper_title: "GR-3 Technical Report"
paper_topic: 具身智能 / VLA
---

# GR-3：少样本长时程 VLA

!!! info "论文信息"
    **论文题名：** GR-3 Technical Report。<br>
    **作者：** Chilam Cheang、Sijin Chen、Zhongren Cui、Yingdong Hu、Liqun Huang、Tao Kong、Hang Li、Yifeng Li、Yuxiao Liu、Xiao Ma 等（共 21 人）。<br>
    **机构：** ByteDance Seed。<br>
    **时间 / 主题：** 2025-07；具身智能 / VLA。<br>
    **arXiv / 官方报告：** arXiv：[2507.15493](https://arxiv.org/abs/2507.15493)；官方材料：[seed.bytedance.com/en/GR3](https://seed.bytedance.com/en/GR3)。<br>
    **GitHub / 项目：** GitHub：未找到官方链接；项目页：[seed.bytedance.com/en/GR3](https://seed.bytedance.com/en/GR3)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2507.15493)；[官方 / 项目材料](https://seed.bytedance.com/en/GR3)；Checked Date：2026-06-15；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 让机器人按语言行动，而不只重复场景中的常见动作

GR-3 的重点从视频预测转向 VLA 的语言条件控制。一个机器人可能在训练场景中很熟练，却在“把叉子放进垃圾桶”时仍放进惯常的餐具盒；它也可能在目标物体不存在时抓起另一个东西。论文把这类错误看作策略对视觉捷径的依赖，通过模型归一化、视觉语言共同训练和任务状态监督，增强真正的指令约束。[↗](https://arxiv.org/pdf/2507.15493#page=4)

![GR-3 teaser](../../assets/images/paper-deep-dives/embodied-ai/gr3/figure-1-teaser.jpeg){ width="920" }

整体能力展示涵盖新物体拾放、移动双臂清理和衣物晾挂。它们分别检验语义泛化、长任务与语言条件，以及可变形物体的双臂协作，所用指标也不同。

## 4B 模型怎样连接理解与控制

GR-3 使用 Qwen2.5-VL-3B-Instruct 处理多视角观测和语言，动作 Diffusion Transformer 以机器人状态和 VLM 的 KV cache 为条件生成动作块，总规模约 4B。动作块的每一步对应一个 token，与状态 token 拼接；flow 时间通过 AdaLN 注入，动作 DiT 内使用 causal mask 表达时间依赖。

![GR-3 model architecture](../../assets/images/paper-deep-dives/embodied-ai/gr3/figure-3-model-arch.jpg){ width="920" }

Figure 3 中两种数据走向不同的训练目标。机器人轨迹同时更新 VLM 和动作 DiT，视觉语言样本只训练 VLM 的 next-token prediction。动作 DiT 层数是 VLM 的一半，只读取后半段 VLM 层的 KV，以降低重复动作采样的计算。

设当前动作块为 $a_t$，flow 时间为 $\tau$，训练输入为

$$
a_t^\tau=(1-\tau)\epsilon+\tau a_t,\qquad
\epsilon\sim\mathcal N(0,I),\quad \tau\sim U(0,1).
$$

目标速度是 $a_t-\epsilon$，动作损失为

$$
\mathcal L_{\mathrm{action}}=\mathbb E\left[
\|v_\theta(l,o_t,s_t,a_t^\tau)-(a_t-\epsilon)\|^2
\right].
$$

同一次 VLM 前向可复用给多个噪声时间，减少训练成本。执行时从噪声出发，用 Euler 更新

$$
a_t^{\tau+\Delta\tau}=a_t^\tau+
\Delta\tau\,v_\theta(l,o_t,s_t,a_t^\tau),
$$

实验取 $\Delta\tau=0.2$，即五步积分。视觉编码和动作积分承担不同成本，不能把多步动作采样描述成多次完整 VLM 推理。[↗](https://arxiv.org/pdf/2507.15493#page=5)

作者在早期训练中观察到不稳定，于注意力和 FFN 内的线性层后增加 RMSNorm。后续消融表明这一改动也改善语言跟随，说明它不仅是数值工程细节，还影响动作专家利用条件信息的能力。

## 任务状态监督如何打破视觉捷径

额外动作维度记录任务状态，Ongoing 为 0、Terminated 为 1、Invalid 为 −1。训练时随机将原指令替换为当前场景无法完成的指令，例如场景没有刀却要求拿刀。此时只监督 Invalid 状态，其余动作维度不参与监督。

这样，同一视觉输入可以对应有效或无效的任务；忽略语言便无法正确预测状态。它在训练目标中直接制造了必须读取语言的例子，同时避免为无效任务虚构一条运动轨迹。[↗](https://arxiv.org/pdf/2507.15493#page=5)

视觉语言共同训练进一步保留 VLM 的物体、关系与概念知识。数据包含图像描述、VQA、grounding 和交错图文，先过滤和重标注，再与机器人 minibatch 等权混合。总目标由 next-token loss 和 flow-matching loss 相加构成。

![GR-3 data recipe](../../assets/images/paper-deep-dives/embodied-ai/gr3/figure-4-data.jpg){ width="920" }

Figure 4 将机器人轨迹、人类手轨迹和视觉语言数据分开。机器人轨迹教可执行动作，VL 数据维持开放语义，人类轨迹则用于少量样本适配；它们没有共享完全相同的动作标签。

## 拾放实验区分选对目标与真正完成

该任务使用 69 小时、35000 条机器人轨迹、101 种物体，指令基本格式为“put A into B”。测试 Basic 使用 54 种已见物体，每组摆六件；新环境包含收银台、会议室、书桌和休息室；新指令要求大小、相对位置和常识理解；新物体条件使用 45 件物体，其中超过 70% 属于机器人示范中未见类别。

Instruction Following rate 只要求机器人正确接近指令目标，Success rate 还要求将目标放入容器。接近正确物体但抓取失败，会提高前者而不提高后者。

![GR-3 pick-and-place results](../../assets/images/paper-deep-dives/embodied-ai/gr3/figure-7-pick-place-results.jpg){ width="920" }

Figure 7(a) 应先比较新指令、新物体条件下共同训练与不共同训练版本。Basic 和新环境中二者没有明显差别，但在开放语义条件中共同训练收益显著。GR-3 的新指令成功率为 77.1%，π0 为 40%；新物体成功率为 57.8%，π0 为 40%。只用机器人轨迹的 GR-3 在这些泛化条件中甚至弱于 π0，说明继承 VLM 并不自动保证其语义知识在动作训练中得到保留。[↗](https://arxiv.org/pdf/2507.15493#page=10)

少量人类示范进一步适配这 45 个新物体。PICO 4 Ultra Enterprise 采集第一视角视频与手轨迹，最多每物体 10 段，共 450 段、约 30 分钟录制时长；追加训练 20K 步，同时继续混合原机器人与 VL 数据。缺少的腕部视图填空白图，不存在的关节和夹爪不监督。

新物体成功率从 57.8% 提升到每物体十段人类示范条件的 86.7%，已见物体没有明显退化。这里的少样本迁移以已经接受机器人训练的模型为起点，且使用手部运动标签，不能将其描述为只看无标注网络视频就学会新物体操作。

## 餐桌清理最能暴露指令是否被忽略

清理任务需把食物装盒、餐具收进周转箱、垃圾扔进垃圾桶，并移动底盘覆盖工作区域，数据约 101 小时。作者分别训练 Flat 和 Instruction Following 两个版本。Flat 输入“清理餐桌”，用完成子任务比例衡量长流程；IF 每次给一个子任务、机器人从 home position 出发，用子任务成功率评价。

![GR-3 table bussing](../../assets/images/paper-deep-dives/embodied-ai/gr3/figure-8-table-bussing.jpg){ width="920" }

IF 测试包含多实例、多容器、新物体—容器组合，以及无效指令。Invalid 条件要求机器人在 10 秒内不操作任何物体，才算正确拒绝。这与普通成功率中“没有动作就是失败”恰好不同，评测显式检查了当前语言的可执行性。

GR-3 的 IF 成功率为 97.5%，π0 为 53.8%。π0 在新目标容器条件中会沿训练关联把东西放回习惯位置；去掉 RMSNorm 或 task status 都使 GR-3 的 IF 表现下降。该组证据把两个设计与语言跟随联系起来，但 **97.5% 是 IF 子任务成功率，不能当作整桌连续清理完全成功率**。[↗](https://arxiv.org/pdf/2507.15493#page=12)

## 衣物晾挂测试双臂协调的实际瓶颈

衣物任务使用约 116 小时轨迹，要求拿衣架、把衣物套好，再转动底盘挂到晾衣架。Basic 测六件已见衣物，Position 改变旋转与褶皱，Unseen Instances 测四件新衣物，其中两件为训练中未见的短袖。

![GR-3 cloth manipulation](../../assets/images/paper-deep-dives/embodied-ai/gr3/figure-10-cloth-results.jpg){ width="920" }

图中的 Sankey 应按四个里程碑读：拿起衣架、套右肩、套左肩、挂上晾衣架。GR-3 的平均进度在 Basic/Position/Unseen 为 86.7%/83.9%/75.8%，它们都是部分进度评分。最困难的是右肩套好之后取出藏在衣架后方的左领口，同时保持衣架不滑落；失败集中在接触几何与双臂协作，而非单纯识别衣服。[↗](https://arxiv.org/pdf/2507.15493#page=13)

![ByteMini robot](../../assets/images/paper-deep-dives/embodied-ai/gr3/figure-5-bytemini.jpg){ width="920" }

ByteMini 是 22 自由度移动双臂机器人，部署策略控制其中 19 个自由度，不包含升降与头部的三个自由度。动作轨迹还经过 pure pursuit 与轨迹优化，以降低 jerk、平滑块间衔接。因此复杂任务表现来自策略与控制系统共同作用。

GR-3 给出的直接经验是，语言跟随必须在动作训练中有可检验的约束。用同一场景中的不同指令、无效目标和新目标容器测试策略，比只看标准拾放成功率更容易发现语义退化。人类轨迹少样本适配又表明，保留下来的语义知识与可观测手部运动可以共同帮助新对象操作，但失败恢复和未见形状抓取仍未被这些结果彻底解决。
