---
paper_date: 2025-09
paper_title: "MapAnything: Universal Feed-Forward Metric 3D Reconstruction"
paper_topic: 具身智能
---

# MapAnything：统一前向 Metric 3D 重建骨干

!!! info "论文信息"
    **论文题名：** MapAnything: Universal Feed-Forward Metric 3D Reconstruction。<br>
    **作者：** Nikhil Keetha、Norman Müller、Johannes Schönberger、Lorenzo Porzi、Yuchen Zhang、Tobias Fischer、Arno Knapitsch、Duncan Zauss、Ethan Weber、Nelson Antunes 等（共 17 人）。<br>
    **机构：** Meta Reality Labs、Carnegie Mellon University。<br>
    **时间 / 主题：** 2025-09；具身智能。<br>
    **arXiv / 官方报告：** arXiv：[2509.13414](https://arxiv.org/abs/2509.13414)；官方材料：[map-anything.github.io/](https://map-anything.github.io/)。<br>
    **GitHub / 项目：** GitHub：[github.com/facebookresearch/map-anything](https://github.com/facebookresearch/map-anything)；项目页：[map-anything.github.io/](https://map-anything.github.io/)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2509.13414)；[GitHub API / repo](https://github.com/facebookresearch/map-anything)；[官方 / 项目材料](https://map-anything.github.io/)；Checked Date：2026-06-15；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 一个模型接收不同完整度的几何信息

MapAnything 面向的是输入条件不统一的三维重建。某些图像只有 RGB，另一些有标定、位姿或稀疏深度；已有信息可能带米制尺度，也可能只知道相对关系。论文将这些条件拆解编码，再用同一个多视图网络预测射线、沿射线深度、相机位姿和全局尺度，覆盖未标定重建、深度补全、相机标定等任务。[↗](https://arxiv.org/pdf/2509.13414#page=4)

![MapAnything overview 原论文图](../../assets/images/paper-deep-dives/embodied-ai/mapanything/figure-1-overview.png){ width="920" }

*来源：原论文 Figure 1。应先辨认每种任务有哪些输入条件，再比较输出；不同条件下的结果不能直接视作相同难度。*

相对只接收 RGB 的网络，这个接口允许应用把已有传感和标定结果交给模型。相对每种输入各训一个专家，它尝试让不同任务共享几何表示与训练。关键是把尺度与形状分开，避免一个巨大场景的米制坐标直接改变全部回归量的范围。

## 射线、深度、位姿与尺度如何重新组合

对视图 $i$，网络输出单位射线 $R_i$、无尺度 ray depth $\tilde D_i$、旋转 $O_i$、平移 $\tilde T_i$，以及所有视图共享的米制尺度 $m$。重建按以下顺序计算：

$$
\tilde L_i=R_i\tilde D_i,\qquad
\tilde X_i=O_i\tilde L_i+\tilde T_i,\qquad
X_i^{metric}=m\tilde X_i.
$$

$\tilde L_i$ 在局部相机坐标系，$\tilde X_i$ 在第一视图参考系。这里射线是单位向量，所以 ray depth 表示沿射线的距离，与普通 z-depth 不同。该射线表示也让中心投影相机不局限于单一焦距、中心主点的针孔参数化。[↗](https://arxiv.org/pdf/2509.13414#page=4)

图 2 从各模态编码器读到共同 token。图像使用 DINOv2 ViT-G 第 24 层特征；稠密射线与深度通过浅卷积编码；旋转、归一化平移和尺度通过 MLP 编码，广播后相加。第一视图加参考标记，整组视图再加入一个 scale token。

![MapAnything architecture 原论文图](../../assets/images/paper-deep-dives/embodied-ai/mapanything/figure-2-architecture.png){ width="920" }

*来源：原论文 Figure 2。scale token 独立预测场景尺度，DPT 负责各视图局部稠密量，pose head 负责共享参考系下的位姿。*

深度输入先除以本视图平均深度，平移输入除以所有可用平移的平均范数。只有确认具有米制单位时，模型才额外使用相应尺度值，并先取对数再编码。这样既能接收米制 RGB-D，也能接收只确定相对尺度的重建结果；只提供旋转或只提供平移也有独立入口。

多视图融合采用 16 层交替注意力 Transformer，隐藏维度 1536、24 heads，使用 DINOv2-G 后 16 层初始化。输出只需要一个 DPT 头来预测射线、深度、有效类别 mask 与置信度，pose head 预测旋转和平移，scale token 经 MLP 和指数变换输出正尺度。

## 监督如何避免尺度误差拖累几何

旋转损失取 $\min(\|\hat Q-Q\|,\|-\hat Q-Q\|)$，处理四元数 $Q$ 与 $-Q$ 表示同一旋转的问题。几何误差先用预测与真值各自的点云范数归一化，再在 log-space 中比较，以减轻远距离点的数值支配。

论文定义向量变换

$$
f_{log}(x)=\frac{x}{\|x\|}\log(1+\|x\|).
$$

它压缩模长并保留方向。米制尺度监督使用 $z_{metric}=m\operatorname{sg}(\tilde z)$，其中 $\operatorname{sg}$ 表示停止梯度。尺度分支因此调整 $m$，不会为了修正单位而直接扭曲无尺度形状。总目标为

$$
\mathcal L=10\mathcal L_{pointmap}+\mathcal L_{rays}+\mathcal L_{rot}
+\mathcal L_{translation}+\mathcal L_{depth}+\mathcal L_{lpm}
+\mathcal L_{scale}+\mathcal L_{normal}+\mathcal L_{GM}+0.1\mathcal L_{mask}.
$$

点图项负责跨视图整体一致性，局部深度与射线项维持分解的几何意义。法向和梯度损失仅用于合成数据，避免真实粗糙标签把错误细节写进模型；逐像素回归还排除最高损失的 5% 以减轻异常值。[↗](https://arxiv.org/pdf/2509.13414#page=5)

## 同一训练过程怎样覆盖不同任务

模型以 0.9 概率启用额外几何输入，射线、深度和位姿各自以 0.5 概率选择。深度被选中时，一半提供稠密图，一半随机移除 90% 点；各视图也可以缺失条件。输入米制尺度还会被随机隐藏。不同任务因此表现为同一输入空间中的不同缺失模式，而无需为每个组合新增网络。

训练包含 13 个数据集，采样时使用深度和位姿预计算共视关系，以 25% 共视阈值进行随机游走，获得覆盖变化的连通视图集合。主多视图评测同样要求输入形成连通分量，这一条件影响其对完全不相交图像的适用判断。项目还发布两个不同数据配方和许可的模型，Apache 2.0 与 CC BY-NC 4.0 版本应分开选择。

## 额外输入带来的收益有多大

下表来自原 Table 2，使用 ETH3D、ScanNet++ v2、TartanAirV2-WB 的双视图平均值；Points rel、Depth rel 越低越好，Pose AUC@5 越高越好。

| Method / Inputs | Scale rel ↓ | Points rel ↓ | Pose AUC ↑ | Depth rel ↓ |
|---|---:|---:|---:|---:|
| VGGT / Images | — | 0.20 | 34.2 | 0.13 |
| MapAnything / Images | 0.13 | 0.08 | 56.0 | 0.07 |
| MapAnything / Images + Intrinsics | 0.13 | 0.07 | 64.7 | 0.06 |
| MapAnything / Images + Intrinsics + Poses | 0.05 | 0.06 | 93.6 | 0.06 |
| MapAnything / Images + Intrinsics + Poses + Depth | 0.01 | 0.02 | 94.8 | 0.02 |

只给图像时，尺度主要靠学习先验，Scale rel 为 0.13；提供米制位姿后下降为 0.05，加入深度后到 0.01。这说明把已知物理信息接入网络具有实际价值。不过完整输入下，Pow3R 的 Points inlier ratio 为 90.1，MapAnything 为 82.0，即使平均相对误差更小，也不代表所有阈值指标都更好。[↗](https://arxiv.org/pdf/2509.13414#page=7)

![MapAnything multi-view results 原论文图](../../assets/images/paper-deep-dives/embodied-ai/mapanything/figure-4-multiview-results.png){ width="920" }

*来源：原论文 Figure 4。横轴为 2–100 个视图，先在同一输入条件下比较曲线，再看增加标定、位姿和稀疏深度的收益；未画出的基线点包含显存不足情况。*

![MapAnything auxiliary inputs 原论文图](../../assets/images/paper-deep-dives/embodied-ai/mapanything/figure-s5-auxiliary-inputs.png){ width="920" }

*来源：原论文 Figure S.5。上方看重复结构能否合并，中间比较 10 m 标尺，下面观察稀疏深度补全。它把“更准确”的收益具体分为几何对齐与米制尺度。*

表示消融使用 50 视图平均结果。仅 Local Pointmap+Pose 的 Points rel 为 0.32、inlier ratio 为 33.2；完整 Rays/Depth/Pose+Scale 为 0.28、40.7。统一训练与专家训练对比也显示，Images-only 的 Points rel 为 0.28 对 0.29，而 inlier ratio 为 40.7 对 31.8；但在有米制位姿的设置，统一模型的 Scale rel 0.05 不如专家的 0.03。统一化换来了广泛接口，某些特定指标仍可能由专家更好地优化。[↗](https://arxiv.org/pdf/2509.13414#page=8)

## 实际采用时，米制预测与可验证尺度要分开

纯图像的米制尺度来自先验，无法消除单目投影本身的尺度歧义。Robust-MVD 结果对此很有说明力：不提供相机信息的多视图 MapAnything 在 KITTI 的 rel 为 5.45，ScanNet 为 22.23；提供内参与位姿后分别为 4.63 和 5.58。不同场景的尺度可靠性差别很大，不能因输出字段写着 metric 就直接用来设安全距离。

![MapAnything qualitative comparison 原论文图](../../assets/images/paper-deep-dives/embodied-ai/mapanything/figure-3-qualitative-vggt.png){ width="920" }

*来源：原论文 Figure 3。两种方法采用相同法向边缘后处理及天空掩码，比较弱纹理、季节变化、大尺度场景下的结构。*

![MapAnything speed memory 原论文图](../../assets/images/paper-deep-dives/embodied-ai/mapanything/figure-s1-speed-memory.png){ width="920" }

*来源：原论文补充材料 Figure S.1。视图数增加时需同时看时间与显存，单次前向仍要处理每个输入像素及其多视图交互。*

适合采用 MapAnything 的场景，是已有部分标定或深度、又希望统一处理不完整条件的重建系统。接口并未显式建模输入条件的不确定性，因此错误位姿或错误单位会作为条件传入；接入前应先校准这些信息。论文当前表示也不描述 scene flow 或动态对应，动态物体需要额外处理。最值得复用的是尺度分解与随机缺失条件训练，这让一个网络能在已有几何线索增加时自然提高精度。
