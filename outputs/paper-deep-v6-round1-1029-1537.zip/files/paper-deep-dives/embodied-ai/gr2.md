---
title: GR-2：Web 视频知识怎样迁移到机器人操作
paper_date: 2024-10
paper_title: "GR-2: A Generative Video-Language-Action Model with Web-Scale Knowledge for Robot Manipulation"
paper_topic: 具身智能 / VLA
---

# GR-2：Web 视频知识怎样迁移到机器人操作

!!! info "论文信息"
    **论文题名：** GR-2: A Generative Video-Language-Action Model with Web-Scale Knowledge for Robot Manipulation。<br>
    **作者：** Chi-Lam Cheang、Guangzeng Chen、Ya Jing、Tao Kong、Hang Li、Yifeng Li、Yuxiao Liu、Hongtao Wu、Jiafeng Xu、Yichu Yang 等（共 12 人）。<br>
    **机构：** ByteDance Research。<br>
    **时间 / 主题：** 2024-10；具身智能。<br>
    **arXiv / 官方报告：** arXiv：[2410.06158](https://arxiv.org/abs/2410.06158)；官方材料：[gr2-manipulation.github.io/](https://gr2-manipulation.github.io/)。<br>
    **GitHub / 项目：** GitHub：[github.com/mees/calvin](https://github.com/mees/calvin)；项目页：[gr2-manipulation.github.io/](https://gr2-manipulation.github.io/)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2410.06158)；[GitHub API / repo](https://github.com/mees/calvin)；[官方 / 项目材料](https://gr2-manipulation.github.io/)；Checked Date：2026-06-15；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 将视频生成预训练扩大到 3800 万段

GR-2 延续通过预测未来视频学习机器人策略的路线，把预训练视频由 GR-1 的约 80 万段扩到 3800 万段，约 500 亿 token，再用机器人示范学习同时输出未来画面和动作轨迹。它检验的核心问题是，视频动态预训练在扩大数据与模型后，能否改善多任务操作、环境迁移和未见物体抓取。[↗](https://arxiv.org/pdf/2410.06158#page=3)

![GR-2 overview](../../assets/images/paper-deep-dives/embodied-ai/gr2/figure-1-overview.png){ width="720" }

整体图中有两个不同的生成接口。图像以离散视觉 token 建模，动作使用连续轨迹生成；二者在语言和观测历史条件下共同训练。最后还需要轨迹优化与控制器把模型的笛卡尔路径转成真实关节运动。

## 离散未来图像与连续动作轨迹

策略的输入是语言 $l$、最近 $h$ 步观测 $o_{t-h:t}$ 和状态 $s_{t-h:t}$，输出未来 $k$ 步动作。

$$
a_{t:t+k}=\pi(l,o_{t-h:t},s_{t-h:t}).
$$

机器人微调阶段同时要求预测下一视觉状态。

$$
\pi(l,o_{t-h:t},s_{t-h:t})\longrightarrow o_{t+1},a_{t:t+k}.
$$

文本编码器冻结，图像由 VQGAN 编成离散 token，再交给 GPT 风格 Transformer 预测未来图像 token，最后经 VQGAN 解码成画面。VQGAN 在互联网和域内机器人图像上训练后固定。机器人状态包含末端位置、旋转与夹爪状态，经可训练线性层编码。机器人数据可以有多视角，而预训练视频通常只有单视角，模型相应接入每个视角的观测和未来图像。[↗](https://arxiv.org/pdf/2410.06158#page=3)

动作轨迹由 conditional VAE 生成。这里使用整段轨迹有两个目的：连续动作更易保持平滑，也可在两次大模型推理之间持续执行。默认 GR-2 总规模约 230M，报告的可训练参数为 95M；不能把这两个数都称为模型总参数。

真实系统使用 Kinova Gen3 机械臂、Robotiq 2F-85 夹爪，以及头部和腕部相机。模型给出的笛卡尔轨迹先被优化以改善连续性，再由 whole-body control 转为关节动作，并在优化中考虑碰撞与可操作性。**200 Hz 是底层关节执行频率**，原文没有将它报告为大模型每秒完成 200 次完整策略推理。[↗](https://arxiv.org/pdf/2410.06158#page=4)

## 数据扩大之前，先筛选与重标注

![GR-2 data and model](../../assets/images/paper-deep-dives/embodied-ai/gr2/figure-2-pretraining-data.png){ width="720" }

Figure 2 展示了视频来源和动词分布。HowTo100M 占据很大比例，Ego4D、Something-Something V2、EPIC-KITCHENS、Kinetics-700 补充其他活动视角，同时加入 RT-1 和 Bridge 机器人视频。动词频次使用对数轴，不能把柱高差当作线性数量差。

为了让互联网视频更贴近操作，处理流程进行手部过滤和重新生成描述。视频多并不自动意味着动作监督多，人类视频在这里主要训练语言条件下的未来画面预测，机器人动作的物理含义仍通过后续示范学习。

真实多任务微调收集 105 个桌面任务、约 40000 条轨迹，平均每任务约 400 条，覆盖抓取、放置、开盖、盖盖、打开、关闭、按压和倾倒。数据稀缺实验再将其减到约八分之一，即每任务约 50 条。[↗](https://arxiv.org/pdf/2410.06158#page=5)

![GR-2 tabletop tasks](../../assets/images/paper-deep-dives/embodied-ai/gr2/figure-4-tasks.png){ width="760" }

任务图展示的是同一组基本技能在不同物体与位置上的组合。理解“超过 100 个任务”时，应保留八类技能这一粒度，避免将其理解为超过 100 种完全独立的运动能力。

## 多任务熟练度与环境泛化分开看

评测包含 Simple、Distractor，以及 Unseen Backgrounds、Unseen Environments、Unseen Manipulation。Simple 接近训练环境，Distractor 增加干扰物；背景泛化使用新桌布，环境泛化进入两个新厨房；未见操作包含新物体实例与新类别，部分语言指令也相应变化。

![GR-2 multitask results](../../assets/images/paper-deep-dives/embodied-ai/gr2/figure-6-multitask-results.png){ width="920" }

Figure 6 的模型标签 400/50 指每任务示范数量，w/ DA 指合成数据增强。先在同一测试条件内比较模型，再看一个模型跨条件怎样下降，可以区分学习不足与泛化问题。

| GR-2 Setting | Success Rate (%) |
|---|---:|
| Full data, Simple | 97.7 |
| Full data, Unseen Backgrounds | 71.4 |
| Full data, Unseen Environments | 71.7 |
| Full data, Unseen Manipulation | 55.8 |
| About 50 demos/task, Simple | 73.9 |
| With Data Augmentation, Unseen Environments | 87.0 |
| With Data Augmentation, Mean of Three Generalization Settings | 74.7 |

最容易的已见条件已接近饱和，但未见物体操作仍只有 55.8%。原文列出的常见失败是抓不住新形状，以及在未见物体指令下选错目标；这分别涉及动作适配和语义辨认，不能用单一的“模型不知道物理”解释。[↗](https://arxiv.org/pdf/2410.06158#page=7)

数据增强并非简单颜色抖动。作者训练扩散模型插入指定物体，用 SAM 定位背景进行替换，再用视频模型将编辑传播到整段视频，并保留机器人运动。新环境成功率从 71.7% 到 87.0%，表明在不重新采集动作的情况下拓展视觉覆盖是有效补充；这一结果包含额外生成式增强管线的成本。

## 工业分拣检查未见对象与拥挤程度

第二组真实实验将物体从一个篮子搬到另一个篮子，指令固定为从右篮移动任意物体到左篮。训练使用约 94000 条拾放轨迹、55 种物体；评测共 122 种物体，其中 67 种未在训练出现。

![GR-2 bin picking setup](../../assets/images/paper-deep-dives/embodied-ai/gr2/figure-7-bin-picking-setup.png){ width="760" }

Figure 7 将物体是否见过与场景是否拥挤交叉组合。普通条件初始为 5–9 件物体，拥挤条件为 12–17 件，约是原场景两倍。即使物体全部见过，Cluttered Seen 仍测试了新的场景密度，而不仅是训练分布复现。

四种条件的平均成功率由 GR-1 的 33.3% 提升至 GR-2 的 79.0%，GR-2 在未见对象与拥挤条件中的表现接近其 seen 条件。透明、可变形和反光物体的示例说明端到端视觉策略可处理某些传统几何管线困难的对象，但这里只报告规定分拣环境中的任务表现，不能据此推断工业生产中的长期故障率。[↗](https://arxiv.org/pdf/2410.06158#page=8)

## CALVIN 的高分对应 ABCD→D 协议

仿真实验采用 **ABCD→D**，训练包含 D 域数据，评测 1000 条五任务指令链。该协议与训练 ABC、测试未见 D 的 ABC→D 不同，跨论文比较必须先统一这一条件。

![GR-2 CALVIN results](../../assets/images/paper-deep-dives/embodied-ai/gr2/figure-10-calvin-results.png){ width="920" }

| Method | One-Task Success (%) | Five-Task Success (%) | Average Length |
|---|---:|---:|---:|
| GR-1 | 94.9 | 73.1 | 4.21 |
| GR-2 | 98.6 | 85.9 | 4.64 |

单任务从 94.9% 到 98.6% 的改善，在连续任务上放大为五任务全部完成率提高 12.8 个百分点。这个指标更能反映链式操作中每个局部错误带来的累计影响，但它仍不是未见环境泛化结果。[↗](https://arxiv.org/pdf/2410.06158#page=8)

## 规模实验与可解释的视觉预期

论文另训练 30M、95M、312M、719M 可训练参数的 S/B/L/XL 版本，视频验证损失随规模增加下降，真实任务子集成功率也随之改善。该组实验将域内机器人视频纳入视频预训练，并在动作微调时固定预训练参数；这个冻结设置属于规模实验的具体协议，不能随意扩大为所有主实验的统一训练方式。[↗](https://arxiv.org/pdf/2410.06158#page=10)

生成视频与真实 rollout 的并排展示提供了策略预期的可观察表达。画面与动作一致时，可以看到模型在向哪种未来状态推进；二者偏离时，则有机会定位预测动态与执行之间的差距。不过，相关的可视化没有直接证明“只提高视频质量就一定提高控制成功率”。

GR-2 的系统经验是将大规模视觉动态学习、动作轨迹生成和高频底层控制明确分层。视频数据负责扩大对交互场景的覆盖，机器人示范负责动作落地，控制器负责平滑执行与约束；97.7% 的已见任务成功率和 55.8% 的未见操作结果，也清楚展示了这条路线已经做强的环节与仍然困难的迁移边界。
