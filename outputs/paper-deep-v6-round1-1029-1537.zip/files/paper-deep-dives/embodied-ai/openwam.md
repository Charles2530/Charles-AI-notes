---
paper_date: 2026-09
paper_title: "OpenWAM: An Open, Modular Exploration Towards Systematic World–Action Model Pretraining"
paper_topic: 具身智能 / World–Action Model
---

# OpenWAM：把 World–Action Model 变成可控的研究程序

!!! info "论文信息"
    **论文题名：** OpenWAM: An Open, Modular Exploration Towards Systematic World–Action Model Pretraining。<br>
    **作者：** Yuran Wang、Siqiao Huang、Mingleyang Li、Chenhao Zhang、Jiaqi Liang、Weiyang Jin、Yue Chen、Xuemin Chi、Donghao Zhou、Qize Yu、Yu-Kai Wang、Yuhan Rui、Shenzhe Yao、Zhen Yuan、Zhenhao Shen、Kefei Zhu、Zijie Zhu、Ning Gao、Xiaowei Chi、Guanqi He、Shanghang Zhang、Hao Dong、Lin Shao、Hang Zhao。<br>
    **机构：** National University of Singapore、Tsinghua University、Peking University、The University of Hong Kong、Zhejiang University、The Chinese University of Hong Kong、Shanghai Jiao Tong University。<br>
    **时间 / 主题：** 2026-09；具身智能 / World–Action Model / 视频生成先验。<br>
    **arXiv / 项目页：** [arXiv:2609.07398](https://arxiv.org/abs/2609.07398)；[OpenWAM 官方项目页](https://openwam-official.github.io/)。<br>
    **代码 / 模型与数据：** [GitHub](https://github.com/OpenWAM-Official/OpenWAM)；[Hugging Face OpenWAM](https://huggingface.co/OpenWAM)；[XPolicyLab OpenWAM policy](https://github.com/XPolicyLab/XPolicyLab/tree/main/policy/OpenWAM)。<br>
    **元数据来源与核验口径：** 来源为 arXiv、官方项目页、官方代码仓库及论文 TeX source；Checked Date：2026-09-11；Repro Status：Paper / official project / code / model page reviewed, independent reproduction not claimed。

## 把 world–action model 的设计拆成可比较的选择

OpenWAM 同时包含研究基础设施、受控实验和一个预训练模型。OpenWAM-Infra 将视觉编码器、视频与动作骨干、跨模态注意力掩码拆成可组合模块；OpenWAM-Study 在共同训练和评测接口上检验这些选择；OpenWAM-α 再把选出的配方扩展到 6369 小时混合数据。理解这三个层次，才能区分受控证据与最终模型的整体能力。[↗](https://arxiv.org/pdf/2609.07398#page=3)

![OpenWAM 总体结构](../../assets/images/paper-deep-dives/embodied-ai/openwam/overview.png){ width="960" }

总览图的重点是共用实验底座。以往 WAM 的骨干、动作头、数据和评测预处理常一起变化，即使成功率不同，也很难知道收益来自哪里。OpenWAM 把这种系统差异显式化，并让模型训练、部署与八个仿真 benchmark 使用相同样本和控制契约。

## 模型接口决定哪些变量可以单独改变

论文将一个配置记为 $C(E,S,M)$。$E$ 是冻结视觉编码器，可以是 Wan/FLUX VAE，也可以是 DINOv3、V-JEPA 2.1 一类表示编码器；$S$ 是视频、动作及可选理解骨干；$M$ 定义各 token 之间的可见性。骨干暴露输入准备、逐层处理和输出还原接口，组合逻辑本身不引入学习参数。

![OpenWAM-Infra 模块化模型](../../assets/images/paper-deep-dives/embodied-ai/openwam/infra-model-1.png){ width="960" }

沿图中的模块边界看，Single-System 让视频和动作更多共享参数；Dual-System 给动作独立容量，再通过 joint self-attention、cross-attention 或 IDM 接口连接；Tri-System 加入只读理解流。视觉 token 的当前帧与未来帧还可采用不同掩码，避免当前观测被未来噪声反向影响。[↗](https://arxiv.org/pdf/2609.07398#page=5)

统一样本为 $(\ell,o_{1:T},a_{1:H},q,m)$，分别包含语言、视频窗口、动作块、本体状态和有效动作维度掩码。设 $z$ 为视频 latent，噪声时间满足 $t=0$ 为噪声、$t=1$ 为干净数据，输入为

$$
z_{t_v}=t_vz+(1-t_v)\epsilon_v,\qquad
 a_{t_a}=t_aa+(1-t_a)\epsilon_a.
$$

训练的联合 flow-matching 目标为

$$
\mathcal L=\lambda_v\mathbb E\!\left[w(t_v)\|\hat v_z-(z-\epsilon_v)\|_2^2\right]
+\lambda_a\mathbb E\!\left[w(t_a)\|m\odot(\hat v_a-(a-\epsilon_a))\|_2^2\right].
$$

视频和动作时间独立采样，覆盖二维噪声平面；当前干净帧不计入视频预测损失，$m$ 只让实际存在的动作维度获得监督。这让不同机器人和无动作标签视频共用训练器，同时保留清楚的监督边界。[↗](https://arxiv.org/pdf/2609.07398#page=8)

## 从哪里继承世界知识

第一组实验比较不同视频骨干。Wan 1.3B、Cosmos 2B、Wan 5B 和 Wan 14B 的结果整体随骨干能力提高而改善，14B 最好，但 5B 仅低 1.40 个百分点，因而成为后续默认设置。这些模型的架构、数据和目标也不同，不能把差距全部解释为参数规模的纯效应。

另一组实验固定 Wan2.2-5B 的网络结构并随机初始化其权重，只改变视觉 latent，尽量隔离编码器的影响。没有压缩时，DINOv3 与 V-JEPA 2.1 的高维特征分别得到 76.42% 和 80.91%；加上 S-VAE 压至 48 维后分别达到 90.18% 和 88.46%。Wan2.2-VAE 为 90.30%，FLUX.2-VAE 为 84.26%。所有非视频编码器都通过四帧平均施加相同时间降采样。[↗](https://arxiv.org/pdf/2609.07398#page=12)

这个实验说明表示型编码器也能成为强 WAM 的视觉空间，前提是其维度和时间结构适合后续 DiT。直接将高维语义特征替换像素 VAE，会同时改变优化难度与 token 结构，因此“语义特征效果差”不是充分结论。

## 世界信息应该怎样流向动作

RoboTwin2.0-Full 上，架构消融保留 clean 与 randomized 条件的平均成功率。

| Architecture | Average Success (%) |
|---|---:|
| Single-System Vanilla | 85.50 |
| Single-System MoE | 84.63 |
| Dual-System Joint Self-Attention | 92.36 |
| Dual-System Joint Cross-Attention | 88.25 |
| Dual-System Detached Cross-Attention | 91.85 |
| Dual-System IDM | 87.95 |
| Tri-System Joint Self-Attention | 92.60 |

动作独立容量带来明显改善，Tri-System 又比最强 Dual-System 高 0.24 个百分点。后续研究采用 Dual joint self-attention，以控制复杂度并排除额外 VLM 理解特征的影响。普通 cross-attention 与 detached 版本相差 3.60 个百分点，也说明跨分支梯度路径本身就是设计变量。[↗](https://arxiv.org/pdf/2609.07398#page=13)

![训练时的信息流消融](../../assets/images/paper-deep-dives/embodied-ai/openwam/training-information-flow-1.png){ width="760" }

接着固定架构，只改变四种可见性。Isolated 为 87.41%，Video Sees Action 为 87.63%，Action Sees Video 为 92.39%，Mutual 为 92.15%。分界线是动作能否读取世界流，而非视频能否读取动作。这是该训练设置下世界到动作信息流有效的直接证据。

推理时还有一种更软的信息控制，即让一条去噪流先变清晰。论文用

$$
f_\alpha(s)=\frac{\alpha s}{1+(\alpha-1)s},\qquad
 h_o(s)=\max\!\left\{\frac{s-o}{1-o},0\right\}
$$

构造领先流的时间变换和落后流的延迟，$s=i/N$ 是全局采样进度。$\alpha=1,o=0$ 恢复同步对角线。由于训练覆盖独立的 $t_v,t_a$，这些路径不需要另训模型。

![推理时的去噪路径](../../assets/images/paper-deep-dives/embodied-ai/openwam/denoising-schedules-1.png){ width="760" }

图中应比较完整路径与最终成功率，而非假设“先想清画面再行动”必然更好。同步达到约 93.0%，测试的 video-lead 和 action-lead 路径都未超过它；两种参数化下，谁领先更好还会反转。因此本实验支持同步联合去噪，未支持显式的先规划后逆动力学顺序。[↗](https://arxiv.org/pdf/2609.07398#page=14)

## 600 小时预训练主要改善分布外测试

受控迁移实验固定骨干、预算和下游过程，只改变具身预训练数据。Robot-only 使用 600 小时机器人数据；混合方案用 350 小时 EgoDex 加 250 小时 RoboCOIN，分别比较先人类后机器人、单阶段共同训练。下游仅在 clean 数据微调，再分别测 clean 和 randomized。

| Pretraining | Clean / ID (%) | Randomized / OOD (%) |
|---|---:|---:|
| From Scratch | 87.00 | 14.50 |
| Robot Only | 88.50 | 23.80 |
| Ego → Robot | 87.10 | 26.50 |
| Ego + Robot | 87.68 | 26.62 |

ID 增益仅 0.10–1.50 个百分点，OOD 增益为 9.30–12.12 个百分点。混入人类视频的主要价值出现在泛化，顺序训练和共同训练则很接近，作者据此采用较简单的单阶段混合方案。[↗](https://arxiv.org/pdf/2609.07398#page=15)

预训练还改变了注意力选择。没有具身预训练时，Mutual 比单向 Action Sees Video 低 0.24 个百分点；预训练后在 Full、Clean2Random 的 ID/OOD 条件分别高 0.16、0.70、0.72 个百分点。方向一致但差值很小，适合解释为最终配方的选择依据，不宜写成双向交互获得了压倒性优势。

## OpenWAM-α 怎样把配方做大

最终模型使用冻结 Wan2.2-VAE、5B 视频 DiT 与 1B ActionDiT。两路共 30 层桥接注意力，视频宽度 3072、动作宽度 1024，通过 24 个 128 维注意力头对接；文本和本体状态进入各自 cross-attention。当前帧只读自身，未来视频与动作互相可见。

![OpenWAM-α 架构与训练配方](../../assets/images/paper-deep-dives/embodied-ai/openwam/architecture.png){ width="960" }

统一控制空间为 80 维：左右臂各 34 维，分别包含位置 3、旋转 6、夹爪 1、灵巧手 24，再留 12 维给移动底盘等本体通道。不同数据按固定物理语义映射到槽位，而非仅在尾部补零。

$$
u=\operatorname{Scatter}_\pi(\operatorname{Norm}(a)),\qquad
 a=\operatorname{Norm}^{-1}(\operatorname{Gather}_\pi(u)).
$$

有效掩码决定哪些槽位训练，反变换确保执行端拿到真实单位。checkpoint 同时保存权重、完整配置、tokenizer 与归一化统计；部署缺统计会报错，resume 遇到统计变化会拒绝继续。这样避免了权重相同却因动作尺度变化而产生完全不同控制行为的问题。[↗](https://arxiv.org/pdf/2609.07398#page=10)

预训练使用 518.5M 帧、6369 小时数据，覆盖 21 种机器人及人类视频。按实际帧数采样，人类视频约占 30.1%、合成机器人 30.0%，其余为 AgiBotWorld-Beta、RoboCOIN 和 DROID。人类视频的动作和状态通道全遮蔽，只监督世界流。清洗先剔除异常视频，再检查动作—状态跟踪、视频与信号对齐及静止段；只裁首尾 idle，不裁轨迹中间暂停，以免拼接出不相邻的物理时刻。[↗](https://arxiv.org/pdf/2609.07398#page=19)

训练在 128 张 H200 上约七天，全局 batch 3072，155862 步约一 epoch。模型采用独立噪声时间、相同 shift 5；执行使用 10 步同步去噪。编译、CUDA graphs、速度缓存、提示词缓存和省略 VAE 解码后，RTX 5090 上约 170 ms 生成一个动作块。所有报告评测都使用同步执行，动作缓存耗尽时等待新推理；基础设施支持的异步动作缓冲没有用于这些主结果。[↗](https://arxiv.org/pdf/2609.07398#page=18) [↗](https://arxiv.org/pdf/2609.07398#page=34)

## 高平均分与特定扰动下的失败并存

![仿真 benchmark 对比](../../assets/images/paper-deep-dives/embodied-ai/openwam/benchmark-grid-1.png){ width="960" }

仿真结果包含不同本体和不同任务接口，不能把所有百分数当作同一种能力。OpenWAM-α 的代表结果为 LIBERO 99.3、RoboTwin2.0-Full 93.60、EBench 49.4、RoboCasa365 38.2、RoboCasa-GR1 60.5；但 LIBERO-Plus 仅 69.2，低于 π0.5 的 84.4 和 Qwen-RobotManip 的 89.0。RoboTwin Clean2Random 图中的 69.0 是 clean 与 randomized 的均值，其 OOD randomized 单项为 48.7，不能把 69.0 当成纯 OOD 成功率。[↗](https://arxiv.org/pdf/2609.07398#page=21)

LIBERO-Plus 的分项尤其有解释力。OpenWAM-α 在 Camera 和 Noise 分别为 33.8、39.8，Language 和 Light 则为 88.0、97.0。这使“泛化不足”具体落到观测扰动，而非所有语言和操作任务。作者将其联系到较少的单臂预训练覆盖、像素未来预测对视觉变化的敏感性；这些是结合跨模型数据和架构的解释，尚不是逐项控制后的因果归因。[↗](https://arxiv.org/pdf/2609.07398#page=22)

真机单臂六任务各 20 次，OpenWAM-α 为 99/120，即 82.5%，LingBot-VA 为 77.5%，π0.5 为 55.0%；其中 Stack Ring 仍低于 LingBot-VA，Hang on M 持平。RoboDojo 真机三本体、18 任务的平均进度分数/完全成功率为 37.6/24.4，π0.5 为 22.9/12.8。新的 Wuji 灵巧手平台经微调后，在收衣服 OOD 条件达到 17/20 完整成功，对照为 9/20；这验证的是新本体适配，包含目标平台训练。[↗](https://arxiv.org/pdf/2609.07398#page=25)

OpenWAM 最有价值的产出是能逐个检验设计的完整接口：表示空间、动作容量、信息流、混合数据和执行调度都可替换，而评测契约保持一致。最终模型的反例也说明，增加视频监督并不会自动解决所有分布变化；预训练覆盖什么观测和本体，仍会决定部署时首先出现哪一类失败。
