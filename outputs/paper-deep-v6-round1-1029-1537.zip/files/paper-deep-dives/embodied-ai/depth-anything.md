---
title: Depth Anything：无标注图像怎样变成单目深度基础模型
paper_date: 2024-01
paper_title: "Depth Anything: Unleashing the Power of Large-Scale Unlabeled Data"
paper_topic: 具身智能
---

# Depth Anything：无标注图像怎样变成单目深度基础模型

!!! info "论文信息"
    **论文题名：** Depth Anything: Unleashing the Power of Large-Scale Unlabeled Data。<br>
    **作者：** Lihe Yang、Bingyi Kang、Zilong Huang、Xiaogang Xu、Jiashi Feng、Hengshuang Zhao。<br>
    **机构：** 未在公开元数据中稳定解析；以 arXiv/PDF 或官方页 affiliation block 为准。<br>
    **时间 / 主题：** 2024-01；具身智能。<br>
    **arXiv / 官方报告：** arXiv：[2401.10891](https://arxiv.org/abs/2401.10891)；官方材料：[depth-anything.github.io/](https://depth-anything.github.io/)。<br>
    **GitHub / 项目：** GitHub：[github.com/LiheYoung/Depth-Anything](https://github.com/LiheYoung/Depth-Anything)；项目页：[depth-anything.github.io/](https://depth-anything.github.io/)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2401.10891)；[GitHub API / repo](https://github.com/LiheYoung/Depth-Anything)；[官方 / 项目材料](https://depth-anything.github.io/)；Checked Date：2026-06-15；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 深度模型的瓶颈如何变成数据问题

Depth Anything 要解决的是单目深度在陌生图像上的失效。训练集内误差较小，并不意味着模型能处理雾天、夜景、远处建筑或训练中少见的室内布局。作者保留 DINOv2 编码器和 DPT 解码器，把主要改动放在训练数据及其使用方式上。整个系统的产物是一张与输入图像对齐的相对逆深度图，近处数值更大；绝对米制距离需要额外微调。[↗](https://arxiv.org/pdf/2401.10891#page=3)

先看图 1 中场景和光照的跨度，再看每一张预测是否仍保持物体与背景的层次。这里展示的是作者对开放场景泛化的目标，后面的跨数据集测试才给出相应的量化证据。

![Depth Anything teaser 原论文图](../../assets/images/paper-deep-dives/embodied-ai/depth-anything/figure-1-teaser.png){ width="920" }

*来源：原论文 Figure 1。样例包含 COCO、未用于训练的 SA-1B 子集以及作者拍摄的照片。*

MiDaS 已经证明多来源监督训练有用，但制作深度标签依赖立体匹配、SfM 或传感器，各自都有采集条件。本文先收集六个有标签数据集约 150 万张图像，再利用八个公共图像集合中的约 6200 万张无标签图像。无标签数据提供的是场景分布，而教师提供几何监督。需要解释的关键问题因而是：当教师和学生使用相近的网络与预训练时，为什么重复学习教师输出还能得到新能力？

## 两条数据流与一个语义约束

图 2 从左向右读。实线中的有标签图像提供直接深度监督；虚线中的无标签图像先交给教师生成伪深度，学生则看到加过强扰动的版本。旁边冻结的编码器只约束学生的中间表示，不参加最终推理。

![Depth Anything pipeline 原论文图](../../assets/images/paper-deep-dives/embodied-ai/depth-anything/figure-2-pipeline.png){ width="920" }

*来源：原论文 Figure 2。图中的 S 表示强扰动，语义保持路径与深度监督共同作用于学生编码器。*

第一阶段用 DINOv2 初始化编码器，在有标签数据上训练教师 $T$。第二阶段构造 $\widehat{\mathcal D}^u=\{(u_i,T(u_i))\}$，重新初始化学生 $S$，在有标签与伪标签图像的混合集上训练。重新初始化是论文采用的自训练设置，学生并非直接从教师深度权重继续优化。

网络结构本身保持简单。DINOv2 将图像编码为 patch 特征，DPT 将不同层的表示恢复到稠密空间，回归每个像素的深度。训练期间出现的教师、语义编码器和 CutMix 都不成为部署时的额外分支，因此可以把昂贵的数据加工留在离线阶段。[↗](https://arxiv.org/pdf/2401.10891#page=4)

### 混合深度数据需要先消除尺度与平移差异

不同来源深度的标定并不统一。论文先把深度转换为逆深度，再使用仿射不变误差。对一个深度图 $d$，定义

$$
t(d)=\operatorname{median}(d),\qquad
s(d)=\frac{1}{HW}\sum_{i=1}^{HW}|d_i-t(d)|,
\qquad \hat d_i=\frac{d_i-t(d)}{s(d)}.
$$

其中 $H,W$ 为图像尺寸，中位数移除整体平移，平均绝对偏差移除尺度。有标签损失是

$$
\mathcal L_l=\frac{1}{HW}\sum_{i=1}^{HW}\rho(d_i^*,d_i),
\qquad \rho(d_i^*,d_i)=|\hat d_i^*-\hat d_i|.
$$

$d_i^*$ 为预测，$d_i$ 为标签。这允许一个模型学习多种传感器或重建方法给出的相对几何，代价是训练目标主动放弃了绝对尺度。后面把模型用于机器人测距时，不能把灰度深度图直接当成米。[↗](https://arxiv.org/pdf/2401.10891#page=3)

### 强扰动让学生承担不同于教师的任务

作者的初始实验中，直接增加伪标签没有稳定增益。教师与学生有相同的预训练和类似结构，容易在同一张图上做出相近判断；监督量增加，却未必增加有效学习难度。

本文让教师看干净图像，让学生看颜色抖动、高斯模糊以及 CutMix 后的图像。CutMix 将两张图按二值矩形掩码拼起来：

$$
u_{ab}=u_a\odot M+u_b\odot(1-M).
$$

训练不能直接将两张独立图像的逆深度拼成一个全局尺度，因为两张教师预测各自有任意仿射尺度。论文分别在 $M$ 与 $1-M$ 内计算仿射不变损失，然后按面积加权：

$$
\mathcal L_u=
\frac{\sum M}{HW}\mathcal L_u^M+
\frac{\sum(1-M)}{HW}\mathcal L_u^{1-M}.
$$

$\mathcal L_u^M$ 比较学生拼接图预测的对应区域与 $T(u_a)$，另一个区域同理。分区域对齐保留了两张图各自的深度关系；强扰动则迫使学生在外观变化或上下文破坏后仍恢复这些关系。论文以 50% 概率使用 CutMix。[↗](https://arxiv.org/pdf/2401.10891#page=4)

### 语义保持为什么使用连续特征

作者尝试过让学生同时预测深度和约 4000 类语义分割标签，没有得到预期改善。最终改为直接对齐冻结 DINOv2 的连续特征：

$$
\mathcal L_{feat}=1-\frac{1}{HW}\sum_{i=1}^{HW}\cos(f_i,f'_i).
$$

$f_i$ 是学生特征，$f'_i$ 是冻结编码器特征。这里保留类别以内的细粒度信息，比将图像压成离散类别掩码更适合作为辅助监督。不过，对齐过强也有问题：同一辆车的车头与车尾可以有相似语义，却处于不同深度。实际优化因此设置容忍阈值 $\alpha=0.85$，相似度超过阈值的像素不再参加特征约束，让深度任务仍能改造表示。最终目标平均组合 $\mathcal L_l$、$\mathcal L_u$ 和 $\mathcal L_{feat}$。[↗](https://arxiv.org/pdf/2401.10891#page=5)

## 训练配方怎样落实这三种约束

教师在有标签数据上训练 20 epochs。学生阶段遍历无标签集合一次，每个 batch 中有标签与无标签样本比例为 1:2。编码器学习率为 $5\times10^{-6}$，随机初始化的解码器为其十倍，采用 AdamW 和线性学习率衰减。有标签样本只做水平翻转，强扰动重点用于无标签分支。这种不对称使稳定监督和困难学习任务同时存在。

公开模型分为 ViT-S、ViT-B、ViT-L，参数量分别为 24.8M、97.5M、335.3M。大模型负责高质量伪标签，小模型在同一数据分布上学习。使用者可以根据端侧预算选模型，离线 6200 万张图像标注的代价无需在每次推理中重复承担。要复现论文训练收益，则必须同时复现数据覆盖、教师质量、强增强与语义约束，仅更换为 DINOv2 编码器并不足以等价复现。

## 跨域结果说明了什么

零样本相对深度测试使用六个未参与 Depth Anything 训练的数据集。下表摘取原 Table 2 的三类场景，AbsRel 越低越好，$\delta_1$ 越高越好。$\delta_1$ 表示预测与真值比值落在 1.25 阈值内的像素比例。

| Method | Encoder | KITTI AbsRel ↓ | KITTI δ1 ↑ | Sintel AbsRel ↓ | Sintel δ1 ↑ | DDAD AbsRel ↓ | DDAD δ1 ↑ |
|---|---|---:|---:|---:|---:|---:|---:|
| MiDaS v3.1 | ViT-L | 0.127 | 0.850 | 0.587 | 0.699 | 0.251 | 0.766 |
| Depth Anything | ViT-S | 0.080 | 0.936 | 0.464 | 0.739 | 0.247 | 0.768 |
| Depth Anything | ViT-B | 0.080 | 0.939 | 0.432 | 0.756 | 0.232 | 0.786 |
| Depth Anything | ViT-L | 0.076 | 0.947 | 0.458 | 0.760 | 0.230 | 0.789 |

同为 ViT-L，DDAD 的 AbsRel 从 0.251 降到 0.230；小模型在 Sintel、DDAD 上也能超过 MiDaS-L。收益因此不仅体现为容量增加。KITTI 的比较还要考虑 MiDaS 使用过该数据集训练图像，而 Depth Anything 没有。另一方面，Sintel 上 ViT-B 的 AbsRel 优于 ViT-L，模型规模并不保证每个域、每个指标单调改善。[↗](https://arxiv.org/pdf/2401.10891#page=5)

下面的定性对照适合补看物体边缘与远近关系，尤其是平均误差容易掩盖的区域。它不能替代上表的总体统计，但能说明错误具体长什么样。

![Depth Anything zero-shot qualitative 原论文图](../../assets/images/paper-deep-dives/embodied-ai/depth-anything/figure-3-zeroshot-vis.png){ width="860" }

*来源：原论文 Figure 3，零样本深度估计可视化。*

消融回答的是收益从哪里来。原文 Table 9 比较单纯增加伪标签、加入强扰动和加入语义约束；论文观察到直接自训练不足以带来预期提升，强扰动之后无标签数据的价值才明显表现出来。单独考察有标签来源时，只有 20K 图像的 HRWSI 在六个测试域上的平均迁移表现优于若干更大集合，说明样本量与分布覆盖是两件不同的事。这也解释了为什么本文使用八类公共图像，而非只把某一个场景的视频采得更密。[↗](https://arxiv.org/pdf/2401.10891#page=7)

## 相对深度以外，哪部分能力可以迁移

在米制深度实验中，作者将 Depth Anything 编码器放入 ZoeDepth 框架并进行目标域微调。NYUv2 的 AbsRel 为 0.056、$\delta_1$ 为 0.984；KITTI 的对应值为 0.046 和 0.982。这些是获得米制标签后的结果，不能与前面的零样本相对深度混写。[↗](https://arxiv.org/pdf/2401.10891#page=6)

更严格的域外米制测试，用 NYUv2 微调模型测试其他室内集合，用 KITTI 微调模型测试其他室外集合。在 SUN RGB-D 上，相比同环境复现的 ZoeDepth，$\delta_1$ 从 0.545 升至 0.660；但 DIODE Outdoor 仍只有 0.288。预训练改善了迁移，目标域外绝对尺度依然很困难。这会直接影响机器人采用方式：相对深度适合提供空间布局先验，绝对避障阈值需要标定、米制模型或其他传感信息。

语义分割测试又检验了另一件事。使用该编码器微调 Mask2Former，Cityscapes 单尺度 mIoU 为 84.8、多尺度为 86.2，ADE20K 为 59.4。深度训练没有完全破坏高层语义，辅助特征约束所希望保留的能力能够在下游体现出来。

图 4 展示将更稳定的深度作为 ControlNet 条件后的生成例子。阅读时应比较输入深度与输出图像的结构一致性，它提供的是深度作为控制接口的实例，并不等于新增了一项深度误差评测。

![Depth Anything depth-conditioned synthesis 原论文图](../../assets/images/paper-deep-dives/embodied-ai/depth-anything/figure-4-synthesis.png){ width="920" }

*来源：原论文 Figure 4，depth-conditioned image synthesis。*

本文最可复用的训练经验是给伪标签学习制造有意义的不对称：教师负责干净输入上的稳定目标，学生在更难的外观条件下恢复目标，再用适度的语义约束防止表示退化。数据扩大之所以有效，依赖这一学习任务确实比重复教师预测更难。
