---
paper_date: 2026-07
paper_title: "Video Generation Models are General-Purpose Vision Learners"
paper_topic: 具身智能 / 视频生成 / 通用视觉感知
---

# GenCeption：视频生成模型如何成为通用视觉学习器

!!! info "论文信息"
    **论文题名：** Video Generation Models are General-Purpose Vision Learners。<br>
    **模型 / 方法名：** GenCeption。<br>
    **作者：** Letian Wang、Chuhan Zhang、Rishabh Kabra、Jasper Uijlings、Steven Waslander、Andrew Zisserman、Joao Carreira、Kaiming He、Misha Andriluka、Eduard Gabriel Bazavan、Andrei Zanfir、Cristian Sminchisescu。<br>
    **机构：** Google DeepMind、University of Toronto、University College London、University of Oxford、MIT、Lund University。<br>
    **时间 / 主题：** 2026-07；视频生成预训练 / 通用视频感知 / 具身视觉状态。<br>
    **会议：** arXiv 页面备注为 ECCV 2026；正式出版信息以会议最终版本为准。<br>
    **原论文：** [arXiv:2607.09024](https://arxiv.org/abs/2607.09024)，[PDF](https://arxiv.org/pdf/2607.09024)。<br>
    **项目页：** [genception.github.io](https://genception.github.io)。论文未在正文中给出独立 GitHub 代码仓库。<br>
    **元数据来源与核验口径：** 来源为 arXiv 摘要页、PDF 和项目页；Checked Date：2026-07-13；Repro Status：Paper / project page reviewed, independent reproduction not claimed。

## 视频生成预训练能否变成通用感知骨干

GenCeption 将 Wan2.1 视频生成模型改成一次前向的视频感知模型。输入真实视频和任务文本，输出深度、法向、分割、相机 raymap 或人体关键点。研究重点是如何保留视频预训练的时空与语言先验，同时把原本数十步的生成过程改成可用于感知的确定性映射。[↗](https://arxiv.org/pdf/2607.09024#page=5)

![GenCeption 方法总览](../../assets/images/paper-deep-dives/embodied-ai/genception/figure-1-methodology.png){ width="920" }

方法图把任务差异移到输出表示与提示词上。深度和分割可以映射到三通道图像，稀疏坐标则由新增查询 token 输出。统一接口减少每个任务单独设计网络的工作，但密集任务与稀疏任务能否无损共训，是论文需要另行检验的问题。

## 干净输入、零时间和输出取反

原视频生成器由 VAE、文本编码器和 DiT 构成，DiT 在噪声时间条件下预测 rectified-flow 速度。原定义为

$$
v=\epsilon-x_0,
$$

其中 $x_0$ 为干净视频 latent。GenCeption 直接将输入视频的干净 latent 送进 DiT，固定 $t=0$，只运行一次，然后对 DiT 原始输出取负再送入监督或 VAE 解码器。

$$
-v=x_0-\epsilon.
$$

这个关系解释了初始化的选择：相较直接使用噪声或速度预测，取反输出在语义上更接近目标视频 latent，实验证明它有助于收敛。但 $x_0-\epsilon$ 并不代数恒等于 $x_0$；模型仍须通过感知任务微调，学习从输入 RGB 到目标模态的映射。[↗](https://arxiv.org/pdf/2607.09024#page=6)

![GenCeption 统一感知架构](../../assets/images/paper-deep-dives/embodied-ai/genception/figure-4-architecture.png){ width="920" }

Figure 4 沿两种输出路径展开。密集任务使用最后一层输出和原 VAE decoder，尽量保持预训练接口；稀疏任务从新增 learnable tokens 读结果。与读取某个中间层再训练专用解码器不同，本文尽量使用生成器原生末端表示。

## 统一三通道表示怎样容纳几何任务

所有密集目标被编码到 $[0,1]$ RGB 空间。单通道深度或 mask 在三通道复制；法向与 DensePose 等使用三个通道表达不同分量。相机位姿先表示为 ray origins 和 ray directions，共六个通道，再采用空间拼接：中心区域放 origin，外围放 direction，形成三通道的 “Rothko” raymap。之后可从 raymap 恢复相机位姿。

这种做法将高维输出约束转成数据布局问题，复用同一个解码器，但额外承担了布局编码与几何解码的职责。它不意味着任意高维任务都能无损压成三个通道。

深度还要处理尺度。论文先用场景中位深度归一化每段视频，再应用

$$
d'=\operatorname{clip}\bigl(\alpha\log(d+1),0,1\bigr).
$$

$\alpha$ 控制近远处结构在有限动态范围中的分配。这样把尺度与值域处理放在目标构造中，损失可以统一为 $L_2$：密集任务在 latent 空间回归，稀疏任务在最终坐标空间回归。代价是归一化后的深度不天然保留任意场景的绝对公制尺度。[↗](https://arxiv.org/pdf/2607.09024#page=9)

稀疏关键点使用每原始视频帧一个可学习 token，MLP 输出该帧的 $K$ 维结构化目标。其空间位置可学习，时间位置按 VAE 压缩比例插值，使新增 token 的 3D RoPE 范围与预训练时间轴一致。这是在统一框架中必要的结构扩展，也是后续多任务干扰的重要来源。

## 少量感知数据建立在大规模生成预训练之上

核心合成集使用 800 个 RenderPeople 人体资产、200 种 CMU 动捕动作，变化背景、焦距、相机位置与轨迹，生成 7500 段视频。Blender 同时提供深度、法向、分割、关键点与相机真值；图像、目标模态和文本条件预先缓存为 latent/embedding，降低训练时编码成本。

此外加入 TartanAir、Virtual KITTI、MVS Synth 作为几何监督。表达式指代分割使用 MeViS、Ref-COCO、YouTube-VOS 等真实数据，因此“纯合成训练”只适用于相应几何与人体任务，不能扩大到所有任务。[↗](https://arxiv.org/pdf/2607.09024#page=9)

模型训练输入为 81 帧、24 FPS、$480\times832$，VAE 时间压缩四倍、空间压缩八倍。训练 batch 64，在 256 个 v6e TPU 上运行 15000 步，Adam 学习率 $5\times10^{-5}$、前 250 步 warmup。除梯度裁剪外，极高梯度 batch 会直接丢弃以稳定训练。较小的感知数据集并不意味着基础预训练或下游计算成本很低。

## 专项版与通用版不能混成一个结果

原 Table 1 同时报告 1.3B 专项版、14B 专项版和 14B 通用版。以下摘出能反映多任务权衡的指标，数值越低越好，分割 J&F 除外。

| Metric / Benchmark | Specialist 14B | Generalist 14B |
|---|---:|---:|
| Normal mAE, Sintel | 29.7 | 29.3 |
| Normal mAE, Hi4D | 10.99 | 11.47 |
| Depth AbsRel, Sintel | 0.130 | 0.156 |
| Depth AbsRel, KITTI | 0.048 | 0.048 |
| Depth AbsRel, ETH3D | 0.037 | 0.044 |
| Camera ATE, Sintel | 0.050 | 0.062 |
| Foreground MSE, VideoMatte | 0.0027 | 0.0010 |
| Foreground MSE, PhotoMatte | 0.0009 | 0.0008 |
| Referring J&F, Ref-DAVIS ↑ | 76.4 | 75.8 |
| Referring J&F, MeViS ↑ | 70.0 | 69.0 |

通用训练改善前景分割，但深度和相机位置多数退化，法向因数据集而异。这比“一个模型全面超过所有专家”更接近实验事实。与外部方法比较，VGGT-Ω 在 KITTI/ETH3D 深度 AbsRel 为 0.041/0.016，优于 GenCeption 专项版的 0.048/0.037；GenCeption 在 Sintel 为 0.130，优于对照的 0.145。几何能力存在不同数据域的优势区间。[↗](https://arxiv.org/pdf/2607.09024#page=11)

表达式分割中，专项版 Ref-DAVIS/MeViS 的 J&F 76.4/70.0，高于表内 SAM3+Gemini 3.5 Flash 的 64.5/57.5，但两者训练和交互方式不同，这是一组任务结果比较，不能单独证明骨干预训练目标更优。人体关键点专项版在 EMDB 的 MPJPE 为 71.8，对照 GVHMR、TRAM、Genmo 分别为 72.6、74.4、73.0。

更关键的失败是把关键点稀疏回归与密集任务联合训练时，关键点表现严重退化，也影响其他任务。作者推测新增随机初始化查询扰动了 DiT 原有注意力，而坐标回归与像素生成的接口差距较大；这是机制解释，尚未被逐项消融完全分离。通用框架能表达任务，并不保证全部任务共享权重时都能保持专项精度。[↗](https://arxiv.org/pdf/2607.09024#page=12)

## 预训练与数据规模的证据分别是什么

![GenCeption 多任务结果和数据效率](../../assets/images/paper-deep-dives/embodied-ai/genception/figure-2-results-and-efficiency.png){ width="920" }

先比较同一 7500 段、约 0.9M 帧感知训练数据上的不同骨干。三个深度 benchmark 平均 AbsRel，V-JEPA-H 0.6B 为 0.281，VideoMAE V2 0.6B 为 0.175、1B 为 0.154，Wan 1.3B 为 0.122、14B 为 0.093。Wan 初始化在该适配方案下更有效，但骨干预训练数据和规模并未完全控制，因此不能将全部差距归因于 diffusion objective 本身。

增加到四个数据集、约 8080 段、1.23M 帧后，14B 的平均 AbsRel 为 0.071，VGGT-Ω 为 0.067；GenCeption 感知微调帧数远少于对照表列出的约 600M。这个比较体现生成先验的下游数据效率，但不能把生成骨干先前消耗的训练数据从整体成本中抹去。论文所说 7–500 倍的数据差距针对表内感知训练口径。

逐层继承预训练参数的实验还显示，从头初始化 DiT 的学习曲线近乎平坦，继承更多层后表现改善。这更直接支持预训练对收敛的重要性；与跨骨干表格相比，它更少受到模型种类同时变化的干扰。[↗](https://arxiv.org/pdf/2607.09024#page=13)

## 一次 DiT 不等于端到端只有一次小计算

单 v6e TPU、81 帧、$480\times832$ 条件下，1.3B 端到端耗时 5.92 秒，约 13.6 FPS，DiT 本身仅 0.96 秒；14B 端到端 10.03 秒，约 8 FPS，DiT 为 5.11 秒。报告内存为 15.3/42.8 GB，文本编码器约 10 GB、VAE 约 0.25 GB，可卸载到主存换取较低设备内存占用。

这说明去掉原 Wan 的约 50 步采样后，编码与解码成为显著成本。处理一个 clip 的吞吐率也不等同于逐帧实时低延迟，具体应用需考虑完整窗口与 VAE 路径。[↗](https://arxiv.org/pdf/2607.09024#page=10)

![GenCeption 的跨实例和跨类别泛化](../../assets/images/paper-deep-dives/embodied-ai/genception/figure-10-emergent-generalization.png){ width="920" }

Figure 10 展示了从合成单人体训练到真实多实例、动物和拟人角色的迁移。这些例子支持预训练先验可以超出下游监督类别，但不是所有未见类别的系统成功率。GenCeption 最明确的贡献是证明视频生成器可通过小幅接口调整转成多种感知模型；同时，稀疏查询造成的联合训练退化也给出了统一感知尚需解决的具体边界。
