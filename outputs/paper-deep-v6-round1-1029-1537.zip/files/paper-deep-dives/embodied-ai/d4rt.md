---
paper_date: 2025-12
paper_title: "Efficiently Reconstructing Dynamic Scenes One D4RT at a Time"
paper_topic: 具身智能 / 4D 重建
---

# D4RT：动态场景的 4D 重建与跟踪

!!! info "论文信息"
    **论文题名：** Efficiently Reconstructing Dynamic Scenes One D4RT at a Time。<br>
    **作者：** Chuhan Zhang、Guillaume Le Moing、Skanda Koppula、Ignacio Rocco、Liliane Momeni、Junyu Xie、Shuyang Sun、Rahul Sukthankar、Joëlle K. Barral、Raia Hadsell、Zoubin Ghahramani、Andrew Zisserman、Junlin Zhang、Mehdi S. M. Sajjadi。<br>
    **机构：** Google DeepMind、University College London、University of Oxford。<br>
    **时间 / 主题：** 2025-12；具身智能 / 4D reconstruction / tracking。项目页标注 CVPR 2026 Best Paper。<br>
    **arXiv / 官方报告：** arXiv：[2512.08924](https://arxiv.org/abs/2512.08924)；项目页：[d4rt-paper.github.io](https://d4rt-paper.github.io/)；Google DeepMind blog：[D4RT](https://deepmind.google/blog/d4rt-teaching-ai-to-see-the-world-in-four-dimensions/)。<br>
    **GitHub / 项目：** GitHub：未找到官方代码链接；项目页提供论文、arXiv、blog 和交互式可视化。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2512.08924)；[项目页](https://d4rt-paper.github.io/)；[Google DeepMind blog](https://deepmind.google/blog/d4rt-teaching-ai-to-see-the-world-in-four-dimensions/)；Checked Date：2026-06-15；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 先编码视频，再按需要询问三维世界

D4RT 把动态重建的输出接口改成一个问题：视频中某一帧的某个像素所对应的物理点，在另一个时刻处于哪里，并用哪一帧的相机坐标表达？这三个时间索引可以不同。网络先计算一次全视频表示，再用轻量解码器独立回答查询，从而把深度、轨迹、点云与相机估计统一起来。[↗](https://arxiv.org/pdf/2512.08924#page=2)

![D4RT teaser 原论文图](../../assets/images/paper-deep-dives/embodied-ai/d4rt/figure-1-teaser.png){ width="720" }

*来源：原论文 Figure 1。全局表示在左，独立点查询在右；不同任务改变的是查询，而非重新编码视频。*

静态重建可以将各帧点云直接累积，动态场景却会把移动物体重建成多个副本。仅从第一帧发起跟踪也不够，因为后来露出的表面没有初始点。D4RT 允许从任意时刻发起查询，既保留物体身份随时间变化的对应，也能补充新出现的表面。

## 五个查询变量分别控制什么

输入视频 $V\in\mathbb R^{T\times H\times W\times3}$ 先变成全局特征 $F=E(V)$。查询和输出为

$$
q=(u,v,t_{src},t_{tgt},t_{cam}),\qquad P=D(q,F)\in\mathbb R^3.
$$

$(u,v)$ 是归一化图像坐标；$t_{src}$ 用来确定被追踪的是哪个点；$t_{tgt}$ 决定这个点的物理状态；$t_{cam}$ 决定表达三维位置的参考坐标系。把目标时刻和相机时刻拆开，才能区分物体运动与坐标系变化。

| Desired output | Query configuration | Interpretation |
|---|---|---|
| Depth | $t_{src}=t_{tgt}=t_{cam}$ | 取输出的 Z 分量 |
| Camera-coordinate track | 固定源像素，令 $t_{tgt}=t_{cam}$ 遍历视频 | 每一时刻在该帧相机下的三维轨迹 |
| World-coordinate track | 固定源像素与 $t_{cam}$，改变 $t_{tgt}$ | 在共同参考系中观察运动 |
| Point cloud | 查询多帧像素，固定 $t_{cam}$ | 将不同观测表达在同一空间 |

图 2 顺着查询嵌入到 cross-attention 读。空间坐标用 Fourier features，三个时间索引用离散嵌入，源点周围 $9\times9$ RGB patch 的嵌入提供精细外观。查询之间没有 self-attention，因此任意选择或分批处理查询都不改变其他点的条件。[↗](https://arxiv.org/pdf/2512.08924#page=3)

![D4RT method 原论文图](../../assets/images/paper-deep-dives/embodied-ai/d4rt/figure-2-method.png){ width="920" }

*来源：原论文 Figure 2。*

独立查询将解码计算与需要输出的点数相联系。编码器仍需处理整段视频，但只求相机时无需生成全部像素的稠密深度；只追踪几个点时，也不必解码完整点云。这是效率收益的结构性来源。

## 相机参数也由点查询恢复

求帧 $i$ 到 $j$ 的相对位姿时，对同一组源点分别查询 $(u_k,v_k,i,i,i)$ 和 $(u_k,v_k,i,i,j)$。两组输出代表同一时刻的同一批三维点，只是参考相机不同；用 Umeyama 求刚性变换即可，核心计算是一个 $3\times3$ SVD。

内参采用中心主点的针孔模型。对解码点 $(p_x,p_y,p_z)$，归一化焦距为

$$
f_x=\frac{p_z(u-0.5)}{p_x},\qquad
f_y=\frac{p_z(v-0.5)}{p_y}.
$$

对粗网格多个点取中位数提高鲁棒性。相机估计因此复用了统一三维接口，不依赖另一个大型相机头；不过针孔模型与主点假设仍然是恢复公式的条件。[↗](https://arxiv.org/pdf/2512.08924#page=3)

## 训练怎样让稀疏查询覆盖多种任务

编码器使用 40 层 ViT-g、$2\times16\times16$ 时空 patch，约 1B 参数；8 层 cross-attention 解码器约 144M。训练输入为 48 帧、$256\times256$ 视频，每段只解码 2048 个采样查询。模型在公共和内部几何数据混合上训练 500K steps，64 个 TPU chips、每设备 batch size 1，耗时略多于两天。

主要三维损失先按各自平均深度归一化预测与目标，再通过 $\operatorname{sign}(x)\log(1+|x|)$ 压缩远点影响，使用 L1 误差。辅助信号包含二维投影位置、表面法向、目标可见性和运动向量；只有标签可用的位置参加对应损失。预测置信度 $c$ 加权三维误差，$-\log c$ 防止通过关闭权重逃避学习。

局部 RGB patch 的必要性在小规模控制实验中很明显：同为 ViT-L，Sintel scale-only 深度 AbsRel 从 0.366 降到 0.302，ATE 从 0.173 降到 0.091。patch 同时帮助查询找到正确时空特征和保住边缘，不能把它仅看成坐标精度的小修补。辅助损失也有任务权衡，例如移除 visibility 会改善某些深度指标，却损害相机指标；训练目标服务的是联合任务。[↗](https://arxiv.org/pdf/2512.08924#page=8)

![D4RT full model overview 原论文图](../../assets/images/paper-deep-dives/embodied-ai/d4rt/figure-6-full-model.png){ width="920" }

*来源：本页保存的原论文局部细节对照图。重点比较有无 local patch 时的轮廓；它解释查询端为何还需要低层图像信息。*

## 动态对应改善的是哪一类重建错误

图 4 先看移动天鹅是否被重复放置，再看遮挡后露出的背景是否留下空洞。纯静态重建会累积动态物体，多阶段跟踪又可能只覆盖第一帧可见区域。D4RT 可以从后续帧补充查询，同时保持运动对应。

![D4RT reconstruction comparison 原论文图](../../assets/images/paper-deep-dives/embodied-ai/d4rt/figure-4-reconstruction-comparison.png){ width="920" }

*来源：原论文 Figure 4。*

TAPVid-3D 将已知内参与未知内参分开评估。已知内参时，D4RT 在 DriveTrack、ADT、PStudio 上的 AJ 分别为 0.304、0.307、0.372；SpatialTrackerV2 为 0.195、0.303、0.175。未知内参时，ADT 上 D4RT 的 AJ 0.240 低于 SpatialTrackerV2 的 0.260，说明内参误差与对应误差会共同影响结果。世界坐标轨迹还额外检验跨帧共同参考系的一致性，不能与相机坐标下的 AJ 混读。[↗](https://arxiv.org/pdf/2512.08924#page=6)

下表摘录视频深度结果，分别保留 scale-only（S）和 scale-and-shift（SS）对齐协议。对齐在整段序列上进行，并不允许每帧独立消除尺度漂移。

| Method | Sintel AbsRel (S) ↓ | Sintel AbsRel (SS) ↓ | ScanNet AbsRel (S) ↓ | KITTI AbsRel (S) ↓ |
|---|---:|---:|---:|---:|
| VGGT | 0.318 | 0.247 | 0.044 | 0.094 |
| π3 | 0.241 | 0.163 | 0.021 | 0.055 |
| D4RT | 0.171 | 0.148 | 0.020 | 0.055 |

Sintel 的动态内容使差距明显；KITTI 上则与 π3 持平。原 Table 5 中 Bonn 的 scale-only 指标为 π3 0.033、D4RT 0.036，也说明动态统一建模并不保证所有静态域的每个数值都领先。[↗](https://arxiv.org/pdf/2512.08924#page=7)

## “按需解码”如何换成实际预算

直接为每一帧每一像素查询整条轨迹，需要 $O(T^2HW)$ 次查询。论文用时空 occupancy grid 记录已经覆盖的像素：只从未覆盖点发起轨迹，一条轨迹穿过的可见位置都标为已访问。根据视频运动复杂度，该策略带来约 5–15 倍加速。它依赖独立、轻量的解码器，不能直接套到要求整帧共同解码的模型上。

原 Table 3 在单张 A100 上测量指定吞吐下可输出的完整视频轨迹数：

| Method | 60 FPS | 24 FPS | 10 FPS | 1 FPS |
|---|---:|---:|---:|---:|
| SpatialTrackerV2 | 29 | 84 | 219 | 2,290 |
| D4RT | 550 | 1,570 | 3,890 | 40,180 |

这些数值说明可支持的查询密度，不是机器人控制器的闭环频率。只求相机的图 3 另报告 200+ FPS，比较前已去掉基线中与相机任务无关的头；完整密集四维输出的成本应结合轨迹数量看。

![D4RT speed 原论文图](../../assets/images/paper-deep-dives/embodied-ai/d4rt/figure-3-speed.png){ width="650" }

*来源：原论文 Figure 3，A100 上相机估计准确率与吞吐。*

![D4RT in-the-wild visualization 原论文图](../../assets/images/paper-deep-dives/embodied-ai/d4rt/figure-5-in-the-wild.png){ width="920" }

*来源：原论文 Figure 5。静态场景看整体结构，动态场景还要看轨迹是否随实体运动。*

D4RT 最适合需要灵活查询的感知系统：粗相机估计、少量目标点跟踪、密集动态重建可以共享同一个场景编码结果。它给出的可复用设计是把物理时刻与观察坐标系分开，并让输出密度由应用需求决定。全视频编码仍需要相应窗口输入，因此离线吞吐不能直接等同于因果在线感知延迟。
