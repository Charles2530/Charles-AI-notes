---
paper_date: 2025-11
paper_title: "Depth Anything 3: Recovering the Visual Space from Any Views"
paper_topic: 具身智能
---

# Depth Anything 3：任意视角的 3D 几何底座

!!! info "论文信息"
    **论文题名：** Depth Anything 3: Recovering the Visual Space from Any Views。<br>
    **作者：** Haotong Lin、Sili Chen、Junhao Liew、Donny Y. Chen、Zhenyu Li、Guang Shi、Jiashi Feng、Bingyi Kang。<br>
    **机构：** 未在公开元数据中稳定解析；以 arXiv/PDF 或官方页 affiliation block 为准。<br>
    **时间 / 主题：** 2025-11；具身智能。<br>
    **arXiv / 官方报告：** arXiv：[2511.10647](https://arxiv.org/abs/2511.10647)；官方材料：[depth-anything-3.github.io/](https://depth-anything-3.github.io/)。<br>
    **GitHub / 项目：** GitHub：[github.com/ByteDance-Seed/Depth-Anything-3](https://github.com/ByteDance-Seed/Depth-Anything-3)；项目页：[depth-anything-3.github.io/](https://depth-anything-3.github.io/)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2511.10647)；[GitHub API / repo](https://github.com/ByteDance-Seed/Depth-Anything-3)；[官方 / 项目材料](https://depth-anything-3.github.io/)；Checked Date：2026-06-22；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 把任意视图几何恢复写成两个稠密预测

Depth Anything 3 将单图深度、多视图几何和相机估计放进同一接口。输入可以是一张图、多张场景照片或视频帧，还可以附带已知相机参数；输出核心是每张图对应的深度图和射线图。两者逐像素组合即可得到统一坐标系中的三维点。论文想验证的是，一套尽量简单的表示与充分预训练的 Transformer，能否承担原来分散在多个网络和优化阶段中的几何推断。[↗](https://arxiv.org/pdf/2511.10647#page=6)

![Depth Anything 3 teaser 原论文图](../../assets/images/paper-deep-dives/embodied-ai/depth-anything-3/figure-1-teaser.png){ width="760" }

*来源：原论文 Figure 1。先看输入视图数与相机信息是否已知，再看深度、射线和点云的对应关系；右侧结果表示不同任务的评测，不能合成一个通用准确率。*

与 V2 相比，DA3 不只扩展了模型输入。V2 的仿射不变逆深度适合相对关系，却不能直接拼接为多相机下一致的几何。DA3 将深度与像素射线都放进几何监督，显式建立图像位置、相机和三维点之间的关系。与直接回归全局 point map 相比，这个分解为每个像素保留了“从哪里看、沿什么方向看、看多远”的结构。

## 深度与射线如何组成三维空间

对像素 $p=(u,v,1)^\top$，内参为 $K$，相机到世界坐标变换为旋转 $R$ 与平移 $t$。定义射线方向 $d=RK^{-1}p$，射线图的六个通道存储 $(t,d)$，则

$$
P=t+D(u,v)d.
$$

这里 $D$ 是沿相机光轴定义的深度；$d$ 不做单位化，它的模长保留了投影尺度。如果把它归一化，却仍将原来的 $D$ 代入，深度与射线的几何含义会不一致。该表示把正交旋转矩阵的预测困难转为逐像素回归，再让深度与射线共同承担三维一致性约束。[↗](https://arxiv.org/pdf/2511.10647#page=6)

理论上可以从射线图恢复相机：对各像素的射线原点求均值得到相机中心，再通过射线方向与像素坐标的对应拟合投影关系。实际使用时，论文另外保留轻量 camera head，直接输出平移、四元数和两个视场角参数。这个头主要省去从稠密射线拟合相机的开销，其价值不应与深度—射线监督的价值混为一谈。

图 2 顺着输入 token 读到两类输出。已知位姿时，相机参数经过 MLP 变成 camera token；未知时使用可学习的占位 token。两者进入相同的注意力路径，使一套权重能适应 posed 与 unposed 输入。

![Depth Anything 3 pipeline 原论文图](../../assets/images/paper-deep-dives/embodied-ai/depth-anything-3/figure-2-pipeline.png){ width="860" }

*来源：原论文 Figure 2。*

## 单个预训练 Transformer 怎样交换跨视图信息

DA3 使用一个标准预训练 ViT。前 $L_s$ 层在每张图内部做 self-attention，后 $L_g$ 层交替做跨视图和图内 self-attention，比例 $L_s:L_g=2:1$。跨视图操作通过重排 token 维度完成，而非再接一套随机初始化的大型融合网络。图内层保持预训练图像特征的工作方式，后部层才利用多视角关联。输入退化为单张图时，跨视图操作也自然退化为单图操作。

Dual-DPT 让深度与射线共享特征重组模块，再通过独立 fusion 和 output 层分别输出。共享部分使两种稠密结果对齐，分离的末端则保留各自回归目标的自由度。下图应先看两条分支在哪里共享、在哪里分开。

![Dual-DPT head 原论文图](../../assets/images/paper-deep-dives/embodied-ai/depth-anything-3/figure-dual-dpt.png){ width="400" .atlas-figure-compact }

*来源：原论文 Figure 3，Dual-DPT Head。*

训练损失把这些接口接起来：

$$
\mathcal L=\mathcal L_D(\hat D,D)+\mathcal L_M(\hat R,M)
+\mathcal L_P(\hat D\odot d+t,P)
+\beta\mathcal L_C(\hat c,v)+\alpha\mathcal L_{grad}(\hat D,D).
$$

$\hat R$ 在这里表示预测射线图，$M$ 为目标射线图；$\hat c,v$ 分别为相机预测和标签。深度、射线及由它们组合得到的点云同时受监督，所以不能仅靠两条分支各自“看起来合理”来满足目标。梯度项为

$$
\mathcal L_{grad}=\|\nabla_x\hat D-\nabla_xD\|_1+
\|\nabla_y\hat D-\nabla_yD\|_1,
$$

它保护局部结构。论文设 $\alpha=\beta=1$，并用共同的三维点平均范数归一化监督尺度，避免不同输出头的数值单位互相冲突。[↗](https://arxiv.org/pdf/2511.10647#page=8)

## 教师标签如何细化几何而不破坏多视图尺度

现实多视图集合提供的相机和稀疏几何很有价值，但稠密深度可能有孔洞或粗糙边界。DA3 沿用合成数据训练教师、再给真实图像补标签的思路，不过教师改为预测深度而非逆深度，并扩展合成场景覆盖。指数深度输出用于改善近相机区域的分辨能力，法向损失进一步约束局部表面。

真实图像的伪标签不能直接覆盖原有深度，因为单目教师的尺度与平移自由度会破坏不同视图的一致性。原 Equation 8 用有效像素掩码 $m_p$ 将教师相对深度 $\tilde D$ 对齐到已有稀疏或噪声深度 $D$：

$$
(\hat s,\hat t)=\arg\min_{s>0,t}\sum_{p\in\Omega}m_p(s\tilde D_p+t-D_p)^2,
\qquad D_{T\to M}=\hat s\tilde D+\hat t.
$$

实际采用 RANSAC 最小二乘来降低异常值影响。原始几何提供尺度锚点，教师提供细节和完整性。这种分工比把单目伪深度当成绝对真值更适合三维任务。[↗](https://arxiv.org/pdf/2511.10647#page=10)

![Teacher supervision 原论文图](../../assets/images/paper-deep-dives/embodied-ai/depth-anything-3/figure-10-teacher-supervision.png){ width="820" }

*来源：原论文中的 teacher supervision 对照。比较同一输入的边界和细结构；增益来自对齐后的高质量深度监督，而不是增加了测试相机信息。*

完整模型训练使用 128 张 H100、200K steps，8K warm-up，峰值学习率 $2\times10^{-4}$。在 $504\times504$ 下随机采样 2–18 个视图，并动态调整 batch 以维持近似 token 预算；120K steps 后从原深度监督切换到教师标签，20% 概率启用位姿条件。Giant 的论文训练耗时约十天；消融改用 ViT-L、最多十视图，避免把小规模控制实验当成全部模型的成本。[↗](https://arxiv.org/pdf/2511.10647#page=16)

## 表示、预训练和教师分别贡献了什么

在相同 ViT-L、120K steps、十视图设置下，原 Table 6 对比预测目标。HiRoom 上 depth+cam 的 Auc3 为 10.8、F1 为 16.5；depth+ray 为 48.7、60.3；depth+pcd+cam 为 9.1、12.8。这个控制实验支持稠密射线作为几何监督的作用。再加入 camera head 并非所有指标都上升，HiRoom 变为 37.2、45.4，而 DTU 的 Auc3 从 46.5 升到 56.3。最终保留相机头主要也考虑直接输出的便利。[↗](https://arxiv.org/pdf/2511.10647#page=17)

主结果来自更大的完整模型和训练预算。下表保留原 Table 2 的严格位姿阈值 Auc3，不与宽阈值 Auc30 混合：

| Method | Params | HiRoom Auc3 ↑ | ETH3D Auc3 ↑ | DTU Auc3 ↑ | 7Scenes Auc3 ↑ | ScanNet++ Auc3 ↑ |
|---|---:|---:|---:|---:|---:|---:|
| VGGT | 1.19B | 49.1 | 26.3 | 79.2 | 23.9 | 62.6 |
| Pi3 | 0.96B | 67.0 | 35.2 | 62.5 | 25.5 | 50.7 |
| DA3-Giant | 1.10B | 80.3 | 48.4 | 94.1 | 28.5 | 85.0 |
| DA3-Large | 0.36B | 58.7 | 32.2 | 70.2 | 29.2 | 60.2 |

Giant 在这些严格阈值列均领先，Large 则在部分数据集已接近大模型，但 DTU 与 ScanNet++ 仍能看到容量差距。宽阈值下 DTU 的 VGGT Auc30 为 99.8，DA3-Giant 为 99.4，因此不能把“几乎所有设置领先”改写为“所有指标都第一”。[↗](https://arxiv.org/pdf/2511.10647#page=14)

教师消融同样有条件。去掉教师后 HiRoom、7Scenes 和 ScanNet++ 下降，DTU 个别指标改善。这与各数据源的原标签质量及场景结构有关；原文提出细结构监督是 HiRoom 收益的重要解释，但单项消融并没有独立拆开所有数据分布因素。

## 几何骨干如何变成新视角生成器

DA3 为 3D Gaussian Splatting 增加一个 GS-DPT head，预测像素对应高斯的透明度、旋转、尺度与颜色；深度反投影决定位置。训练使用新视角图像的 MSE、LPIPS 以及输入视图的深度监督。有相机时按给定位姿投影，无相机时使用预测位姿。局部相机空间中的高斯参数让这两个路径共享权重。[↗](https://arxiv.org/pdf/2511.10647#page=11)

原 Table 5 使用每场景 12 张上下文图像，分辨率 $270\times480$。在域外 Tanks and Temples 上，VGGT 骨干的 PSNR/LPIPS 为 17.18/0.347，DA3 为 18.10/0.311；MegaDepth 上分别为 16.45/0.417 与 17.89/0.351。相同应用接口下几何骨干的改善能传递给渲染，正是“空间表示可复用”的具体证据。[↗](https://arxiv.org/pdf/2511.10647#page=17)

仓库中保存的 SOH 两个视图与对应深度可用于直观理解输入输出的像素对齐关系。它们是示例资产，不能当作上述基准表的独立重复实验。

![DA3 SOH 示例输入 view 0](../../assets/images/paper-deep-dives/embodied-ai/depth-anything-3/soh-input-view-000.png){ width="360" }

![DA3 SOH view 0 depth visualization](../../assets/images/paper-deep-dives/embodied-ai/depth-anything-3/soh-depth-vis-0000.jpg){ width="420" .atlas-figure-compact }

![DA3 SOH 示例输入 view 1](../../assets/images/paper-deep-dives/embodied-ai/depth-anything-3/soh-input-view-010.png){ width="360" }

![DA3 SOH view 1 depth visualization](../../assets/images/paper-deep-dives/embodied-ai/depth-anything-3/soh-depth-vis-0001.jpg){ width="420" .atlas-figure-compact }

*来源：本页随附的 SOH 示例输入及深度可视化。每幅深度图对应其上方输入视图。*

部署选型应同时考虑视图数、分辨率和输出头。论文在 A100 上、32 张 $504\times336$ 图像的场景中报告 Giant 平均 37.6 FPS、Large 78.37 FPS；这是一批场景推理折算的每图吞吐，不能当成流式系统每一新帧的延迟。DA3 最有价值的接口是允许把已有相机信息接进统一骨干，并以深度和射线保持预测的几何含义。对于已有 SfM、SLAM 或标定管线的应用，这比只接受完全未知相机的模型更容易嵌入现有流程。
