---
paper_date: 2025-12
paper_title: "Motus: A Unified Latent Action World Model"
paper_topic: 具身智能 / Latent Action World Model
---

# Motus：把 latent action、世界模型和 VLA 合到一个生成框架

!!! info "论文信息"
    **论文题名：** Motus: A Unified Latent Action World Model。<br>
    **作者：** Hongzhe Bi、Hengkai Tan、Shenghao Xie、Zeyuan Wang、Shuhe Huang、Haitian Liu、Ruowen Zhao、Yao Feng、Chendong Xiang、Yinze Rong、Hongyan Zhao、Hanyu Liu、Zhizhong Su、Lei Ma、Hang Su、Jun Zhu。<br>
    **机构：** Tsinghua University；Peking University；Horizon Robotics。项目页另列 Shengshu。<br>
    **时间 / 主题：** 2025-12；具身智能 / latent action world model / MoT / UniDiffuser-style scheduler。<br>
    **arXiv / 项目：** arXiv：[2512.13030](https://arxiv.org/abs/2512.13030)；PDF：[2512.13030](https://arxiv.org/pdf/2512.13030)；项目页：[motus-robotics.github.io/motus](https://motus-robotics.github.io/motus)。<br>
    **GitHub / 模型：** GitHub：[thu-ml/Motus](https://github.com/thu-ml/Motus)；HF 组织：[motus-robotics](https://huggingface.co/motus-robotics)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2512.13030)、[项目页](https://motus-robotics.github.io/motus)、[GitHub](https://github.com/thu-ml/Motus)、[HF paper API](https://huggingface.co/api/papers/2512.13030)；Checked Date：2026-06-17；Repro Status：Paper / official code and checkpoints reviewed, independent reproduction not claimed。

## 五种生成任务共享什么

Motus 将机器人策略、世界模型、逆动力学和视频生成看作同一组变量的不同条件分布。当前观测 $o_t$、语言 $\ell$、未来动作 $a_{t+1:t+k}$ 与未来观测 $o_{t+1:t+k}$ 不变，变化的是哪些变量已知、哪些需要生成。

| Mode | Distribution | 已知信息与输出 |
|---|---|---|
| VLA | $p(a_{t+1:t+k}\mid o_t,\ell)$ | 当前观测和指令生成动作 |
| World Model | $p(o_{t+1:t+k}\mid o_t,a_{t+1:t+k})$ | 给定动作预测视觉后果 |
| IDM | $p(a_{t+1:t+k}\mid o_{t:t+k})$ | 从视觉变化推断动作 |
| Video Generation | $p(o_{t+1:t+k}\mid o_t,\ell)$ | 根据指令生成未来 |
| Joint Prediction | $p(o_{t+1:t+k},a_{t+1:t+k}\mid o_t,\ell)$ | 联合预测未来与控制 |

统一这些接口的价值在于共享训练数据和先验。带动作标签的机器人轨迹可以监督控制，无标签视频可以监督动态；同一模型通过不同条件组合吸收二者。论文另外引入潜在动作，使只有视频的样本也能训练动作专家，而不仅仅训练视频分支。[↗](https://arxiv.org/pdf/2512.13030#page=3)

## 三个专家在注意力层交换信息

Motus 使用 Mixture-of-Transformers。生成专家继承 Wan2.2-5B，动作专家具有相同深度并通过 AdaLN 注入 flow 时间，理解专家读取 Qwen3-VL-2B 最后一层的特征。各专家保留自己的 Transformer 参数，在 Tri-modal Joint Attention 中汇合注意力，从而在多层持续交换表示。

![Motus architecture 原论文图](../../assets/images/paper-deep-dives/embodied-ai/motus/figure-1-architecture.png){ width="860" }

Figure 1 应从三路输入分别跟踪到联合注意力。视频专家保留预训练动态知识，理解专家补充语言和空间语义，动作专家学习控制输出。这里冻结的是提供特征的 VLM，不能把整个理解分支或所有专家都视为冻结。

动作与观测分别分配噪声时间 $\tau_a,\tau_o$，采用 rectified flow 速度回归。将原文的两项损失写在一起为

$$
\mathcal L=\mathbb E\left[\|v_a^\theta-(\epsilon_a-a_{t+1:t+k})\|_2^2\right]
+\mathbb E\left[\|v_o^\theta-(\epsilon_o-o_{t+1:t+k})\|_2^2\right].
$$

$\epsilon_a,\epsilon_o$ 为独立高斯噪声，$v_a^\theta,v_o^\theta$ 为相应速度预测；观测生成在模型的视觉表示空间内进行。独立时间调度使一个模态可保持为给定条件，另一个模态从噪声恢复，也可以让两者一起生成。这是五种接口共用一个模型的操作基础。[↗](https://arxiv.org/pdf/2512.13030#page=4)

视频每帧有大量 token，如果按动作频率逐帧生成，联合注意力将被视觉 token 占据。Motus 用 action-dense/video-sparse 采样保持动作稠密、视频稀疏，例如将视频帧率设为动作频率的六分之一。它同时降低计算和重复视觉信息，避免为每个控制步都付出完整图像预测成本。

![Motus action-dense video-sparse prediction 原论文图](../../assets/images/paper-deep-dives/embodied-ai/motus/figure-2-action-dense-video-sparse.png){ width="760" }

*原论文 Figure 2。对齐的是覆盖同一时间范围的两条序列，动作步数和视觉帧数无需相等。*

## 潜在动作先从光流学习，再由少量真实动作约束

异构视频缺少统一控制坐标。人手位移、机械臂关节角和另一种机器人末端姿态不能直接拼成相同动作标签。Motus 从相邻帧光流提取更通用的视觉运动表示，再通过少量动作监督把这个表示约束到可执行行为附近。

具体流程是 DPFlow 计算光流，将光流编码为 RGB 图，再由 DC-AE 压缩成四个 512 维 token，最后用轻量编码器映射为 14 维潜在动作。14 维接近常见机器人控制向量规模，但维度相同本身不保证动作语义已经对齐。

![Motus latent action VAE 原论文图](../../assets/images/paper-deep-dives/embodied-ai/motus/figure-3-latent-action-vae.png){ width="430" }

Figure 3 中应同时看重建路径和动作监督路径。前者让 latent 保留画面里的运动，后者约束其中哪些变化对应真实机器人控制。只优化重建时，相机运动、背景变化也可能进入 latent。

训练混合 90% 无标签样本和 10% 有标签轨迹，有标签部分同时包含机器人示范与任务无关数据。后者用 Curobo 在目标机器人的动作空间采样，产生图像—动作对，提供可行运动的锚点。目标为

$$
\mathcal L=\mathcal L_{\mathrm{recon}}
+\lambda_a\|a_{\mathrm{real}}-a_{\mathrm{pred}}\|^2
+\beta\mathcal L_{\mathrm{KL}}.
$$

重建项保存光流信息，动作回归项建立控制对应，KL 项约束潜在分布。弱监督的作用发生在这里，因此“无标签视频训练动作专家”并不意味着完全不需要动作标签来定义 latent 的含义。[↗](https://arxiv.org/pdf/2512.13030#page=5)

## 数据金字塔对应不同训练职责

数据覆盖 web 视频、人类操作、合成数据、任务无关机器人运动、多机器人示范和目标机器人示范。越靠近目标机器人的数据越适合直接监督控制，覆盖面广的视频则提供多样动态。图中的层次表达这种职责差异，不是对所有数据质量作严格排序。

![Motus embodied data pyramid 原论文图](../../assets/images/paper-deep-dives/embodied-ai/motus/figure-4-data-pyramid.png){ width="760" }

训练分三阶段。第一阶段用人类、合成和多机器人视频适配视频生成专家；第二阶段利用潜在动作训练多专家模型，VLM 特征提取器保持冻结，使无动作标签样本也能参与动作侧学习；第三阶段换成目标机器人真实动作做策略微调。这个顺序把“学会看懂交互”“学通用运动表示”“输出目标本体控制”分配给不同监督信号。

## 仿真消融说明预训练在哪一步有增益

RoboTwin2.0 使用 2500 条 clean 与 25000 条 randomized 示范，目标任务微调 40K 步，每任务测试 100 次。下表使用原 Table 2 的数值，区分无具身预训练、仅第一阶段以及完整 Motus。

| Model | Clean Success (%) | Randomized Success (%) |
|---|---:|---:|
| π0.5 | 42.98 | 43.84 |
| X-VLA | 72.80 | 72.84 |
| Motus w/o pretraining | 72.80 | 77.00 |
| Motus with Stage 1 | 82.86 | 81.86 |
| Motus | 88.66 | 87.02 |

只看随机化条件，无预训练到视频领域适配提升 $81.86-77.00=4.86$ 个百分点，完整训练再提升 $87.02-81.86=5.16$ 个百分点。这支持先适配动态、再以潜在动作整合异构数据都能提供增益。此处的“无预训练”指不进行论文的具身预训练流程，模型仍继承视频和视觉语言基础模型。[↗](https://arxiv.org/pdf/2512.13030#page=7)

![Motus ablation 原论文图](../../assets/images/paper-deep-dives/embodied-ai/motus/figure-6-ablation.png){ width="760" }

Figure 6 对比不同预训练阶段与组件的效果。随机化条件的阶段趋势与上表一致；图中 clean 条件的部分数值与 Table 2 不完全一致，上表统一采用 Table 2，避免在同一比较中混用两个口径。

这些结果主要验证完整训练流程的收益。要把全部增益进一步归因于光流、某一种数据或某一位专家，还需要保持数据量与预算一致的对应消融；不能仅凭完整模型分数反推每个组件都同等重要。

## 真机的部分完成度不能当作完整成功率

真机覆盖 AC-One 和 Aloha2，两种平台各任务使用 100 条示范，并按平台进行多任务训练。任务包含键盘操作、取物、倒水和烤箱交互。论文使用部分成功评分，长任务完成若干步骤也会获得分数。

![Motus task definitions 原论文图](../../assets/images/paper-deep-dives/embodied-ai/motus/figure-5-task-definitions.png){ width="860" }

Figure 5 展示了评分对应的任务流程。阅读真实机器人结果时，应先识别一个任务有哪些子步骤，才知道 60 分意味着什么。

| Platform | π0.5 Average Partial Success (%) | Motus w/o Pretraining (%) | Motus (%) |
|---|---:|---:|---:|
| AC-One | 14.79 | 25.86 | 63.22 |
| Aloha2 | 48.60 | 26.60 | 59.30 |

两个平台的平均分都支持完整预训练，但收益并不逐任务成立。AC-One 键盘任务中 Motus 为 82.5，无预训练版本为 100；Aloha2 烤箱任务中 Motus 为 34，π0.5 为 36。任务相关技能与训练分布仍会改变相对优势。[↗](https://arxiv.org/pdf/2512.13030#page=8)

烤箱是理解指标差异的具体例子。AC-One 上 Motus 的部分成功评分为 42%，10 次测试里只有 3 次全部完成，5 次完全失败。Aloha2 倒水的部分成功评分为 96%，对应 8 次完整成功，另 2 次完成了杯子填充等部分步骤。把 42% 或 96% 直接写为完整任务成功概率，会夸大或误读实际能力。[↗](https://arxiv.org/pdf/2512.13030#page=9)

Motus 给出的可复用接口是独立噪声时间控制的多模态生成，给出的数据方案则是带弱动作约束的光流 latent。前者让一个模型支持策略、预测和逆动力学，后者让无动作标签视频能参与动作专家学习。实际采用时，最关键的衔接仍是最后一阶段的目标机器人动作监督，它把共享运动知识落到特定控制坐标和执行系统中。
