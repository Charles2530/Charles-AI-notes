---
paper_date: 2024-12
paper_title: "Video Prediction Policy: A Generalist Robot Policy with Predictive Visual Representations"
paper_topic: 具身智能 / VLA
---

# Video Prediction Policy：预测视觉表征训练机器人策略

!!! info "论文信息"
    **论文题名：** Video Prediction Policy: A Generalist Robot Policy with Predictive Visual Representations。<br>
    **作者：** Yucheng Hu、Yanjiang Guo、Pengchao Wang、Xiaoyu Chen、Yen-Jen Wang、Jianke Zhang、Koushil Sreenath、Chaochao Lu、Jianyu Chen。<br>
    **机构：** 未在公开元数据中稳定解析；以 arXiv/PDF 或官方页 affiliation block 为准。<br>
    **时间 / 主题：** 2024-12；具身智能 / VLA。<br>
    **arXiv / 官方报告：** arXiv：[2412.14803](https://arxiv.org/abs/2412.14803)；官方材料：[video-prediction-policy.github.io/](https://video-prediction-policy.github.io/)。<br>
    **GitHub / 项目：** GitHub：[github.com/roboterax/video-prediction-policy](https://github.com/roboterax/video-prediction-policy)；项目页：[video-prediction-policy.github.io/](https://video-prediction-policy.github.io/)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2412.14803)；[GitHub API / repo](https://github.com/roboterax/video-prediction-policy)；[官方 / 项目材料](https://video-prediction-policy.github.io/)；Checked Date：2026-06-04；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 从视频模型的一次前向中读取未来

Video Prediction Policy（VPP）把视频生成模型用作预测性视觉编码器。模型先学习根据当前图像与语言预测操作视频，再冻结视频网络，提取其第一次前向中的中间特征作为动作策略的条件。这样保留了未来运动相关的表示，又避免在每次控制更新前完成整段视频去噪。[↗](https://arxiv.org/pdf/2412.14803#page=3)

![VPP overview](../../assets/images/paper-deep-dives/embodied-ai/vpp/figure-1-overview.png){ width="920" }

整体结构中，视频预测负责学习操作会怎样改变画面，Video Former 将多层、多帧、多视角特征压成固定长度 token，动作 diffusion head 再输出连续动作块。这里一次前向属于视觉网络，动作生成仍有自己的多步采样过程。

## 先把通用 SVD 变成语言可控的操作预测器

基础模型是 1.5B Stable Video Diffusion。原始 SVD 主要以首帧为条件，VPP 增加 CLIP 语言特征的 cross-attention，并将视频输出调整为 16 帧、$256\times256$ 分辨率。当前观测 $s_0$ 与每个待预测帧沿通道拼接，作为持续可见的条件。

设干净视频为 $x_0$，前向加噪为

$$
x_t=\sqrt{\bar\alpha_t}x_0+\sqrt{1-\bar\alpha_t}\epsilon.
$$

文本引导预测器直接回归干净视频，原文目标为

$$
\mathcal L_D=\mathbb E_{x_0\sim D,\epsilon,t}
\|V_\theta(x_t,l_{\mathrm{emb}},s_0)-x_0\|^2,
$$

并按人类视频、网络机器人视频和自采数据的来源加权。

$$
\mathcal L_{\mathrm{video}}
=\lambda_H\mathcal L_{D_H}+\lambda_R\mathcal L_{D_R}+\lambda_C\mathcal L_{D_C}.
$$

这个阶段只需视频与语言，不要求所有来源共享机器人动作空间。训练数据同时包含 Something-Something-v2、RT-1、Bridge、BC-Z 等，以及 CALVIN、MetaWorld 与真实机器人视频。因而后续策略继承的既有通用视频先验，也有目标操作域的视频适配。[↗](https://arxiv.org/pdf/2412.14803#page=3)

附录按采样来源列出约 375K 条轨迹，人类视频占采样权重 0.30，CALVIN 与 MetaWorld 分别占 0.10、0.05。视频模型微调在八张 A100 上约需 2–3 天，下游策略在四张 A100 上约需 6–12 小时。这是两阶段方法的实际训练成本，而非只训练一个小动作头的预算。[↗](https://arxiv.org/pdf/2412.14803#page=6)

## 预测特征怎样压缩为动作条件

执行时将当前图像、语言和高噪声 latent 输入冻结 TVP，一次前向就读取上采样层特征。第 $m$ 层为

$$
L_m\in\mathbb R^{T\times C_m\times W_m\times H_m}.
$$

各层先插值到共同空间尺寸，再沿通道拼接。

$$
L'_m=\operatorname{Interpolation}(L_m),\qquad
F_p=\operatorname{Concat}_{\mathrm{channel}}(L'_0,\ldots,L'_m).
$$

多层聚合避免只依赖最终图像中偏重纹理的特征；静态相机和腕部相机分别预测，再交给 Video Former 汇合。[↗](https://arxiv.org/pdf/2412.14803#page=4)

![VPP training pipeline](../../assets/images/paper-deep-dives/embodied-ai/vpp/figure-3-training-pipeline.png){ width="760" }

*原论文方法图。按信息流看，冻结视频模型与可训练 Video Former、动作头之间有明确边界，视频网络不会在动作训练时重新学习全部表示。*

Video Former 使用每帧一组可学习查询，先对相应帧的多视角特征进行空间注意力，再做时间注意力和 FFN。

$$
Q'=\{\operatorname{SpatAttn}(Q[i],F_p^{\mathrm{static}}[i],F_p^{\mathrm{wrist}}[i])\}_i,
\qquad Q''=\operatorname{FFN}(\operatorname{TempAttn}(Q')).
$$

固定长度 $Q''$ 通过 cross-attention 送入动作 DiT。原文 Eq. 6 的动作目标回归干净动作块。

$$
\mathcal L_{\mathrm{diff}}=\mathbb E_{a_0,\epsilon,k}
\|D_\psi(a_k,l_{\mathrm{emb}},Q'')-a_0\|^2.
$$

这种结构可以视为从预测性表示中学习隐式逆动力学，但它没有先解码一段完整未来视频再调用独立 IDM。减少的计算主要来自视觉端只运行一次，以及 Video Former 压缩动作头需要处理的条件。

![One-step prediction](../../assets/images/paper-deep-dives/embodied-ai/vpp/figure-5-one-step-prediction.png){ width="720" }

一次前向可视化中的纹理比 30 步生成粗糙，但物体和机械臂的运动趋势已经可辨。这个图帮助解释为什么粗略未来表示可能足够支持动作；是否有用仍由后续控制消融检验，不能仅从画面观感判断策略质量。

## 连续任务提升来自哪些组件

CALVIN 使用 ABC→D，策略只在 ABC 训练，测试 D 环境中的五个连续语言任务。主指标 Avg. Len 是平均连续完成任务数，上限为 5；同时保留连续五任务全部完成的比例。

| Method | Five-Task Success | Avg. Len |
|---|---:|---:|
| Robo-Flamingo | 0.235 | 2.47 |
| Susie | 0.260 | 2.69 |
| GR-1 | 0.401 | 3.06 |
| Vidman | 0.467 | 3.42 |
| RoboUniview | 0.507 | 3.65 |
| VPP | 0.769 | 4.33 |
| VPP, 10% annotated ABC | 0.453 | 3.25 |

少标签版本平均完成 3.25 个任务，但仍继承视频预训练与视频适配，10% 指动作策略使用的标注数据比例。MetaWorld 则用每任务 50 条示范训练同一个语言条件策略，50 任务平均成功率为 68.2%，GR-1 为 57.4%，相差 10.8 个百分点。[↗](https://arxiv.org/pdf/2412.14803#page=5)

消融保持 CALVIN ABC→D 评测，分别改变视频适配数据、初始化及特征接口。

| Configuration | Avg. Len | Latency |
|---|---:|---:|
| VPP | 4.33 | ≈140 ms |
| w/o Internet Data | 3.97 | ≈140 ms |
| w/o CALVIN Video | 3.31 | ≈140 ms |
| w/o Internet Data and SVD Pretraining | 1.63 | ≈140 ms |
| w/o Video Former | 3.86 | ≈450 ms |
| w/o Feature Aggregation | 3.60 | ≈140 ms |

去掉 CALVIN 视频适配的下降大于去掉额外互联网操作数据，说明目标域预测能力对该设置很重要。去掉 SVD 初始化与互联网数据后降至 1.63，则说明从头在小型目标域数据学习动态不足以复现完整效果。Video Former 既改善成功表现，也将高维特征直接交给动作头的约 450 ms 延迟降至约 140 ms。[↗](https://arxiv.org/pdf/2412.14803#page=7)

单层特征中，第九层平均长度 4.29，已接近聚合的 4.33；聚合相对最终层替代方案的收益更大。再多做一次视频去噪，平均长度为 4.19，并未超过一次前向，却接近翻倍视觉端成本。去掉时间注意力降为 4.18，单视角为 3.58。这里 3.58 是平均任务长度，单视角连续五任务成功率为 0.518，两者单位不同。[↗](https://arxiv.org/pdf/2412.14803#page=15)

## 真机扩展与可用控制速度

Franka Panda 使用约 2000 条示范、30 多个任务，覆盖六类技能；Xarm 搭配 12 自由度 Xhand 的采集覆盖 100 多个任务和 13 类技能。真机的 unseen 以新物体或新背景定义，另外考察勺子、锤子、电钻和移液工具等操作。

![VPP real robots](../../assets/images/paper-deep-dives/embodied-ai/vpp/figure-7-real-robot.png){ width="760" }

| Platform / Setting | Diffusion Policy | Susie | GR-1 | VPP |
|---|---:|---:|---:|---:|
| Franka Seen | 0.42 | 0.56 | 0.52 | 0.85 |
| Franka Unseen | 0.25 | 0.46 | 0.38 | 0.73 |
| Dexterous Seen | 0.28 | 0.45 | 0.32 | 0.75 |
| Dexterous Unseen | 0.11 | 0.28 | 0.15 | 0.60 |
| Dexterous Tool Use | 0.05 | 0.23 | 0.15 | 0.68 |

表中为成功率，Panda 进行了 200 多次 rollout，灵巧手 500 多次。它支持预测性表示跨这些平台和任务类型的用途，但 unseen 条件仍主要是操作对象与场景变化，并不等于任意新技能无需示范。[↗](https://arxiv.org/pdf/2412.14803#page=8)

![VPP predictive representations](../../assets/images/paper-deep-dives/embodied-ai/vpp/figure-12-predictive-representations.png){ width="920" }

*附录中的预测性表示展示。可比较同一指令下机械臂和物体的未来变化，不必把纹理细节是否逼真作为唯一判断。*

RTX 4090 上报告约 7–10 Hz 的策略更新速度；动作头使用 10 步 diffusion sampling，CALVIN/Panda 默认输出 10 个动作，而 MetaWorld 为 4 个。动作块长度、去噪步数和策略更新频率分别描述三个不同环节。VPP 的实用意义，是给出了把视频模型改作快速动态编码器的具体路径，预测未来这一训练任务可以通过中间表示帮助控制，而无需每次先生成可播放的视频。
