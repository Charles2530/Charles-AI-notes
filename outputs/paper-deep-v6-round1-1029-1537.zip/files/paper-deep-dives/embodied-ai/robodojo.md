---
paper_date: 2026-07
paper_title: "RoboDojo: A Unified Sim-and-Real Benchmark for Comprehensive Evaluation of Generalist Robot Manipulation Policies"
paper_topic: 具身智能 / 机器人操作评测
---

# RoboDojo：把仿真诊断与真实部署放进同一张成绩单

!!! info "论文信息"
    **论文题名：** RoboDojo: A Unified Sim-and-Real Benchmark for Comprehensive Evaluation of Generalist Robot Manipulation Policies。<br>
    **作者：** Tianxing Chen、Yue Chen、Zixuan Li、Junyuan Tang、Kailun Su、Haoran Lu、Weijie Wan 等（共 44 人）。<br>
    **机构：** MMLab@HKU、UC Berkeley、Tsinghua University、Peking University、Stanford University、MIT 等 18 家机构。<br>
    **时间 / 主题：** 2026-07；具身智能 / 机器人操作评测。<br>
    **arXiv / 项目：** arXiv：[2607.04434v3](https://arxiv.org/abs/2607.04434v3)；项目页：[robodojo-benchmark.com](https://robodojo-benchmark.com/)。<br>
    **GitHub / 平台：** [RoboDojo-Benchmark/RoboDojo](https://github.com/RoboDojo-Benchmark/RoboDojo)；[XPolicyLab/XPolicyLab](https://github.com/XPolicyLab/XPolicyLab)；[Leaderboard](https://robodojo-benchmark.com/leaderboard)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2607.04434v3)、[官方项目页](https://robodojo-benchmark.com/)；Checked Date：2026-07-14；Repro Status：Paper / official project and public code links reviewed, independent reproduction not claimed。

## 把失败拆开，才能知道策略进步在哪里

机器人完成一次抓放，并不能说明它能记住先前看到的规则、在拥挤场景中辨认目标，或在插入失败后重新对准。已有操作策略又常在不同机器人、任务和部署脚本下评测，分数变化可能同时来自模型、数据、相机和执行方式。RoboDojo 的贡献是建立一套可重复的诊断流程，包含 42 个仿真任务、18 个真实任务和统一策略接入平台 XPolicyLab。[↗](https://arxiv.org/pdf/2607.04434v3#page=3)

![RoboDojo 总览](../../assets/images/paper-deep-dives/embodied-ai/robodojo/figure-1-overview.png){ width="880" }

Figure 1 的连接点是底部的策略接口与评测协议。仿真用于并行运行大量试次、分解能力；真实平台检验接触、动作稳定和部署表现。两端任务并不一一配对，因此这个设计支持互补诊断，不能用两个总分直接计算同一任务的 sim-to-real transfer rate。

论文冻结于 2026 年 7 月 3 日的榜单给出一个直接结果：30 个仿真策略中，最好的平均成功率为 8.80%，专家遥操作为 76.03%；真实评测中的最佳策略 π0.5 为 12.8%。理解这个差距，要先看任务如何划分、总分如何计算，以及训练和评测给了多少数据。

## 五个维度怎样形成不同压力

仿真统一采用 ARX X5 双臂，两个机械臂底座间隔 0.6 m。任务不是只增加物体种类，而是改变完成操作所需的信息与控制条件。[↗](https://arxiv.org/pdf/2607.04434v3#page=5)

![RoboDojo 任务总览](../../assets/images/paper-deep-dives/embodied-ai/robodojo/figure-2-task-overview.png){ width="880" }

Figure 2 将五类仿真任务与三种真实机器人放在一起。读图时应关注任务中的困难来源：消失的物体需要保留历史，细孔与插头需要接触精度，多步骤整理需要判断中间阶段是否完成。

| Dimension | Tasks | 主要压力 | 设计含义 |
| --- | ---: | --- | --- |
| Generalization | 12 | 背景、照明、物体与 clutter 改变 | 同一任务分别在标准场景与随机场景执行 |
| Memory | 6 | 关键观测离开当前画面 | 传送带物体消失后匹配，或模仿另一只手的排序顺序 |
| Precision | 8 | 小误差会阻断接触过程 | 插管、插充电器、投币等要求定位与轨迹稳定共同成立 |
| Long-Horizon | 8 | 多个阶段相互依赖 | 抓取、交接、分类或摆放中的早期失败会影响后续动作 |
| Open | 8 | 缺少目标任务的专门示范 | 在新指令下重组其他训练任务中出现过的技能 |

Generalization 随机场景最多放置 25 个干扰物，增加视觉遮挡与目标选择难度。Memory 任务则制造部分可观测性：只看当前图像可能无法区分正确动作。Open 的关键条件是没有 **task-specific training demonstrations**；这并不意味着策略完全没有相关技能训练，也不能把它简单等同于开放词汇识别。

五维之间有交叉。例如插入任务同时需要视觉泛化、精度和失败恢复；这里的分类用来突出主要压力源，并不声称把机器人能力分成互不相关的五块。

## 数据规模、试次数量与总分口径

仿真提供 35 个训练目录，包括 34 个有训练数据的任务和一个 DLC 辅助目录，每个目录 100 条示范，共 3,500 条轨迹、1,859,602 帧、20.66 小时，记录频率为 25 Hz。DLC 额外提供随机场景下的抓放数据，其目标独立于具体评测任务。因此，随机场景表现差不能归因于训练中绝对没有出现过随机化。[↗](https://arxiv.org/pdf/2607.04434v3#page=7)

每个训练种子评测 42 个任务、每任务 50 个 episode，共 2,100 次。Generalization 的 50 次再分成 25 次标准场景和 25 次随机场景。多数模型训练三个种子，对应每任务累计 150 次试验；论文附录对少数例外单独说明。

指标有两种。Success Rate 要求完整任务成功，Score 则给完成的中间阶段部分分数。模型已经抓到物体但交接失败时，Score 可以显示它完成了部分工作，SR 仍为零。这对长时程任务尤其有用，因为相同的零成功率可能对应完全不同的失败位置。

总体结果先在每个能力维度内求平均，再对五维等权平均。按该协议可写成下面的解释式，其中 $m_t$ 是任务 $t$ 的 Score 或 SR，$\mathcal{T}_d$ 是维度 $d$ 的任务集合。

$$
\mathrm{Overall}(m)=\frac{1}{5}\sum_{d=1}^{5}\left(\frac{1}{|\mathcal{T}_d|}\sum_{t\in\mathcal{T}_d}m_t\right).
$$

这与把 42 个任务直接平均不同。Generalization 有 12 个任务，Memory 只有 6 个，等维度权重避免前者仅凭任务数量主导总分。引用或重算榜单时需要沿用这个口径。[↗](https://arxiv.org/pdf/2607.04434v3#page=13)

## 真实评测如何恢复同样的起点

真实平台使用 ARX X5、Piper 和 Piper X，每种机器人六个任务。每任务由四名操作者合计采集 100 条示范，共 1,800 条轨迹、1,611,841 帧、17.91 小时，同样为 25 Hz。观测包括头部相机、两只腕部相机、机器人状态和语言指令。每种本体使用一个训练种子，每任务评测 10 次，一套策略完成全部真实评测需要 180 次试验。[↗](https://arxiv.org/pdf/2607.04434v3#page=8)

![RoboDojo-RealEval 平台](../../assets/images/paper-deep-dives/embodied-ai/robodojo/figure-7-realeval.png){ width="880" }

Figure 7 展示真实平台的固定几何与 layout replay。硬件区域约为 1.5 m × 1.5 m，桌面约为 1.2 m × 1.2 m，头部与腕部相机分别采用 Gemini 335L 和 Gemini 305。固定安装、受控照明和一致的相对位置减少部署端的变化。

物体重置使用预先记录的目标画面，与实时图像透明叠加。操作者据此复原位置和姿态，比“摆回差不多的位置”更容易检查。评分由三名独立评估者在双盲协议下完成，最终 Score 取平均；视频保留用于复查与申诉。它没有消除物理接触和人工重置的全部噪声，但把主要可控因素变成了明确操作。[↗](https://arxiv.org/pdf/2607.04434v3#page=9)

公开 layout 用于可复现开发，hidden layout 提供补充验证。官方 verified leaderboard 要求在线评测，提交仿真三种子均值与标准差、完成三种真实本体评测、通过隐藏布局验证，并释放实际评测使用的权重、代码、配置、复现材料和视频。远程私有评测可以保留私有，但不因此成为官方 verified 条目。这些规则使分数附带可检查的运行条件，而不仅是一个数字。

## XPolicyLab 把接入成本放在哪一层

RoboDojo 没有要求 diffusion policy、VLA 和 world-model policy 改成相同网络。XPolicyLab 统一策略生命周期：episode 开始调用 `reset`，用 `update_obs` 更新视觉、语言和状态，用 `get_action` 查询动作。策略返回一个 action chunk，环境执行相应动作后再获取新观测并查询。

批量接口为 `update_obs_batch` 和 `get_action_batch(active_indices)`。已结束的环境从 active indices 中移除，剩余环境继续执行；这避免为了同步某个长 episode 而持续给已完成环境推理。接口标准化的是外围数据与执行过程，仍允许模型保留自己的输入预处理、动作表示和推理服务。[↗](https://arxiv.org/pdf/2607.04434v3#page=35)

仿真基于 Isaac Sim / Isaac Lab 和 MagicSim。任务的资产、初始化、成功判定与运行时分离，通过模块化 YAML 配置组合；刚体、关节物体与可变形物体的物理参数采用统一处理。示范生成结合 cuRobo v2 的技能组合和复杂场景中的 VR 遥操作。

异质并行让同一组向量化环境拥有不同的物体数量、几何、关节结构与 clutter。普通批量仿真容易通过复制一个场景提高吞吐，而评测需要同时覆盖不同任务；这里的系统设计使任务多样性可以进入并行执行，而不必为每一类环境完全独立启动一套运行流程。[↗](https://arxiv.org/pdf/2607.04434v3#page=10)

## 低总分背后，各策略擅长什么

下面摘录论文冻结榜单中的代表策略。Score 与 SR 均以百分制表示，Overall 是前述五维宏平均。人类对照来自三名具有超过 1,000 小时仿真遥操作经验、并参与数据构建的专家，不代表普通用户首次操作水平。[↗](https://arxiv.org/pdf/2607.04434v3#page=13)

| Policy | Generalization Score / SR | Precision Score / SR | Long-Horizon Score / SR | Memory Score / SR | Open Score / SR | Overall Score / SR |
| --- | --- | --- | --- | --- | --- | --- |
| Hy-Embodied-0.5 | 11.77 / 8.39 | 13.81 / 8.00 | 25.74 / 14.92 | 13.37 / 12.11 | 0.65 / 0.58 | 13.07 / 8.80 |
| SpatialForcing | 14.12 / 9.33 | 17.33 / 10.58 | 23.26 / 14.58 | 5.43 / 4.11 | 1.78 / 1.58 | 12.38 / 8.04 |
| π0.5 | 13.37 / 8.17 | 12.40 / 5.50 | 23.54 / 14.67 | 5.78 / 4.56 | 1.98 / 1.67 | 11.41 / 6.91 |
| XVLA | 10.48 / 6.78 | 18.32 / 12.00 | 16.53 / 9.75 | 4.76 / 3.56 | 0.55 / 0.50 | 10.13 / 6.52 |
| Human Expert | — | — | — | — | — | 80.42 / 76.03 |

总体第一没有包揽全部能力。SpatialForcing 的 Generalization 更强，XVLA 的 Precision 更强，Hy-Embodied-0.5 在 Memory 与 Long-Horizon 上占优，π0.5 的 Open 最好。即便是 Open 最佳值，SR 也只有 1.67%，说明在缺少任务专门示范时，跨任务技能重组仍然困难。

显式记忆机制也不自动转化为高成功率。EventVLA 的 Memory SR 为 4.78%、Score 为 4.92；XWAM 分别为 4.67% 和 6.32%。历史证据需要继续经过正确的目标判断和动作执行，保存信息只是整个控制链中的一环。

### 随机场景暴露了什么

Generalization 把任务目标保持不变，只改变场景条件，因而能够检查同一策略对外观和布局变化的敏感程度。Table 3 报告的是 **Score**，相对下降按 `(Standard − Randomized) / Standard` 计算。[↗](https://arxiv.org/pdf/2607.04434v3#page=15)

| Policy | Standard Score | Randomized Score | Relative drop |
| --- | ---: | ---: | ---: |
| Hy-Embodied-0.5 | 21.98 | 1.57 | 92.9% |
| SpatialForcing | 21.25 | 6.98 | 67.2% |
| π0.5 | 20.92 | 5.82 | 72.2% |
| XVLA | 17.92 | 3.04 | 83.0% |

Hy-Embodied-0.5 在标准场景得分最高，随机化后却低于另外三种策略。只报告标准场景或总体平均，会掩盖这个排序变化。SpatialForcing 的相对下降较小，但 6.98 的随机场景 Score 仍不支持可靠操作的判断。

失败视频进一步区分了视觉误判与执行纠错问题。在 `insert_key` 中，策略可能未对准或交接失败，却继续执行下一个阶段，说明动作序列与真实完成状态脱节。动作抖动同时出现在末端执行器和关节空间输出策略中，也难以归因于某一种动作表示。这里更需要检查观测是否触发了动作修正，而不只增加一条更长的预生成动作序列。[↗](https://arxiv.org/pdf/2607.04434v3#page=16)

### 真实平台改变了排序

真实榜单评测十个策略，π0.5 的 Overall Score / SR 为 22.9 / 12.8，InternVLA-A1 为 12.0 / 7.2，Galaxea 为 9.0 / 4.4。人类专家为 100 / 100，其经验超过 1,500 小时，并参与了数据采集。[↗](https://arxiv.org/pdf/2607.04434v3#page=14)

这些结果显示仿真领先与真实领先不必重合。不过，由于两端任务不同、训练与试次数量也不同，不能进一步把排序变化分解成某个模型的精确迁移损失。更合理的使用方式是在仿真中定位能力短板，再用真实任务检查这些短板是否影响实际控制。

## 一轮评测需要多少时间，重复结果有多稳定

吞吐实验采用八张 RTX 4090，每张卡一个进程、每进程十个环境，渲染三个 640 × 480 视角。零动作策略排除了模型推理延迟，π0.5 则由同局域网中的 A800 提供远程推理。[↗](https://arxiv.org/pdf/2607.04434v3#page=18)

| Setting | Heterogeneous time | Throughput | Non-heterogeneous time | Throughput | Speedup |
| --- | --- | ---: | --- | ---: | ---: |
| Zero action，约 1.64M frames | 5 h 53 min | 77.4 interactions/s | 11 h 22 min | 40.0 interactions/s | 1.94× |
| π0.5 inference | 7 h 07 min | 64.0 interactions/s | 11 h 38 min | 39.2 interactions/s | 1.63× |

加入真实模型推理后仍有加速，但幅度变小，符合总时间中增加了策略服务开销这一条件。论文同时比较了 RoboTwin 的运行时间，不过任务数量、帧数、分辨率与进程配置不同，那组结果适合估计各自评测预算，不能用于单独测量仿真引擎差异。

真实 π0.5 采用同局域网 RTX 4090 推理，完整运行 18 个任务各 10 次需要 202.0 分钟，约 3.4 小时，平均每任务 11.2 分钟。时间包括重置、推理和执行，并且不提前终止。这使一轮真实比较有了可规划的人工与设备预算。

重复性实验也需要区分总体和单任务。仿真三个训练种子中，整体 SR 的最大标准差为 0.5 个百分点，整体 Score 为 0.49；维度级最大值分别为 1.1 和 1.07。真实重复三轮时，π0.5、Galaxea、InternVLA-A1 的整体 SR 标准差分别为 1.0、1.2、1.3 个百分点，但各自最大的单任务 SR 标准差达到 23.1、15.3、17.3 个百分点。[↗](https://arxiv.org/pdf/2607.04434v3#page=19)

因此，总体分数比较稳定不等于某个十试次任务能稳定区分细小增益。若新方法只改善某个精细接触任务，增加该任务重复次数会比只看总体榜单更有解释力。

## 可以直接复用的是一套诊断过程

RoboDojo 将任务能力轴、策略 adapter、场景恢复、部分进度评分和发布证据连成了可复用流程。做策略研究时，可以先固定训练数据和部署接口，在五维结果中找到变化位置，再用标准／随机场景与失败视频区分感知、记忆、阶段判断和执行问题。做真实机器人应用时，layout overlay、固定相机几何与多评估者评分则可以直接用于降低实验间的偶然差异。

目前评测覆盖的是这些双臂操作平台。触觉、移动操作、灵巧手和人形扩展属于后续计划，不能由当前榜单推断其表现。论文留下的实际问题已经足够具体：当策略记住目标、预测了动作，却没有确认上一步真的完成时，如何把新的观测重新接入控制过程。RoboDojo 提供了能反复暴露这类问题的任务与测量方式。
