---
paper_date: 2023-07
paper_title: "RT-2: Vision-Language-Action Models Transfer Web Knowledge to Robotic Control"
paper_topic: 具身智能 / VLA
---

# RT-2：把 web-scale VLM 变成会输出动作的 VLA

!!! info "论文信息"
    **论文题名：** RT-2: Vision-Language-Action Models Transfer Web Knowledge to Robotic Control。<br>
    **作者：** Anthony Brohan、Noah Brown、Justice Carbajal、Yevgen Chebotar、Xi Chen、Krzysztof Choromanski、Tianli Ding、Danny Driess、Avinava Dubey、Chelsea Finn 等（共 54 人）。<br>
    **机构：** 未在公开元数据中稳定解析；以 arXiv/PDF 或官方页 affiliation block 为准。<br>
    **时间 / 主题：** 2023-07；具身智能。<br>
    **arXiv / 官方报告：** arXiv：[2307.15818](https://arxiv.org/abs/2307.15818)；官方材料：[robotics-transformer2.github.io/](https://robotics-transformer2.github.io/)。<br>
    **GitHub / 项目：** GitHub：未找到官方链接；项目页：[robotics-transformer2.github.io/](https://robotics-transformer2.github.io/)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2307.15818)；[官方 / 项目材料](https://robotics-transformer2.github.io/)；Checked Date：2026-06-15；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 视觉语言知识怎样直接进入控制输出

RT-2 的关键实验是将已经会看图和回答问题的 VLM，直接微调为预测机器人动作的模型。动作被转换为离散 token，和语言回答使用同一输出空间；机器人示范与原视觉语言数据共同训练。由此，互联网知识可以参与决定抓哪个物体、放到什么语义位置，而运动执行仍由机器人示范教会。[↗](https://arxiv.org/pdf/2307.15818#page=5)

![RT-2 overall 原论文图](../../assets/images/paper-deep-dives/embodied-ai/rt2/figure-1-overview.png){ width="920" }

*来源：原论文 Figure 1。先看 web data 与 robot data 如何进入同一个模型，再看输出 token 怎样还原为机器人动作。*

这种设计与让语言模型只输出高层计划不同，也与冻结视觉编码器再训练一个小策略不同。RT-2 让用于语言和动作的模型权重共同适配，机器人控制成为 VLM 的一个输出任务。论文使用 PaLI-X 5B/55B 和 PaLM-E 12B 两类骨干，从而检查该思路是否依赖某一个架构。

## 动作字符串的语义必须固定

一个动作包含终止命令、末端位置增量三维、旋转增量三维以及夹爪开合，共八个分量。连续分量均匀离散为 256 bins，用相应 bin 编号作为 token。输入以 VQA 形式给出当前图像和任务，模型输出顺序固定的动作串，再由控制接口反量化。

PaLI-X 的 tokenizer 中，所需整数已有单独 token，可以直接使用；PaLM-E 则用 256 个低频 token 重新定义动作词表。动作不是普通语言中任意一串数字，训练和执行必须共享每个位置的物理含义、取值范围和终止编码。解码时，机器人任务只允许采样合法动作 token，普通 VQA 任务仍开放完整语言词表。[↗](https://arxiv.org/pdf/2307.15818#page=6)

这个统一接口让原有 next-token 训练可以继续使用，不需要额外动作专用网络层。其代价是连续控制经过量化，多个动作分量要自回归生成，模型推理时间会直接进入控制闭环。

## 为什么继续混合 web 数据

只在机器人示范上微调，可能让模型忘掉原有的语义与视觉概念。RT-2 在每个 batch 中继续保留 VQA、图像描述和交错图文数据，同时提高机器人样本采样权重，使动作学习获得足够梯度。训练数据中的机器人示范来自 13 台机器人、17 个月的办公室厨房采集，每段有自然语言任务标注。

消融分别比较从头训练、仅机器人微调、web 与机器人共同微调，以及 5B/55B 规模。原文观察到 5B 从头训练表现很差；预训练和混合微调均改善泛化，较大模型进一步提高表现。这个证据链支持“预训练知识在动作适配期间需要保留”，不能仅用 55B 大于 35M 来解释全部差距。[↗](https://arxiv.org/pdf/2307.15818#page=10)

## 见过的技能与未见的场景应分开评估

论文开展约 6000 条真实机器人评测轨迹。已见任务包含拾取、移动、摆正、抽屉操作等，测试仍随机改变物体位置、时间和机器人位置；泛化测试另分新物体、新背景和新环境，各自设 easy/hard 条件。

| Model | Seen Tasks (%) | Unseen Objects Easy/Hard (%) | Unseen Backgrounds Easy/Hard (%) | Unseen Environments Easy/Hard (%) | Unseen Average (%) |
|---|---:|---|---|---|---:|
| RT-1 | 92 | 31 / 43 | 71 / 9 | 26 / 14 | 32 |
| MOO | 75 | 58 / 48 | 38 / 41 | 19 / 3 | 35 |
| RT-2-PaLI-X-55B | 91 | 70 / 62 | 96 / 48 | 63 / 35 | 62 |
| RT-2-PaLM-E-12B | 93 | 84 / 76 | 75 / 71 | 36 / 33 | 62 |

表中是原 Appendix Table 4。已见任务没有显著拉开差距，未见条件平均从 RT-1 的 32% 提升到 62%。两个 RT-2 平均相同，但 PaLM-E 更擅长表内某些新物体和背景条件，PaLI-X 在 easy 新环境上更强；一个平均值掩盖了不同预训练配方带来的偏好。[↗](https://arxiv.org/pdf/2307.15818#page=23)

![RT-2 generalization 原论文图](../../assets/images/paper-deep-dives/embodied-ai/rt2/figure-4-generalization.png){ width="860" }

*来源：原论文 Figure 4。先比较 seen 与 unseen 两组，再比较各 unseen 轴，避免把整体提升理解为新的低层运动能力。*

开放 Language-Table 仿真提供另一种机器人和二维动作空间的对照。RT-2-PaLI-3B 达到 $90\pm10$，RT-1 为 $74\pm13$，LAVA 为 $77\pm4$。这一版本仅预测二维位移，运行约 5 Hz；不能与真实机器人八维动作模型的成功率合并。[↗](https://arxiv.org/pdf/2307.15818#page=9)

## 所谓涌现，主要是旧动作的新语义用法

作者将新能力分为符号理解、推理和人物相关理解。例如把物体移动到数字或图标附近、按颜色关系选择容器、理解另一种语言的指令。评测用 A/B 框架让不同模型依次面对相同场景，降低摆放差异带来的方差。

![RT-2 emergent examples](../../assets/images/paper-deep-dives/embodied-ai/rt2/figure-2-emergent-examples.png){ width="860" }

*来源：原论文 Figure 2。先识别任务要求的语义推断，再看其最终是否仍由抓取、移动、放置这些已学习运动实现。*

![RT-2 emergent ablation 原论文图](../../assets/images/paper-deep-dives/embodied-ai/rt2/figure-6-emergent-ablation.png){ width="860" }

*来源：原论文 Figure 6，涌现能力与规模、训练方式的对照。左侧测试不同语义要求，右侧用于分析预训练和 co-fine-tuning 的作用。*

“把快掉下桌子的袋子拿起来”需要识别关系与状态，但最终执行仍是已有抓取技能。论文明确指出，web 预训练没有让机器人凭空学会新的运动动态。这一区分决定了可部署范围：陌生对象的语义理解可能成功，陌生质量、摩擦、形变或运动模式仍可能失败。

![RT-2 failure dynamics](../../assets/images/paper-deep-dives/embodied-ai/rt2/figure-9-failure-dynamics.png){ width="860" }

*来源：原论文 Figure 9，未见物体动态导致的失败例子。*

## 将计划和动作写进同一次生成

链式推理变体在数据中增加 Plan 字段，让模型先用语言说明即将采取的子任务，再生成动作 token。作者用 PaLM-E 变体额外微调数百步，展示了根据“需要锤钉子”等意图选择物品的例子。这证明统一语言—动作输出可以容纳显式中间决策，但该部分主要为定性展示，不能从示例数量推断稳定的长任务成功率。

![RT-2 chain-of-thought rollouts](../../assets/images/paper-deep-dives/embodied-ai/rt2/figure-7-cot-rollouts.png){ width="860" }

*来源：原论文 Figure 7。每个例子都应同时看语言计划是否合理，以及后续动作是否能执行。*

## 计算接口决定了这条路线的使用条件

RT-2 的大模型通过网络访问多 TPU 云端服务。55B PaLI-X 的控制频率约 1–3 Hz，5B 约 5 Hz。这个速度在论文操作任务中可用，却明显限制了对快速接触变化的响应；云端往返延迟也属于控制链路的一部分。[↗](https://arxiv.org/pdf/2307.15818#page=6)

RT-2 留下的可复用方案是将动作加入已有多模态模型的 token 空间，并在适配时继续保留非机器人任务。真正迁移的是视觉和语义决策能力，动作执行能力、控制频率和动力学范围仍需要由机器人数据与部署系统承担。
