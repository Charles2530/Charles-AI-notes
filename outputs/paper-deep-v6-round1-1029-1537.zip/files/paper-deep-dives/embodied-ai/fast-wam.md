---
paper_date: 2026-03
paper_title: "Fast-WAM: Do World Action Models Need Test-time Future Imagination?"
paper_topic: 具身智能 / WAM
---

# Fast-WAM：WAM 一定要推理时想象未来吗

!!! info "论文信息"
    **论文题名：** Fast-WAM: Do World Action Models Need Test-time Future Imagination?。<br>
    **作者：** Tianyuan Yuan、Zibin Dong、Yicheng Liu、Hang Zhao。<br>
    **机构：** IIIS, Tsinghua University；Galaxea AI。<br>
    **时间 / 主题：** 2026-03；具身智能 / World Action Model。<br>
    **arXiv / 官方报告：** arXiv v1：[2603.16666v1](https://arxiv.org/html/2603.16666v1)；PDF：[2603.16666](https://arxiv.org/pdf/2603.16666)；项目页：[yuantianyuan01.github.io/FastWAM/](https://yuantianyuan01.github.io/FastWAM/)。<br>
    **GitHub / 项目：** GitHub：[github.com/yuantianyuan01/FastWAM](https://github.com/yuantianyuan01/FastWAM)；项目页：[Fast-WAM](https://yuantianyuan01.github.io/FastWAM/)。<br>
    **元数据来源与核验口径：** 来源：[arXiv v1 HTML](https://arxiv.org/html/2603.16666v1)、[arXiv TeX Source](https://arxiv.org/src/2603.16666v1)、[项目页](https://yuantianyuan01.github.io/FastWAM/)、[GitHub API / repo](https://github.com/yuantianyuan01/FastWAM)；Checked Date：2026-06-16；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。注意：arXiv abstract 页已提示存在 v2，本文按用户指定的 v1 HTML 和 v1 TeX 源文件解读。

## 未来视频可以只在训练时发挥作用吗

Fast-WAM 把 world–action model 的两个环节拆开检验。训练时预测未来画面，可以迫使模型理解动作相关的视觉变化；执行时继续生成整段未来视频，却会让每次控制更新承担视频去噪的成本。论文构造一种注意力结构，让策略保留视频预测训练带来的表示收益，同时在执行时完全移除未来视频 token。[↗](https://arxiv.org/pdf/2603.16666#page=2)

![Fast-WAM paradigms](../../assets/images/paper-deep-dives/embodied-ai/fast-wam/figure-1-paradigms.png){ width="920" }

图中三条路径分别是联合视频动作生成、先视频后逆动力学，以及 Fast-WAM。先看未来视频是否出现在动作所依赖的计算路径里，再比较采样次数。Fast-WAM 的核心改变是依赖关系，单纯缓存一个普通联合模型并不能得到相同结果。

## 注意力掩码先保证可删，再谈加速

模型由 Wan2.2-5B 视频 DiT 和约 1B 的动作专家构成，动作专家隐藏维度为 1024，总规模约 6B。两个专家通过 Mixture-of-Transformers 的共享注意力接口交互，但保留各自参数。输入分成三组：干净的当前观测 token、带噪未来视频 token、带噪动作 token。

![Fast-WAM model architecture](../../assets/images/paper-deep-dives/embodied-ai/fast-wam/figure-2a-model-architecture.png){ width="780" }

*原论文 Figure 2(a)。视频骨干同时承担当前观测表示和训练期的视频生成，动作专家通过对应层的注意力读取观测特征。*

![Fast-WAM attention mask](../../assets/images/paper-deep-dives/embodied-ai/fast-wam/figure-2b-attention-mask.png){ width="460" }

Figure 2(b) 是整个方法最关键的约束。当前观测只看自身；未来视频可以看当前观测与未来视频；动作可以看当前观测与动作，不能看未来视频。因而当前观测特征不依赖未来噪声，动作输出也不依赖未来视频的生成状态。

这一掩码产生两种不同的联系。前向计算时，动作与未来视频隔开；训练更新时，预测未来视频的梯度仍更新共享的视频骨干，使当前观测表示包含预测动态所需的信息。执行时只需让视频骨干处理一次当前观测，缓存逐层 K/V，动作专家就可以反复读取这些固定特征完成去噪。[↗](https://arxiv.org/pdf/2603.16666#page=4)

所谓 one-pass 指大视频骨干对当前观测的一次处理。实验中的动作专家仍执行 **10 步去噪**，不能将其理解为一次前向就输出最终动作，也不能与一步动作蒸馏混为同一种加速。

## 视频监督与动作监督怎样共享表示

两路都采用 flow matching。对干净目标 $y$、高斯噪声 $\epsilon$，论文使用

$$
y_t=(1-t)y+t\epsilon,
\qquad v^*=\epsilon-y.
$$

这里 $t=0$ 为干净目标、$t=1$ 为噪声，采样时沿反向路径恢复目标。视频与动作各自预测速度场，联合损失为

$$
\mathcal L=\mathcal L_{\mathrm{act}}+\lambda\mathcal L_{\mathrm{vid}}.
$$

$\lambda$ 控制视频监督在训练中的比重。方法的可检验主张是，第二项改善了观测编码，而执行时动作条件并不需要未来视频自身。论文因此设置 no-video 对照，仅去掉视频预测目标，保留相同部署结构；它比直接与另一种骨干的 VLA 比较更能隔离视频监督的作用。[↗](https://arxiv.org/pdf/2603.16666#page=4)

具体实现预测 32 个动作，视频按四倍间隔采样为 9 帧，多视角拼接输入。训练使用 AdamW，学习率 $10^{-4}$、weight decay 0.01，推理 CFG 为 1.0。动作维持稠密采样，视频使用更稀疏的时间轴，避免将每个动作步都扩成大量视觉 token。

## 用受控对照区分动态监督和显式想象

作者在同一骨干和数据上训练四种方式。Joint 允许视频与动作相互可见；IDM 先生成视频，再从视频生成动作；Fast-WAM 使用上述掩码；no-video 去掉视频损失。IDM 训练时以概率 0.5 给真实视频加入噪声，以缓解训练时看真视频、执行时看生成视频的分布差异。

RoboTwin2.0 使用 50 个任务，共 2500 条 clean 与 25000 条 randomized 示范，训练 30K 步，每任务测试 100 次。LIBERO 四套任务各有 500 条示范，训练 20K 步，总计 2000 次测试。

| Method | RoboTwin2.0 Average (%) | LIBERO Average (%) |
|---|---:|---:|
| Fast-WAM | 91.8 | 97.6 |
| Joint | 90.6 | 98.5 |
| IDM | 91.3 | 98.0 |
| Fast-WAM w/o video objective | 83.8 | 93.5 |

Fast-WAM 的 RoboTwin clean/randomized 分别为 91.88/91.78；LIBERO Spatial/Object/Goal/Long 分别为 98.2/100/97.0/95.2。移除未来视频的执行期计算后，RoboTwin 没有下降，LIBERO 比 Joint 低 0.9 个百分点。相反，移除训练期视频目标使两个 benchmark 分别下降 8.0 与 4.1 个百分点。这组对照支持视频预测能够通过训练改善策略表示，同时表明“执行时生成视频”并非这些任务达到高分的必要条件。[↗](https://arxiv.org/pdf/2603.16666#page=6)

与外部模型比较时，RoboTwin 中预训练 LingBot 为 92.2、Motus 为 87.8、π0.5 为 79.8。Fast-WAM 没有进行额外的具身预训练，但继承了大型视频模型的预训练，不能称作完全从头学习。不同模型的预训练规模也使这组排名无法单独证明某种架构更高效。

## 真机结果把节省的计算变成控制延迟

真机任务是在 Galaxea R1 Lite 上折毛巾，使用约 60 小时示范并训练 30K 步。它要求抓取、展开和折叠可形变物体，能检验策略是否仅在结构化仿真里受益。

![Fast-WAM real-world towel folding task](../../assets/images/paper-deep-dives/embodied-ai/fast-wam/figure-3-towel-folding-task.png){ width="920" }

*原论文 Figure 3。任务包含连续操作与形状变化，完成一部分折叠与完整成功分别计分。*

![Fast-WAM real-world performance and latency](../../assets/images/paper-deep-dives/embodied-ai/fast-wam/figure-4-realworld-results-latency.png){ width="760" }

Figure 4 应同时读成功率、完成程度和延迟。预训练 π0.5 的任务成功与完成表现最好，Fast-WAM 的几种视频训练版本表现接近；no-video 只有约 10% 成功率，而且完成任务耗时最长。因此真机证据同样支持训练视频目标的价值，但没有支持 Fast-WAM 全面优于预训练 VLA。

延迟在 **RTX 5090D V2 32GB** 上测量。

| Method | Inference Latency (ms) |
|---|---:|
| Pretrained π0.5 | 180 |
| Fast-WAM | 190 |
| Fast-WAM w/o video objective | 190 |
| Joint | 580 |
| IDM | 810 |

按表内数据计算，Fast-WAM 比 Joint 快约 $580/190=3.05$ 倍，比 IDM 快约 $810/190=4.26$ 倍。它与 no-video 延迟相同，恰好说明训练期视频监督没有留下执行期未来视频生成成本。[↗](https://arxiv.org/pdf/2603.16666#page=7)

这项设计最适合当前观测足以决定下一动作块、而视频骨干计算昂贵的策略。若应用依赖显式多候选规划、长时程想象或对未来轨迹进行外部筛选，删除未来视频会改变任务接口；本文的单动作块评测并未检验那些需求。可直接复用的做法，是在训练阶段通过注意力约束建立可分离的计算图，再让部署缓存与这个约束严格一致。
