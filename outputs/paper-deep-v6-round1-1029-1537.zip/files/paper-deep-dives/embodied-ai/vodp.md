---
title: VO-DP：RGB-only 扩散策略怎样借用语义和几何特征
paper_date: 2025-10
paper_title: "VO-DP: Semantic-Geometric Adaptive Diffusion Policy for Vision-Only Robotic Manipulation"
paper_topic: 具身智能
---

# VO-DP：RGB-only 扩散策略怎样借用语义和几何特征

!!! info "论文信息"
    **论文题名：** VO-DP: Semantic-Geometric Adaptive Diffusion Policy for Vision-Only Robotic Manipulation。<br>
    **作者：** Zehao Ni、Yonghao He、Lingfeng Qian、Jilei Mao、Fa Fu、Wei Sui、Hu Su、Junran Peng、Zhipeng Wang、Bin He。<br>
    **机构：** National Key Laboratory of Autonomous Intelligent Unmanned Systems、University of Science and Technology Beijing、State Key Laboratory of Multimodal Artificial Intelligence System (MAIS)、Institute of Automation of Chinese Academy of Sciences。<br>
    **时间 / 主题：** 2025-10；具身智能。<br>
    **arXiv / 官方报告：** arXiv：[2510.15530](https://arxiv.org/abs/2510.15530)；官方材料：[d-robotics-ai-lab.github.io/vodp/](https://d-robotics-ai-lab.github.io/vodp/)。<br>
    **GitHub / 项目：** GitHub：[github.com/D-Robotics-AI-Lab/DRRM](https://github.com/D-Robotics-AI-Lab/DRRM)；项目页：[d-robotics-ai-lab.github.io/vodp/](https://d-robotics-ai-lab.github.io/vodp/)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2510.15530)；[GitHub API / repo](https://github.com/D-Robotics-AI-Lab/DRRM)；[官方 / 项目材料](https://d-robotics-ai-lab.github.io/vodp/)；Checked Date：2026-06-15；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 单视角 RGB 能否获得接近点云策略的操作精度

VO-DP 将 VGGT 学到的几何表示接入 Diffusion Policy。策略输入只有单视角 RGB 图像与机器人本体状态，不使用深度图、显式点云或相机外参作为控制输入；它同时提取 DINOv2 的语义特征与 VGGT alternating-attention 后的几何特征，再压缩为动作生成条件。论文检验的是几何预训练能否缩小 RGB 策略与原生点云策略的差距。[↗](https://arxiv.org/pdf/2510.15530#page=3)

![VO-DP overview 原论文图](../../assets/images/paper-deep-dives/embodied-ai/vodp/figure-1-overview.png){ width="920" }

“Vision-only”描述外部感知模态，机器人关节状态仍在输入中。VGGT 的三维先验也来自预训练，因此这不是完全不使用三维知识的策略。

## 从视觉骨干抽出两种互补表示

设观测历史包含 $T$ 帧图像和 $J$ 维状态，动作为长度 $N$ 的关节轨迹。

$$
O_t=\{I_t\in\mathbb R^{T\times H\times W\times3},
S_t\in\mathbb R^{T\times J}\},\qquad
A_t\in\mathbb R^{N\times J}.
$$

DINOv2 将每帧切成 $P$ 个 token，得到 $h_t^{\mathrm{sem}}\in\mathbb R^{T\times P\times C}$。这些 token 再通过 VGGT 的 24 个 alternating-attention blocks，交替进行帧内与全局注意力。论文取最后一层的两类输出拼接，构成 $h_t^{\mathrm{geo}}\in\mathbb R^{T\times P\times2C}$。

![VO-DP architecture 原论文图](../../assets/images/paper-deep-dives/embodied-ai/vodp/figure-2-framework.png){ width="920" }

框架图中应先看语义与几何特征在哪处分叉，再看如何重新汇合。策略使用的是几何骨干的中间表示，并未要求每次把深度、点云和相机参数完整解码后交给动作头。

对一帧的几何特征 $g$ 和语义特征 $s$，先沿特征维平均池化，将 $2C$ 降到 $C$，再以几何为 query、语义为 key/value 做残差 cross-attention。

$$
h'=\operatorname{AvgPool}(g),\qquad
h''=h'+\operatorname{CrossAttn}(h'W_Q,sW_K,sW_V),
$$

$$
h_t^{\mathrm{sg}}[i]=h''+\operatorname{FFN}(h'').
$$

这里池化作用在特征维，不是把两个图像 patch 合成一个；空间布局仍保留给后续压缩器。几何 query 帮助策略按空间关系选择语义信息，但哪些任务真正受益，要由融合消融确定。[↗](https://arxiv.org/pdf/2510.15530#page=3)

## 保留 patch 布局，再交给扩散动作头

融合 token 还原为二维 patch grid，经三个 $3\times3$、stride 2 的残差块降采样，再用自适应平均池化和 MLP 压缩，与本体状态拼接。

$$
h_t^{\mathrm{sc}}=[\operatorname{MLP}(h_t^{\mathrm{sp}}),S_t].
$$

动作头沿用 Diffusion Policy 的 DDPM 噪声预测，通过带噪轨迹 $A_t^k$ 和场景表示预测噪声，损失为

$$
\mathcal L(\theta)=\operatorname{MSE}
\bigl(\epsilon_k,\epsilon_\theta(h_t^{\mathrm{sc}},A_t^k,k)\bigr).
$$

其主要变化发生在感知条件，而非重新设计扩散动作分布。实验输出长度 $N=8$，VO-DP 使用三帧历史，VO-DP-1 使用单帧；两者都训练 300 epochs，batch 128、学习率 $10^{-4}$，在八张 A100 上使用 bf16。[↗](https://arxiv.org/pdf/2510.15530#page=4)

![RoboTwin reconstruction 原论文图](../../assets/images/paper-deep-dives/embodied-ai/vodp/figure-3-robotwin-reconstruct.png){ width="920" }

几何重建展示用于说明视觉骨干具有场景空间信息。它与策略输入的区别是，控制网络读取潜在特征；重建图像看起来合理，不等于所有抓取位置已经满足执行误差要求。

## 仿真平均值接近，但任务差异很大

RoboTwin 主表覆盖 14 个任务，比较普通 RGB Diffusion Policy（DP）、点云 DP3 和两个 VO-DP 版本。

| Method | Average Success (%) | Pick Apple Messy (%) | Container Place (%) | Diverse Bottles Pick (%) | Blocks Stack Easy (%) |
|---|---:|---:|---:|---:|---:|
| DP | 34.8 | 31.0 | 14.0 | 7.3 | 3.7 |
| DP3 | 64.0 | 18.7 | 83.7 | 60.7 | 22.0 |
| VO-DP, 3 frames | 63.9 | 80.0 | 43.0 | 32.3 | 52.3 |
| VO-DP-1, 1 frame | 64.6 | 81.7 | 31.3 | 31.3 | 69.3 |

VO-DP 的平均成绩确实接近 DP3，但 Container Place 和 Diverse Bottles Pick 仍落后很多；混乱苹果拾取和叠块则明显领先。收益可能来自识别与空间先验的组合，不能把平均持平解释成 RGB 已在每类精细几何任务中替代点云。单帧平均比三帧高 0.7 个百分点，后续真机采用单帧版本；该结果也未支持更长观测历史必然更好。[↗](https://arxiv.org/pdf/2510.15530#page=6)

五任务融合消融中，完整模型平均 80.0%，去掉几何为 71.12%，去掉语义为 63.9%。但只用语义的 Dual Bottles Pick Easy 达到 95.3%，高于完整模型的 88.3%；Put Apple Cabinet 和 Blocks Stack Easy 也有相同方向的例外。因此融合改善的是整体任务组合，任务特异的感知需求仍然存在。

几何维度压缩的 MLP 版本为 79.7%，平均池化为 80.0%，额外参数没有带来清楚收益。示范数从 20 增至 100 时，复杂任务提升明显，例如苹果拾取约从 3.0% 到 80.0%；少量数据起点仍很低，不能只用增长斜率将其描述成所有任务都已具备很高的小样本能力。

## 真机比较的感知与采集条件

真实系统使用 Realman RM65-B、Inspire 夹爪和 RealSense L515。L515 为对照实验同时提供 RGB 与点云，VO-DP 只读取 RGB；论文展示了降低策略输入传感需求的可能性，没有实际测量低价 RGB 相机替换后的硬件成本与性能。

![Real-world setup 原论文图](../../assets/images/paper-deep-dives/embodied-ai/vodp/figure-5-realworld-setup.png){ width="780" }

每任务收集 200 条示范，按工作区域网格随机放置物体，使训练与测试均覆盖不同空间位置。DP3 使用人工定义的点云操作区域，叠块任务使用含颜色的 DP3 版本，以便辨别不同颜色方块。

![Real-world tasks 原论文图](../../assets/images/paper-deep-dives/embodied-ai/vodp/figure-4-realworld-tasks.png){ width="920" }

| Method | Small Cube PnP (%) | Big Cube PnP (%) | Cover Cuboid (%) | Stack Cubes (%) | Average (%) |
|---|---:|---:|---:|---:|---:|
| DP | 23.3 | 16.7 | 3.3 | 1.7 | 11.2 |
| DP3 | 73.3 | 68.3 | 75.0 | 53.3 | 67.5 |
| VO-DP-1 | 96.7 | 91.7 | 93.3 | 70.0 | 87.9 |

四个任务包含 3 cm/5 cm 方块拾放、用杯子罩住长方体和叠放 3 cm 方块。VO-DP-1 平均高于 DP3 20.4 个百分点，说明在这套真实视觉与点云处理条件下，预训练 RGB 表示可比当前点云管线更有效。作者将 DP3 的落差联系到深度噪声和预处理，但没有逐一隔离这些因素，不能把差距全部归于深度传感器。[↗](https://arxiv.org/pdf/2510.15530#page=7)

## 鲁棒性不是单一分数

![Robustness environments 原论文图](../../assets/images/paper-deep-dives/embodied-ai/vodp/figure-7-environment.png){ width="820" }

![Robustness tests 原论文图](../../assets/images/paper-deep-dives/embodied-ai/vodp/figure-8-robustness-tests.png){ width="920" }

同一 3 cm 方块拾放策略在不同扰动下呈现不同边界。原尺寸成功率为 85%，改为 2.5 cm 或 5 cm 后为 60% 和 50%；三者平均 65%。几何尺寸变化仍造成明显损失，所以结果支持部分尺度迁移，不支持严格的尺度不变性。

随机开关灯和闪烁照明分别为 80% 与 85%，接近正常照明的 85%；背景替换四条件平均 87.5%。颜色变化则更难，接近训练橙色的黄色表现较好，蓝色和绿色下降明显，四颜色平均 66.3%。这些结果将较强的照明、背景稳定性与较弱的物体外观、尺度迁移分开。[↗](https://arxiv.org/pdf/2510.15530#page=8)

VO-DP 的可复用部分是几何基础模型的特征接口：保留早期语义、读取深层几何、轻量融合，再接已有动作 diffusion head。它展示了无需显式点云也能使用三维预训练知识的路线，同时提示选型应按任务检查短板，尤其是结构化容器操作与新尺寸对象，不能仅根据跨任务平均分决定感知方案。
