---
title: DreamZero：世界动作模型为什么可以做零样本策略
paper_date: 2026-02
paper_title: "World Action Models are Zero-shot Policies"
paper_topic: 具身智能 / VLA
---

# DreamZero：世界动作模型为什么可以做零样本策略

!!! info "论文信息"
    **论文题名：** World Action Models are Zero-shot Policies。<br>
    **作者：** Seonghyeon Ye、Yunhao Ge、Kaiyuan Zheng、Shenyuan Gao、Sihyun Yu、George Kurian、Suneel Indupuru、You Liang Tan、Chuning Zhu、Jiannan Xiang 等（共 36 人）。<br>
    **机构：** NVIDIA。<br>
    **时间 / 主题：** 2026-02；具身智能。<br>
    **arXiv / 官方报告：** arXiv：[2602.15922](https://arxiv.org/abs/2602.15922)；官方材料：[dreamzero0.github.io/](https://dreamzero0.github.io/)。<br>
    **GitHub / 项目：** GitHub：[dreamzero0/dreamzero](https://github.com/dreamzero0/dreamzero)；项目页：[dreamzero0.github.io/](https://dreamzero0.github.io/)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2602.15922)；[官方 / 项目材料](https://dreamzero0.github.io/)；[官方 GitHub](https://github.com/dreamzero0/dreamzero)；Checked Date：2026-06-16；Repro Status：Paper / official materials / official GitHub reviewed, independent reproduction not claimed。

## 将视频预测能力接到机器人动作上

DreamZero 研究的是一个直接的迁移问题。大视频模型见过大量运动、接触和物体变化，但它们输出像素；机器人需要的是与自身关节、相机和控制周期对应的动作。论文以 Wan2.1-I2V-14B-480P 为骨干，把未来视频与动作放进同一个生成模型，用约 500 小时的 AgiBot 数据学习这种对应关系，再检验未见过的任务和环境能否直接执行。[↗](https://arxiv.org/pdf/2602.15922#page=6)

![DreamZero overview](../../assets/images/paper-deep-dives/world-models/dreamzero/figure-1-overview.png){ width="920" }

图中值得关注的是视频预训练到机器人策略之间的接口。视频模型提供的是视觉动态先验，动作编码器、解码器和机器人训练数据负责把它转换为可执行控制。这里的 zero-shot 指特定下游任务无需再收集机器人示范微调，不代表模型没有接受机器人训练。

论文用下式说明视频和动作之间的关系。给定语言 $c$、本体状态 $q_l$ 和视觉历史 $o_{0:l}$，联合分布可拆为未来视频预测与逆动力学。

$$
\pi(o_{l:l+H},a_{l:l+H}\mid o_{0:l},c,q_l)
=\pi(o_{l:l+H}\mid o_{0:l},c,q_l)
\pi(a_{l:l+H}\mid o_{0:l+H},q_l).
$$

第一个因子回答接下来会看到什么，第二个因子把视觉变化与动作联系起来。DreamZero 实际训练一个端到端联合模型，两个因子并非部署时串联的两张独立网络。这个区别影响延迟，也使动作损失能够参与共享表示的学习。

![Joint video and action prediction](../../assets/images/paper-deep-dives/world-models/dreamzero/figure-2-joint-video-action.png){ width="920" }

*原论文 Figure 2。未来画面与动作共享生成过程，图中的视觉变化是控制预测的一部分监督。*

## 以真实历史约束每一段未来

骨干之外新增状态编码器、动作编码器和动作解码器；文本编码器、图像编码器与 VAE 冻结，DiT 和新增模块更新。多视角输入先拼成一张画面，以沿用视频骨干。模型按 chunk 自回归预测视频，当前 chunk 内的视频和动作联合去噪；视觉历史提供连续上下文，动作则保持闭环生成，避免直接累积过去动作预测的误差。

![DreamZero architecture](../../assets/images/paper-deep-dives/world-models/dreamzero/figure-4-architecture.png){ width="920" }

沿 Figure 4 从左向右看，先是观测、语言和状态进入模型，再是当前视频与动作块生成，最后是执行后的真实观测回填。尤其应看右侧 KV cache 的更新方式：执行一块动作之后，用实际看到的画面替换此前预测的画面。后续决策因此依据真实状态继续生成，减少沿想象历史越走越偏的问题。

训练采用 teacher forcing，当前带噪块以先前干净块为上下文。对第 $k$ 块，视频 latent 和归一化动作分别为 $z_1^k,a_1^k$，高斯噪声为 $z_0^k,a_0^k$，插值为

$$
z_{t_k}^k=t_kz_1^k+(1-t_k)z_0^k,\qquad
 a_{t_k}^k=t_ka_1^k+(1-t_k)a_0^k.
$$

这里 $t=0$ 是纯噪声，$t=1$ 是干净数据。初始训练让同一块的视频、动作共享 $t_k$，不同块独立采样。网络预测联合速度

$$
v^k=[z_1^k-z_0^k,\ a_1^k-a_0^k],
$$

并最小化原文的加权 flow-matching 目标

$$
\mathcal L(\theta)=\mathbb E\!\left[
\frac1K\sum_{k=1}^{K}w(t_k)
\left\|u_\theta([z_{t_k}^k,a_{t_k}^k];\mathcal C_k,c,q_k,t_k)-v^k\right\|^2
\right].
$$

$\mathcal C_k$ 表示先前干净块构成的上下文，$w(t_k)$ 调节不同噪声位置的损失权重。动作误差和视频误差进入同一目标，要求生成过程同时满足视觉动态与控制对应，而非单独优化画面观感。[↗](https://arxiv.org/pdf/2602.15922#page=7)

![DreamZero attention strategy](../../assets/images/paper-deep-dives/world-models/dreamzero/figure-14-attention-strategy.png){ width="860" }

*原论文 Appendix Figure 14。按块的注意力可见性决定哪些历史可以缓存，以及当前视频和动作如何交换信息。*

实际策略保留约 6 秒视觉历史。它有助于处理近期运动上下文，但论文没有专门检验需要长期记忆的任务，因而不能把可缓存历史直接等同于长期记忆能力。

## 数据的多样性承担了什么作用

AgiBot 数据约 500 小时，覆盖 22 个环境、7193 条轨迹，平均每条 4.4 分钟、42.4 个子任务。作者保留相对多样的日常操作，过滤闲置动作，默认使用相对关节位置作为动作表示。Franka 的 DROID 模型单独训练，不能将两套结果描述成一个同时预训练于两种本体的策略。

两个模型均训练 100K 步、全局 batch 128。受控消融进一步固定 50K 步和 batch 32：同为 500 小时数据，重复操作数据的简单拾放进度为 $33\pm4.2$，多样数据达到 $50\pm6.3$；5B 与 14B 在这一设置中分别为 $21\pm4.2$ 和 $50\pm6.3$。数据覆盖与模型容量各自都影响收益，不能将结果只归因于 14B 视频预训练。[↗](https://arxiv.org/pdf/2602.15922#page=17)

同一消融中，自回归与双向模型的平均进度均为 50。自回归方案的依据主要是动作更平滑、推理快约 3–4 倍，以及历史缓存方便；这一表格没有证明它在任务分数上优于双向模型。

## 泛化结果要同时看任务定义和指标

论文把运动类型与物体类型的组合用于区分 seen/unseen task，评测环境与训练采集地分开。AgiBot 各 10 个已见、未见任务，每任务 8 次；DROID 各 20 个已见、未见任务，每任务 2 次。以下保留原文的 task progress，避免与完全完成任务的 success rate 混用。

| Evaluation | DreamZero Task Progress (%) | Pretrained π0.5 Task Progress (%) |
|---|---:|---:|
| AgiBot seen tasks | 62.2 | 27.4 |
| AgiBot unseen tasks | 39.5 | 16.3 |
| DROID unseen tasks | 49.0 | 33.0 |

DROID 未见任务的完全成功率则为 DreamZero 22.5%、π0.5 7.5%、GR00T 12.5%，GR00T 的进度为 31%。49% 的平均进度意味着部分步骤已经完成，不能写成约一半任务完整成功。[↗](https://arxiv.org/pdf/2602.15922#page=12)

![Seen task evaluation](../../assets/images/paper-deep-dives/world-models/dreamzero/figure-8-seen-task.png){ width="920" }

*原论文 Figure 8。已见任务仍在新环境中执行，结果同时受场景迁移与技能熟练度影响。*

![Zero-shot generalization](../../assets/images/paper-deep-dives/world-models/dreamzero/figure-9-zero-shot.png){ width="920" }

*原论文 Figure 9。重点看 unseen task 与不同本体的分组，并保留 task progress 与 success 的区别。*

专门微调检查了另一个问题：视频先验在获得任务数据后是否仍有价值。衬衫操作、果盘整理、餐桌清理分别使用约 33、12、40 小时数据，每任务再训练 50K 步并测试 10 次。DreamZero 进度分别为 92.5、96、83，平均 90.5；预训练 π0.5 为 92.5、71、76，平均 79.8。衬衫任务持平，优势集中在另两项，三任务均值不宜扩展为所有精细操作上的优势。[↗](https://arxiv.org/pdf/2602.15922#page=14)

![Posttraining results](../../assets/images/paper-deep-dives/world-models/dreamzero/figure-10-posttraining.png){ width="920" }

## 只有视频的新示范，能补进多少行为知识

跨本体实验使用人类或另一台 YAM 机器人的纯视频，不提供对应动作标签。九个任务共 72 段示范，YAM 视频约 20 分钟、人类视频约 12 分钟；与原数据按 1∶1 混合，再训练 10K 步。平均任务进度由 $38.3\pm7.6$ 提升至人类视频条件的 $54.3\pm10.4$、YAM 视频条件的 $55.4\pm9.5$。[↗](https://arxiv.org/pdf/2602.15922#page=15)

![Cross-embodiment transfer](../../assets/images/paper-deep-dives/world-models/dreamzero/figure-11-cross-embodiment.png){ width="920" }

这个实验支持无动作标签视频可以补充行为信息，因为原有动作接口仍由机器人数据维持。它与“给一台从未学过的机器人看一段视频就能执行”有不同前提。论文另用约 30 分钟、55 条 YAM 轨迹展示新本体适配，涉及 11 个任务，但这部分主要是少量数据适配展示。

## 从 5.7 秒到实时，靠的是完整推理栈

原始生成每个动作块约需 5.7 秒。一个块包含 48 个 30 Hz 动作，覆盖约 1.6 秒执行时间，因此原始版本赶不上持续闭环。作者依次使用双 GPU 并行 CFG、DiT 速度缓存把 16 步减少到 4 步、编译与 CUDA graphs、内核优化，以及 GB200 上的混合精度量化。敏感的 QKV/softmax 等环节保持更高精度，不能把整体描述成无差别的 4 bit 推理。

累计约 38 倍加速是在 **两张 GB200** 上达到的，对应约 150 ms 生成一个动作块，约 7 Hz 的块更新频率。机器人内部动作仍以 30 Hz 执行。这两种频率分别约束感知反馈速度和动作插值精度。[↗](https://arxiv.org/pdf/2602.15922#page=8)

进一步的 DreamZero-Flash 将视频和动作的噪声水平解耦。动作仍均匀采样，视频设置 $t_v=1-\eta,\ \eta\sim\operatorname{Beta}(7,1)$，使训练更多落在视频尚不清晰的状态。由于这里 $t=0$ 为噪声，视频的平均 $t_v=0.125$。这样动作分支学会在不等待高质量完整视频的条件下预测控制。

![Decoupled noise schedules](../../assets/images/paper-deep-dives/world-models/dreamzero/figure-5-decoupled-noise.png){ width="860" }

*原论文 Figure 5。应把分布位置与噪声时间的方向一起读，高噪声视频是这一训练调整的关键。*

餐桌清理中，4 步模型在 350 ms 下得到 $83\pm6.1$ 的进度；直接压成一步降为 $52\pm10.2$，Flash 一步在 150 ms 下恢复到 $74\pm10.1$。Flash 明显缓解一步采样损失，但仍比 4 步低 9 个百分点，属于速度与效果之间的实际折中。[↗](https://arxiv.org/pdf/2602.15922#page=16)

![Failure case](../../assets/images/paper-deep-dives/world-models/dreamzero/figure-16-failure-case.png){ width="920" }

失败案例中，预测视频的错误常与错误动作同时出现，说明联合模型的视觉动态和控制输出可能一起失准。它也提示一个可检查的调试对象：在动作偏离时回看模型预期的视觉后果。但这种相关性尚不足以证明改好视频就一定能修复动作。DreamZero 最具体的贡献，是把视频动态迁移、真实观测回填和能赶上动作执行的推理方案组合成了可运行的策略。
