---
paper_date: 2026-05
paper_title: "VGGT-Ω"
paper_topic: 具身智能 / 3D 几何表征
---

# VGGT-Ω：几何重建怎样变成具身空间表征

!!! info "论文信息"
    **论文题名：** VGGT-Ω。<br>
    **作者：** Jianyuan Wang、Minghao Chen、Shangzhan Zhang、Nikita Karaev、Johannes Schönberger、Patrick Labatut、Piotr Bojanowski、David Novotny、Andrea Vedaldi、Christian Rupprecht。<br>
    **机构：** Visual Geometry Group, University of Oxford；Meta AI。<br>
    **时间 / 主题：** 2026-05；具身智能 / feed-forward 3D reconstruction / VLA spatial representation。<br>
    **arXiv / 官方报告：** arXiv：[2605.15195](https://arxiv.org/abs/2605.15195)；官方材料：[vggt-omega.github.io](https://vggt-omega.github.io/)。<br>
    **GitHub / 项目：** GitHub：[facebookresearch/vggt-omega](https://github.com/facebookresearch/vggt-omega)；Demo / Model：[Hugging Face demo](https://huggingface.co/spaces/facebook/vggt-omega-demo)、[model page](https://huggingface.co/facebook/VGGT-Omega-1B-512)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2605.15195)、[项目页](https://vggt-omega.github.io/)、[官方 GitHub](https://github.com/facebookresearch/vggt-omega)；Checked Date：2026-06-20；Repro Status：Paper / official materials / official code reviewed, independent reproduction not claimed。

## 扩大几何模型，先降低每个训练样本的负担

VGGT-Ω 延续多视图 Transformer 的路线，但把重点放在如何扩大模型和数据。它移除独立点图与跟踪解码头，只直接输出深度和相机；通过几何反投影与特征匹配损失保留相关监督。同时，部分全局注意力改成 scene registers 之间的信息交换，并引入大规模视频标注与自监督训练。[↗](https://arxiv.org/pdf/2605.15195#page=6)

![VGGT-Ω scaling 原论文图](../../assets/images/paper-deep-dives/embodied-ai/vggt-omega/figure-1-scaling.png){ width="760" }

*来源：原论文 Figure 1。分别沿模型规模与数据规模读 point error 曲线；两条轴的实验回答不同问题，不能把所有改善归为参数增加。*

原 VGGT 的多头监督有益，但每个稠密头都保存高分辨率特征，增加训练显存。Ω 的核心取舍是保留训练约束、减少显式输出。规模从 200M 扩展到 10B 后，本文再检验这种减负是否牺牲准确率，以及额外数据能否同时改善静态和动态场景。

## Registers 怎样传递场景信息

输入由 DINOv3 初始化的视觉编码器产生 token，骨干仍交替做图内和跨图注意力。默认将 25% 的 global attention 层换成 register attention：只有各帧的少量 registers 跨帧交互，下一次图内注意力再把聚合后的信息传播回图像 token。其余全局层仍可处理细粒度跨视图对应。

![VGGT-Ω architecture 原论文图](../../assets/images/paper-deep-dives/embodied-ai/vggt-omega/figure-2-architecture.png){ width="920" }

*来源：原论文 Figure 2。先区分图像 token 与 scene registers，再看低成本跨帧通信如何经后续图内层返回图像表示。*

这种修改主要降低计算量。使用 Flash Attention 时，完整注意力矩阵本来就不会显式存入显存，因此把全部全局层换成 register 层，推理峰值显存也不一定大幅减少。稠密解码器则在四分之一分辨率以上用 MLP 加 pixel shuffle 替代较重的高分辨率卷积，输出深度和置信度。保留低分辨率卷积是因为纯 MLP 版本虽然基准分数可用，却会出现块状伪影。[↗](https://arxiv.org/pdf/2605.15195#page=5)

## 没有点图头，怎样继续监督三维几何

总体损失为

$$
\mathcal L=\lambda_{cam}\mathcal L_{cam}+\lambda_{depth}\mathcal L_{depth}
+\lambda_{point}\mathcal L_{point}+\lambda_{match}\mathcal L_{match}.
$$

相机用 L1 回归。深度误差同时包含相对尺度权重、梯度和预测置信度；点图通过预测深度和相机反投影得到，残差为 $e_i=\pi^{-1}(\hat D_i,\hat g_i)-P_i$，因此三维误差仍能反向传到两个输出。

匹配损失直接约束最后一层 token：

$$
\mathcal L_{match}=\mathbb E_{pos}[-\log\sigma(s)]
+\mathbb E_{neg}[-\log(1-\sigma(s))].
$$

$s$ 为归一化特征的余弦相似度，正样本来自相同三维位置，负样本来自不同位置。网络无需输出独立跟踪场，也能学习跨视图对应。动态场景中，深度表示每帧物体的形状位置，相机单独表示观察者运动，避免必须先用所有像素共同拟合刚性点图来恢复相机。[↗](https://arxiv.org/pdf/2605.15195#page=6)

## 数据管线怎样把互联网视频变成几何监督

公开与内部几何数据合计约 3M 序列；另有约 40M 互联网风格视频用于筛选和自监督。稠密监督管线先用 VLM 排除剪辑、模糊、水印和难重建视频，再检测可能运动的物体，把这些区域排除在静态匹配与重建之外。多种匹配器提供对应，VGGT 可在传统初始化失败时给出相机初值，再通过 COLMAP BA、MVS、跨视图一致性及质量分类器筛选。

最后保留约 200K 动态场景和 600K 静态场景的高质量相机与深度标注。这里“动态场景”不意味着动态像素都获得可信 SfM 深度；管线会排除动态区域，其运动监督仍需其他数据源补足。质量比较也只在两种方法共同通过筛选的 Sintel 序列和静态像素上进行，不能把筛选后的准确率当作所有视频的标注成功率。

![VGGT-Ω data quality 原论文图](../../assets/images/paper-deep-dives/embodied-ai/vggt-omega/figure-data-quality.png){ width="820" }

*来源：原论文数据质量对照。阅读时同时关注被接受的几何和被丢弃的区域，高质量监督以保守筛选为代价。*

自监督阶段使用从已监督模型初始化的学生和 EMA 教师。两者看到同一组帧的不同增强，包括外观变化、90° 旋转、patch masking 和帧重排；恢复共同顺序后，对齐多层特征、深度和相机预测。深度与相机头冻结以避免塌缩，教师按

$$
\theta_T\leftarrow m\theta_T+(1-m)\theta_S
$$

更新。完整训练为 160K 监督、50K 自监督、30K 监督 steps，最后一段把扩展表示重新对齐到几何标签。使用 128 张 96GB H100、bfloat16、FSDP 和 gradient checkpointing，训练帧数随机取 1–24，面积约为 $512^2$。[↗](https://arxiv.org/pdf/2605.15195#page=8)

## 静态与动态测试怎样区分规模收益

原主结果每场景随机采十帧。下表保留严格角阈值的相机 AUC@3°，DA3 使用 Giant 版本：

| Method | ETH3D ↑ | DyCheck ↑ | Sintel ↑ | TUM-Dynamic ↑ |
|---|---:|---:|---:|---:|
| MegaSaM | 5.9 | 26.8 | 22.5 | 15.4 |
| DA3 | 46.1 | 32.1 | 16.2 | 20.8 |
| VGGT-Ω 1B | 49.8 | 38.4 | 35.3 | 30.2 |
| VGGT-Ω 10B | 56.3 | 43.7 | 40.0 | 36.4 |

MegaSaM 在 Sintel 比先前前向模型更强，但在 ETH3D 宽基线条件下较弱；Ω 同时改善两类设置。1B 已超过对照，10B 又进一步提高，说明这里既有配方与数据的收益，也有额外容量收益。Sintel 深度 AbsRel 从 DA3 的 0.118 降到 Ω-1B 的 0.097、Ω-10B 的 0.081，与相机结果方向一致。[↗](https://arxiv.org/pdf/2605.15195#page=8)

![VGGT-Ω qualitative comparison to DA3 原论文图](../../assets/images/paper-deep-dives/embodied-ai/vggt-omega/figure-qual-da3.png){ width="920" }

*来源：原论文 Figure 6。左侧看重复雪地纹理下相机是否被错误固定，右侧看大幅相机滚转是否造成塔身重影。*

消融采用较小的统一训练预算，以逐像素对应的三维 point error 衡量，避免无序 Chamfer 被大墙面主导。全局注意力版本误差 0.071，替换 25% 后 0.073；移除点图与匹配监督后为 0.078；保留 VGGT 原多头则为 0.070，但成本更高。替换少量步骤为自监督降到 0.070。各项收益规模不同，结果支持效率与精度之间的明确取舍。[↗](https://arxiv.org/pdf/2605.15195#page=10)

## 推理效率比较中容易被忽略的条件

作者先修正原 VGGT 推理时缓存全部 24 层中间特征的问题，只保留预测头需要的四层，再做效率比较。单张 80GB A100、Flash Attention v2 下，VGGT 与 Ω 都可处理约 1250 帧，DA3 在约 750 帧耗尽显存。模型 patch 大小不同，测试分辨率分别适配为 $518\times336$ 与 $512\times336$。

![VGGT-Ω memory and speed 原论文图](../../assets/images/paper-deep-dives/embodied-ai/vggt-omega/figure-memory-speed.png){ width="860" }

*来源：原论文 Figure 7。叉号为首次显存不足；速度和显存曲线应分开读，不能把更快推理直接解释为同等幅度节省显存。*

DINOv3 的 16 像素 patch 相比 14 像素 patch 减少约四分之一 token，默认 register attention 另外带来约 20–25% 速度收益。极端地替换所有全局层，1000 帧耗时从 240.2 秒变为 11.7 秒，但重建精度下降；这个变体不应与标准模型的主表精度拼成一个性能点。[↗](https://arxiv.org/pdf/2605.15195#page=9)

## Scene tokens 可以怎样接进机器人策略

冻结 Ω，将 registers 作为附加输入拼到 OpenVLA-OFT，按原策略训练协议学习。LIBERO 平均成功率从 97.1% 升至 98.5%，Long 从 94.5% 升至 96.7%。这项实验说明 scene tokens 可作为紧凑几何特征使用，尚不意味着几何模型自身已经是动作策略。

![VGGT-Ω language alignment 原论文图](../../assets/images/paper-deep-dives/embodied-ai/vggt-omega/figure-language-alignment.png){ width="760" }

*来源：原论文 Figure 8。语言 token 只读取 registers，再与冻结 VLM 产生的序列级文本表示做对比对齐，用来检验 registers 是否包含场景语义。*

![VGGT-Ω motion-aware representations 原论文图](../../assets/images/paper-deep-dives/embodied-ai/vggt-omega/figure-motion-aware.png){ width="820" }

*来源：原论文运动相关表示可视化。结合对应实体和运动区域观察特征，而非将颜色差异直接当作可执行动作。*

语言对齐与机器人实验的冻结方式不同：前者微调 Ω，后者冻结 Ω。采用时最值得复用的是后者的模块接口，将少量 scene tokens 接到已有控制网络，控制几何分支的推理与训练成本。本文的规模证据来自完整数据与训练配方，大型权重单独复制并不能替代相同监督质量。
