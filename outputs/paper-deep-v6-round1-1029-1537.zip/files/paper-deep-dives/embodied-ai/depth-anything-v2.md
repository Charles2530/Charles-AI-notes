---
paper_date: 2024-06
paper_title: "Depth Anything V2"
paper_topic: 具身智能
---

# Depth Anything V2：单目深度的数据配方

!!! info "论文信息"
    **论文题名：** Depth Anything V2。<br>
    **作者：** Lihe Yang、Bingyi Kang、Zilong Huang、Zhen Zhao、Xiaogang Xu、Jiashi Feng、Hengshuang Zhao。<br>
    **机构：** 未在公开元数据中稳定解析；以 arXiv/PDF 或官方页 affiliation block 为准。<br>
    **时间 / 主题：** 2024-06；具身智能。<br>
    **arXiv / 官方报告：** arXiv：[2406.09414](https://arxiv.org/abs/2406.09414)；官方材料：[depth-anything-v2.github.io/](https://depth-anything-v2.github.io/)。<br>
    **GitHub / 项目：** GitHub：[github.com/DepthAnything/Depth-Anything-V2](https://github.com/DepthAnything/Depth-Anything-V2)；项目页：[depth-anything-v2.github.io/](https://depth-anything-v2.github.io/)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2406.09414)；[GitHub API / repo](https://github.com/DepthAnything/Depth-Anything-V2)；[官方 / 项目材料](https://depth-anything-v2.github.io/)；Checked Date：2026-06-04；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 从更多场景转向更可靠的几何监督

Depth Anything V2 的主要变化发生在标签来源。V1 已经用大规模真实图像提高了场景覆盖，但模型仍会在透明物体、细杆、复杂边界上继承训练标签的错误。V2 将教师的深度监督完全换成精确合成数据，再让教师给真实图像生成伪标签，用这些真实图像训练可部署的学生。它同时处理两个不同问题：几何标签需要准确，输入图像的分布需要广。[↗](https://arxiv.org/pdf/2406.09414#page=6)

先看下图的细小结构与透明区域。V2 追求的改进是深度图能否忠实表达这些结构，单看一个低分辨率测试集的平均误差未必能捕捉这种变化。

![Depth Anything V2 teaser 原论文图](../../assets/images/paper-deep-dives/embodied-ai/depth-anything-v2/figure-1-teaser.png){ width="920" }

*来源：原论文 Figure 1。*

## 为什么真实深度标签也会成为上限

原文指出真实深度集合的三个问题。首先，立体匹配、SfM 或深度相机产生的标签会漏掉弱纹理、遮挡和细物体；其次，透明或反光表面的“深度”可能对应背景或反射，而非可供接触的表面；最后，为扩大数据集而使用的处理流程会进一步平滑细节。模型即使准确拟合这些标签，也可能在几何上出错。

图 4 应从图像中的细结构和表面材质读起，再对比标注。它把“预测不够锐利”追溯到监督本身，而不只归因于解码器分辨率。

![Real and synthetic depth labels 原论文图](../../assets/images/paper-deep-dives/embodied-ai/depth-anything-v2/figure-4-real-synthetic-labels.png){ width="920" }

*来源：原论文 Figure 4，真实与合成深度标签的质量对照。*

合成场景能直接提供稠密、精确的几何，但输入外观与真实照片有差距。把所有标签换成合成深度后，小模型的真实场景泛化反而会下降。作者比较 BEiT、SAM、SynCLR 和 DINOv2 等预训练编码器，发现 DINOv2-G 在这种训练条件下迁移最可靠，其他系列和较小 DINOv2 模型均容易出现明显错误。结论所针对的是本文的合成到真实深度迁移设置，不是对这些编码器所有下游任务的排名。[↗](https://arxiv.org/pdf/2406.09414#page=5)

![Synthetic-to-real transfer 原论文图](../../assets/images/paper-deep-dives/embodied-ai/depth-anything-v2/figure-5-encoder-transfer.png){ width="920" }

*来源：原论文 Figure 5。优先比较同一真实输入在不同编码器下的预测，关注完整物体的深度关系是否被保留。*

即使 DINOv2-G 也不自动覆盖合成集缺少的人体、天空等分布。图 6 中应关注头部与身体的一致性，以及云层是否被错误地当作近物体。这些失败促成下一步的真实图像学习。

![DINOv2-G synthetic-only failure 原论文图](../../assets/images/paper-deep-dives/embodied-ai/depth-anything-v2/figure-6-synthetic-only-failure.png){ width="920" }

*来源：原论文 Figure 6。加入无标签真实图像后，相应错误得到改善。*

## 三阶段数据路径怎样同时保住细节与泛化

图 7 的每一步使用不同的数据职责。左侧精确合成图像先教会大型教师几何；中间无标签真实图像让教师的知识转换为真实外观上的监督；右侧学生通过这些伪标签学习。教师与学生之间传递的是输出深度图，未强制不同规模的隐藏表示逐维对齐。

![Depth Anything V2 training pipeline 原论文图](../../assets/images/paper-deep-dives/embodied-ai/depth-anything-v2/figure-7-training-pipeline.png){ width="920" }

*来源：原论文 Figure 7，Depth Anything V2 training pipeline。*

教师采用 DINOv2-G，监督数据为五个合成集合的 595K 图像，包括 BlendedMVS、Hypersim、IRS、TartanAir 与 Virtual KITTI 2。教师随后为八个真实图像集合约 62M 图像生成深度。最终学生采用 DINOv2 Small、Base、Large 或 Giant，仍接 DPT 解码器，但训练输入只保留这些伪标签真实图像。

这条路径看似绕了一步，其必要性来自学生的任务变化。小模型直接从有限合成图像学习时，必须同时掌握几何和跨域迁移；有了教师标注的真实图像后，它可以在目标视觉分布中直接学习几何。教师的合成训练则保留了真实标签中缺失的细节标准。参数范围从约 25M 到 1.3B，输出级蒸馏让训练策略适用于很大的师生规模差。[↗](https://arxiv.org/pdf/2406.09414#page=6)

下面的伪标签样例应重点看完整性和边缘，而不只看颜色层次。伪标签的作用不只是便宜，它还改变了真实图像可得到的监督质量。

![Pseudo labels 原论文图](../../assets/images/paper-deep-dives/embodied-ai/depth-anything-v2/figure-17-pseudo-labels.png){ width="820" }

*来源：原论文 Figure 17，教师为真实图像生成的深度伪标签。*

## 损失、训练尺度与学生需要保留的东西

模型仍预测仿射不变逆深度。合成监督使用 scale-and-shift-invariant loss $\mathcal L_{ssi}$ 与 gradient matching loss $\mathcal L_{gm}$，权重比为 1:2。前者约束整体深度关系，后者约束空间变化，使边缘与细结构更清晰。这两个损失沿用 MiDaS；本文改变的是让精确标签真正支持梯度监督，而不是提出一个新的梯度算子。

图 10 固定图像和方法，改变梯度项权重。应观察细杆、轮廓是否随权重增加而更清晰。原文将权重从 0.5 增大到 4.0，最终选 2.0 来平衡数值指标和锐利度。这个实验说明监督精确时显式梯度约束有用；若标签本身已经把细物体抹掉，增大梯度项也无法恢复正确监督。[↗](https://arxiv.org/pdf/2406.09414#page=14)

![Gradient matching loss 原论文图](../../assets/images/paper-deep-dives/embodied-ai/depth-anything-v2/figure-10-gradient-matching-loss.png){ width="820" }

*来源：原论文 Figure 10。*

伪标签分支沿用 V1 的语义特征保持损失，防止深度训练丢掉 DINOv2 的语义信息；每张伪标签图像还忽略损失最大的 10% 区域，降低错误伪标签的影响。这种筛选并不保证剩下的标签全都正确，但避免少量严重错误主导训练。

所有图像将短边缩放至 518 后随机裁为 $518\times518$。教师以 batch size 64 训练 160K iterations，学生以 batch size 192 训练 480K iterations；使用 Adam，编码器与解码器学习率分别为 $5\times10^{-6}$ 和 $5\times10^{-5}$。各数据集直接拼接，不另做数据源平衡。训练成本因此主要在大型教师、62M 次离线标注和学生训练，部署仍为单次编码器加解码器前向。[↗](https://arxiv.org/pdf/2406.09414#page=8)

## 伪标签真的比真实标签好吗

原 Table 6 固定 DIML 的真实图像，分别用原标签和教师伪标签训练，检验标签来源本身的作用。

| Label Source | KITTI AbsRel ↓ | NYU-D AbsRel ↓ | DIODE AbsRel ↓ | DA-2K Acc (%) ↑ |
|---|---:|---:|---:|---:|
| Manual Label | 0.122 | 0.074 | 0.126 | 80.2 |
| Pseudo Label | 0.099 | 0.062 | 0.084 | 89.7 |

图像来源保持一致后，伪标签训练仍有更好的迁移表现。这支持了本文的关键判断：对当前数据而言，原有“真实标签”的质量低于强教师输出，而不只是额外真实图像数量带来收益。[↗](https://arxiv.org/pdf/2406.09414#page=10)

下一项消融检验学生训练是否仍需要合成图像。摘取 Table 5 的 ViT-S：

| Training data | KITTI AbsRel ↓ | NYU-D AbsRel ↓ | DA-2K Acc (%) ↑ |
|---|---:|---:|---:|
| Synthetic only | 0.104 | 0.084 | 89.8 |
| Synthetic + pseudo-labeled real | 0.085 | 0.054 | 94.1 |
| Pseudo-labeled real only | 0.078 | 0.053 | 95.3 |

加入真实图像明显改善迁移；进一步移除学生阶段的合成样本，Small 模型表现继续改善。Large 模型的 DA-2K 则是混合数据 97.3、纯真实伪标签 97.1，并非每个规模、每个指标都在移除合成数据后更好。论文最终选择统一的纯伪标签学生训练路线，是性能和简单性之间的总体决定。[↗](https://arxiv.org/pdf/2406.09414#page=9)

![Add unlabeled real images 原论文图](../../assets/images/paper-deep-dives/embodied-ai/depth-anything-v2/figure-16-add-unlabeled.png){ width="760" }

*来源：原论文 Figure 16。比较同一真实场景在加入无标签图像前后的几何一致性，尤其适合观察小模型的跨域失败。*

## 为什么需要 DA-2K，以及它测到了哪一种改进

V2 在传统测试集上的分数与 V1 接近，有时略差。例如 ViT-L 的 Sintel AbsRel 从 V1 的 0.458 变成 V2 的 0.487，ETH3D 从 0.127 变为 0.131。论文没有用这些结果证明全面数值胜出，而是指出旧基准的噪声、场景单一与低分辨率，可能遮蔽细粒度改善。

为测量更广的相对深度判断，DA-2K 收集 1K 图像、2K 像素对，覆盖室内、室外、非真实图像、透明反光、异常风格、航拍、水下和物体等八类场景。第一条标注路径用 SAM 产生候选关键点，四个深度模型投票，将不一致点对交给人工；第二条路径直接由人寻找困难点对，以补上多个模型共同犯错的情况。每个标签由其他两位标注者复核。[↗](https://arxiv.org/pdf/2406.09414#page=7)

| Method | DA-2K Accuracy (%) ↑ |
|---|---:|
| Marigold | 86.8 |
| Geowizard | 88.1 |
| DepthFM | 85.8 |
| Depth Anything V1 | 88.5 |
| Depth Anything V2 Small | 95.3 |
| Depth Anything V2 Base | 97.0 |
| Depth Anything V2 Large | 97.1 |
| Depth Anything V2 Giant | 97.4 |

这是原 Table 3 的像素对前后关系准确率。Small 相比 V1 高 6.8 个百分点，Giant 相比 Marigold 高 10.6 个百分点，差值按表内百分比相减得到。它支持复杂场景相对几何判断改善，却不能直接证明稠密三维重建误差下降，因为一对点的顺序没有规定两者相距多少米。[↗](https://arxiv.org/pdf/2406.09414#page=8)

透明表面实验提供了更贴近机制的补充证据。在 NTIRE 2024 Transparent Surface Challenge 上，零样本 $\delta_1$ 为 MiDaS 0.259、V1 0.535、V2 0.836；用挑战数据简单微调后，V2 达到 0.912，原表冠军为 0.917。这里的强改善对应合成监督可以提供透明表面几何的论点，测试条件也比“平均深度更好”更具体。[↗](https://arxiv.org/pdf/2406.09414#page=13)

## 在实际视觉系统中怎样采用

如果需要视频编辑中的层次关系、图像条件控制或单图空间理解，相对逆深度模型可直接提供稠密先验。如果需要米制深度，论文展示了用 ZoeDepth 框架微调编码器的路径，并另外使用 Hypersim 和 Virtual KITTI 的合成米制标签训练室内、室外模型，以尽量保住细节。NYU-D 或 KITTI 上较好分数不能自动保证透明物体和细边界仍然可靠，目标任务应据此选择微调数据。

数据规模消融还给出一个可复用判断。保持 480K 训练步数，只使用约 11M SA-1B 图像并多次重复，ViT-S 在 NYU-D 的 $\delta_1$ 为 0.948；使用八个集合的约 62M 图像时为 0.971。但 ETH3D 和 DIODE 的个别指标并未同向改善。扩大多样性改善总体覆盖，不代表每一域都会受益相同。实际自建数据管线应分别检查标签精确性、输入覆盖和目标场景，而不能用总图片数代替这三个判断。

V2 留下的核心方法是把“高质量几何从哪里来”与“现实场景在哪里覆盖”拆开处理。合成图像、巨大教师、真实无标签图像和小型学生分别承担适合自己的职责，最终部署模型才有机会兼顾细节与速度。
