---
paper_date: 2026-02
paper_title: "χ₀: Resource-Aware Robust Manipulation via Taming Distributional Inconsistencies"
paper_topic: 具身智能
---

# kai0：资源受限下的高可靠机器人操作

!!! info "论文信息"
    **论文题名：** χ₀: Resource-Aware Robust Manipulation via Taming Distributional Inconsistencies。<br>
    **作者：** Checheng Yu、Chonghao Sima、Gangcheng Jiang、Hai Zhang、Haoguang Mai、Hongyang Li、Huijie Wang、Jin Chen、Kaiyang Wu、Li Chen、Lirui Zhao、Modi Shi、Ping Luo、Qingwen Bu、Shijia Peng、Tianyu Li、Yibo Yuan。<br>
    **机构：** HKU MMLab / OpenDriveLab 相关团队；以 arXiv/PDF affiliation block 和官方项目页为准。<br>
    **时间 / 主题：** 2026-02；具身智能 / 机器人操作 / VLA 后训练。<br>
    **arXiv / 官方报告：** arXiv：[2602.09021](https://arxiv.org/abs/2602.09021)；项目页：[mmlab.hk/research/kai0](https://mmlab.hk/research/kai0)。<br>
    **GitHub / 模型：** GitHub：[OpenDriveLab/KAI0](https://github.com/OpenDriveLab/KAI0)；Hugging Face：[OpenDriveLab-org/Kai0](https://huggingface.co/OpenDriveLab-org/Kai0)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2602.09021)、[GitHub](https://github.com/OpenDriveLab/KAI0)、[Hugging Face model card](https://huggingface.co/OpenDriveLab-org/Kai0)；Checked Date：2026-06-15；Repro Status：Paper / official repo / official model card reviewed, independent reproduction not claimed。

## 长任务可靠性为什么不能只看模仿损失

χ₀ 针对双臂协作衣物操作。模型可能在示范数据上拟合良好，却在真实执行中因分布覆盖不足、阶段混淆、推理延迟或缺少恢复动作而连续失败。论文分别用 Model Arithmetic、Stage Advantage 和 Train-Deploy Alignment 处理这些问题，主要建立在 π0.5 上进行后训练。[↗](https://arxiv.org/pdf/2602.09021#page=4)

![kai0 pipeline 原论文图](../../assets/images/paper-deep-dives/embodied-ai/kai0/figure-1-pipeline.png){ width="920" }

*来源：原论文系统总览。先看训练示范、策略分布与执行轨迹的区别，再把三个模块对应到它们实际改变的位置。*

任务有三组。A 在 180 秒内把任意初态 T 恤展平并折叠至桌面中央；B 在 180 秒内按衣物类型分别折叠堆放或交接；C 将接收到的衬衫挂稳。每任务约 20 小时专家数据，8 张 A100 全参数 flow-matching 微调。论文报告连续运行 24 小时的系统展示，但它与标准任务成功率、吞吐和重试成本的定量协议不是同一项统计。

## 参数合并怎样利用有限示范的不同模式

将同一任务数据划为互不重叠子集，各自训练策略 $\theta_i$，再在权重空间合成

$$
\theta_{merged}=\sum_{i=1}^{n}\alpha_i\theta_i,
\qquad \alpha_i\ge0,\quad\sum_i\alpha_i=1.
$$

部署只有一个合并后的策略，不需要多个模型同时推理或 router。论文实现以四个子集 checkpoint 为例，比较均匀平均、按验证损失反比加权、梯度优化系数和贪心搜索。

真正关键的是验证集来自哪里。用子集策略执行后收集的 DAgger 恢复轨迹作为 OOD 验证，能选择更适合部署偏离状态的权重；仅在原专家分布中选系数，可能偏好看起来拟合良好却无法恢复的策略。这是将执行分布信息引入模型选择，而非无条件保证任意模型参数可以相加。[↗](https://arxiv.org/pdf/2602.09021#page=4)

![Model Arithmetic 原论文图](../../assets/images/paper-deep-dives/embodied-ai/kai0/figure-2-model-arithmetic.png){ width="760" }

*来源：原论文 Model Arithmetic 图。比较系数选择方式时，要同时区分 in-domain 与 OOD 验证轨迹。*

![Model Arithmetic ablation 原论文图](../../assets/images/paper-deep-dives/embodied-ai/kai0/figure-7-model-arithmetic-ablation.png){ width="840" }

*来源：原论文 MA 消融。看成功率与吞吐是否共同改善，再看 retry cost；更高完成率可能伴随更多恢复尝试。*

原实验中各 MA 变体总体优于最佳单个子模型及全数据训练基线，OOD 验证的标准误更低，贪心策略整体较有效。这个结论限于共享初始化、同一任务互补子集的策略，论文没有验证把任意不同任务策略合并后能保留所有技能。

## 阶段条件为什么比两个独立进度值相减更稳定

长任务可能在多个阶段出现相似画面。衣服平放在桌上既可能是准备折叠，也可能是刚恢复抓取；单帧全局进度值 $V(s)$ 容易产生歧义。用 $V(s')-V(s)$ 估计 advantage 还会叠加两次预测误差。

Stage Advantage 直接看一对状态，预测它们在当前阶段内的进展：

$$
A_{stage}(s,a,g)=f_\theta(s,s'\mid g).
$$

$s'$ 从同一轨迹随机时间跨度取得，$g$ 为人工语义阶段标签。A 分为展平、折叠两阶段；B 分为取衣、展平、折叠、交接四阶段；C 分为取衣、套衣架、悬挂三阶段。双帧比较减少独立值函数相减造成的噪声，阶段条件则减少视觉相似状态的语义冲突。[↗](https://arxiv.org/pdf/2602.09021#page=5)

![Stage Advantage 原论文图](../../assets/images/paper-deep-dives/embodied-ai/kai0/figure-3-stage-advantage.png){ width="820" }

*来源：原论文阶段进度示例。先看滑落、重抓和继续任务的位置，再看累积信号是否能反映恢复过程。*

![Stage Advantage loss curve 原论文图](../../assets/images/paper-deep-dives/embodied-ai/kai0/figure-12-sa-loss-curve.jpeg){ width="760" }

*来源：原论文补充材料中的 Stage Advantage 训练曲线。曲线用于理解训练稳定性，执行能力仍需机器人任务指标验证。*

训练将 advantage 转成二元优劣条件，偏重有效进展。正文用阈值形式说明，附录实现进一步按预测值排序选择顶部 0.3 比例为正样本；这个操作与把未经归一化的绝对数值 0.3 当作所有任务通用阈值不同。对应实验用 Smooth Frame Ratio 与 Mean Squared Temporal Difference 衡量稳定性，再观察 Task A/B 的成功率和重试，避免只凭更平滑的曲线认定控制一定更好。

![Stage Advantage ablation 原论文图](../../assets/images/paper-deep-dives/embodied-ai/kai0/figure-8-stage-advantage-ablation.png){ width="840" }

*来源：原论文 SA 消融。稳定性指标和任务执行指标分列，二者的关联是实验观察，不等于所有平滑信号都有效。*

## 动作块到达时，前几步可能已经过期

异步推理期间机器人仍在执行旧动作块。新块返回后若从第一步执行，会把旧时刻的预测重新施加到已经变化的状态；直接切换又可能造成关节目标跳变。Temporal Chunk-wise Smoothing 先根据已消费索引丢弃新块中过期命令，再在重叠区从旧块逐步过渡到新块：

$$
\tilde a_i=w_i a_i^{old}+(1-w_i)a_i^{new},
\qquad w_i=1-\frac{i}{\max(L-1,1)}.
$$

$L$ 为有效重叠长度。开头更信任正在执行的旧轨迹，末端逐步采用新预测；旧缓冲太短时重复末命令以满足最小重叠，过期量超过新块长度则忽略更新。它是一项执行调度修改，不需要重写动作模型结构。[↗](https://arxiv.org/pdf/2602.09021#page=6)

![Train-Deploy Alignment 原论文图](../../assets/images/paper-deep-dives/embodied-ai/kai0/figure-4-train-deploy-alignment.png){ width="820" }

*来源：原论文 TDA 图。数据增强、恢复示范和缓冲平滑分别改变训练输入、训练状态覆盖和实际执行。*

Heuristic DAgger 则直接把系统初始化到人工设计的失败附近，如抓取偏移或部分滑落，再采集恢复示范，省去等待策略自然失败的时间。水平翻转同时交换左右臂，部分跳帧改变运动速度，扩展时空分布。控制与数据必须一起考虑，否则训练中的平滑动作在异步部署时仍可能被破坏。

## 评价“可靠”需要四个同时看的量

每种衣物十次试验、三种衣物下，论文报告成功率、估计每小时完成任务数、每 episode 重试次数，以及按子任务里程碑给出的部分得分。这里吞吐是按协议估计的任务完成率，重试少也可能是完全不会自救。

![kai0 system efficacy 原论文图](../../assets/images/paper-deep-dives/embodied-ai/kai0/figure-6-system-efficacy.png){ width="840" }

*来源：原论文系统组件对照。优先看完整组合与单模块、双模块的差别，再读成功率和吞吐是否同向。*

Task A 中，SA 对吞吐贡献突出，TDA 更明显提高成功率，却可能增加重试；这符合恢复行为让任务更容易最终完成、同时占用执行时间的机制。Heuristic DAgger 与标准 DAgger 都改善执行，前者减少采集时的等待，但有些设置重试更多。时空增强也不是必然增益，论文指出 Task A 上未见显著提高。[↗](https://arxiv.org/pdf/2602.09021#page=8)

![TDA control ablation 原论文图](../../assets/images/paper-deep-dives/embodied-ai/kai0/figure-11-control-ablation.png){ width="840" }

*来源：原论文控制策略消融。对比应固定数据增强设置，再看 temporal smoothing、temporal ensembling 与 RTC；组合 RTC 和本文平滑还可进一步改善。*

作者称成功率相对 π0.5 提高近 250%，这是相对增幅表述，不应改写为增加 250 个百分点。更有操作意义的证据是模块对吞吐、成功和重试的不同影响，以及失败恢复数据怎样改变部署分布。

## 适合复用的系统改进顺序

χ₀ 适合已经有可用基础策略、但长任务执行容易中断的团队。可先核对动作块时间戳与缓冲消费，再采集失败附近的恢复示范；若阶段混淆明显，再训练阶段条件的双帧进展模型；多个同任务 checkpoint 的参数合并则提供几乎不增加部署计算的改善路径。

其资源描述是每任务约 20 小时数据与 8 张 A100 后训练，依赖既有 π0.5 预训练能力，并非从零获得通用机器人模型的全部成本。论文也未系统检验后训练后的通用能力保留或刚体任务迁移。最有价值的认识是把示范、模型和执行当作三个不同分布，逐项检查可靠性在哪个接口损失。
