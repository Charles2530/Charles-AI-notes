---
paper_date: 2026-03
paper_title: "KVSlimmer: Theoretical Insights and Practical Optimizations for Asymmetric KV Merging"
paper_topic: 高效推理
---

# KVSlimmer：非对称 KV 合并的数学与工程

!!! info "论文信息"
    **论文题名：** KVSlimmer: Theoretical Insights and Practical Optimizations for Asymmetric KV Merging。<br>
    **作者：** Lianjun Liu、Hongli An、Weiqi Yan、Xin Du、Shengchuan Zhang、Huazhong Liu、Yunshan Zhong。<br>
    **机构：** 未在公开元数据中稳定解析；以 arXiv/PDF 或官方页 affiliation block 为准。<br>
    **时间 / 主题：** 2026-03；高效推理。<br>
    **arXiv / 官方报告：** arXiv：[2603.00907](https://arxiv.org/abs/2603.00907)。<br>
    **GitHub / 项目：** GitHub：[github.com/lianjunl13-sudo/KVSlimmer](https://github.com/lianjunl13-sudo/KVSlimmer)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2603.00907)；[GitHub API / repo](https://github.com/lianjunl13-sudo/KVSlimmer)；Checked Date：2026-06-04；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## KV 合并节省显存，也可能把成本转移到压缩过程

KV cache 随上下文增长，长文本推理需要在容量与信息保留之间折中。直接淘汰 token 会丢失未来可能需要的信息；合并则试图把多个历史位置压成更少的表示。KVSlimmer 接续 AsymKV 的非对称思路：相邻 Key 往往较相似，Value 却可能承载不同内容，不宜对两者机械执行相同平均。

前作使用基于梯度的二阶近似来决定 Key 合并权重，额外反向传播又引入时间和峰值显存。KVSlimmer 的工作分为两部分：用投影矩阵的谱解释 Q/K/V 的相似性差异，再把含相邻 Key 耦合项的合并规则简化为只依赖前向变量的计算。[↗](https://arxiv.org/pdf/2603.00907#page=3)

下面的框架图应比较两条压缩路径在哪里需要梯度，以及新方法保留了哪些相邻 Key 之间的交叉项。它的主要工程价值在减少合并本身的代价。

![KVSlimmer vs AsymKV 原论文图](../../assets/images/paper-deep-dives/inference/kvslimmer/figure-1-asymkv-vs-kvslimmer.png)

## 投影的谱决定哪些方向主导相似度

对于相邻 hidden state $x_t,x_{t+1}$，Q、K、V 都来自线性投影 $y=xW$。令 $M=WW^\top$，投影后余弦相似度可写成

$$
\cos(y_t,y_{t+1})=
\frac{x_tMx_{t+1}^\top}{\sqrt{x_tMx_t^\top}\sqrt{x_{t+1}Mx_{t+1}^\top}}.
$$

把 $M$ 分解到特征方向，令特征值为 $\lambda_i$、输入在方向 $i$ 上的分量为 $p_{t,i}$，得到

$$
\cos(y_t,y_{t+1})=
\frac{\sum_i\lambda_i p_{t,i}p_{t+1,i}}
{\sqrt{\sum_i\lambda_i p_{t,i}^2}\sqrt{\sum_i\lambda_i p_{t+1,i}^2}}.
$$

这是一条精确的相似度重写。若能量集中，少数方向在分子分母中占主导；结合相邻输入在这些方向上的对齐，投影后便可能高度相似。仅有“谱集中”并不能脱离输入条件保证任意两个向量同向。

原图同时展示层间相邻 token 相似度、奇异值能量和方向贡献。作者观察到 Q/K 的谱更集中、V 的谱更分散，支持前者更偏匹配、后者保留多样信息的解释。它是所测模型上的结构证据，不应升级为所有层、所有架构都满足的固定规律。

![QKV spectral analysis 原论文图](../../assets/images/paper-deep-dives/inference/kvslimmer/figure-2-qkv-spectral-analysis.png)

## 合并 Key 为什么要考虑交叉项

设一条 query 为 $q$，Key/Value 为 $k_i,v_i$：

$$
e_i=\frac{q^\top k_i}{\sqrt{d_k}},\qquad
\alpha_i=\frac{\exp(e_i)}{\sum_t\exp(e_t)},\qquad
o=\sum_t\alpha_tv_t.
$$

Softmax 的归一化把所有位置连在一起。改变 $k_i$ 不仅改变第 $i$ 个权重，也改变其他位置的权重。因此，同时替换相邻两个 Key 时，忽略它们的二阶交叉项会丢掉一部分耦合信息。

令上游信号 $E=\partial L/\partial o$。由 Softmax 导数可得

$$
\nabla_{k_i}L=\frac{1}{\sqrt{d_k}}\alpha_i[E^\top(v_i-o)]q.
$$

论文沿固定上游信号 $E$ 的局部推导，定义相邻位置 $m,m+1$ 的三个前向向量：

$$
c_{11}=\alpha_m(1-2\alpha_m)(v_m-o),
$$

$$
c_{22}=\alpha_{m+1}(1-2\alpha_{m+1})(v_{m+1}-o),
$$

$$
c_{12}=-\alpha_m\alpha_{m+1}(v_m+v_{m+1}-2o).
$$

相应局部二阶块具有 $h_{ij}=(E^\top c_{ij})qq^\top/d_k$ 的形式。$c_{12}$ 正是相邻 Key 的交叉项，前作对角近似没有保留它。[↗](https://arxiv.org/pdf/2603.00907#page=5)

这里“exact Hessian”的适用对象需要说清。上述求导把 E 当作固定量；若下游损失对 o 也有非零曲率，完整复合损失的 Hessian 还包含 E 随 o 变化产生的项。因此这些式子应理解为文中局部敏感性推导，不能直接宣传为任意网络最终损失的完整精确 Hessian。

## 无反向的最终公式依赖一个可检验近似

记 $g_{ij}=E^\top c_{ij}$。包含交叉项的加权 Key 形式为

$$
k^*=\frac{(g_{11}+g_{12})k_m+(g_{22}+g_{12})k_{m+1}}
{g_{11}+2g_{12}+g_{22}}.
$$

由于局部矩阵 $qq^\top$ 为秩一，方程主要约束沿 q 的分量。原文伪逆给出的投影解与上面 Key 空间中的加权代表，在 q 方向作用一致；不能把不同空间中的向量说成必然逐元素相同。这也限制了“局部最优”向未来所有 query 的外推。

问题尚未解决，因为 $g_{ij}$ 仍需要 E。论文把它拆成范数与夹角：

$$
g_{ij}=\|E\|_2\|c_{ij}\|_2\cos(E,c_{ij}),
$$

并在相邻 Key 同质的区域观察到

$$
\cos(E,c_{11})\approx\cos(E,c_{22})\approx-\cos(E,c_{12}).
$$

下图的每个点对应一个 head 的平均对齐关系。它支持以共同夹角因子近似不同 $g$，但 head 级平均接近线性关系，不代表每个 token、每个 query 都严格相等。

![Head alignment relationships 原论文图](../../assets/images/paper-deep-dives/inference/kvslimmer/figure-3-head-alignment.png)

代入这一近似并约去共同因子，得到实际无梯度规则：

$$
k^*=\frac{(\|c_{11}\|_2-\|c_{12}\|_2)k_m+(\|c_{22}\|_2-\|c_{12}\|_2)k_{m+1}}
{\|c_{11}\|_2-2\|c_{12}\|_2+\|c_{22}\|_2}.
$$

它只需要 attention 权重、Value 与输出，省去反向图。这个表达式中的相减也意味着分母可能较小，权重不必落在普通凸平均区间；数值稳定处理与合并对象的选择仍影响实现。Value 路线沿用前作的相加与基数归一化语义，不能把它误写成把 Key/Value 都简单取均值。[↗](https://arxiv.org/pdf/2603.00907#page=6)

## 质量提升是相对压缩基线，不是普遍超过完整上下文

主实验使用单张 A100 80GB，通常 context budget 2048、chunk size 512，保留最初 32 个 attention sink token。达到预算后批量合并相邻位置，避免每生成一个 token 都执行一次压缩。H2O 另有 recent 2048 加 heavy 512 的设置，比较时需要保留这一预算差别。

| LongBench 模型 | Full Context 平均分 | AsymKV | KVSlimmer |
| --- | ---: | ---: | ---: |
| Llama3.1-8B-Instruct | 48.07 | 43.12 | 44.04 |
| Mistral-7B-Instruct-v0.3 | 46.15 | 40.88 | 41.28 |
| Qwen2-1.5B-Instruct | 34.29 | 31.98 | 32.45 |

Llama 的 0.92 分提升来自 $44.04-43.12$，相对完整上下文仍低 4.03 分。Mistral 上 single-doc、multi-doc 与摘要分项也并非全部超过 AsymKV；平均分改善不能替代逐任务结果。[↗](https://arxiv.org/pdf/2603.00907#page=7)

LongBenchV2 使用更大的 8192 cache budget。Overall 为 30.22，略高于 AsymKV 与 Full Context 的 30.02；但 Hard 为 28.62，低于 AsymKV 的 29.90，Medium 为 25.12，低于 27.44。因此证据支持有条件的质量成本折中，不支持全面无损压缩。

## 性能收益来自省掉压缩中的反向状态

相对 AsymKV，LongBench 各任务 runtime ratio 平均约 0.72，即约减少 28% 时间。图中有的任务接近 1，有的明显更低，说明压缩触发频率、上下文与任务结构影响收益。

![Relative runtime 原论文图](../../assets/images/paper-deep-dives/inference/kvslimmer/figure-4-runtime-relative.png)

解码效率图进一步比较持续生成时的开销。应沿相同生成条件读取曲线，确认合并省下的存储没有被昂贵压缩操作吞掉。

![Decoder efficiency 原论文图](../../assets/images/paper-deep-dives/inference/kvslimmer/figure-5-decoder-efficiency.png)

| Chunk size | AsymKV 峰值显存 | KVSlimmer 峰值显存 |
| --- | ---: | ---: |
| 128 | 20.2 GB | 17.4 GB |
| 512 | 32.9 GB | 23.4 GB |
| 1024 | 57.5 GB | 35.2 GB |
| 1536 | OOM | 51.4 GB |

512 时减少约 $(32.9-23.4)/32.9=28.9\%$，1024 时约 38.8%。这是整体峰值显存相对 AsymKV 的减少，并非 KV 容量统一减少相同比例。[↗](https://arxiv.org/pdf/2603.00907#page=8)

![Peak GPU memory 原论文图](../../assets/images/paper-deep-dives/inference/kvslimmer/figure-6-peak-gpu-memory.png)

采用 KVSlimmer 最需要保留的判断是：更细的压缩数学模型必须同时考虑计算代价。前向可得的局部敏感性代理让相邻合并更实用，但它仍依赖局部同质性、近似对齐与压缩预算；应在自己的长文本任务上同时测质量、触发次数、合并时间与峰值显存。
