---
paper_date: 2023-09
paper_title: "Efficient Memory Management for Large Language Model Serving with PagedAttention"
paper_topic: 高效推理
---

# vLLM / PagedAttention：为什么 KV cache 需要分页管理

!!! info "论文信息"
    **论文题名：** Efficient Memory Management for Large Language Model Serving with PagedAttention。<br>
    **作者：** Woosuk Kwon、Zhuohan Li、Siyuan Zhuang、Ying Sheng、Lianmin Zheng、Cody Hao Yu、Joseph E. Gonzalez、Hao Zhang、Ion Stoica。<br>
    **机构：** 未在公开元数据中稳定解析；以 arXiv/PDF 或官方页 affiliation block 为准。<br>
    **时间 / 主题：** 2023-09；高效推理。<br>
    **arXiv / 官方报告：** arXiv：[2309.06180](https://arxiv.org/abs/2309.06180)；官方材料：[vllm.ai/blog/2023-06-20-vllm](https://vllm.ai/blog/2023-06-20-vllm)。<br>
    **GitHub / 项目：** GitHub：[github.com/vllm-project/vllm](https://github.com/vllm-project/vllm)；项目页：[vllm.ai/blog/2023-06-20-vllm](https://vllm.ai/blog/2023-06-20-vllm)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2309.06180)；[GitHub API / repo](https://github.com/vllm-project/vllm)；[官方 / 项目材料](https://vllm.ai/blog/2023-06-20-vllm)；Checked Date：2026-06-15；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 能批处理，不代表显存能装下足够多请求

LLM 服务的吞吐不只受矩阵乘法速度限制。每个请求在解码时都保留历史 Key/Value，长度不断增长，而未来输出长度事先未知。即使调度器可以在每次迭代加入新请求，KV cache 的容量和碎片仍可能限制 batch。

PagedAttention 的核心是把连续的逻辑 token 序列映射到不连续的固定大小物理 KV 块。attention kernel 根据 block table 读取它们，内存管理器按实际增长分配空间，并允许多个序列共享块。vLLM 再把这个机制与迭代级调度、抢占和分布式执行组合成服务系统。[↗](https://arxiv.org/pdf/2309.06180#page=4)

论文的主张主要是服务吞吐和可容纳请求数提高。它并不要求单条请求的每个 attention kernel 都更快，事实上单 kernel 微基准存在额外开销。

## 先算清 KV cache 为什么足以成为瓶颈

对普通多头 attention，一条长度 T 的序列，FP16 KV 大小近似为

$$
M_{\mathrm{KV}}=2\times T\times L\times d\times2\ \mathrm{bytes},
$$

前一个 2 表示 K 和 V，L 是层数，d 是总 KV hidden width，后一个 2 是每元素字节数。对 GQA/MQA 应改用实际 KV heads 的宽度，而不是直接套模型总 hidden size。

论文的 OPT-13B 例子使用 $L=40,d=5120$，每 token 为 $2\times40\times5120\times2=819200$ bytes，即约 800 KiB；2048 token 约 1.6 GiB。显存还要容纳约 26 GB 的模型权重及运行空间，所以同时容纳的长请求有限。

连续预留引入三类浪费：已经预留但尚未生成的空间、最终不会使用的内部空洞，以及不同请求之间难以拼接使用的外部碎片。请求结束时间和长度不同，使这些问题随着在线流量不断变化。更精细的 batching 能减少等待和 padding，却不能自动消除 KV 分配浪费。

## 分页改变物理位置，不改变 attention 的可见历史

假设块大小 B，每个逻辑块包含 B 个 token 的 K/V。用 $\mathcal B_j$ 表示第 j 块内有效位置，则正常 attention 可以写成块求和：

$$
Z_i=\sum_j\sum_{t\in\mathcal B_j}\exp(q_i^\top k_t/\sqrt d),
$$

$$
o_i=\frac{\sum_j\sum_{t\in\mathcal B_j}\exp(q_i^\top k_t/\sqrt d)v_t}{Z_i}.
$$

这是原文 blockwise attention 的等价展开，强调分母仍覆盖全部可见历史，不能对每块独立 Softmax 后直接相加。物理地址改变不意味着丢弃任何历史 token，也不是滑动窗口或近似注意力。

下图应沿 query 到各个物理块读取的顺序看。K/V 可以散布在显存中，逻辑 token 顺序由表管理；kernel 对这些块计算同样的 attention 结果。

![PagedAttention 原理图](../../assets/images/paper-figures/inference/vllm-pagedattention.png)

这种间接寻址由应用的 CUDA kernel 和 block table 实现，不等同于让操作系统按 CPU 页故障自动管理 GPU tensor。借用的是虚拟内存的逻辑/物理解耦思想。[↗](https://arxiv.org/pdf/2309.06180#page=5)

## Block table 把未知输出长度变成增量分配

例如，一条序列的逻辑块 0、1 可以映射到物理块 7、1。当前最后一块还有空位时，新 token 直接写入；写满后再分配一个可用物理块，如 3，并更新映射。它不需要为后续最大长度寻找一整段连续内存。

下面的图重点看逻辑编号与物理编号不是同一个东西。同一请求的块不连续，不同请求可以交错分布，释放任意完整块后都能重新交给其他请求。

![vLLM logical and physical block table 原论文图](../../assets/images/paper-figures/inference/vllm-logical-physical-block-table.png)

按需分配使一条不共享的活跃序列通常只有最后一块未填满，内部浪费上界约为 $B-1$ 个 token 槽，而不是最大输出长度的全部预留。固定尺寸块也避免了变长连续区间的外部碎片。

小块不总是更好。块太小，更多表项、寻址与较差的并行读取会增加开销；块太大，尾部浪费更多，分支共享也更难。原论文在其负载下选择默认 B=16，属于当时系统实现的经验平衡。

## 共享与 copy-on-write 让多候选生成少复制数据

同一 prompt 生成多个回答时，前缀 KV 相同，可以让不同序列的逻辑块映射到同一物理块。每个块维护引用计数。分支要写入仍被共享的尾块时，先复制该块、调整引用计数，再各自继续写入；已满且不再修改的前缀块持续共享。

Beam search 的共享关系更动态。多个 beam 可能共享 prompt 和一段生成历史，淘汰某条 beam 时只减少相应引用，计数归零才释放。这样避免每轮重排 beam 时复制整段 KV。真正需要 copy-on-write 的通常是发生分叉且仍有空位的块。

服务方预设的公共 prompt 也可以提前计算为共享块。共享要求相同有效前缀及其模型上下文；不能因为某两个 token 字符串相同，就认定它们在不同历史中的 KV 相同。原文讨论的是这种明确的前缀共享机制，不宜把后来的所有自动缓存策略都归入这篇论文。[↗](https://arxiv.org/pdf/2309.06180#page=7)

## 调度器如何处理增长、抢占与多卡

下面的系统总图把控制与计算分开。中央 scheduler 维护请求与块分配，每轮给 GPU worker 发送 token 和 block table；worker 执行模型、读取分页 KV、返回生成 token。完成的请求立即释放块，新请求可以在迭代边界加入。

![vLLM serving system overview](../../assets/images/paper-figures/inference/vllm-system-overview-padded.png)

当物理块耗尽时，原论文使用 FCFS，并优先抢占较晚请求。一次 attention 需要该序列的全部历史，因此对一个序列采用全部或不全部换出的策略；有共享关系的同请求多序列作为一个 group 调度。

恢复有两种路径。Swapping 把 KV 搬到 CPU RAM，之后搬回；recomputation 丢弃缓存但保留 token，把已有前缀和已生成 token 一次性作为 prompt 重算 KV。后者不需要把过去每个 decode step 按原先的顺序慢慢重跑，因此可以比直觉便宜。

张量并行下，各 worker 处理同一批 token，但保存不同 heads 的 KV。逻辑与物理块 ID 映射可以共享，而每张 GPU 的实际块内容是自己的分片。调度器统一广播管理信息，模型层内的 all-reduce 由 worker 按张量并行逻辑执行。[↗](https://arxiv.org/pdf/2309.06180#page=9)

## 实验用“同延迟可承受多少流量”衡量服务能力

论文测试 OPT-13B、66B、175B，硬件分别是单张 A100 40GB、4 张 A100 共 160GB、8 张 A100 80GB 共 640GB。给 KV 的显存约为 12、21、264 GB。任务长度来自 ShareGPT 与 Alpaca，输入输出长短分布不同。

关键指标 normalized latency 是每个请求端到端延迟除以其输出 token 数，再取均值。随着到达率增加，服务容量不足时排队会持续增长，曲线出现陡升。因此比较在相近 normalized latency 下能维持的 request rate，比只测一个无排队请求更能解释服务吞吐。

| 原论文实验 | 观察 | 它支持的判断 |
| --- | --- | --- |
| ShareGPT，单输出 | 相对 Orca Oracle 可承受约 1.7–2.7× 请求率 | 即使知道实际输出长度，连续分配仍会受到管理浪费影响 |
| ShareGPT，单输出 | 相对 Orca Max 约 2.7–8× 请求率 | 最大长度预留对可用 batch 的影响更大 |
| OPT-13B ShareGPT | 同时处理请求数为 Oracle 的约 2.2×、Max 的约 4.3× | 更有效利用 KV 显存是吞吐收益的重要来源 |
| OPT-175B Alpaca | 相对部分 Orca 配置优势缩小 | KV 空间足、序列短时，瓶颈可能转为计算 |

Oracle 在这里表示给予基线未来长度信息的配置，不是理论无限快实现。相对 FasterTransformer 的最高 22 倍请求率，还混合了迭代调度差异，不能全部归因于页表或单个 kernel。[↗](https://arxiv.org/pdf/2309.06180#page=11)

## 共享消融与 kernel 开销构成一组必要反证

在 OPT-13B、Alpaca 上，共享 KV 块带来的显存节省如下，分母是“不共享时所需块数”：

| 生成方式 | 2 个输出 / beam | 4 个输出 / beam | 6 个输出 / beam |
| --- | ---: | ---: | ---: |
| Parallel sampling | 6.09% | 8.53% | 9.79% |
| Beam search | 37.56% | 53.13% | 55.16% |

Beam search 能共享生成中的部分历史，因此比只共享 prompt 的 parallel sampling 收益更大。ShareGPT 的长前缀进一步提高共享机会，不能把 Alpaca 的比例当成所有业务的固定节省。

另一方面，PagedAttention 的单 attention kernel 相对优化过的 FasterTransformer 高出约 20%–26% 延迟，来自 block table、额外分支和变长处理。整体服务仍更快，是因为更大有效 batch 和更少内存浪费超过这部分开销。这一反例是理解系统贡献的关键：单算子微基准与服务吞吐可以朝不同方向变化。[↗](https://arxiv.org/pdf/2309.06180#page=12)

块大小消融中，ShareGPT 的 16–128 表现较好，Alpaca 较短序列更偏好 16 或 32。恢复策略实验则发现小块 swapping 被大量小传输拖慢，重算更有利；中等 16–64 块大小下两种策略端到端表现接近。这些结果解释设计取舍，而不只是给一个默认配置。

PagedAttention 最值得带走的是把 KV cache 从一个必须连续增长的大 tensor，改成受调度器管理、可增量分配和共享的状态。它适合内存容量限制并发的自回归服务；如果工作负载已经计算饱和、请求很短或无共享机会，分页的额外开销就更值得单独测量。部署评估应同时记录请求率、排队延迟、KV 占用与吞吐，而不是仅比较一次 attention 调用。
