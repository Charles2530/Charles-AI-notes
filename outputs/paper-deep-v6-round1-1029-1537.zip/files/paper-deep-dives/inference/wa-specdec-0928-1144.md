---
paper_date: 2026-08
paper_title: "WA-SpecDec: World-Aware Speculative Decoding for Vision-Language-Action Models"
paper_topic: 高效推理
---

# WA-SpecDec：让 Draft 与 Target 共享物理场景表征

!!! info "论文信息"
    **论文题名：** WA-SpecDec: World-Aware Speculative Decoding for Vision-Language-Action Models。<br>
    **作者：** Zikang Wen、Yuning Zhang、Dong Yuan。<br>
    **机构：** The University of Sydney。<br>
    **时间 / 主题：** 2026-08；VLA 投机解码与物理场景表征。<br>
    **版本 / 发表状态：** arXiv:2608.08725v1，2026-08-09；arXiv preprint。<br>
    **arXiv / 官方报告：** [摘要](https://arxiv.org/abs/2608.08725)、[PDF](https://arxiv.org/pdf/2608.08725v1)。<br>
    **GitHub / 项目：** 论文 Section 4.1 写明代码与评测脚本将在接收后发布，本次未确认公开实现。<br>
    **元数据来源与核验口径：** arXiv v1 全文及 Appendix A–C；Checked Date：2026-09-28；Repro Status：Paper Only，未进行独立复现。

## 相同动作偏差，在自由空间和接触附近不是同一回事

离散动作 VLA 可以像语言模型一样先提草稿、再并行验证。为了提高接受长度，Spec-VLA 等方法允许草稿 token 与目标 token 在一定距离内不同。问题是一个固定距离阈值并不了解接触几何：同样的小位移，在空旷位置可能无关紧要，在把手或物体边缘附近却可能导致错过抓取。

WA-SpecDec 保留原有 relaxed acceptance rule，改进生成草稿和验证参考共同使用的观测表示。它从当前图像的 VAE latent 提取空间信息，作为逐 patch 偏置加入 VLA 的视觉 embedding，再通过目标模型 prefill 形成共享状态。目标参考与草稿都建立在这个更新后的条件上。[↗](https://arxiv.org/pdf/2608.08725v1#page=4)

“World-aware”在这里指通过重建型 latent 与预测辅助训练得到的场景表示。部署时不模拟未来视频，也不运行一个额外物理判官来批准动作。

## WAB 插在 prefill 前，所以两边会一起改变

下面的结构图应先跟踪当前图像的两条路线。原视觉骨干产生 VLA patch embedding；冻结 VAE 产生另一组空间 latent，经可训练适配后对齐到同一 patch 网格。两者相加后才进入 LLM，因此它们会影响后续 Q/K/V、hidden state 和动作分布。

![WA-SpecDec 总体结构原图](../../assets/images/paper-deep-dives/inference/wa-specdec/figure-2-architecture.png)

具体地，对当前帧 $I_t$，

$$
Z_t=E_{\mathrm{vae}}(I_t),\qquad
U_t=F_\omega(\phi_{\mathrm{tok}}(Z_t)),
$$

$$
w_t=f_{\mathrm{bias}}(\operatorname{SpatialAlign}(U_t)),\qquad
V_t^{\mathrm{wa}}=V_t+w_t.
$$

$Z_t$ 是二维 latent 网格，$\phi_{\mathrm{tok}}$ 展平并投影，$F_\omega$ 是四层 spatial VideoEncoder；SpatialAlign 把它插值到 VLA patch 分辨率，再投到相同 hidden width。因此 $w_t$ 与 $V_t$ 形状一致，不额外追加目标侧 token。

目标 prefill 为

$$
h_t^{\mathrm{wa}}=\operatorname{Prefill}_{\theta+\Delta\theta}([T_x;V_t^{\mathrm{wa}}]),
$$

$T_x$ 是指令 token，$\Delta\theta$ 是 LoRA 适配。共享条件改变了目标策略本身，不能把它写成“目标模型原封不动，只换了草稿”。不增加 token 数也不等于零开销，VAE 和 WAB 路线仍要计算。[↗](https://arxiv.org/pdf/2608.08725v1#page=5)

## 下一帧监督只在训练中塑造表示

WAB 接受动作交叉熵与辅助未来 latent 监督：

$$
\mathcal L=\mathcal L_{\mathrm{action}}+\lambda\mathcal L_{\mathrm{video}},\qquad\lambda=0.1,
$$

$$
\mathcal L_{\mathrm{video}}=
\frac{\|g_\eta(U_t)-E_{\mathrm{vae}}(I_{t+1})\|_2^2}{H_zW_zC_{\mathrm{vae}}}.
$$

训练数据包含下一帧 $I_{t+1}$，损失在完整 latent 网格上计算，使当前表示保留能预测短期变化的空间信息。VAE 使用冻结的 Wan 2.2 encoder 作为压缩器；并未调用 Wan 视频生成流程。

动作损失则对示范动作 token 最大化条件概率。训练更新 token projector、spatial encoder、bias projector、辅助 head 与 LoRA，保持 VAE 和基础视觉栈冻结。结束后丢弃 $g_\eta$，推理只有当前图像输入，不需要未来帧、VAE decoder 或未来视频采样。

目标训练完成后冻结，用其分布蒸馏草稿：

$$
\mathcal L_{\mathrm{draft}}=
\mathbb E\left[\operatorname{KL}\left(
 p_\theta^{\mathrm{wa}}(\cdot\mid x,I_t,a_{<i})
 \Vert q_\phi(\cdot\mid h_t^{\mathrm{wa}},a_{<i})\right)\right].
$$

这保证草稿学习的是改过条件的目标，而不是让原草稿去追一个突然变化的参考分布。[↗](https://arxiv.org/pdf/2608.08725v1#page=6)

## 验证规则不变，并不意味着恢复精确采样保证

在 token-distance 版本，目标给出

$$
a_i^{\mathrm{wa}}=\arg\max_a p_\theta^{\mathrm{wa}}(a\mid x,I_t,a_{<i}),
$$

再按

$$
\operatorname{Accept}^{\mathrm{wa}}_\rho(\hat a_i)
=\mathbf1[d(\hat a_i,a_i^{\mathrm{wa}})\le\rho]
$$

逐位置接受连续前缀。第一个拒绝位置使用目标 token 替换，之后进入下一轮。验证候选后续位置时，条件前缀包括此前提出的草稿，而不能把所有 token 当成相互独立。

$\rho>0$ 允许与目标不同的动作，故这是任务成功率与速度的折中，不能直接援引 EAGLE 的精确拒绝采样证明。WAB 又通过 LoRA 等训练改变了目标策略，因此也不能声称保持原始 OpenVLA 的输出分布。论文的有效证据是执行成功率、接受长度与延迟，而非无损分布定理。

KERV 和 HeiSD 版本分别加入运动学或混合判据，本文在每一族内部保持相同验证配置，观察 WAB 的增益。它不是将三种规则混成一个新的统一接受公式。

## 主结果需要同时看成功率、速度和失败口径

LIBERO 主实验用 OpenVLA-7B，每 suite 10 个任务、每任务 50 次 rollout。$\rho$ 主配置为 10；树配置最多 50 节点、深度 4、top-8 候选。报告 wall-clock speedup 包含 WAB、draft、target verification 与缓存更新，避免只展示草稿计算时间。

| $\rho=10$，OpenVLA | Spatial 成功率 | Object 成功率 | Goal 成功率 | Long 成功率 |
| --- | ---: | ---: | ---: | ---: |
| 自回归目标 | 82.8% | 69.8% | 78.2% | 57.8% |
| Standard SpecDec | 79.4% | 63.0% | 69.6% | 49.4% |
| WA-SpecDec | 83.0% | 68.8% | 75.8% | 56.2% |

WA 在同一放宽规则下显著减少相对自回归策略的成功率损失，但 Object、Goal、Long 仍未完全恢复。Spatial 的 speedup 从 1.26 倍变成 1.54 倍，Goal 从 1.23 到 1.32 倍，说明成功率改善没有被 WAB 开销完全抵消。[↗](https://arxiv.org/pdf/2608.08725v1#page=7)

NCF 的分母尤其重要。它定义为“失败 rollout 中，末端曾进入目标物或容器附近阈值范围的比例”，默认距离 2 cm；不是所有 rollout 的碰撞率，也不要求失败恰好发生在进入近接触的那一刻。成功率改变会同时改变 NCF 的分母，因此应与整体成功率一起解读。

例如 Goal、$\rho$ 配置中，NCF 从 64.5 降到 46.3；这对应约 28.2% 的相对下降，而非 28.2 个百分点。论文跨表 1 成对设置报告平均相对下降约 18.6%。这个汇总结果不能证明所有减少的失败都由接触误差这一单一因素导致。

## 接受长度曲线比单个容差点更能说明设计

下面的图在固定验证规则家族内改变放宽程度。纵轴成功率、横轴平均接受长度，向上意味着相近长度下更可靠，向右意味着相近成功率下接受更多 token。

![WA-SpecDec 接受长度与成功率曲线原图](../../assets/images/paper-deep-dives/inference/wa-specdec/figure-3-acceptance-success.png)

$\rho$ 扫描的平均成功率为：

| 容差 | Spec-VLA | WA-SpecDec |
| --- | ---: | ---: |
| 5 | 67.7% | 71.3% |
| 10 | 65.4% | 71.0% |
| 15 | 61.2% | 67.0% |
| 20 | 55.1% | 63.5% |

更好表示减缓了放宽阈值带来的退化，却没有消除退化。Long 在 $\rho=20$ 时 WA 也只有 43.0%，低于自回归 57.8%。因此实际选点仍要由任务容错决定，不能用 WAB 为无限增大阈值提供理由。

## 消融把目标策略改善与真正解码加速分开

| 四 suite 平均 | 成功率 | Accepted length | Speedup |
| --- | ---: | ---: | ---: |
| AR target | 72.2% | — | 1.00× |
| WA target-only | 73.5% | — | 0.97× |
| Spec-VLA | 65.4% | 3.59 | 1.20× |
| WAB，去掉 video loss | 69.4% | 4.09 | 1.31× |
| 完整 WA-SpecDec | 71.0% | 4.22 | 1.34× |

只给目标加 WAB 能提高成功率，但速度变慢；真正的加速还依赖投机生成。去掉下一帧辅助损失仍有效，完整训练进一步提高成功率和接受长度。这个表支持表示学习与解码策略互补，不支持把全部收益归于一个更强的 draft。[↗](https://arxiv.org/pdf/2608.08725v1#page=10)

原文主表四个 $\rho$ speedup 的简单算术平均与消融表的汇总 speedup 口径并不相同，因此 1.34 倍应作为该消融表的结果保留，不能由四列直接推导。

## 更强策略与新环境验证了哪些迁移

ActionCodec 在 LIBERO-Goal 的自回归成功率为 95.8%。KERV 规则下，Standard SpecDec 为 91.2%、1.57 倍，WA 为 95.6%、1.72 倍；HeiSD 下则为 88.0%、2.41 倍与 94.2%、2.63 倍。这说明收益并不只出现在较弱 OpenVLA 上，但更快的配置仍可能离自回归成功率更远。

SIMPLER-Env 进一步覆盖 Carrot、Stack、Spoon、Eggplant 和 OpenVLA/UniVLA。UniVLA 表使用 0 到 1 的成功率，不能与前面的百分数直接混排。例如 HeiSD 下 WA 四任务为 0.708、0.250、0.625、0.917，标准投机为 0.542、0.083、0.583、0.750。均有改善，但 Stack 仍明显困难。[↗](https://arxiv.org/pdf/2608.08725v1#page=9)

NCF 阈值从 1 到 4 cm 的检查也保持下降趋势，支持结果不只依赖默认 2 cm。训练、蒸馏与评估总预算约 192 GPU hours，使用 4 张 RTX A6000、约 48 小时；当前证据主要来自仿真，不能直接等同真实接触力学中的执行保证。

WA-SpecDec 的可复用设计是把辅助场景信息放在双方共同依赖的 prefill 之前。这样既改善草稿，也改善它要接近的目标参考，同时保持原动作 token 接口。采用时应把新的目标策略、自回归可靠性、放宽阈值和所有额外计算一起评估，而不是只报告更长的接受前缀。
