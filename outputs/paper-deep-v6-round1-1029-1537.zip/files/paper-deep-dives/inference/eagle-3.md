---
paper_date: 2025-03
paper_title: "EAGLE-3: Scaling up Inference Acceleration of Large Language Models via Training-Time Test"
paper_topic: 高效推理
---

# EAGLE-3：为什么 draft model 要在训练时“见过自己犯错”

!!! info "论文信息"
    **论文题名：** EAGLE-3: Scaling up Inference Acceleration of Large Language Models via Training-Time Test。<br>
    **作者：** Yuhui Li、Fangyun Wei、Chao Zhang、Hongyang Zhang。<br>
    **机构：** Peking University、Microsoft Research、University of Waterloo、Vector Institute。<br>
    **时间 / 主题：** 2025-03；高效推理。<br>
    **arXiv / 官方报告：** arXiv：[2503.01840](https://arxiv.org/abs/2503.01840)。<br>
    **GitHub / 项目：** GitHub：[github.com/SafeAILab/EAGLE](https://github.com/SafeAILab/EAGLE)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2503.01840)；[GitHub API / repo](https://github.com/SafeAILab/EAGLE)；Checked Date：2026-06-15；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 更多数据没有自然带来更快的草稿模型

EAGLE-3 从一个反常观察出发：扩大 EAGLE 的训练数据，推理加速并没有持续明显提高。第一代要求小 head 既预测正确 token，又逼近目标模型指定的顶层 hidden feature；后一个约束未必是提高接受率所必需的，却限制了小模型的表达方式。

作者因而移除特征回归目标，让 head 直接服务于 token 预测。但只删 loss 会产生新的问题：第一步输出不再接近目标特征，第二步把这个自由向量作为输入时，就进入训练没见过的分布。EAGLE-3 用 training-time test 在训练里实际反馈草稿输出，再结合目标模型的低、中、高层特征，解决这一连串依赖。[↗](https://arxiv.org/pdf/2503.01840#page=2)

下面两幅 scaling 图应一起看：横轴是相对 ShareGPT 的数据量，一幅看速度，一幅看接受长度。EAGLE-3 的增长表明新增数据能在该设置下转化为更好的草稿；这不是对无限扩大数据的普遍幂律证明。

![EAGLE 与 EAGLE-3 的 scaling law 原图](../../assets/images/paper-deep-dives/inference/eagle-3/figure-1-scaling-law-eagle.png)

![EAGLE-3 scaling law 原图](../../assets/images/paper-deep-dives/inference/eagle-3/figure-1-scaling-law-eagle3.png)

## 先解除输出约束，再让训练经历真实递归

第一代 EAGLE 的输出 $\hat f$ 同时接受特征回归和 token 分类监督。EAGLE-3 的输出改记为 $a$：它仍是能送进 LM head 的隐藏向量，但不需要等于目标模型某一层的特征。所谓 direct token prediction 指优化目标直接围绕 token，不意味着模型内部完全没有连续表示。

如果训练永远输入真实目标特征，推理却从第二步开始输入自生成 $a$，训练和使用条件就不一致。Training-time test 在训练中执行若干步草稿，把产生的 $a$ 继续反馈给同一个 decoder layer，并在后续 token 目标上学习。它让模型学会处理“真实目标信息加一段自己的输出”这种混合历史。

下面的图按上、中、下三组比较。中间仅删除特征 loss 的方法可以提高第一步接受率，却会损害递归后的表现；底部在训练中加入测试式展开，才把解除约束的好处带到多步草稿。[↗](https://arxiv.org/pdf/2503.01840#page=3)

![Training-time test 原论文图](../../assets/images/paper-deep-dives/inference/eagle-3/figure-3-training-time-test.png)

训练展开还涉及 attention mask。不同原序列位置产生的续写属于不同分支，不能互相看见。论文根据这些依赖调整 mask，并利用后续展开中稀疏的对应关系减少无效注意力计算。这属于训练数据依赖的正确表达，不是单纯把同一份 teacher-forcing 数据重复几次。

## 多层特征融合为什么在此时变得可行

顶层特征紧邻 LM head，强烈服务于下一个 token 的预测。要连续预测更远处的 token，来自不同深度的表示可能提供额外信息。第一代强迫输出拟合某个顶层状态，使输入与输出接口绑定；移除这个约束并训练递归后，EAGLE-3 可以选择更丰富的目标特征。

若目标 hidden size 为 $d$，低、中、高层特征分别是 $l_i,m_i,h_i$，融合可写成

$$
g_i=W_g[l_i;m_i;h_i],\qquad g_i\in\mathbb R^d.
$$

这是对论文 FC 融合操作的记号化表达。三组 $d$ 维特征先拼成 $3d$，再降回 $d$。接着把融合特征与已采样 token 的 embedding 拼接，经另一个 FC 和单层 decoder 产生 $a$，由 LM head 预测下一个 token。

下面的推理流程图从目标模型最近一次 prefill/verification 开始。第一步使用真实融合特征 $g$；尚未通过目标模型验证的新位置没有对应 $g$，于是使用上一草稿步输出 $a$ 替代。已采样 token 仍显式输入，保留 EAGLE 对采样不确定性的处理。

![EAGLE-3 inference pipeline 原论文图](../../assets/images/paper-deep-dives/inference/eagle-3/figure-5-inference-pipeline.png)

因此 EAGLE-3 不是“每草稿一步再读取一次目标中间层”，否则会失去节省目标调用的意义。真实特征在目标模型本来就要运行的阶段采集，草稿内部自行递归；验证完成后再更新接受路径上的状态。[↗](https://arxiv.org/pdf/2503.01840#page=5)

## 树调度和分布保证沿用已有机制

EAGLE-3 与 EAGLE-2 的动态树兼容：用草稿 confidence 的路径乘积选择扩展节点，再从全树重排候选。第三代主要提高草稿模型本身的能力，而第二代负责把有限候选预算用得更有效。

最终验证仍由目标模型完成。标准规则对草稿 token $\hat t$ 以 $\min(1,p(\hat t)/q(\hat t))$ 接受，拒绝后按归一化的正残差 $\max(0,p-q)$ 采样；树形输入要求每个节点只能看到祖先。分布一致性来自这些规则，不来自草稿模型在 benchmark 上接近目标的程度。

训练使用 ShareGPT 约 68K 与 UltraChat 约 464K 条数据，并调用目标模型生成回答；推理模型 DeepSeek-R1-Distill-LLaMA 8B 还使用 OpenThoughts-114k-math。AdamW 学习率为 $5\times10^{-5}$，$\beta=(0.9,0.95)$，梯度裁剪 0.5。约八倍数据既包含规模变化，也伴随目标回答生成等训练设置，采用时应计入离线训练与目标调用成本。[↗](https://arxiv.org/pdf/2503.01840#page=6)

## 消融先检验架构，再看扩大数据的结果

下面是 LLaMA-Instruct 3.1 8B 上的逐步改动。$\tau$ 表示平均接受长度。

| 方法 | MT-bench speedup | MT-bench $\tau$ | GSM8K speedup | GSM8K $\tau$ |
| --- | ---: | ---: | ---: | ---: |
| EAGLE-2 | 3.16× | 4.05 | 3.39× | 4.24 |
| 去掉特征约束的改进 | 3.82× | 5.37 | 3.77× | 5.22 |
| 再融合多层特征，EAGLE-3 | 4.40× | 6.13 | 4.48× | 6.23 |

这组实验支持解除约束后的训练设计和融合特征都有增益。不能把表中“去掉特征约束”理解成前述完全不处理递归分布偏移的失败版本；应与论文整体 training-time test 设计一起理解。[↗](https://arxiv.org/pdf/2503.01840#page=8)

接受率图进一步考察草稿递归深度。$n$-$\alpha$ 是输入已有 $n$ 个自生成状态、且此前 token 被接受的条件下，下一 token 的接受率。越往后越能暴露递归问题，所以第一步准确率不能替代这组检查。

![EAGLE vs EAGLE-3 acceptance rate 原论文图](../../assets/images/paper-deep-dives/inference/eagle-3/figure-7-acceptance-rate.png)

主实验在对话、代码、数学、指令和摘要上报告约 3.0–6.5 倍加速，最高值属于特定模型与任务配置。测试覆盖 Vicuna 13B、LLaMA 3.1 8B、LLaMA 3.3 70B 和蒸馏版 R1 8B，没有覆盖 405B 或 671B 目标模型，因此最高倍数不应直接套到更大模型部署。

## 生产运行时把收益压到更现实的尺度

论文在 SGLang v0.4.4 上由 SGLang 团队评估单张 H100、LLaMA 3.1 8B、MT-bench。这里使用链式草稿，长度 3，没有使用树。batch 1 时，吞吐为：

| SGLang 配置 | Throughput，tokens/s ↑ |
| --- | ---: |
| 无投机解码 | 158.34 |
| EAGLE-2 | 244.10 |
| EAGLE-3 | 373.25 |

因此第三代相对这个已优化基线约为 $373.25/158.34\approx2.36$ 倍，相对 EAGLE-2 约 1.53 倍。它们与较早基线上的最高 6.5 倍不冲突，但测量口径不同。

大 batch 的收益更小，却更能说明新增草稿计算是否值得：

| Batch size | EAGLE 相对无投机吞吐 | EAGLE-3 相对无投机吞吐 |
| --- | ---: | ---: |
| 8 | 1.23× | 1.62× |
| 16 | 1.02× | 1.48× |
| 24 | 0.93× | 1.39× |
| 32 | 0.94× | 1.32× |
| 64 | 0.99× | 1.38× |

随着 batch 增大，目标模型原有的闲置算力减少，验证额外候选不再那么便宜。EAGLE-3 在 batch 64 仍提高 38% 吞吐，支持它在这组生产运行时配置中的价值，但不保证所有并发规模都持续获益。[↗](https://arxiv.org/pdf/2503.01840#page=8)

论文还报告 vLLM 链长不超过 2 的实验，其正文设备描述与表题存在 RTX3090/A100 不一致，因而不能据该表确定跨硬件绝对性能。可明确读出的趋势是第三代在更大 batch 下仍保持较好的相对吞吐；部署选型应以自己硬件和版本的实测为准。

EAGLE-3 的实际启发是让训练目标与最终用途一致：草稿需要生成能被接受的 token，并在递归使用自己的输出时保持稳定，而不必模仿大模型某个指定中间表示。工程采用时则要同时考虑目标特征采集、草稿训练数据、运行时支持与 batch 分布；接受长度提高是必要证据，真正的交付指标仍是目标负载上的延迟和吞吐。
