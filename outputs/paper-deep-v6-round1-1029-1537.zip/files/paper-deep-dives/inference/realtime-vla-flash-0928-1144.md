---
paper_date: 2026-05
paper_title: "Realtime-VLA FLASH: Speculative Inference Framework for Diffusion-based VLAs"
paper_topic: 高效推理
---

# Realtime-VLA FLASH：用并行 Flow 验证减少完整 VLA 重规划

!!! info "论文信息"
    **论文题名：** Realtime-VLA FLASH: Speculative Inference Framework for Diffusion-based VLAs。<br>
    **作者：** Jiahui Niu、Kefan Gu、Yucheng Zhao、Shengwen Liang、Tiancai Wang、Xing Hu、Ying Wang、Huawei Li。<br>
    **机构：** 中科院计算所、国科大、南京大学、Dexmal。<br>
    **时间 / 主题：** 2026-05；连续动作 VLA 的投机推理与运行时优化。<br>
    **版本 / 发表状态：** arXiv:2605.13778v1，2026-05-13；arXiv preprint。<br>
    **arXiv / 官方报告：** [摘要](https://arxiv.org/abs/2605.13778)、[PDF](https://arxiv.org/pdf/2605.13778v1)。<br>
    **GitHub / 项目：** [dexmal/realtime-vla-flash](https://github.com/dexmal/realtime-vla-flash)、[项目页](https://dexmal.github.io/realtime-vla-flash)。<br>
    **元数据来源与核验口径：** arXiv v1 全文、附录及作者仓库 README；Checked Date：2026-09-28；Repro Status：Author Code available，本文未进行独立训练、仿真或真机复现。

## 每次重规划都跑完整 VLA，会让动作追着旧场景走

π0 一类 diffusion/flow VLA 从图像、语言和机器人状态生成未来动作块。执行其中一段后重新观测、再次规划，可以减少模型调用次数，但每次完整规划仍要经过图像编码、VLM prefill 和多步动作去噪。物体移动较快时，等计算完成，先前看到的位置已经过时。

FLASH 的问题是能否让多数重规划走便宜路径，再在需要时回到完整模型。它使用轻量模型直接提出连续动作块，让原 Action Expert 在少量 flow 时刻并行检查；通过的前缀执行，拒绝或进入精细操作阶段时刷新完整路径。[↗](https://arxiv.org/pdf/2605.13778v1#page=4)

这里的 speculative inference 并不是把离散 token 的精确拒绝采样照搬到动作空间。它依赖连续动作的一致性阈值和运行时回退，最终可靠性由任务实验检验。

## 延迟分解决定哪些计算值得跳过

在 RTX 4090D 上，原 Torch π0 完整一次推理约 58.0 ms，其中图像编码 11.3 ms，VLM prefill 26.7 ms，10 步 Action Denoise 20.0 ms。作者的 roofline 分析认为前两部分更偏计算受限，动作去噪则反复读取条件缓存、存在较多未充分利用的计算资源。

于是 flash path 保留当前图像编码，让 draft 看到新观测，但跳过完整 VLM prefill。验证器复用最近一次 full path 产生的视觉语言 prefix KV，并使用最新机器人状态。需要分别记住这三项：图像是新的，机器人状态是新的，验证器的视觉语言缓存可能是旧的。

下面的框架图左侧区分两条路径，右侧展示草稿网络。缓存复用节省了最贵的 prefill，代价则是必须监测旧条件是否仍适用。

![FLASH 双路径框架与 draft 架构原图](../../assets/images/paper-deep-dives/inference/realtime-vla-flash/figure-3-framework.png)

## 约 110M 的草稿 head 并行输出整个动作块

Draft 使用一个 Gemma block，加上线性 action head。当前图像特征与语言组成条件前缀，机器人状态投影到相同 hidden space，后面接 H 个可学习 action queries。每个 query 对应未来一个动作位置，action block 可读取完整条件前缀，因此一次前向产生全部候选，而不是逐动作自回归。

相对约 2.7B 参数的 VLM，这个约 110M 的 head 明显便宜。监督目标为

$$
\mathcal L_{\mathrm{draft}}=\sum_{h=1}^{H}w_h\ell(\hat a^d_{t+h-1},a_{t+h-1}),
$$

其中 $w_h$ 强调近期可执行动作，$\ell$ 为逐步回归损失。附录使用 weighted Smooth L1/Huber、$\beta=1$；前缀采样最长 16 步、衰减系数 0.9，tail weight 0.1，以前 12 个可执行位置的验证 RMS 选择检查点。

实验设置 $H=50$，通常执行最多 12 个动作后重规划。四个 LIBERO suite 分别训练 draft，AdamW 学习率 $2\times10^{-3}$、batch 64、100 epochs，每个 head 约需 4 张 4090D 运行 6 小时。这不是无需训练的运行时补丁。[↗](https://arxiv.org/pdf/2605.13778v1#page=12)

## 给定草稿终点，为什么可以并行检查多个 flow 时刻

原策略从噪声出发，顺序积分速度场

$$
\frac{dA_t^\tau}{d\tau}=v_\theta(A_t^\tau,\tau,o_t),\qquad A_t^0\sim\mathcal N(0,I).
$$

连续去噪的后一步依赖前一步，难以并行。但验证阶段已经有候选终点 $\hat A_t^{(d)}$，可以直接把它与同一份高斯噪声 $\epsilon$ 插值到不同 $\tau$：

$$
\tilde A^\tau=\tau\hat A_t^{(d)}+(1-\tau)\epsilon.
$$

对每个选定时刻，原 Action Expert 给出局部速度，再用剩余区间长度重建终点：

$$
\hat A_t(\tau)=\tilde A^\tau+(1-\tau)v_\theta(\tilde A^\tau,\tau\mid c_t,s_t).
$$

$c_t$ 是最近 full path 的缓存，$s_t$ 为最新状态。不同 $\tau$ 的输入可以独立构造，故能并行执行，省掉 10 次顺序积分。使用共享噪声也避免额外噪声差异干扰这些检查。

下面的验证图先对照 sequential denoise 与 parallel verify：后者比较的是候选诱导路径上局部重建的终点，并没有完整生成一条教师轨迹。右侧拒绝例子表示某些重建与 draft 差异超过阈值。

![FLASH 多时刻并行验证原图](../../assets/images/paper-deep-dives/inference/realtime-vla-flash/figure-4-parallel-verification.png)

## 接受的是连续前缀，夹爪切换另作处理

对时刻 k、动作位置 h，计算位置和旋转通道距离 $d_h^{(k)}$。每个检查时刻的最长通过前缀为

$$
L^{(k)}=\sum_{h=1}^{H}\prod_{j=1}^{h}\mathbf1[d_j^{(k)}\le\delta],
\qquad L=\min_kL^{(k)}.
$$

乘积让任何一次失败都截断后续动作，跨时刻取最小值则要求所有检查共同通过。如果 $L=0$，立即回 full path，刷新缓存与动作。通过较短前缀时，只执行允许的前段，而非接受整个 50 步块。

夹爪开闭具有离散语义，不与位移旋转混在同一个连续距离里。LIBERO 的开闭编码为 -1/+1，标准化后通过零阈值检测切换。任何验证分支在候选块内出现夹爪切换，都触发 phase-aware fallback，因为抓取、释放附近的小偏差更容易造成失败。

LIBERO-10 还加入周期性 full-path refresh。它处理长期累积漂移，夹爪触发处理精细操作阶段，验证失败触发处理当前不一致；三者有不同用途，不能把完整系统结果全部归于单次 flow 验证。[↗](https://arxiv.org/pdf/2605.13778v1#page=8)

## 7.8 ms 是快路径，19.1 ms 才是整任务平均

主实验在单张 RTX 4090D 上运行，每个 LIBERO suite 10 个任务、每任务 50 次试验。

| 方法 | 平均成功率 ↑ | 平均重规划延迟 ↓ | 平均每动作延迟 ↓ | 相对 Torch π0 |
| --- | ---: | ---: | ---: | ---: |
| Torch-π0 | 94.1% | 58.0 ms | 5.0 ms | 1.00× |
| Triton-π0 | 94.2% | 39.7 ms | 3.5 ms | 1.46× |
| FLASH-π0 | 93.4% | 34.9 ms | 3.0 ms | 1.66× |
| FLASH+Triton-π0 | 93.8% | 19.1 ms | 1.9 ms | 3.04× |

优化快路径的 7.8 ms 由当前图像编码 4.7、draft 0.9、verifier 2.2 ms 组成。它不能替代所有重规划的平均，因为任务中仍有完整路径、拒绝与刷新。约 66.8% 轮次走 flash path，接受前缀长度相对 12 步窗口平均约 69.7%，两者共同决定实际吞吐。

$58/19.1\approx3.04$ 是平均重规划加速；$5.0/1.9\approx2.63$ 是平均每动作延迟改善。前缀长度变化使两个口径不同。主结果平均成功率低了 0.3 个百分点，也不应改写成精确无损。[↗](https://arxiv.org/pdf/2605.13778v1#page=8)

## 回退消融解释为什么不能始终走最快路径

LIBERO-10 固定 $K=2,\delta=0.15$ 的比较如下：

| 运行时配置 | 成功率 ↑ | 延迟 ↓ |
| --- | ---: | ---: |
| 仅 flash path | 58.4% | 13.3 ms |
| 每 2 轮 flash 后周期刷新 | 80.6% | 21.0 ms |
| 仅 phase-aware fallback | 66.8% | 17.7 ms |
| phase-aware + 每 2 轮刷新 | 84.6% | 24.1 ms |

最快配置成功率最低。更频繁回 full path 会吃掉一部分速度，却让执行稳定下来。作者把最后一行用于 LIBERO-10 主结果，说明最终方案是完整运行时组合。

验证器自身也有取舍。增加检查时刻、收紧阈值通常减少 flash 使用，但不是每一项成功率都严格单调；附录的严格配置接近完整路径耗时。$K=2,\delta=0.15$ 是结合回退后的选择，不能说它单独就给出最优验证可靠性。

## 真机结果扩展的是同步控制下的可用速度范围

真机使用 UR5、两台 RealSense D435i，对 toy dog 与 hairbrush 做传送带分拣；每对象 200 条示范，LoRA 微调 20K steps，每个速度与对象条件测试 10 次。所有方法采用相同同步循环，没有额外异步隐藏延迟。

| 速度 | 方法 | Toy dog 成功率 | Hairbrush 成功率 |
| --- | --- | ---: | ---: |
| 10 m/min | Triton-π0 | 80% | 40% |
| 10 m/min | FLASH+Triton | 80% | 90% |
| 13 m/min | Triton-π0 | 30% | 10% |
| 13 m/min | FLASH+Triton | 50% | 30% |
| 15 m/min | Triton-π0 | 0% | 0% |
| 15 m/min | FLASH+Triton | 20% | 10% |

15 m/min 下的非零成功对应 2/10 与 1/10，说明可用边界有所扩展，但还不是可靠工业分拣。更慢基线常因过时动作追到物体后方或闭爪太晚而失败，支持减小时延对动态场景的重要性。[↗](https://arxiv.org/pdf/2605.13778v1#page=9)

FLASH 附录明确把终点检查定位为启发式局部一致性。误差还来自速度场近似、缓存条件滞后，以及候选插值路径与真实完整生成路径的差异；通过检查不保证与 full path 轨迹等价。最可复用的是这种多层控制安排：新观测驱动便宜草稿，已有动作模型提供局部检查，关键阶段与周期刷新恢复高保真上下文，并用任务成功率决定可接受的速度折中。
