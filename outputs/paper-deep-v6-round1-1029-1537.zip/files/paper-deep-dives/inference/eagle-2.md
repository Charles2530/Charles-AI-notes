---
paper_date: 2024-06
paper_title: "EAGLE-2: Faster Inference of Language Models with Dynamic Draft Trees"
paper_topic: 高效推理
---

# EAGLE-2：用动态 Draft Tree 加速投机解码

!!! info "论文信息"
    **论文题名：** EAGLE-2: Faster Inference of Language Models with Dynamic Draft Trees。<br>
    **作者：** Yuhui Li、Fangyun Wei、Chao Zhang、Hongyang Zhang。<br>
    **机构：** 未在公开元数据中稳定解析；以 arXiv/PDF 或官方页 affiliation block 为准。<br>
    **时间 / 主题：** 2024-06；高效推理。<br>
    **arXiv / 官方报告：** arXiv：[2406.16858](https://arxiv.org/abs/2406.16858)；官方材料：[huggingface.co/papers/2406.16858](https://huggingface.co/papers/2406.16858)。<br>
    **GitHub / 项目：** GitHub：未找到官方链接；项目页：[huggingface.co/papers/2406.16858](https://huggingface.co/papers/2406.16858)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2406.16858)；[官方 / 项目材料](https://huggingface.co/papers/2406.16858)；Checked Date：2026-06-04；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 同一棵草稿树，为什么会在不同上下文里浪费预算

EAGLE 已经能通过目标模型特征生成高接受率草稿，但它始终按预设树形状分配候选。有些上下文下一 token 几乎确定，应把预算用于往深处走；另一些上下文有多个合理分支，增加宽度可能更有用。固定树无法根据这一差别调整。

EAGLE-2 保留 EAGLE 草稿模型和精确验证规则，把改动集中在树的扩展与筛选。它利用草稿置信度估计候选被接受的可能性，并且考虑整条祖先路径；因此不需要再训练一个专门预测树形状的网络。[↗](https://arxiv.org/pdf/2406.16858#page=4)

下面的温度 1 与温度 0 图是两个独立条件。相同模型在采样更随机时通常更难连续预测；不同温度的倍数不能拼成一个统一排行榜。

![EAGLE-2 speedup temperature 1 原论文图](../../assets/images/paper-deep-dives/inference/eagle-2/figure-1-speedup-temp1.png)

![EAGLE-2 speedup temperature 0 原论文图](../../assets/images/paper-deep-dives/inference/eagle-2/figure-2-speedup-temp0.png)

## 基础接口没变，变的是把哪些草稿交给大模型

EAGLE 的草稿 head 接收 LM head 前的特征和提前一个时间步的 token embedding。它预测下一特征，再经目标 LM head 得到 token 分布。下面的草稿图说明这种内部特征复用与独立小 LLM 的差别。

![EAGLE drafting stage 原论文图](../../assets/images/paper-deep-dives/inference/eagle-2/figure-3a-drafting-stage.png)

验证阶段，目标模型用 tree attention 一次计算多个候选的条件分布。不同分支不可互相看见；接受或拒绝仍服从 speculative sampling 规则。对目标分布 $p$、草稿分布 $q$，接受概率是 $\min(1,p(\hat t)/q(\hat t))$，拒绝后使用归一化的 $\max(0,p-q)$ 残差分布。

![EAGLE verification stage 原论文图](../../assets/images/paper-deep-dives/inference/eagle-2/figure-3b-verification-stage.png)

动态树只改变候选集合及其组织方式，不靠放宽接受规则获得加速。这是“无损”的来源，也解释了为什么草稿预测得不好时主要损失速度，而不是由算法主动牺牲目标模型的分布。

## 两个观察让动态树成为可计算的方案

第一个问题是同一树位置的接受率是否随上下文变化。作者在 Vicuna 7B 与 Alpaca 上测量若干固定位置：整体上较浅、较高概率的节点更容易接受，但同一位置的不同 query 有很大方差。

先看位置示意，再对照散点图。横轴相同位置上的纵向离散程度，才是“不能只按位置分配预算”的证据。

![Draft tree positions 原论文图](../../assets/images/paper-deep-dives/inference/eagle-2/figure-5a-draft-tree-positions.png)

![Acceptance rates by position 原论文图](../../assets/images/paper-deep-dives/inference/eagle-2/figure-5b-acceptance-by-position.png)

第二个问题是能否在调用目标模型之前估计这种差别。实验发现草稿 confidence 与接受率强相关：低于 0.05 的区间平均接受率约 0.04，高于 0.95 的区间约 0.98。下面的校准图支持把它用作廉价调度信号。[↗](https://arxiv.org/pdf/2406.16858#page=4)

![Draft confidence calibration 原论文图](../../assets/images/paper-deep-dives/inference/eagle-2/figure-6-confidence-calibration.png)

这里 confidence 并不在数学上等于接受概率。真实接受还涉及目标分布与草稿分布之比，图中关系是该模型与任务上的经验观察。动态树可以用近似信号来提高效率，最终正确性仍交给精确验证。

## 路径 value 解决“局部很稳、祖先不稳”的问题

一个深层节点只有在祖先路径被接受后才有机会进入结果。假设节点 $t_i$ 的路径上各点接受概率为 $p_j$，作者定义全局 value：

$$
V_i=\prod_{t_j\in\operatorname{Path}(root,t_i)}p_j
\approx\prod_{t_j\in\operatorname{Path}(root,t_i)}c_j,
$$

其中 $c_j$ 是草稿 confidence。路径上的概率应理解为对应前缀条件下的概率；乘积表达连续到达该节点的机会。

例如，作为解释性例子，一个节点自己的 confidence 为 0.95，但到达它之前要经过 confidence 0.2 的分支，路径值只有约 0.19；另一个节点局部只有 0.7、祖先为 0.9，路径值约 0.63。只按局部 confidence 选节点会偏向前者，按 value 则会优先后者。

下面的静态/动态示例用“10+2”展示直觉：加入等号后，某个续写更确定，预算应改变。具体树形是调度结果，而不是另一个语言模型的输出。

![EAGLE vs EAGLE-2 static and dynamic tree 原论文图](../../assets/images/paper-deep-dives/inference/eagle-2/figure-4-static-vs-dynamic-tree.png)

## 扩展与重排分别控制草稿成本和验证成本

扩展阶段只从最新一层选 value 最大的 $k$ 个节点并行继续生成，避免每层全部分支造成指数增长。它控制的是草稿模型下一次 forward 的输入规模。

重排阶段则回看已经生成的所有节点，从全树挑 value 最大的 $m$ 个送给目标模型。不能直接把扩展阶段选中的路径当成最终树，因为某个未继续扩展的浅层候选，可能比深层新节点更值得验证。

由于每个置信度在 0 到 1 之间，子节点 value 不会大于祖先。相等时优先浅层节点，就能使 top-$m$ 结果保持祖先连通。随后把树 flatten 为一维 token 输入，并根据父子关系构造 attention mask，让每个节点只看祖先。

下面的总图上半部分展示局部逐层扩展，下半部分展示全局重排与 mask。两次选择发生在不同候选范围，作用也不同。

![EAGLE-2 dynamic draft tree 原论文图](../../assets/images/paper-deep-dives/inference/eagle-2/figure-7-eagle2-dynamic-tree.png)

论文实现对 7B/8B、13B、70B 目标模型分别使用 60、50、48 个总草稿 token，树深 6，扩展阶段选 10 个节点。模型大小不同，验证额外候选的成本不同，这些预算是实验配置而非通用最佳值。EAGLE-2 复用原 EAGLE head；新目标模型仍需要自己的 head，所谓无需额外训练是相对于已经有合适 EAGLE 草稿权重而言。[↗](https://arxiv.org/pdf/2406.16858#page=11)

## 主表把动态预算的收益与任务差异分开

Vicuna 13B、temperature 0 的同组比较如下。$\tau$ 是每轮平均接受长度，speedup 是相对普通解码的实测时间改善。

| 任务 | EAGLE speedup | EAGLE $\tau$ | EAGLE-2 speedup | EAGLE-2 $\tau$ |
| --- | ---: | ---: | ---: | ---: |
| MT-bench | 3.07× | 3.98 | 4.26× | 4.83 |
| HumanEval | 3.58× | 4.39 | 4.96× | 5.41 |
| GSM8K | 3.08× | 3.97 | 4.22× | 4.79 |
| Alpaca | 3.03× | 3.95 | 4.25× | 4.89 |
| CNN/DM | 2.49× | 3.52 | 3.40× | 4.21 |
| Natural Questions | 2.42× | 3.11 | 3.13× | 3.74 |
| 六任务平均 | 2.95× | 3.82 | 4.04× | 4.65 |

接受长度提高，说明同一草稿模型的候选被组织得更有效；wall-clock 提高则说明收益超过动态构树的额外成本。HumanEval 与 Natural Questions 的差异也提醒我们，投机收益依赖任务。作者将知识问答、摘要上的较弱表现与 SFT 草稿训练数据覆盖联系起来，这是对观察的解释，并非独立控制数据类型的因果消融。[↗](https://arxiv.org/pdf/2406.16858#page=7)

temperature 1 下，Vicuna 13B 的 MT-bench 从 2.32 倍提高到 3.80 倍。不能因为采样条件下仍有收益，就断言任意高温度、任意校准误差下都有同样提升。

## 消融证明两次选择都在发挥作用

| Vicuna 7B，temperature 0 | MT-bench speedup | MT-bench $\tau$ | GSM8K speedup | GSM8K $\tau$ |
| --- | ---: | ---: | ---: | ---: |
| 不用 value，也不重排 | 2.81× | 3.92 | 2.85× | 3.93 |
| 用局部 confidence 替代 value | 3.21× | 4.39 | 2.93× | 3.96 |
| 不做最终重排 | 3.48× | 4.86 | 3.50× | 4.85 |
| 完整 EAGLE-2 | 3.62× | 4.98 | 3.63× | 4.97 |

value 的作用是把祖先路径纳入选择，重排的作用是把浅层未扩展节点重新纳入验证竞争。结果支持二者互补，但贡献大小随任务变化，不能把单个增量当成固定百分比。[↗](https://arxiv.org/pdf/2406.16858#page=8)

工程上最有用的迁移是把草稿预算视为在线决策。应同时测接受长度、草稿耗时、验证耗时和临时缓存占用，而不是只优化 confidence 排序。如果目标模型在大 batch 下已经计算饱和，更多候选可能不再便宜；如果新领域 confidence 校准变差，动态树也可能误分配预算。EAGLE-2 提供了可复用的调度方法，其实际收益仍应在目标服务负载中测量。
