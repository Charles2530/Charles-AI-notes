---
paper_date: 2024-01
paper_title: "EAGLE: Speculative Sampling Requires Rethinking Feature Uncertainty"
paper_topic: 高效推理
---

# EAGLE：为什么 draft 不一定要是一个小模型

!!! info "论文信息"
    **论文题名：** EAGLE: Speculative Sampling Requires Rethinking Feature Uncertainty。<br>
    **作者：** Yuhui Li、Fangyun Wei、Chao Zhang、Hongyang Zhang。<br>
    **机构：** 未在公开元数据中稳定解析；以 arXiv/PDF 或官方页 affiliation block 为准。<br>
    **时间 / 主题：** 2024-01；高效推理。<br>
    **arXiv / 官方报告：** arXiv：[2401.15077](https://arxiv.org/abs/2401.15077)。<br>
    **GitHub / 项目：** GitHub：[github.com/SafeAILab/EAGLE](https://github.com/SafeAILab/EAGLE)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2401.15077)；[GitHub API / repo](https://github.com/SafeAILab/EAGLE)；Checked Date：2026-06-15；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 小草稿模型的困难，不只是参数不够少

自回归解码每生成一个 token 都要调用目标模型。小 batch 下，这常常受到模型参数读取和顺序依赖限制。Speculative sampling 让便宜的草稿模型先走几步，再由目标模型并行验证；收益取决于草稿是否便宜，以及连续多少 token 能被接受。

普通方案用一个独立小语言模型来拟合大模型。EAGLE 改为复用目标模型已经算出的 hidden features，只训练一个较轻的自回归 head。它的关键发现是：沿特征序列预测更容易，但下一步特征还取决于刚刚采样出了哪个 token。把这个采样结果明确输入草稿模型，才能消除不必要的不确定性。[↗](https://arxiv.org/pdf/2401.15077#page=2)

下面的主结果图比较 MT-bench、temperature 0 下的 wall-clock 加速。图中标为 N/A 的普通投机配置包含找不到合适草稿模型或草稿开销过大的情形；不能把 N/A 当成零性能。部分比较方法数字来自各自报告，详细评测还需看论文统一实验设置。

![EAGLE speedup temperature 0 原论文图](../../assets/images/paper-deep-dives/inference/eagle/figure-1-speedup-temp0.png)

## 目标模型的特征提供了什么额外信息

设 token 序列为 $T_{1:j}$，embedding 为 $E$，目标模型在 LM head 前的特征为 $f_j$。正常生成路径是

$$
T_{1:j}\rightarrow E_{1:j}\rightarrow f_j\rightarrow p_{j+1}\rightarrow t_{j+1}.
$$

这里论文称为 second-to-top-layer feature 的量，是 LM head 之前的 hidden state，不应机械理解成 Transformer 倒数第二个 block 的输出。它已经融合上下文，比只给一个小模型离散 token 提供更多目标模型内部信息。

但同一个 $f_j$ 经采样可能产生不同 $t_{j+1}$。继续处理“am”与“always”显然应得到不同的后续状态。如果只给特征序列，不告诉草稿实际选择了哪个 token，模型就不得不对不同未来做平均。

下面的不确定性图应在同一个前缀处分叉阅读：分歧来自采样结果，随后才进入新的特征。EAGLE 把提前一个时间步的 token 序列与特征序列一起输入，使“预测下一状态”成为已知所选 token 条件下的问题。

![Feature uncertainty 原论文图](../../assets/images/paper-deep-dives/inference/eagle/figure-3-feature-uncertainty.png)

## 一层自回归 head 如何连续产生草稿

输入 $F_{1:i}$ 和 $T_{2:i+1}$，token 先经目标模型 embedding，得到与特征同宽的向量。二者在通道维拼接，从 $2d$ 经全连接层降到 $d$，再通过一个 decoder layer 预测 $\hat f_{i+1}$。复用目标模型 LM head，便得到下一个草稿 token 的分布。

$$
\hat f_{i+1}=\operatorname{Draft}(T_{2:i+1},F_{1:i}),\qquad
\hat p_{i+2}=\operatorname{Softmax}(W_{\mathrm{LM}}\hat f_{i+1}).
$$

第一步可以使用目标模型提供的真实特征；后续目标模型尚未验证，便把预测特征和采样 token 反馈到草稿 head。这样保持轻量自回归，而不必每一步重新运行完整目标模型。

下面的流程图先看冻结的 embedding/LM head，再跟随草稿预测出的特征和新 token。下半部分展示树状候选：一次草稿层可以并行扩展多个分支，若某个候选失败，验证仍可考虑同位置的替代分支。

![EAGLE pipeline 原论文图](../../assets/images/paper-deep-dives/inference/eagle/figure-6-pipeline.png)

EAGLE 的树形状预先设定。tree attention 让每个节点只看自己的祖先，避免把互不兼容的候选当成同一条连续文本。目标模型验证后，接受路径上的真实特征会被保存，供下一轮草稿使用。[↗](https://arxiv.org/pdf/2401.15077#page=4)

## 训练同时约束特征与最终 token 分布

第一代草稿 head 的目标由回归和分类两部分组成：

$$
\mathcal L_{\mathrm{reg}}=\operatorname{SmoothL1}(f_{i+1},\hat f_{i+1}),
$$

$$
\mathcal L_{\mathrm{cls}}=\operatorname{CrossEntropy}(p_{i+2},\hat p_{i+2}),\qquad
\mathcal L=\mathcal L_{\mathrm{reg}}+0.1\mathcal L_{\mathrm{cls}}.
$$

回归使预测特征接近目标模型，分类使特征经过 LM head 后产生有用草稿。第二项的标签是目标分布，不只是单个离散 token。论文因两项数值尺度不同而给分类项较小权重。

训练时目标模型冻结，使用约 68K 条 ShareGPT 对话；学习率 $3\times10^{-5}$，AdamW 的 $\beta=(0.9,0.95)$，梯度裁剪 0.5。为模拟递归预测误差，在真实特征上加入 $U(-0.1,0.1)$ 噪声。7B、13B、33B、70B 对应的可训练 head 约为 0.24B、0.37B、0.56B、0.99B；70B 的 head 训练报告使用 4 张 A100 40GB，约 1–2 天。[↗](https://arxiv.org/pdf/2401.15077#page=5)

这个成本与重新预训练一个完整小语言模型不同，但也意味着每个目标模型需要合适的草稿权重。换了目标参数或领域分布后，原 head 的接受率不由架构自动保证。

## 无损来自验证规则，不能由草稿准确率代替

令目标分布为 $p$，草稿分布为 $q$。对草稿采样出的 $\hat t$，标准投机采样的接受概率是

$$
a(\hat t)=\min\left(1,\frac{p(\hat t)}{q(\hat t)}\right).
$$

拒绝后从归一化的正残差分布采样：

$$
p_{\mathrm{res}}(t)=\frac{\max(0,p(t)-q(t))}{\sum_v\max(0,p(v)-q(v))}.
$$

因此，被拒绝的候选不会强行写进最终结果，草稿误差影响速度而不改变理论目标分布。树状版本需要递归执行相应验证与分布更新，并保持祖先可见性；并不是简单选目标模型打分最高的整条树路径。

这个保证适用于论文采用的精确规则。temperature 0 的贪心结果与非零温度下的分布一致性是相关但不同的检查；若实现额外放宽接受条件，就不能继续直接引用同一保证。[↗](https://arxiv.org/pdf/2401.15077#page=3)

## 实验分别检验特征输入、树结构与最终速度

输入消融比较 token、feature 以及加入 shifted token 的配置。下面的图应同时看草稿准确率和速度，而不是只看哪条线更高：更准确但更昂贵的草稿未必更快。论文的结果支持特征复用有帮助，显式输入采样 token 进一步改善预测。

![Feature and shifted-token ablation 原论文图](../../assets/images/paper-deep-dives/inference/eagle/figure-4-draft-input-ablation.png)

树状草稿的实验再问，额外候选是否值得计算。下面的比较显示 tree attention 能把更多候选的潜力转成接受长度与速度；收益仍受树宽、深度和验证成本约束。

![Tree attention speedup 原论文图](../../assets/images/paper-deep-dives/inference/eagle/figure-7-tree-attention-speedup.png)

主实验大多采用 batch 1，覆盖对话、代码、数学和指令任务。MT-bench 的代表结果如下，基线都是普通自回归解码的 1 倍：

| 目标模型 | Temperature 0 加速 | Temperature 1 加速 |
| --- | ---: | ---: |
| Vicuna 7B | 2.90× | 2.13× |
| Vicuna 13B | 3.07× | 2.32× |
| LLaMA2-Chat 13B | 3.03× | 2.68× |
| LLaMA2-Chat 70B | 3.01× | 2.67× |

LLaMA2-Chat 70B 在 HumanEval、GSM8K、Alpaca 的 temperature 0 加速分别为 3.52、3.03、2.97 倍；任务不同，连续接受长度也不同。代码模板较多是作者解释其较高收益的因素，不应据此假定任意代码服务都能达到相同倍数。

理解速度时可以使用一个明确的成本近似：若每轮平均产出 $\tau$ 个有效 token，草稿与验证时间分别为 $T_d,T_v$，普通单步时间为 $T_1$，则加速约为 $\tau T_1/(T_d+T_v)$。这是对执行成本的解释，不是论文承诺的常数。接受长度提高只有超过新增草稿、树验证和缓存成本，才会变成端到端改善。

EAGLE 留下的核心接口是“目标特征 + 已采样 token → 轻量草稿 → 精确验证”。后续 [EAGLE-2](eagle-2.md) 调整同一个 head 的候选预算，[EAGLE-3](eagle-3.md) 再改变训练目标与多步输入。理解第一代时，应把特征信息的收益与验证保证分开，前者决定能快多少，后者决定输出分布是否保持。
