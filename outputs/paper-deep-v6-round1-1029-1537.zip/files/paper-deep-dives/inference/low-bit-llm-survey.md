---
paper_date: 2024-09
paper_title: "A Survey of Low-bit Large Language Models: Basics, Systems, and Algorithms"
paper_topic: 高效推理
---

# Low-bit LLM Survey：低比特大模型从格式到推理系统

!!! info "论文信息"
    **论文题名：** A Survey of Low-bit Large Language Models: Basics, Systems, and Algorithms。<br>
    **作者：** Ruihao Gong、Yifu Ding、Zining Wang、Chengtao Lv、Xingyu Zheng、Jinyang Du、Haotong Qin、Jinyang Guo、Michele Magno、Xianglong Liu。<br>
    **机构：** 未在公开元数据中稳定解析；以 arXiv/PDF 或官方页 affiliation block 为准。<br>
    **时间 / 主题：** 2024-09；高效推理。<br>
    **arXiv / 官方报告：** arXiv：[2409.16694](https://arxiv.org/abs/2409.16694)。<br>
    **GitHub / 项目：** GitHub：未找到官方链接。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2409.16694)；Checked Date：2026-06-15；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 低比特选型要同时回答数值、算法与系统三个问题

同样标为“4-bit”的模型，可能使用均匀整数、浮点、非均匀 codebook 或多个向量码本；有的只压权重，有的连激活和 KV cache 一起压；有的只减少存储，有的能直接调用低比特矩阵乘法。仅比较平均 bit 数，无法预测质量、显存或实际速度。

这篇综述把低比特 LLM 分为数值基础、系统支持、训练和推理算法四个层次。最有用的阅读方式是沿着一个具体部署问题走：要压缩哪个张量，它为何对误差敏感，怎样分配量化精度，最后由哪个 kernel 把压缩兑现为收益。[↗](https://arxiv.org/pdf/2409.16694#page=3)

下面的总图应先看横向分类轴，而不是逐个记算法名。PTQ、QAT、PEFT 说的是何时以及怎样适应量化；weight-only、W&A、KV quantization 说的是作用对象；INT、FP、NF、VQ 又是表示形式。这些维度可以交叉组合。

![Low-bit LLM survey skeleton 原图](../../assets/images/paper-deep-dives/inference/low-bit-llm-survey/figure-1-skeleton.png)

## 量化误差从表示范围和有限格点开始

以均匀仿射量化为例，可把数值过程记为

$$
q=\operatorname{clip}\left(\operatorname{round}(x/s)+z,q_{\min},q_{\max}\right),
\qquad \hat x=s(q-z).
$$

$s$ 为步长，$z$ 为零点，$q$ 是实际保存的低比特码，$\hat x$ 为参与后续高精度计算时恢复的近似值。有限格点带来舍入误差，超出范围时又有截断误差。用极端值决定 s 可以减少截断，却使大多数普通值共享更粗的间隔；这就是 outlier 会影响整组数据的原因。

压缩率还必须计入元数据。若每 g 个权重用一个 b-bit 值和 s-bit scale，忽略其他项时平均存储约为 $b+s/g$ bits/weight；若还有 zero-point、稀疏异常值和索引，需要继续相加。作为解释性计算，4-bit 权重、每 128 个共享 16-bit scale，已是 4.125 bits/weight，而非恰好 4。这个算式说明更细粒度的精度收益为何伴随存储成本。

### 浮点把有限 bits 分给动态范围与有效精度

正规浮点数的基本形式为

$$
x=(-1)^s2^{p-\mathrm{bias}}\left(1+\sum_{i=1}^{m}d_i2^{-i}\right).
$$

指数 bits 决定可表达的数量级，尾数 bits 决定局部间隔。FP16 的 E5M10 与 BF16 的 E8M7 同为 16 bits，但后者动态范围更大、尾数更少；FP8 的 E4M3 与 E5M2 也有类似取舍。是否支持 subnormal、特殊值和何种饱和规则，还取决于具体格式，不能仅用“FP8”确定全部数值行为。

| 表示路线 | 主要机制 | 更需要关注的代价 |
| --- | --- | --- |
| INT | 均匀整数格点加 scale/zero-point | outlier 拉大步长，分组选择影响误差 |
| FP | 指数与尾数分配 | 范围、舍入与硬件格式支持 |
| NF / SF | 按假设分布设计非均匀代表值 | 查表/反量化，以及实际分布是否符合假设 |
| Microscaling | 小块共享缩放、块内低比特表示 | scale 元数据、块大小与硬件布局 |
| Binary / ternary | 极少数可取值 | 表达能力下降和训练适应成本 |
| Vector / additive codebook | 多维权重共同选码本向量 | 码本、索引、重建和专用 kernel |

NF 用正态分布分位数设计代表值，SF 针对更重尾的分布；它们并非对任意权重分布都自动最优。Microscaling 把共同尺度提到块级，例如共享 E8M0 scale，既改善局部表示，也要求系统知道这种分块方式。[↗](https://arxiv.org/pdf/2409.16694#page=3)

## 粒度选择决定谁与谁共用一个 scale

一个 activation 张量通常同时有 token 与 channel 维度。per-tensor 用一个 scale，最简单但受最大异常值影响；per-token 允许不同 token 范围不同；per-channel 处理通道间持久差异；group-wise 在局部子组共享，平衡误差与元数据。

下图应沿 scale 广播方向阅读。同样叫“group size 128”，若沿不同维度分组，数值效果和 kernel 布局都可能不同。写清分组轴比只记录数字更重要。

![Quantization granularity 原图](../../assets/images/paper-deep-dives/inference/low-bit-llm-survey/figure-2-granularity.png)

矩阵乘法中常见的组合是 activation per-token、weight per-output-channel。若 $X_{ik}\approx s_i^XQ^X_{ik}$，$W_{kj}\approx s_j^WQ^W_{kj}$，在对称且尺度不沿归约维变化时，

$$
Y_{ij}\approx s_i^Xs_j^W\sum_kQ^X_{ik}Q^W_{kj}.
$$

scale 可以放到累加结果上应用。若分组跨越 k 维、不同子块有不同 scale，则需要分块处理再合并，系统成本也会变化。更细粒度通常减少局部量化误差，却不保证更高推理吞吐。

### Dynamic 与 static 描述量化参数什么时候确定

静态方案通过校准数据确定 activation range 等参数，部署时直接使用；动态方案在当前输入上计算 scale，更能适应 token 范围变化，但付出在线统计与转换成本。权重通常可以提前量化打包，动态量化主要涉及输入激活等运行时量。

![Dynamic and static quantization 原图](../../assets/images/paper-deep-dives/inference/low-bit-llm-survey/figure-3-dynamic-static.png)

图中的绿色区域是推理阶段，应看哪些操作被搬到离线准备。动态 scale 并不意味着整个算法从不需要校准：它可以与使用校准样本优化权重、旋转或重建误差的 PTQ 方法组合。静态方案也不能仅凭校准集上的低误差保证所有未来域都稳定。[↗](https://arxiv.org/pdf/2409.16694#page=5)

## 小文件只有沿着实际数据通路保持紧凑，才可能变快

GPU 的显存、片上缓存、共享内存和寄存器具有不同容量与带宽。低比特收益来自减少关键通路上传输的 bytes，或调用吞吐更高的低精度计算指令；反量化、scale 应用和特殊布局转换则是新增成本。

下面的层次图应从显存到计算单元跟踪权重和激活。它是系统抽象，不意味着常驻 GPU 的模型每次 decode 都从 CPU 重新加载全部权重。实际瓶颈取决于权重是否常驻、batch、序列长度及 offloading 策略。

![Cache hierarchy data transmission 原图](../../assets/images/paper-deep-dives/inference/low-bit-llm-survey/figure-4-cache-hierarchy.png)

### Weight-only 主要减少权重存储与读取

权重离线量化、紧密打包，运行时按 tile 读取并反量化到矩阵乘法需要的格式。如果解码主要受权重带宽限制，少读的数据可以超过解包成本，即使最后仍用 FP16/BF16 GEMM 也能加速。若提前把整份权重反量化并常驻高精度副本，很多存储与传输收益就会消失。

3、5、6 bit 等非标准位宽可以减少表示成本，却通常需要专门 packing 与解码。框架“能加载”不代表相同硬件上存在高效 kernel。码本方案也可能保存得很小，但在运行时付出额外 lookup 或重建时间。

### Weight-and-activation 还试图减少矩阵乘法成本

W&A 把两侧输入都变成低比特，可以使用相应 INT/FP Tensor Core 或其他低精度指令；同时新增 activation 量化、累加结果转换和 scale 处理。输出累加精度往往更高，因此 W4A4 不意味着中间所有运算都只占 4 bit。

下面的时序图区分离线 packing、weight-only 和 W&A。看加速的箭头之外，也要看新出现的量化与反量化区间，才能解释为什么两种方案在小 batch decode 与较大 prefill 上表现不同。

![Quantization data transmission 原图](../../assets/images/paper-deep-dives/inference/low-bit-llm-survey/figure-5-data-transmission.png)

系统选择应分别测 prefill、decode 和目标 batch 下的吞吐；在一种瓶颈下的倍数，不能直接移到另一种瓶颈。综述列举多种框架和硬件支持，实际部署还需核对格式、group、模型算子和 backend 是否共同匹配。[↗](https://arxiv.org/pdf/2409.16694#page=10)

## KV cache 是运行时不断增长的另一笔账

只量化权重无法解决长上下文、大并发带来的 KV 占用。KV 来自每轮推理的新 token，必须在线量化并保存；attention 使用时再读取或解码。新 token 的量化开销、历史 cache 的带宽与注意力误差，需要一起考虑。

下图展示新旧 K/V 如何更新。图里还画了缓存超限后的 drop，它属于示意的窗口策略，不是量化本身必需的步骤；压低 bits 与淘汰 token 是两种不同的信息损失方式。

![KV cache quantization 原图](../../assets/images/paper-deep-dives/inference/low-bit-llm-survey/figure-6-kv-cache.png)

综述归纳的几条路线可以按所解决的问题理解。KIVI 等工作利用 K/V 不同的分布选择不同量化轴；窗口方案把最新 KV 暂存高精度，凑够一批再量化，减少频繁小操作；混合精度方案保留敏感 token 或通道；其他方案用低秩残差补偿误差。相同平均 bit 数下，这些保留规则可能决定检索、长文本推理是否退化。

评估时不能只看短上下文 perplexity。应明确 prompt 长度、生成长度、cache 是否量化全部层、最近窗口大小、scale 与残差占用，以及最终可增加多少并发。KV bits 降一半不意味着整体显存减半，因为模型权重与其他工作空间仍在。[↗](https://arxiv.org/pdf/2409.16694#page=10)

## 低比特训练、QAT 和量化 LoRA 不是一个训练目标

低比特训练关心训练计算本身的成本。FP16 通常需要高精度主权重与 loss scaling，避免小梯度下溢；BF16 更大的指数范围缓解部分问题，但不会自动消除所有数值误差。FP8 进一步需要针对张量或块的 scale，历史 amax 驱动的 delayed scaling 是综述讨论的实现路线之一。

QAT 则把量化效应放进训练，使参数适应未来低比特推理。很多实现使用 fake quantization 与高精度计算梯度，因而“QAT”不自动意味着训练更快或显存更小。极低比特训练还会保留较高精度的累加、优化器状态等，必须按实际状态逐项核算。

| 综述中的 QAT 代表 | 量化对象与位宽 | 适应方式 |
| --- | --- | --- |
| LLM-QAT | W/A/KV，4 或 8 bit 设置 | 使用教师输出进行蒸馏 |
| BitDistiller | 2/3-bit 权重 | 低比特自蒸馏与非对称截断 |
| EfficientQAT | 2/3/4-bit 权重 | 先块级优化，再优化全网量化参数 |
| BitNet | 1-bit 权重，较高精度激活 | 改变线性层并从头适应训练 |
| BitNet b1.58 | 三值权重，8/16-bit 激活设置 | 从训练阶段适应三值表示 |

这个表比较路线与成本来源，不是同一数据、参数规模和训练预算下的统一效果排名。三值的 $\log_2 3\approx1.585$ bits 是表示的信息量，不等于任意存储布局和硬件都恰好以 1.585 bits 计算。[↗](https://arxiv.org/pdf/2409.16694#page=16)

## QLoRA 的核心是冻结低比特底座，只更新小分支

普通 LoRA 减少可训练参数，却仍需存储大模型底座。量化 LoRA 进一步把冻结 W 压成 $W_q$，前向为

$$
Y=X\operatorname{dequant}(W_q)+XAB.
$$

优化器主要保存 A/B 的梯度与状态，底座以低比特存储。这与训练完整低比特 W 的 QAT 不同；底座计算时可反量化到 BF16 等格式。QLoRA 的 NF4、对 scale 的 double quantization 和相关内存技术，共同支持论文所述单张 48GB GPU 微调 65B 模型的代表案例，但这个案例不能转成任意序列长度和 batch 都可行的保证。

下面三种 LoRA 结构应看哪些参数保留高精度、哪些参与更新，以及最终能否直接合并。QLoRA 类型偏向降低微调内存；QA-LoRA 调整结构以适配量化合并；L4Q 类型把量化器与低秩更新一起纳入训练，保存的状态和部署产物不同。

![Low-bit LoRA structures 原图](../../assets/images/paper-deep-dives/inference/low-bit-llm-survey/figure-7-training.png)

LoftQ、LQ-LoRA 等方法还优化初始化，使低比特底座加低秩分支更好逼近原 W。应区分两个目的：低秩分支可以补量化残差，也可以学习新任务，前者的重建目标不自动替代后者的下游训练目标。[↗](https://arxiv.org/pdf/2409.16694#page=15)

## PTQ 的第一条主线，先改变误差分布再量化

异常值不一定可以直接删除，因为它们可能承载有效信息。等价变换在浮点下保持层输出，重新分配不同张量中的数值范围，让低比特近似更容易。

综述给出的统一式是

$$
Y=XW+B=[(X-\Delta)M^{-1}][MW]+(B+\Delta W).
$$

$\Delta$ 平移分布，$M$ 为可逆变换。浮点恒等不表示量化后也完全相等；设计目标是使变换后的两个乘数更适合量化。还需判断这些变换能否合并进相邻参数，还是会增加在线计算。

![PTQ algorithms overview 原图](../../assets/images/paper-deep-dives/inference/low-bit-llm-survey/figure-8-ptq.png)

### 平移与缩放调节通道范围

平移把偏斜分布移回更适合有限格点的位置，并在 bias 中补偿。下图应沿 $\Delta$ 的来源与可合并位置读，确认输出等价关系完整，而不是只对 activation 减一个常数。

![Shifting transformation 原图](../../assets/images/paper-deep-dives/inference/low-bit-llm-survey/figure-9-outlier.png)

SmoothQuant 取对角缩放，

$$
XW=(X\operatorname{diag}(\Phi)^{-1})(\operatorname{diag}(\Phi)W),
\qquad
\Phi_j=\frac{\max|X_j|^\alpha}{\max|W_j|^{1-\alpha}}.
$$

activation 的极大范围被部分转移到权重，$\alpha$ 控制迁移程度。它并未让误差凭空消失，而是利用两者对量化难度的承受能力不同。AWQ 同样使用 activation 信息寻找重要权重通道与缩放，但主要目标是 weight-only 的质量保留，不能仅因都用了缩放就视为同一算法。

### 旋转把少数异常方向分散到更多维度

对正交 R，$XW=(XR)(R^\top W)$。随机正交/Hadamard 旋转可以把集中异常值分散，QuaRot、QuIP 系列由此构造更利于低比特的表示；SpinQuant 则学习旋转，降低随机选择导致的质量差异。

下面的原图来自综述对旋转路线的组织，应重点区分可合并进权重的 R 与必须在线执行的 R。非线性、RoPE、分头结构等都会限制随意搬移变换，不能把任意旋转穿过全部算子。

![Rotation transformation 原图](../../assets/images/paper-deep-dives/inference/low-bit-llm-survey/figure-11-rotation.png)

这一类方法与重建补偿可以组合，但同时也可能增加在线 Hadamard、layout 转换或新的异常值，最终仍需在部署 kernel 上测量。[↗](https://arxiv.org/pdf/2409.16694#page=20)

## PTQ 的第二条主线，给已经产生的误差找补偿

GPTQ 沿权重列进行量化，并用二阶信息调整尚未量化的部分。若第 i 个权重从 $W_i$ 变成 $Q(W_i)$，综述中的补偿形式为

$$
\delta_R=-\frac{W_i-Q(W_i)}{[H_R^{-1}]_{ii}}(H_R^{-1})_{:,i},
\qquad H_R=2X_RX_R^\top.
$$

这里 Hessian 来自校准激活下的局部重建目标，而非完整大模型任务损失的通用 Hessian。它告诉我们哪些其他权重变化能补偿当前舍入对输出的影响。逐列与批量处理让这种思路可以扩展到大模型，但校准分布、阻尼和数值稳定性仍影响结果。

等价变换与补偿的分工很清楚：前者让输入量化器的数据更友好，后者处理量化后留下的输出误差。没有必要把 SmoothQuant、AWQ、GPTQ 和旋转方案放进互斥的单选框；实际配方可能按张量与后端组合它们。

## 混合精度、低秩、稀疏和码本怎样互补

混合精度把更多 bits 留给敏感位置。敏感单元可以是元素、通道、token、层或 MoE expert。SpQR 等保留少量高精度异常值，LLM.int8() 对异常通道采用不同计算，KV 方法则可能保留初始或近期 token。收益要扣除索引、稀疏存取与多路 kernel 的成本。

低秩补偿用额外矩阵近似量化残差，节省 bits 的同时增加计算；它与 PEFT 使用相似数学工具，却可能优化不同目标。稀疏化删除权重、量化减少剩余权重的精度，两者也不总是独立：幅值大的权重可能因稀疏化而被保留，又恰好让量化范围更难处理，因此联合优化比简单叠加更有意义。

向量/加性量化让多个维度共享一个编码决策。综述写成

$$
\hat W_{i,j}=\sum_{m=1}^{M}C_m d_{ijm},
$$

$C_m$ 是码本，$d_{ijm}$ 为选中某个码字的 one-hot 指示，多个码字相加近似一组权重。AQLM 等路线用这类结构追求极低平均 bits 下的质量，但真实资源还包括 codebook 和索引；专用 kernel 能否高效消费它，比模型文件压缩比更直接决定部署速度。[↗](https://arxiv.org/pdf/2409.16694#page=22)

多模态模型还需区分视觉和语言激活分布，MoE 则涉及 expert 敏感度与路由。把 dense text LLM 的统一配置套到所有模块，可能把误差集中到真正决定任务效果的位置。

## 从综述得到一套可执行的比较口径

这篇综述汇总了不同工作，主要贡献是分类与机制关联，不是重新控制硬件和训练预算后得到统一胜负表。一个方法的代表结果可以解释可行性，但不能与另一篇不同模型、不同 calibration 和不同后端的数字直接排序。

| 当前主要限制 | 优先考察的路线 | 必须一起核算 |
| --- | --- | --- |
| 权重装不下、小 batch decode 带宽不足 | weight-only、合适的 packing/kernel | scale/异常值占用、反量化时间、实际 decode 延迟 |
| prefill 或大 batch 计算成本高 | 有原生支持的 W&A / FP8 等 | 在线量化、累加精度、真实矩阵形状 |
| 长上下文或并发导致 KV 过大 | KV 量化、近期窗口与分层精度 | 长文本质量、缓存写入读取与峰值显存 |
| 微调优化器和底座占用过大 | 量化底座 + PEFT | 激活内存、序列长度、最终 adapter 合并方式 |
| 极低 bits 下 PTQ 质量不足 | QAT、蒸馏、混合精度或码本 | 训练成本、部署格式、下游任务退化 |

质量至少应覆盖困惑度和实际任务能力，长文本、代码、推理与对话不必同步退化。系统至少应报告模型及 KV 真实字节数、校准或训练成本、prefill/decode 分开计时、batch/长度/硬件/后端，以及同配置高精度基线。综述特别把“生产量化模型的成本”和“使用量化模型的效率”分开，这避免用昂贵离线优化换来的质量被描述成免费。[↗](https://arxiv.org/pdf/2409.16694#page=23)

低比特方法最值得保留的判断并非某个固定 bit 数。应先找到当前资源瓶颈，再为敏感张量选择可承受的误差分配，最后让表示、kernel 与运行时匹配。若低比特文件更小却没有让目标请求更快，也没有让原先放不下的工作负载装下，那么部署目标仍未完成。
