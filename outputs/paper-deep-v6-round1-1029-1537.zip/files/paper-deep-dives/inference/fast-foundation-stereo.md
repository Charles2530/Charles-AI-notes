---
paper_date: 2025-12
paper_title: "Fast-FoundationStereo: Real-Time Zero-Shot Stereo Matching"
paper_topic: 高效推理
---

# Fast-FoundationStereo：实时 Zero-Shot 双目匹配

!!! info "论文信息"
    **论文题名：** Fast-FoundationStereo: Real-Time Zero-Shot Stereo Matching。<br>
    **作者：** Bowen Wen、Shaurya Dewan、Stan Birchfield。<br>
    **机构：** NVIDIA。<br>
    **时间 / 主题：** 2025-12；高效推理。<br>
    **arXiv / 官方报告：** arXiv：[2512.11130](https://arxiv.org/abs/2512.11130)；官方材料：[nvlabs.github.io/Fast-FoundationStereo/](https://nvlabs.github.io/Fast-FoundationStereo/)。<br>
    **GitHub / 项目：** GitHub：[github.com/NVlabs/Fast-FoundationStereo](https://github.com/NVlabs/Fast-FoundationStereo)；项目页：[nvlabs.github.io/Fast-FoundationStereo/](https://nvlabs.github.io/Fast-FoundationStereo/)。<br>
    **元数据来源与核验口径：** 来源：[arXiv](https://arxiv.org/abs/2512.11130)；[GitHub API / repo](https://github.com/NVlabs/Fast-FoundationStereo)；[官方 / 项目材料](https://nvlabs.github.io/Fast-FoundationStereo/)；Checked Date：2026-06-04；Repro Status：Paper / official materials reviewed, independent reproduction not claimed。

## 双目基础模型要保住的，是换场景后仍然可靠的匹配

FoundationStereo 一类模型通过单目先验、复杂代价体处理和迭代修正获得较强零样本泛化，但高计算成本限制了实时机器人应用。轻量 stereo 网络虽然快，往往更依赖目标域微调。Fast-FoundationStereo 的目标是压缩前者，同时保留它在陌生场景中的能力。

作者没有给全部模块套同一种压缩方法。特征骨干用蒸馏，代价过滤用块级架构搜索，迭代 refinement 用结构化剪枝；再用大规模真实双目伪标签补充合成训练数据。三种手段分别对应不同瓶颈。[↗](https://arxiv.org/pdf/2512.11130#page=3)

先看定性图中的透明、反光、弱纹理区域。它们是局部外观匹配容易失效的位置，单目先验和全局上下文的价值也最容易体现。但判断压缩损失，还需后面的误差表。

![Fast-FoundationStereo 定性对比原图](../../assets/images/paper-deep-dives/inference/fast-foundation-stereo/figure-1-intro.png)

速度精度图使用同一 NVIDIA 3090；绿色轮廓点额外使用 TensorRT。应把原始模型变化与推理后端加速分开，否则会把编译收益全部算给架构。

![速度与精度权衡原图](../../assets/images/paper-deep-dives/inference/fast-foundation-stereo/figure-2-speed-accuracy.png)

## 三段信息流对应三种压缩选择

输入是校正后的左右图像。骨干提取多尺度特征，再通过相关性与拼接构造四维 cost volume；过滤网络整合空间和视差信息，给出初始 disparity；ConvGRU 反复查询代价特征并修正结果。

下图按这条顺序阅读。若只加速骨干，代价过滤仍可能主导延迟；若只减少 refinement 次数，初始错误又可能来不及修正。本文同时优化三段，并最终端到端训练组装后的模型。

![总体框架原图](../../assets/images/paper-deep-dives/inference/fast-foundation-stereo/figure-3-framework.png)

### 用一个学生骨干接替双模块教师

教师结合 DepthAnything V2 与 side-tuning CNN，前者提供大规模单目先验，后者适应双目任务。学生学习教师在尺度 $i\in\{4,8,16,32\}$ 的 feature pyramid，用 MSE 对齐；通道不一致时加入线性投影。教师冻结，左右图像都进入训练 batch，使学生保留双目输入的统计特征。

这与直接剪小教师的 ViT 不同：蒸馏允许更换整个骨干家族，不必保留原双模块拓扑。下面的图先看边缘与相对深度结构，再比较有无蒸馏时透明区域的结果，观察单目和双目先验是否转移到学生。

![Backbone 蒸馏原图](../../assets/images/paper-deep-dives/inference/fast-foundation-stereo/figure-4-backbone-distillation.png)

### 把组合爆炸拆成可分别训练的候选块

教师代价过滤包含 3D hourglass、Axial-Planar Convolution 和 Disparity Transformer。作者按结构边界划成 $N$ 个块，每块提供多个更快、输入输出维度相同的候选。若 8 块各有 200 个候选，完整组合约 $200^8\approx10^{18}$，逐个训练不可行。

块级蒸馏固定教师前一块的输出 $f_{i-1}$，让候选 $B_i$ 拟合 $\bar B_i(f_{i-1})$；再仅替换该块，测完整模型误差变化 $\Delta m_i$ 与时间变化 $\Delta t_i$。用 one-hot 变量 $e_i$ 选择每块候选，求解

$$
\min_{\{e_i\}}\sum_i(\Delta\mathbf m_i)^\top e_i,
\qquad
\text{s.t. }\sum_i(\Delta\mathbf t_i)^\top e_i\le\Delta\tau.
$$

这是整数线性规划。$\Delta\tau$ 是相对教师的时间预算，目标用各块误差增量之和近似整网误差。它大幅减少候选训练成本，但忽略模块之间非线性相互作用，所以最终组装模型还要端到端训练、验证。[↗](https://arxiv.org/pdf/2512.11130#page=5)

下图直接检验这个代理是否有用：在相同延迟约束下，对比搜索结果与随机组装候选。应沿同一个预算看误差；更紧预算下随机结构更容易严重退化，支持有指导的块组合。

![Cost filtering blockwise search 原图](../../assets/images/paper-deep-dives/inference/fast-foundation-stereo/figure-8-blockwise-search.png)

### 循环模块的剪枝必须闭合维度依赖

ConvGRU 的 $h_{k-1}$ 输入与 $h_k$ 输出会在下一次迭代相接，不能独立剪掉不同通道。预测 disparity 和 upsampling mask 的输出维度固定，读取 cost volume 的 motion encoder 输入也固定。下图中可剪与固定接口的区分，正是结构剪枝能正常循环执行的前提。

![Refinement pruning 原图](../../assets/images/paper-deep-dives/inference/fast-foundation-stereo/figure-5-refinement-pruning.png)

作者通过多次迭代的梯度累积估计一阶 Taylor 重要性，剪去低重要参数后冻结其他模块、重训练 refinement：

$$
\mathcal L=\sum_{k=1}^{K}\gamma^{K-k}\|d_k-\bar d\|_1+
\lambda\sum_{i=1}^{L}\|x_i-\bar x_i\|_2^2,
\qquad\gamma=0.9,\ \lambda=0.1.
$$

第一项监督每次修正的 disparity，越后面的权重越高；第二项对齐师生中间特征。两项共同恢复剪枝后的精度。

![Pruning ratio 原图](../../assets/images/paper-deep-dives/inference/fast-foundation-stereo/figure-9-pruning-ratio.png)

剪枝率图应比较剪后和重训练后的误差，不能仅看删除参数时的即时下降。下面的迭代图则说明模型容量与迭代次数相关：论文主配置选择剪枝率 0.6、8 次 refinement；更强剪枝下，增加迭代也未必能补回容量损失。

![Refinement iterations 原图](../../assets/images/paper-deep-dives/inference/fast-foundation-stereo/figure-12-refinement-iterations.png)

## 140 万真实双目对如何成为可用监督

教师为 Stereo4D 校正图像对预测 disparity，另一个单目深度模型提供独立几何线索。二者使用相同相机参数反投影并计算法线，以逐像素法线余弦相似度生成一致性 mask；一致性不足的样本被丢弃。

选择法线而非直接比较深度，旨在适应真实互联网数据的巨大深度范围，并降低深度尺度差异对筛选的影响。天空单独用开放词汇分割识别，不进入普通几何一致性判断，最终设为零 disparity。视频按 stride 10 采样，得到约 1.4M 双目对。[↗](https://arxiv.org/pdf/2512.11130#page=6)

![Pseudo-labeling pipeline 原图](../../assets/images/paper-deep-dives/inference/fast-foundation-stereo/figure-6-pseudo-labeling.png)

中间样例图应把教师 disparity、法线一致性和筛选 mask 对应起来。它解释哪些区域提供监督；筛选减少错误，却不能使伪标签自动等同于传感器真值。

![Pseudo-labeling intermediate samples 原图](../../assets/images/paper-deep-dives/inference/fast-foundation-stereo/figure-15-pseudo-label-samples.png)

## 速度提高十倍，仍需交代留下了多少误差

主表 runtime 在 Middlebury-Q 上用同一 3090 测量。BP-X 是 disparity 误差超过 X 像素的比例；KITTI D1 同时使用 3 像素和 5% 相对误差阈值，均越低越好。

| 方法 | Middlebury-Q BP-2 ↓ | ETH3D BP-1 ↓ | KITTI-2015 D1 ↓ | Runtime ↓ |
| --- | ---: | ---: | ---: | ---: |
| FoundationStereo | 1.30 | 0.50 | 2.80 | 496 ms |
| MonSter | 3.19 | 0.99 | 3.41 | 336 ms |
| RT-IGEV，同数据训练 | 5.59 | 5.05 | 4.00 | 45 ms |
| Fast-FoundationStereo | 2.12 | 1.22 | 3.25 | 49 ms |
| Fast-FoundationStereo，TensorRT | 同一模型 | 同一模型 | 同一模型 | 21 ms |

$496/49\approx10.1$ 倍是原始推理的比较；21 ms 对应约 47.6 FPS，并包含 TensorRT 后端。精度接近大型教师并不等于所有列都更好，ETH3D 与 Middlebury 的误差明显增加。它的优势是把这一质量成本放进实时模型可用的预算，而非严格保持教师输出。[↗](https://arxiv.org/pdf/2512.11130#page=7)

Booster-Q 的非朗伯表面实验更接近透明、镜面场景：教师 EPE 为 1.13 px，学生 1.54 px，同数据 RT-IGEV 为 4.20 px。这里同时保留了相对实时基线的显著收益，以及相对教师仍存在的差距。

## 消融确认三段优化与数据各自的作用

骨干不蒸馏时，Middlebury-H BP-2 为 2.87、KITTI-2015 D1 为 4.32；MSE 蒸馏后为 2.20、3.25。Cosine 蒸馏在 ETH3D 得到 1.19，略好于 MSE 的 1.22，所以不能说 MSE 在所有数据集都绝对最优。

真实伪标签也能帮助其他实时模型。对本文模型，加入伪标签后 Middlebury-H BP-2 从 2.53 降到 2.20，KITTI-2015 D1 从 3.48 降到 3.25；这说明数据有独立贡献。把基线用相同数据重新训练，则减少了“只是数据更多”的混淆。

最后看延迟分解图，骨干、代价过滤和 refinement 都有实际缩短。分段优化的意义在于避免加速一处后另一个模块立即占满预算。

![Runtime decomposition 原图](../../assets/images/paper-deep-dives/inference/fast-foundation-stereo/figure-10-runtime-detail.png)

这套方法最容易复用的部分是按模块结构选工具：已有成熟替代架构的骨干用蒸馏，组合空间大但接口固定的中间网络用块级搜索，具有明显冗余的循环更新器用保持依赖关系的剪枝。实际接入机器人时，还要在自己的分辨率、视差范围、后端和相机几何下测端到端延迟；论文的 21 ms 并不自动包含图像采集与整个控制系统。
